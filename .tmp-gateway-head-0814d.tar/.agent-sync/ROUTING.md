# Task Routing — AI API Reseller Gateway

Updated for commercial MVP scope: 2026-07-31
Source of truth: `INIT.md` and `.agent-sync/TEAM.md`

## Routing Principles

1. `orchestrator` owns dispatch, dependency ordering, human approval gates, and
   file claims. It never writes product code or merges branches.
2. Architecture or feature work follows this gate sequence:
   `brainstorming` → `architect`/ADR → `writing-plans` → approved plan →
   isolated worktree → test-driven implementation.
3. A new or changed endpoint, webhook, service interface, or event schema must
   pass `api-contract-first` before implementation.
4. A database schema change or backfill must pass `data-migration` with forward,
   rollback, compatibility, and verification plans before implementation.
5. Every code change receives `code-reviewer`; every Go change also receives
   `go-reviewer`; every TypeScript/React change also receives
   `typescript-reviewer`. Add the domain reviewers listed below cumulatively.
6. Any bug, failing test, or unexpected behavior routes to `debugger` and
   `systematic-debugging` before a fix is attempted.
7. Completion claims require fresh evidence through
   `verification-before-completion`; production-readiness also requires the
   applicable security, compliance, performance, AI, database, and
   infrastructure reviews.
8. Independent tasks should run in parallel only when they have no shared
   files, state, schema, or unresolved dependency.

## Task Routing Table

| Task or trigger | Primary agent | Mandatory supporting review / gate |
|---|---|---|
| Project dispatch, checkpoint state, dependency ordering | `orchestrator` | Human approval at specified gates |
| Channel abstraction, routing, failover, health state, ledgers | `architect` | `ai-reviewer`, `security-reviewer`, `performance-profiler`; ADR before implementation |
| Complex feature or release plan | `planner` | `writing-plans`; human approval before execution |
| New feature implementation | `tdd-guide` | `test-driven-development`, `code-reviewer`, language and domain reviewers |
| Go source change | `tdd-guide` | `go-reviewer`, `code-reviewer`, `verification-before-completion` |
| TypeScript/React customer-console or setup-page change | `tdd-guide` | `typescript-reviewer`, `code-reviewer`, accessibility/security checks, `verification-before-completion` |
| API endpoint, Responses compatibility, webhook, SSE contract | `architect` | `api-contract-first`, `ai-reviewer`, `security-reviewer`, `go-reviewer` |
| Upstream model call, mapping, usage/token/cost normalization | `ai-reviewer` | `architect`, `security-reviewer`, `go-reviewer` |
| Authentication, API keys, authorization, secrets, customer input, SSRF | `security-reviewer` | `code-reviewer`, `go-reviewer`, `compliance-reviewer` |
| Quota, rate, concurrency, image limiter, Redis fail-closed behavior | `security-reviewer` | `database-reviewer`, `performance-profiler`, `go-reviewer`, failure-injection tests |
| PostgreSQL schema, query, transaction, index, ledger, migration | `database-reviewer` | `data-migration`, `security-reviewer`, `compliance-reviewer`, `go-reviewer` |
| Subscription, Stripe webhook, renewal, upgrade, top-up, refund | `compliance-reviewer` | `security-reviewer`, `database-reviewer`, `api-contract-first`, idempotency tests |
| Thin customer integration page and Codex setup instructions | `typescript-reviewer` | `security-reviewer`, `ai-reviewer`, customer-isolation E2E tests |
| GDPR, retention, erasure, audit data, privacy controls | `compliance-reviewer` | `security-reviewer`, `database-reviewer`, documented data-flow review |
| Docker, CI/CD, deployment, environment config, production secrets | `infra-reviewer` | `security-reviewer`, `compliance-reviewer`, deployment verification |
| E2E customer flow, direct-API enforcement, failover, billing lifecycle | `e2e-runner` | `security-reviewer` for bypass cases; `ai-reviewer` for wire compatibility |
| Load, latency, p95, concurrency, resource use, failover under load | `performance-profiler` | `performance-audit`, `go-reviewer`; measured baseline and comparison |
| Bug, failed test, race, unexpected response, quota leakage | `debugger` | `systematic-debugging`; add affected domain reviewers after root cause |
| Build, compiler, lint, vet, or static-analysis failure | `build-error-resolver` | `go-reviewer` for Go changes; minimal diff only |
| General code-quality review | `code-reviewer` | `go-reviewer` for Go plus every triggered domain reviewer |
| Documentation, API guide, runbook, deployment or security docs | `doc-updater` | Technical owner review; verify examples against the implemented contract |
| Explicitly approved dead-code or duplicate cleanup | `refactor-cleaner` | `code-reviewer`, `go-reviewer`, full regression verification; no drive-by scope |
| Workflow-gate audit before merge/release | `harness-optimizer` | Confirm real commands and reviewer evidence, not self-reported compliance |
| Production degradation or outage | `orchestrator` | `incident-response`; dispatch `debugger`, `infra-reviewer`, and relevant domain agents |

## Mandatory Review Fan-Out

Apply every matching row; these are cumulative, not alternatives.

| Changed area | Required reviewers |
|---|---|
| Any product code | `code-reviewer` |
| Any `.go` file | `go-reviewer` |
| LLM/upstream channel behavior | `ai-reviewer` |
| API, auth, input, secrets, limiters, network targets, logs | `security-reviewer` |
| SQL, schema, migrations, transactions, Redis/PostgreSQL boundary | `database-reviewer` |
| Customer identity, usage data, payments, audit, third parties | `compliance-reviewer` |
| Docker, CI/CD, environment, deployment | `infra-reviewer` |
| Performance-critical request path or pre-release load behavior | `performance-profiler` |
| Critical end-user/API flow | `e2e-runner` |
| Documentation affected by behavior | `doc-updater` |

## Release Evidence

Before a checkpoint can pass, retain evidence appropriate to its scope:

- Unit and integration tests for success, boundary, rejection, retry, timeout,
  cancellation, malformed input, and dependency-outage cases.
- Race-enabled and concurrent tests for Go state, quotas, limiters, routing, and
  idempotency.
- E2E tests using platform-issued keys through the public API, including
  attempts to bypass UI-layer controls.
- Failure injection for Redis, PostgreSQL, primary upstream, secret resolution,
  streaming pre-commit, and webhook replay.
- Load/stress measurements at exact tier caps and above-cap rejection, plus
  rapid sequential image calls and concurrent upstream failover.
- Secret, dependency, static, input, authorization, SSRF, injection, log
  leakage, and response leakage checks.
- Cost/accounting reconciliation against known token counts and integer-unit
  calculations.
- Migration forward/rollback verification when durable schema changes exist.
- Fresh `verification-before-completion` output and all triggered specialist
  reviews.

## File Claims

All file paths must be normalized relative to the repository root. Claim only
source files; do not claim documentation, configuration, or test fixtures.

| File | Agent | Task | Status |
|---|---|---|---|
| (empty — populated at dispatch time) | | | |
