# Active Team — AI API Reseller Gateway

Updated for commercial MVP scope: 2026-07-31

Source: `INIT.md`

Active agents: 19
Inactive agents: 7

This is a project-specific logical roster. Inactive roles must not be
dispatched. No files were removed from the centrally installed A Team plugin
because this initialization was explicitly limited to project metadata.

## Active Agents

- `ai-reviewer`: Required for OpenAI-compatible Responses API behavior,
  upstream LLM calls, model mapping, token/cost handling, and AI-specific
  failure modes.
- `architect`: Required for the channel abstraction, failover commitment
  boundary, health state machine, ledgers, and other architectural decisions.
- `build-error-resolver`: Retained for minimal, scoped resolution of build,
  compiler, and static-analysis failures.
- `code-reviewer`: Mandatory after every product-code change.
- `compliance-reviewer`: Required for GDPR, PCI-DSS, authentication, customer
  usage data, audit logs, payments, and third-party integrations.
- `database-reviewer`: Required for PostgreSQL schema, migrations, ledger
  integrity, query behavior, locking, indexes, and Redis interaction boundaries.
- `debugger`: Mandatory for bugs, failed tests, or unexpected behavior before
  fixes are proposed.
- `doc-updater`: Required because API, security, deployment, operations, and
  compatibility documentation are deliverables.
- `e2e-runner`: Required for customer API flows, exact-cap enforcement,
  failover, image limits, billing lifecycle, and direct-API bypass tests.
- `go-reviewer`: Mandatory for every Go change, including concurrency and error
  handling.
- `harness-optimizer`: Always retained to audit that required workflow and
  verification gates actually ran.
- `infra-reviewer`: Required for Docker, CI/CD, production deployment, secrets
  injection, and infrastructure configuration.
- `orchestrator`: Required to maintain project routing, dispatch, file claims,
  checkpoints, and human approval gates; it never writes product code.
- `performance-profiler`: Required for latency, concurrency, quota-leakage,
  failover-under-load, and resource-efficiency measurements.
- `planner`: Required for the multi-phase build plan and complex implementation
  slices.
- `refactor-cleaner`: Retained for explicitly approved cleanup after upstream
  fork changes; it must not perform drive-by refactoring.
- `security-reviewer`: Mandatory for API endpoints, authentication,
  authorization, inputs, secrets, SSRF, rate limiting, payments, and logs.
- `tdd-guide`: Required to enforce tests-first implementation for features,
  fixes, and refactors.
- `typescript-reviewer`: Required for the thin branded integration page and any
  inherited New API customer-console changes.

## Pruned Agents

- `chief-of-staff`: Removed from project routing because no email, Slack, LINE,
  Messenger, or other human communication triage is in scope.
- `flutter-reviewer`: Removed because Dart and Flutter are not declared.
- `kotlin-reviewer`: Removed because Kotlin, Java, and Android are not declared.
- `loop-operator`: Removed because unattended autonomous coding-agent loops are
  not declared. Gateway health workers are product processes, not agent loops.
- `python-reviewer`: Removed because Python application source is not declared.
- `rust-reviewer`: Removed because Rust is not declared.
- `swift-reviewer`: Removed because Swift and Apple-platform development are not
  declared.

## Active Skills

- `api-contract-first`: Hard gate before adding or changing any API endpoint,
  webhook, service interface, or event contract.
- `brainstorming`: Required for greenfield feature and architecture discovery.
- `data-migration`: Required before production schema changes, backfills, or
  durable data transformations.
- `dispatching-parallel-agents`: Required when independent work can proceed
  without shared files or state.
- `executing-plans`: Retained for controlled execution of an approved written
  plan.
- `finishing-a-development-branch`: Required by the feature-branch workflow.
- `five-whys`: Retained for recurring failures and systemic root-cause analysis.
- `incident-response`: Required because the service will run in production.
- `performance-audit`: Required for latency-sensitive routing, distributed
  limiters, quota integrity, and launch load testing.
- `subagent-driven-development`: Retained for implementation slices that can be
  independently dispatched and reviewed.
- `systematic-debugging`: Mandatory for bugs, test failures, and unexpected
  behavior.
- `test-driven-development`: Mandatory for implementation and fixes.
- `using-a-team`: Always active as the routing and workflow enforcement map.
- `using-git-worktrees`: Required before isolated feature implementation.
- `verification-before-completion`: Mandatory before any passing, fixed,
  complete, or release-ready claim.
- `writing-plans`: Required before implementing this multi-step specification.

## Pruned Skills

- `skill-duplication-audit`: Inactive because this project is not maintaining
  the A Team method-pack or reconciling skill packages.
- `smart-init`: Initialization is complete and `INIT.md` now exists; reactivate
  only if project onboarding must be regenerated.
- `writing-skills`: Inactive because creating or editing A Team skills is not in
  project scope.

## Reactivation Rules

- Reactivate a language reviewer before the first source change in that
  language.
- Reactivate `chief-of-staff` if email, Slack, support, or customer-message
  workflows enter scope.
- Reactivate `loop-operator` before any unattended autonomous coding-agent
  execution.
- Regenerate this roster whenever `INIT.md` changes materially.
