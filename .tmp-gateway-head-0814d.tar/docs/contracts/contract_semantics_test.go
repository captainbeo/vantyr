package contracts_test

import (
	"fmt"
	"os"
	"sort"
	"strings"
	"testing"

	"github.com/santhosh-tekuri/jsonschema/v6"
	"github.com/stretchr/testify/require"
	"gopkg.in/yaml.v3"
)

const refreshCookieIssuedPattern = `^new_api_refresh=[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\.[A-Za-z0-9]{64}; Path=/api/user/auth; Expires=(Mon|Tue|Wed|Thu|Fri|Sat|Sun), (0[1-9]|[12][0-9]|3[01]) (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) [0-9]{4} [0-9]{2}:[0-9]{2}:[0-9]{2} GMT; Max-Age=[1-9][0-9]*; HttpOnly; Secure; SameSite=Strict$`

const refreshCookieClearedValue = "new_api_refresh=; Path=/api/user/auth; Expires=Thu, 01 Jan 1970 00:00:01 GMT; Max-Age=0; HttpOnly; Secure; SameSite=Strict"

func TestInheritedRefreshCookieWireContract(t *testing.T) {
	data, err := os.ReadFile("customer-api.openapi.yaml")
	require.NoError(t, err)
	root, err := decodeYAMLBytes("customer-api.openapi.yaml", data)
	require.NoError(t, err)
	require.Equal(t, refreshCookieIssuedPattern, value(root, "components", "headers", "RefreshCookieIssued", "schema", "pattern"))
	require.Equal(t, refreshCookieClearedValue, value(root, "components", "headers", "RefreshCookieCleared", "schema", "const"))
}

func TestRefreshCookieRoutesPreserveColdStartRecovery(t *testing.T) {
	root := readContractYAML(t, "customer-api.openapi.yaml")
	require.Equal(t, false, decodedValue(root, "components", "parameters", "AuthSessionBinding", "required"))
	require.Equal(t, false, decodedValue(root, "components", "requestBodies", "EmptyCommand", "required"))

	for _, route := range []string{"/api/user/auth/refresh", "/api/user/auth/logout"} {
		operation := child(root, "paths", route, "post")
		require.NotNil(t, operation)
		require.Equal(t, "exact-configured-origin", value(operation, "x-origin-policy"))
		require.Equal(t, "origin-and-optional-auth-session-binding", value(operation, "x-csrf-policy"))

		var security []map[string][]string
		require.NoError(t, child(operation, "security").Decode(&security))
		require.Equal(t, []map[string][]string{{"RefreshCookie": {}}}, security)

		var parameters []map[string]string
		require.NoError(t, child(operation, "parameters").Decode(&parameters))
		require.ElementsMatch(t, []map[string]string{
			{"$ref": "#/components/parameters/Origin"},
			{"$ref": "#/components/parameters/AuthSessionBinding"},
		}, parameters)
		require.NotNil(t, child(operation, "responses", "409"))
	}
}

func TestAuthBundleResponseAcceptsPinnedLoginAndRefreshWireFields(t *testing.T) {
	schema := compileCustomerDefinition(t, "AuthBundleResponse")
	fixture := map[string]any{
		"success": true,
		"message": "",
		"data": map[string]any{
			"access_token":      strings.Repeat("a", 32),
			"token_type":        "Bearer",
			"access_expires_at": int64(1),
			"user": map[string]any{
				"id":       1,
				"username": "customer",
				"role":     1,
				"status":   1,
			},
			"session": map[string]any{
				"sid":            "00000000-0000-4000-8000-000000000000",
				"current":        true,
				"login_method":   "password",
				"ip":             "192.0.2.1",
				"user_agent":     "pinned-browser",
				"created_at":     int64(1),
				"last_active_at": int64(1),
				"expires_at":     int64(2),
			},
		},
	}

	require.NoError(t, schema.Validate(fixture))
}

func TestBrowserErrorResponseAcceptsPinnedTopLevelConflictCode(t *testing.T) {
	schema := compileCustomerDefinition(t, "BrowserErrorResponse")
	require.NoError(t, schema.Validate(map[string]any{
		"success": false,
		"code":    "AUTH_SESSION_MISMATCH",
		"message": "Conflict",
	}))
	require.Error(t, schema.Validate(map[string]any{
		"success": false,
		"message": "Conflict",
		"data":    map[string]any{"code": "AUTH_SESSION_MISMATCH"},
	}))
}

func TestCodexToolWireContract(t *testing.T) {
	data, err := os.ReadFile("customer-api.schemas.yaml")
	require.NoError(t, err)
	root, err := decodeYAMLBytes("customer-api.schemas.yaml", data)
	require.NoError(t, err)
	require.Equal(t, []string{
		"#/$defs/FunctionToolDefinition",
		"#/$defs/NamespaceToolDefinition",
		"#/$defs/ToolSearchDefinition",
		"#/$defs/CustomToolDefinition",
	}, referenceList(child(root, "$defs", "ToolDefinition", "oneOf")))
	require.Equal(t, "true", value(root, "$defs", "FunctionToolDefinition", "properties", "defer_loading", "const"))
	require.Contains(t, stringsAt(root, "$defs", "FunctionToolDefinition", "required"), "strict")
	require.Equal(t, "client", value(root, "$defs", "ToolSearchDefinition", "properties", "execution", "const"))
	require.Equal(t, []string{"#/$defs/LoadableFunctionToolDefinition", "#/$defs/NamespaceToolDefinition"}, referenceList(child(root, "$defs", "LoadableToolDefinition", "oneOf")))
	responseItems := referenceList(child(root, "$defs", "ResponseItem", "oneOf"))
	require.Contains(t, responseItems, "#/$defs/ToolSearchCallItem")
	require.Contains(t, responseItems, "#/$defs/ToolSearchOutputItem")
}

func TestServerAuthoredResponseOutputUsesOnePinnedOwner(t *testing.T) {
	root := readContractYAML(t, "customer-api.schemas.yaml")
	sse := readContractYAML(t, "customer-api.sse.schemas.yaml")
	require.Equal(t, "#/$defs/ResponseOutputItem", value(root, "$defs", "ResponseObject", "properties", "output", "items", "$ref"))
	require.Equal(t, "./customer-api.schemas.yaml#/$defs/ResponseOutputItem", value(sse, "$defs", "SSEOutputItem", "$ref"))

	schema := compileCustomerDefinition(t, "ResponseOutputItem")
	valid := []map[string]any{
		{"type": "message", "id": "msg_1", "role": "assistant", "phase": "commentary", "content": []any{map[string]any{"type": "output_text", "text": "working"}}},
		{"type": "reasoning", "id": "rs_1", "summary": []any{}, "encrypted_content": "opaque-ciphertext"},
		{"type": "function_call", "id": "fc_1", "call_id": "call_1", "name": "calendar_create", "namespace": "calendar", "arguments": "{}"},
		{"type": "custom_tool_call", "id": "ct_1", "call_id": "call_2", "name": "shell", "namespace": "workspace", "status": "completed", "input": "pwd"},
		{"type": "tool_search_call", "execution": "client", "arguments": map[string]any{"query": "docs"}},
		{"type": "tool_search_output", "status": "completed", "execution": "client", "tools": []any{}},
	}
	for _, fixture := range valid {
		require.NoError(t, schema.Validate(fixture), "pinned server output should validate: %v", fixture["type"])
	}
	require.Error(t, schema.Validate(map[string]any{
		"type": "reasoning", "id": "rs_missing_summary", "encrypted_content": "opaque-ciphertext",
	}))

	require.Error(t, schema.Validate(map[string]any{
		"type": "message", "role": "user", "content": []any{map[string]any{"type": "input_text", "text": "hostile output"}},
	}))
	require.Error(t, schema.Validate(map[string]any{
		"type": "function_call_output", "call_id": "call_1", "output": "input-only item",
	}))
	require.Error(t, schema.Validate(map[string]any{
		"type": "custom_tool_call_output", "call_id": "call_2", "output": "input-only item",
	}))
	require.Error(t, schema.Validate(map[string]any{
		"type": "compaction", "encrypted_content": "next-turn input only",
	}))

	sseSchema := compileSSEDefinition(t, "SSEOutputItem")
	require.NoError(t, sseSchema.Validate(valid[0]))
	require.NoError(t, sseSchema.Validate(valid[2]))
	require.NoError(t, sseSchema.Validate(valid[3]))
}

func TestGatewayKeyCanonicalCrockfordGrammar(t *testing.T) {
	const (
		publicIDPattern  = `^[0-9A-HJKMNP-TV-Z]{25}[048CGMRW]$`
		maskedKeyPattern = `^sk-pxv1\.[0-9A-HJKMNP-TV-Z]{25}[048CGMRW]\.\*{4}$`
		fullKeyPattern   = `^sk-pxv1\.[0-9A-HJKMNP-TV-Z]{25}[048CGMRW]\.[0-9A-HJKMNP-TV-Z]{51}[0G]$`
	)
	openapi := readContractYAML(t, "customer-api.openapi.yaml")
	schemas := readContractYAML(t, "customer-api.schemas.yaml")
	parameters := child(openapi, "paths", "/api/token/{id}", "delete", "parameters")
	require.NotNil(t, parameters)
	require.Equal(t, yaml.SequenceNode, parameters.Kind)
	var keyIDParameter *yaml.Node
	for _, parameter := range parameters.Content {
		if value(parameter, "name") == "id" {
			keyIDParameter = parameter
			break
		}
	}
	require.NotNil(t, keyIDParameter)
	require.Equal(t, publicIDPattern, value(keyIDParameter, "schema", "pattern"))
	require.Equal(t, fullKeyPattern, value(openapi, "components", "securitySchemes", "GatewayBearer", "x-bearer-pattern"))
	require.Equal(t, maskedKeyPattern, value(schemas, "$defs", "GatewayKeyListResponse", "properties", "data", "items", "properties", "masked_key", "pattern"))

	publicID := strings.Repeat("0", 26)
	secret := strings.Repeat("0", 52)
	validList := map[string]any{
		"success": true, "message": "ok", "data": []any{map[string]any{
			"id": publicID, "name": "Codex", "masked_key": "sk-pxv1." + publicID + ".****", "status": "active", "created_at": int64(1),
		}},
	}
	listSchema := compileCustomerDefinition(t, "GatewayKeyListResponse")
	require.NoError(t, listSchema.Validate(validList))
	invalidList := map[string]any{
		"success": true, "message": "ok", "data": []any{map[string]any{
			"id": strings.Repeat("0", 25) + "1", "name": "Codex", "masked_key": "sk-pxv1." + strings.Repeat("0", 25) + "1.****", "status": "active", "created_at": int64(1),
		}},
	}
	require.Error(t, listSchema.Validate(invalidList), "noncanonical public-ID pad bits must be rejected")

	createdSchema := compileCustomerDefinition(t, "GatewayKeyCreatedResponse")
	validCreated := map[string]any{
		"success": true, "message": "created", "data": map[string]any{
			"id": publicID, "name": "Codex", "secret": "sk-pxv1." + publicID + "." + secret,
		},
	}
	require.NoError(t, createdSchema.Validate(validCreated))
	validCreated["data"].(map[string]any)["secret"] = "sk-pxv1." + publicID + "." + strings.Repeat("0", 51) + "1"
	require.Error(t, createdSchema.Validate(validCreated), "noncanonical secret pad bits must be rejected")
}

func TestCodexToolSearchOutputPinnedFixtures(t *testing.T) {
	schema := compileCustomerDefinition(t, "ToolSearchOutputItem")
	valid := toolSearchOutputFixture("calendar_create")
	require.NoError(t, schema.Validate(valid), "pinned 0.146.0 fixture omits strict on a loadable function")

	unknownControl := toolSearchOutputFixture("calendar_create")
	unknownControl["tools"].([]any)[0].(map[string]any)["vendor_control"] = true
	require.ErrorContains(t, schema.Validate(unknownControl), "additional properties 'vendor_control' not allowed")

	invalidBound := toolSearchOutputFixture("")
	require.ErrorContains(t, schema.Validate(invalidBound), "minLength")
}

func TestCodexToolOutputImagePinnedFixtures(t *testing.T) {
	data, err := os.ReadFile("customer-api.schemas.yaml")
	require.NoError(t, err)
	root, err := decodeYAMLBytes("customer-api.schemas.yaml", data)
	require.NoError(t, err)
	require.Equal(t, []string{"input_audio", "encrypted_content"}, stringsAt(root, "$defs", "ToolOutputContent", "x-codex-intentionally-unsupported-content-item-types"))

	schema := compileCustomerDefinition(t, "ToolOutputContent")
	valid := []any{map[string]any{
		"type": "input_image", "image_url": "data:image/png;base64,Zm9v", "detail": "high",
	}}
	require.NoError(t, schema.Validate(valid))

	remoteURL := []any{map[string]any{
		"type": "input_image", "image_url": "https://example.invalid/image.png",
	}}
	require.Error(t, schema.Validate(remoteURL))

	invalidShape := []any{map[string]any{
		"type": "input_image", "image_url": 7,
	}}
	require.Error(t, schema.Validate(invalidShape))
}

func compileCustomerDefinition(t *testing.T, definition string) *jsonschema.Schema {
	t.Helper()
	data, err := os.ReadFile("customer-api.schemas.yaml")
	require.NoError(t, err)
	root, err := decodeYAMLBytes("customer-api.schemas.yaml", data)
	require.NoError(t, err)
	var document any
	require.NoError(t, root.Decode(&document))
	compiler := jsonschema.NewCompiler()
	compiler.DefaultDraft(jsonschema.Draft2020)
	require.NoError(t, compiler.AddResource(customerSchemaResource, document))
	schema, err := compiler.Compile(customerSchemaResource + "#/$defs/" + definition)
	require.NoError(t, err)
	return schema
}

func toolSearchOutputFixture(name string) map[string]any {
	return map[string]any{
		"type": "tool_search_output", "status": "completed", "execution": "client",
		"tools": []any{map[string]any{
			"type": "function", "name": name, "description": "Create a calendar event.",
			"defer_loading": true,
			"parameters": map[string]any{
				"type": "object", "properties": map[string]any{}, "additionalProperties": false,
			},
		}},
	}
}

func TestRelaySizeUnitsContract(t *testing.T) {
	data, err := os.ReadFile("customer-api.openapi.yaml")
	require.NoError(t, err)
	root, err := decodeYAMLBytes("customer-api.openapi.yaml", data)
	require.NoError(t, err)
	require.Equal(t, 8388608, decodedValue(root, "x-relay-contract", "validation", "max-decompressed-body-bytes"))
	require.Equal(t, 8388608, decodedValue(root, "x-relay-contract", "validation", "max-string-bytes"))
	require.Equal(t, "utf8-octets", value(root, "x-relay-contract", "validation", "string-byte-count"))
	require.Equal(t, "unicode-code-points", value(root, "x-relay-contract", "validation", "schema-maxLength-unit"))
	require.Equal(t, "operation-x-json-limits-when-present-otherwise-root", value(root, "x-relay-contract", "validation", "string-byte-limit-selection"))
	require.Equal(t, "selected-utf8-byte-limit-and-schema-code-point-limit-both-apply", value(root, "x-relay-contract", "validation", "effective-string-limit"))
	require.Equal(t, "decompressed-body-then-selected-string-bytes-then-schema-code-points", value(root, "x-relay-contract", "validation", "validation-order"))
	for _, requestBody := range []string{"ResponseRequestBody", "CompactRequestBody"} {
		require.Equal(t, 8388608, decodedValue(root, "components", "requestBodies", requestBody, "x-json-limits", "string-bytes"), requestBody)
	}

	schemas := readContractYAML(t, "customer-api.schemas.yaml")
	require.Equal(t, 8388608, decodedValue(schemas, "$defs", "InputImageContent", "properties", "image_url", "maxLength"))
	imageURL := "data:image/png;base64," + strings.Repeat("A", 1048580)
	require.NoError(t, compileCustomerDefinition(t, "InputImageContent").Validate(map[string]any{"type": "input_image", "image_url": imageURL}))
}

func TestPublicErrorCodeAuthority(t *testing.T) {
	openapi := readContractYAML(t, "customer-api.openapi.yaml")
	schemas := readContractYAML(t, "customer-api.schemas.yaml")
	sse := readContractYAML(t, "customer-api.sse.schemas.yaml")
	canonical := mappingKeys(child(openapi, "x-relay-contract", "errors", "stable-statuses"))
	sort.Strings(canonical)

	t.Run("canonical owner", func(t *testing.T) {
		require.Equal(t, "stable-statuses", value(openapi, "x-relay-contract", "errors", "code-owner"))
	})
	t.Run("HTTP projection", func(t *testing.T) {
		require.ElementsMatch(t, canonical, stringsAt(openapi, "x-relay-contract", "errors", "transport-code-subsets", "http"))
		require.ElementsMatch(t, canonical, stringsAt(schemas, "$defs", "OpenAIErrorDetail", "properties", "code", "enum"))
	})
	t.Run("SSE projection", func(t *testing.T) {
		configured := stringsAt(openapi, "x-relay-contract", "errors", "transport-code-subsets", "sse")
		require.ElementsMatch(t, configured, stringsAt(sse, "$defs", "SanitizedError", "properties", "code", "enum"))
		for _, code := range configured {
			require.Contains(t, canonical, code)
		}
	})
	t.Run("compiled schemas reject vendor codes", func(t *testing.T) {
		httpError := map[string]any{"message": "Request rejected.", "type": "server_error", "code": "vendor_private"}
		require.Error(t, compileCustomerDefinition(t, "OpenAIErrorDetail").Validate(httpError))
		sseError := map[string]any{"message": "Request failed.", "type": "server_error", "code": "vendor_private"}
		require.Error(t, compileSSEDefinition(t, "SanitizedError").Validate(sseError))
	})
}

func TestUsageAccountingAuthority(t *testing.T) {
	schemas := readContractYAML(t, "customer-api.schemas.yaml")
	sse := readContractYAML(t, "customer-api.sse.schemas.yaml")
	mainUsage := child(schemas, "$defs", "Usage")
	sseUsage := child(sse, "$defs", "SSEUsage")

	t.Run("schema parity", func(t *testing.T) {
		mainDigest, err := canonicalNodeSHA256(mainUsage)
		require.NoError(t, err)
		sseDigest, err := canonicalNodeSHA256(sseUsage)
		require.NoError(t, err)
		require.Equal(t, mainDigest, sseDigest)
		require.Equal(t, "gateway-post-schema-arithmetic", value(mainUsage, "x-accounting-validator"))
	})

	mainSchema := compileCustomerDefinition(t, "Usage")
	sseSchema := compileSSEDefinition(t, "SSEUsage")
	tooLarge := usageFixture(2147483648, 0, 2147483648, 0, 0, 0)
	t.Run("compiled maximum bounds", func(t *testing.T) {
		require.Error(t, mainSchema.Validate(tooLarge))
		require.Error(t, sseSchema.Validate(tooLarge))
	})

	valid := usageFixture(10, 7, 17, 4, 2, 3)
	t.Run("valid accounting", func(t *testing.T) {
		require.NoError(t, validateUsageAccountingFixture(mainSchema, valid))
		require.NoError(t, validateUsageAccountingFixture(sseSchema, valid))
	})
	withoutCacheWrite := usageFixture(10, 7, 17, 4, 0, 3)
	delete(withoutCacheWrite["input_tokens_details"].(map[string]any), "cache_write_tokens")
	t.Run("optional cache-write accounting", func(t *testing.T) {
		require.NoError(t, validateUsageAccountingFixture(mainSchema, withoutCacheWrite))
		require.NoError(t, validateUsageAccountingFixture(sseSchema, withoutCacheWrite))
	})
	badTotal := usageFixture(10, 7, 18, 4, 2, 3)
	t.Run("total arithmetic is executable not generic schema", func(t *testing.T) {
		require.NoError(t, mainSchema.Validate(badTotal), "x-equals-input-plus-output is an annotation")
		require.ErrorContains(t, validateUsageAccountingFixture(mainSchema, badTotal), "total_tokens")
	})
	t.Run("detail meters cannot exceed owners", func(t *testing.T) {
		require.ErrorContains(t, validateUsageAccountingFixture(mainSchema, usageFixture(10, 7, 17, 11, 2, 3)), "cached_tokens")
		require.ErrorContains(t, validateUsageAccountingFixture(mainSchema, usageFixture(10, 7, 17, 4, 11, 3)), "cache_write_tokens")
		require.ErrorContains(t, validateUsageAccountingFixture(mainSchema, usageFixture(10, 7, 17, 4, 2, 8)), "reasoning_tokens")
	})
}

func usageFixture(input, output, total, cached, cacheWrite, reasoning int64) map[string]any {
	return map[string]any{
		"input_tokens": input, "output_tokens": output, "total_tokens": total,
		"input_tokens_details":  map[string]any{"cached_tokens": cached, "cache_write_tokens": cacheWrite},
		"output_tokens_details": map[string]any{"reasoning_tokens": reasoning},
	}
}

func validateUsageAccountingFixture(schema *jsonschema.Schema, usage map[string]any) error {
	if err := schema.Validate(usage); err != nil {
		return err
	}
	input, inputOK := usage["input_tokens"].(int64)
	output, outputOK := usage["output_tokens"].(int64)
	total, totalOK := usage["total_tokens"].(int64)
	if !inputOK || !outputOK || !totalOK {
		return fmt.Errorf("usage fixture has invalid core meter types")
	}
	cached, cachedPresent, err := optionalUsageDetailMeter(usage, "input_tokens_details", "cached_tokens")
	if err != nil {
		return err
	}
	cacheWrite, cacheWritePresent, err := optionalUsageDetailMeter(usage, "input_tokens_details", "cache_write_tokens")
	if err != nil {
		return err
	}
	reasoning, reasoningPresent, err := optionalUsageDetailMeter(usage, "output_tokens_details", "reasoning_tokens")
	if err != nil {
		return err
	}
	if total != input+output {
		return fmt.Errorf("total_tokens must equal input_tokens plus output_tokens")
	}
	if cachedPresent && cached > input {
		return fmt.Errorf("cached_tokens must not exceed input_tokens")
	}
	if cacheWritePresent && cacheWrite > input {
		return fmt.Errorf("cache_write_tokens must not exceed input_tokens")
	}
	if reasoningPresent && reasoning > output {
		return fmt.Errorf("reasoning_tokens must not exceed output_tokens")
	}
	return nil
}

func optionalUsageDetailMeter(usage map[string]any, detailsName, meterName string) (int64, bool, error) {
	detailsValue, detailsPresent := usage[detailsName]
	if !detailsPresent {
		return 0, false, nil
	}
	details, ok := detailsValue.(map[string]any)
	if !ok {
		return 0, false, fmt.Errorf("usage fixture has invalid %s type", detailsName)
	}
	meterValue, meterPresent := details[meterName]
	if !meterPresent {
		return 0, false, nil
	}
	meter, ok := meterValue.(int64)
	if !ok {
		return 0, false, fmt.Errorf("usage fixture has invalid %s type", meterName)
	}
	return meter, true, nil
}

func TestPinnedCodexTerminalFields(t *testing.T) {
	usage := usageFixture(10, 7, 17, 4, 2, 3)
	httpTerminal := map[string]any{
		"id": "resp_1", "object": "response", "status": "completed", "model": "gpt-5.6",
		"output": []any{}, "usage": usage, "end_turn": false,
	}
	require.NoError(t, compileCustomerDefinition(t, "ResponseObject").Validate(httpTerminal))

	sseTerminal := map[string]any{
		"id": "resp_1", "object": "response", "status": "completed", "model": "gpt-5.6",
		"error": nil, "usage": usage, "end_turn": false,
	}
	require.NoError(t, compileSSEDefinition(t, "SSECompletedResponse").Validate(sseTerminal))
}

func lintUsageAccountingAuthority(schemas, sse *yaml.Node) error {
	mainUsage := child(schemas, "$defs", "Usage")
	sseUsage := child(sse, "$defs", "SSEUsage")
	mainDigest, err := canonicalNodeSHA256(mainUsage)
	if err != nil {
		return fmt.Errorf("HTTP usage accounting authority: %w", err)
	}
	sseDigest, err := canonicalNodeSHA256(sseUsage)
	if err != nil {
		return fmt.Errorf("SSE usage accounting authority: %w", err)
	}
	if mainDigest != sseDigest {
		return fmt.Errorf("HTTP and SSE usage accounting schemas differ")
	}
	if value(mainUsage, "x-accounting-validator") != "gateway-post-schema-arithmetic" ||
		decodedValue(mainUsage, "properties", "total_tokens", "x-equals-input-plus-output") != true ||
		value(mainUsage, "properties", "input_tokens_details", "properties", "cached_tokens", "x-less-than-or-equal-to") != "input_tokens" ||
		value(mainUsage, "properties", "input_tokens_details", "properties", "cache_write_tokens", "x-less-than-or-equal-to") != "input_tokens" ||
		value(mainUsage, "properties", "output_tokens_details", "properties", "reasoning_tokens", "x-less-than-or-equal-to") != "output_tokens" {
		return fmt.Errorf("usage arithmetic extension contract mismatch")
	}
	for _, path := range [][]string{
		{"properties", "input_tokens"}, {"properties", "output_tokens"}, {"properties", "total_tokens"},
		{"properties", "input_tokens_details", "properties", "cached_tokens"},
		{"properties", "input_tokens_details", "properties", "cache_write_tokens"},
		{"properties", "output_tokens_details", "properties", "reasoning_tokens"},
	} {
		if decodedValue(mainUsage, append(path, "maximum")...) != 2147483647 {
			return fmt.Errorf("usage meter %s maximum mismatch", strings.Join(path, "."))
		}
	}
	return nil
}

func lintPublicErrorCodeAuthority(openapi, schemas, sse *yaml.Node) error {
	errors := child(openapi, "x-relay-contract", "errors")
	if value(errors, "code-owner") != "stable-statuses" {
		return fmt.Errorf("public error code owner mismatch")
	}
	canonical := mappingKeys(child(errors, "stable-statuses"))
	if !sameStrings(stringsAt(errors, "transport-code-subsets", "http"), canonical) ||
		!sameStrings(stringsAt(schemas, "$defs", "OpenAIErrorDetail", "properties", "code", "enum"), canonical) {
		return fmt.Errorf("public HTTP error code projection mismatch")
	}
	sseCodes := stringsAt(errors, "transport-code-subsets", "sse")
	if !sameStrings(stringsAt(sse, "$defs", "SanitizedError", "properties", "code", "enum"), sseCodes) {
		return fmt.Errorf("public SSE error code projection mismatch")
	}
	canonicalSet := map[string]bool{}
	for _, code := range canonical {
		canonicalSet[code] = true
	}
	for _, code := range sseCodes {
		if !canonicalSet[code] {
			return fmt.Errorf("public SSE error code %q is not canonical", code)
		}
	}
	return nil
}

func readContractYAML(t *testing.T, name string) *yaml.Node {
	t.Helper()
	data, err := os.ReadFile(name)
	require.NoError(t, err)
	root, err := decodeYAMLBytes(name, data)
	require.NoError(t, err)
	return root
}

func TestStripeContractHasOneNormativeOwner(t *testing.T) {
	data, err := os.ReadFile("stripe-events.md")
	require.NoError(t, err)
	frontmatter, err := frontmatterBytes(data)
	require.NoError(t, err)
	root, err := decodeYAMLBytes("stripe-events.md", frontmatter)
	require.NoError(t, err)
	require.Equal(t, "structured-frontmatter-only", value(root, "normative_authority"))
	require.Equal(t, "informational-projection", value(root, "prose_role"))
	require.Nil(t, child(root, "normative_prose_sha256"))
}

func referenceList(node *yaml.Node) []string {
	if node == nil || node.Kind != yaml.SequenceNode {
		return nil
	}
	refs := make([]string, len(node.Content))
	for i, item := range node.Content {
		refs[i] = value(item, "$ref")
	}
	return refs
}
