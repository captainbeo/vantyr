package contracts_test

import (
	"bytes"
	"fmt"
	"os"
	"path/filepath"
	"testing"

	"github.com/stretchr/testify/require"
)

func TestContractArtifactsStayReviewable(t *testing.T) {
	entries, err := os.ReadDir(".")
	require.NoError(t, err)
	artifacts := make(map[string][]byte)
	for _, entry := range entries {
		if entry.IsDir() || !isMaintainedContractArtifact(entry.Name()) {
			continue
		}
		data, readErr := os.ReadFile(entry.Name())
		require.NoError(t, readErr)
		artifacts[entry.Name()] = data
	}
	require.NoError(t, lintContractArtifactLineCounts(artifacts))
}

func isMaintainedContractArtifact(name string) bool {
	switch filepath.Ext(name) {
	case ".go", ".md", ".yaml":
		return true
	default:
		return false
	}
}

func lintContractArtifactLineCounts(artifacts map[string][]byte) error {
	for name, data := range artifacts {
		lines := bytes.Count(data, []byte{'\n'})
		if len(data) > 0 && data[len(data)-1] != '\n' {
			lines++
		}
		if lines >= 800 {
			return fmt.Errorf("%s has %d lines; contract artifacts must stay under 800", name, lines)
		}
	}
	return nil
}
