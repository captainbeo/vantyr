package contracts_test

import (
	"fmt"
	"strings"

	"gopkg.in/yaml.v3"
)

func containsMappingKey(node *yaml.Node, target string) bool {
	if node.Kind == yaml.MappingNode {
		for index := 0; index < len(node.Content); index += 2 {
			if node.Content[index].Value == target || containsMappingKey(node.Content[index+1], target) {
				return true
			}
		}
		return false
	}
	for _, child := range node.Content {
		if containsMappingKey(child, target) {
			return true
		}
	}
	return false
}

func lintOperationContract(root, operation *yaml.Node, route string) error {
	allowedFields := map[string]bool{
		"operationId": true, "summary": true, "x-commercial-route-class": true,
		"x-canonical-operation": true, "x-route-alias": true, "x-enforcement-pipeline": true,
		"x-origin-policy": true, "x-csrf-policy": true, "x-tenant-scope": true,
		"security": true, "parameters": true, "requestBody": true, "responses": true,
	}
	for _, field := range mappingKeys(operation) {
		if !allowedFields[field] {
			return fmt.Errorf("%s has unapproved operation field %s", route, field)
		}
	}
	for _, status := range expectedStatuses(route) {
		owner := expectedResponseOwner(route, status)
		if owner == "" || value(operation, "responses", status, "$ref") != "#/components/responses/"+owner {
			return fmt.Errorf("%s status %s has wrong response owner", route, status)
		}
	}
	if err := lintParameterOwners(operation, route); err != nil {
		return err
	}
	if route == "GET /livez" && value(root, "components", "responses", "HealthSuccess", "content", "application/json", "schema", "properties", "status", "const") != "ok" {
		return fmt.Errorf("GET /livez health response is not detail-free")
	}
	return nil
}

func expectedResponseOwner(route, status string) string {
	if owner, ok := successOwners()[route]; ok && status == successStatus(route) {
		return owner
	}
	browser := strings.Contains(route, "/api/") && route != "POST /api/stripe/webhook"
	if browser {
		return map[string]string{"400": "BrowserBadRequest", "401": "BrowserUnauthorized", "403": "BrowserForbidden", "404": "BrowserNotFound", "409": "BrowserConflict", "429": "BrowserRateLimited", "503": "BrowserUnavailable"}[status]
	}
	return map[string]string{"400": "BadRequest", "401": "Unauthorized", "403": "Forbidden", "404": "NotFound", "409": "Conflict", "413": "TooLarge", "415": "UnsupportedMediaType", "429": "RateLimited", "502": "BadGateway", "503": "Unavailable"}[status]
}

func successStatus(route string) string {
	switch route {
	case "POST /api/token":
		return "201"
	case "DELETE /api/token/{id}":
		return "204"
	default:
		return "200"
	}
}

func lintParameterOwners(operation *yaml.Node, route string) error {
	want := map[string][]string{
		"GET /v1/models/{model}":                 {"#/components/parameters/PublicModel"},
		"GET /models/{model}":                    {"#/components/parameters/PublicModel"},
		"POST /api/user/login":                   {"#/components/parameters/Origin"},
		"POST /api/user/auth/refresh":            {"#/components/parameters/Origin", "#/components/parameters/AuthSessionBinding"},
		"POST /api/user/auth/logout":             {"#/components/parameters/Origin", "#/components/parameters/AuthSessionBinding"},
		"POST /api/token":                        {"#/components/parameters/Origin"},
		"DELETE /api/token/{id}":                 {"#/components/parameters/Origin", "inline:id"},
		"POST /api/subscription/stripe/checkout": {"#/components/parameters/Origin", "#/components/parameters/IdempotencyKey"},
		"POST /api/subscription/stripe/portal":   {"#/components/parameters/Origin"},
	}[route]
	parameters := child(operation, "parameters")
	if len(want) == 0 {
		if parameters != nil {
			return fmt.Errorf("%s has unapproved parameters", route)
		}
		return nil
	}
	if parameters == nil || parameters.Kind != yaml.SequenceNode || len(parameters.Content) != len(want) {
		return fmt.Errorf("%s has incomplete parameter ownership", route)
	}
	for i, owner := range want {
		parameter := parameters.Content[i]
		if owner != "inline:id" && value(parameter, "$ref") != owner {
			return fmt.Errorf("%s has wrong parameter owner", route)
		}
		if owner == "inline:id" && (value(parameter, "name") != "id" || value(parameter, "in") != "path" || decodedValue(parameter, "required") != true || value(parameter, "schema", "pattern") != "^[0-9A-HJKMNP-TV-Z]{25}[048CGMRW]$") {
			return fmt.Errorf("%s has incomplete path parameter ownership", route)
		}
	}
	return nil
}

func lintSecuritySchemes(root *yaml.Node) error {
	securitySchemes := map[string][4]string{
		"GatewayBearer":   {"http", "bearer", "", ""},
		"DashboardBearer": {"http", "bearer", "", ""},
		"RefreshCookie":   {"apiKey", "", "cookie", "new_api_refresh"},
		"StripeSignature": {"apiKey", "", "header", "Stripe-Signature"},
	}
	for name, want := range securitySchemes {
		base := []string{"components", "securitySchemes", name}
		got := [4]string{value(root, append(base, "type")...), value(root, append(base, "scheme")...), value(root, append(base, "in")...), value(root, append(base, "name")...)}
		if got != want {
			return fmt.Errorf("security scheme %s mismatch", name)
		}
	}
	if value(root, "components", "securitySchemes", "GatewayBearer", "x-bearer-pattern") != `^sk-pxv1\.[0-9A-HJKMNP-TV-Z]{25}[048CGMRW]\.[0-9A-HJKMNP-TV-Z]{51}[0G]$` {
		return fmt.Errorf("security scheme GatewayBearer bearer grammar mismatch")
	}
	return nil
}
