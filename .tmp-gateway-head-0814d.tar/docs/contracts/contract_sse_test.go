package contracts_test

import (
	"fmt"
	"os"
	"reflect"
	"testing"

	"github.com/santhosh-tekuri/jsonschema/v6"
	"github.com/stretchr/testify/require"
	"gopkg.in/yaml.v3"
)

const approvedSSESchemaAuthoritySHA256 = "73930c60ba554de9e937dd0c928e6c76994e324330f28d6ea5ee229ca1f7d2dd"

func TestResponseSuccessReferencesBoundedSSEWireContract(t *testing.T) {
	data, err := os.ReadFile("customer-api.openapi.yaml")
	require.NoError(t, err)
	root, err := decodeYAMLBytes("customer-api.openapi.yaml", data)
	require.NoError(t, err)
	require.Equal(t, "./customer-api.sse.schemas.yaml#/$defs/SSEWireStream", value(root, "components", "responses", "ResponseSuccess", "content", "text/event-stream", "schema", "$ref"))
}

func TestPinnedSSEEventInventoryExcludesUnhandledEvents(t *testing.T) {
	data, err := os.ReadFile("customer-api.sse.schemas.yaml")
	require.NoError(t, err)
	root, err := decodeYAMLBytes("customer-api.sse.schemas.yaml", data)
	require.NoError(t, err)
	require.NotContains(t, stringsAt(root, "x-sse-wire-contract", "supported-event-types"), "response.in_progress")
}

func TestSSEFailureAcceptsApprovedTwoFieldError(t *testing.T) {
	schema := compileSSEDefinition(t, "SanitizedError")
	require.NoError(t, schema.Validate(map[string]any{
		"code":    "server_is_overloaded",
		"message": "The response stream ended before completion.",
	}))
}

func TestSSEOutputItemEventMatchesDataDiscriminator(t *testing.T) {
	schema := compileSSEFrameSchema(t)
	for _, eventType := range []string{"response.output_item.added", "response.output_item.done"} {
		t.Run("accept "+eventType, func(t *testing.T) {
			require.NoError(t, schema.Validate(outputItemFrame(eventType, eventType)))
		})
	}
	for _, mismatch := range []struct {
		outer, inner string
	}{
		{"response.output_item.added", "response.output_item.done"},
		{"response.output_item.done", "response.output_item.added"},
	} {
		t.Run("reject "+mismatch.outer+" with "+mismatch.inner, func(t *testing.T) {
			require.Error(t, schema.Validate(outputItemFrame(mismatch.outer, mismatch.inner)))
		})
	}
}

func TestPinnedSSEOutputItemSupportsEncryptedReasoningAndToolSearch(t *testing.T) {
	root := readContractYAML(t, "customer-api.sse.schemas.yaml")
	require.Equal(t, "./customer-api.schemas.yaml#/$defs/ResponseOutputItem", value(root, "$defs", "SSEOutputItem", "$ref"))

	schema := compileSSEDefinition(t, "SSEOutputItem")
	require.NoError(t, schema.Validate(map[string]any{
		"type": "reasoning", "id": "rs_1", "summary": []any{}, "encrypted_content": "opaque-ciphertext",
	}))
	require.Error(t, schema.Validate(map[string]any{
		"type": "reasoning", "id": "rs_missing_summary", "encrypted_content": "opaque-ciphertext",
	}))
	require.NoError(t, schema.Validate(map[string]any{
		"type": "tool_search_call", "execution": "client", "arguments": map[string]any{"query": "docs"},
	}))
	require.NoError(t, schema.Validate(map[string]any{
		"type": "tool_search_output", "status": "completed", "execution": "client", "tools": []any{},
	}))
}

func compileSSEFrameSchema(t *testing.T) *jsonschema.Schema {
	return compileSSEDefinition(t, "SSEFrame")
}

func compileSSEDefinition(t *testing.T, definition string) *jsonschema.Schema {
	t.Helper()
	externalData, err := os.ReadFile("customer-api.schemas.yaml")
	require.NoError(t, err)
	externalRoot, err := decodeYAMLBytes("customer-api.schemas.yaml", externalData)
	require.NoError(t, err)
	var externalDocument any
	require.NoError(t, externalRoot.Decode(&externalDocument))
	data, err := os.ReadFile("customer-api.sse.schemas.yaml")
	require.NoError(t, err)
	root, err := decodeYAMLBytes("customer-api.sse.schemas.yaml", data)
	require.NoError(t, err)
	var document any
	require.NoError(t, root.Decode(&document))
	compiler := jsonschema.NewCompiler()
	compiler.DefaultDraft(jsonschema.Draft2020)
	compiler.UseLoader(denyContractURLLoader{})
	require.NoError(t, compiler.AddResource(customerSchemaResource, externalDocument))
	require.NoError(t, compiler.AddResource(sseSchemaResource, document))
	schema, err := compiler.Compile(sseSchemaResource + "#/$defs/" + definition)
	require.NoError(t, err)
	return schema
}

func outputItemFrame(outer, inner string) map[string]any {
	return map[string]any{
		"event": outer,
		"data": map[string]any{
			"type": inner, "sequence_number": 1, "output_index": 0,
			"item": map[string]any{"type": "message", "id": "msg_1", "role": "assistant", "content": []any{}},
		},
	}
}

func lintSSEContract(root *yaml.Node) error {
	if value(root, "$schema") != "https://json-schema.org/draft/2020-12/schema" || value(root, "$id") != "customer-api.sse.schemas.yaml" {
		return fmt.Errorf("SSE schema identity mismatch")
	}
	wire := child(root, "x-sse-wire-contract")
	if value(wire, "data-frames") != "single-compact-json-line" || value(wire, "literal-cr-or-lf-in-data-frame") != "forbidden" ||
		decodedValue(wire, "max-stream-bytes") != 8388608 || decodedValue(wire, "max-event-data-bytes") != 1048576 ||
		value(wire, "unknown-or-vendor-event-data") != "reject-before-output" {
		return fmt.Errorf("SSE wire bounds or sanitization contract mismatch")
	}
	wantEvents := []string{"response.created", "response.output_item.added", "response.output_item.done", "response.output_text.delta", "response.custom_tool_call_input.delta", "response.reasoning_summary_part.added", "response.reasoning_summary_text.delta", "response.reasoning_summary_text.done", "response.reasoning_text.delta", "response.failed", "response.incomplete", "response.completed"}
	if !reflect.DeepEqual(stringsAt(wire, "supported-event-types"), wantEvents) {
		return fmt.Errorf("SSE supported event inventory mismatch")
	}
	if value(root, "$defs", "SSEWireStream", "type") != "string" || decodedValue(root, "$defs", "SSEWireStream", "maxLength") != 8388608 || value(root, "$defs", "SSEWireStream", "x-data-frames") != "single-compact-json-line" {
		return fmt.Errorf("SSE wire stream is unconstrained")
	}
	if !sameStrings(stringsAt(root, "$defs", "SSECompletedResponse", "required"), []string{"id", "object", "status", "model", "error", "usage"}) ||
		value(root, "$defs", "SSECompletedResponse", "properties", "usage", "$ref") != "#/$defs/SSEUsage" ||
		value(root, "$defs", "SSECompletedResponse", "properties", "end_turn", "type") != "boolean" ||
		value(root, "$defs", "SSEFailedResponse", "properties", "error", "$ref") != "#/$defs/SanitizedError" ||
		value(root, "$defs", "PublicModelAlias", "x-model-rewrite") != "request-scoped-public-alias-only" {
		return fmt.Errorf("SSE terminal or public-model contract mismatch")
	}
	return lintSSEClosedObjects(root, "$defs")
}

func lintSSEClosedObjects(node *yaml.Node, path string) error {
	if node == nil || node.Kind != yaml.MappingNode {
		return nil
	}
	if value(node, "type") == "object" && value(node, "additionalProperties") != "false" {
		return fmt.Errorf("%s server-authored object is not closed", path)
	}
	for i := 0; i < len(node.Content); i += 2 {
		if err := lintSSEClosedObjects(node.Content[i+1], path+"."+node.Content[i].Value); err != nil {
			return err
		}
	}
	return nil
}
