---
contract_version: 1
implementation_status: desired-commercial-contract
normative_authority: structured-frontmatter-only
prose_role: informational-projection
routes:
  checkout:
    method: POST
    path: /api/subscription/stripe/checkout
    auth: dashboard-bearer
    origin: exact-configured-origin
    csrf: not-applicable-dashboard-bearer
  portal:
    method: POST
    path: /api/subscription/stripe/portal
    auth: dashboard-bearer
    origin: exact-configured-origin
    csrf: not-applicable-dashboard-bearer
    return_policy: allowlisted
  webhook:
    method: POST
    path: /api/stripe/webhook
    auth: stripe-signature
    origin: not-applicable
    csrf: not-applicable
checkout:
  enabled_plans: [limited-weekly, limited-monthly]
  enabled_price_count: 2
  price_policy: allowlisted-price-to-versioned-plan
  idempotency_header: Idempotency-Key
  persisted_request_fingerprint: true
  fingerprint_fields: [plan-key, configured-currency, contract-version]
  exact_retry: return-original-checkout-session
  fingerprint_conflict_http: 409
  stripe_idempotency_key: server-command-id
  command_unique_key: [customer-id, command-type, idempotency-key]
  command_ownership: persist-before-stripe-compare-and-set-single-owner
  concurrent_duplicate: wait-bounded-then-original-session-or-503
  indeterminate_recovery: reconcile-same-command-by-server-command-id-never-create-replacement
  browser_state_authoritative: false
portal:
  customer_ownership: authenticated-customer-only
  customer_id_input: forbidden
  return_destination: server-allowlisted-only
  stripe_hosted: true
webhook:
  max_raw_body_bytes: 1048576
  signature_header: Stripe-Signature
  endpoint_secret: environment-secret-paired-with-configured-webhook-endpoint-id
  signature_tolerance: {minimum_seconds: 1, default_seconds: 300, maximum_seconds: 300}
  signature_timestamp_source: stripe-signature-t
  signature_timestamp_rule: absolute-clock-skew-lte-configured-tolerance
  clock_failure: fail-closed-pre-inbox-400
  verify_sequence:
    - read-bounded-raw-bytes
    - verify-signature-over-exact-raw-bytes
    - parse-json
  raw_payload_logs: forbidden
  signature_logs: forbidden
bindings:
  startup_account_check: api-account-and-webhook-endpoint-id-match-configured-account-before-readiness
  endpoint_account: configured-webhook-endpoint-id-retrieved-under-configured-account
  event_account: present-must-match-configured-account-absent-requires-verified-endpoint-binding
  mode: configured-live-or-test
  customer: known-owned-customer
  subscription: known-owned-subscription
  price: allowlisted-price-to-versioned-plan
  currency: configured-price-currency
  period: stripe-billing-period
inbox:
  unique_key: stripe-event-id
  payload_hash: sha256-exact-verified-bytes
  persist_before_effect: true
  states: [received, processing, applied, ignored, rejected, deferred, failed-retryable]
  terminal_states: [applied, ignored, rejected]
  retryable_states: [received, deferred, failed-retryable]
  processing_ownership: compare-and-set-with-expiring-owner-lease
  terminal_replay: same-acknowledgement-no-effect
  retryable_replay: elect-one-owner-and-resume-existing-row
  concurrent_duplicate: wait-bounded-then-terminal-ack-or-503
  payload_mismatch: security-conflict-409-no-effect
  out_of_order: deferred-503-until-monotonic-reconciliation
  unknown_reference: deferred-503-then-audited-apply-or-terminal-reject
  unsupported_event: verified-parsed-event-persists-terminal-ignored-before-200
  recovery: expired-processing-or-failed-effect-resumes-same-inbox-row
acknowledgement:
  success_http: 200
  success_states: [applied, ignored, rejected]
  success_cases: [supported-event-terminal-state, unsupported-event-type-terminal-ignored]
  bad_request_http: 400
  bad_request_cases: [invalid-signature, malformed-json, invalid-signature-timestamp, clock-unavailable]
  conflict_http: 409
  conflict_cases: [event-id-payload-hash-mismatch]
  too_large_http: 413
  too_large_cases: [raw-body-limit-exceeded]
  retry_http: 503
  retry_cases: [inbox-persistence-failed, received, processing-not-terminal-after-bounded-wait, deferred, failed-retryable, effect-transaction-failed]
events:
  - checkout.session.completed
  - checkout.session.expired
  - customer.subscription.created
  - customer.subscription.updated
  - customer.subscription.deleted
  - invoice.paid
  - invoice.payment_failed
event_effects:
  checkout.session.completed: [bind-known-command-customer-subscription, access-no-activation-authority, quota-no-grant-or-reset-authority]
  checkout.session.expired: [expire-known-command, access-no-change, quota-no-grant-or-reset]
  customer.subscription.created: [record-known-subscription-price-period, access-apply-configured-paid-state-policy, quota-no-grant-or-reset]
  customer.subscription.updated: [access-apply-monotonic-status-and-scheduled-cancellation, plan-apply-allowlisted-versioned-upgrade-or-downgrade, quota-reconcile-exactly-once-only-for-paid-billing-period-id]
  customer.subscription.deleted: [access-revoke-or-expire, cancel-precommit-next-request-reject, quota-no-grant-or-reset]
  invoice.paid: [access-activate-or-renew, quota-exactly-once-grant-or-reset-by-billing-period-id]
  invoice.payment_failed: [access-configured-unpaid, cancel-precommit-next-request-reject, quota-no-grant-or-reset]
transaction:
  scope:
    - access-state
    - audit-entry
    - billing-command
    - billing-period
    - event-inbox-status
    - mapped-plan-version
    - quota-grant-or-reset
    - subscription-state
  billing_period_id_owner: stripe-subscription-and-period
  grant_reset_cardinality: exactly-once-per-billing-period-id
  audit: append-only-sanitized
known_nonconformance:
  file: controller/topup_stripe.go
  behavior: logs-raw-signature-and-payload
  repair_phase: 4
---

# Stripe command and event contract

The reviewed structured frontmatter is the sole normative authority. The prose below is an
informational projection; if it ever differs, the frontmatter controls and the projection must be
repaired. This is the desired commercial contract, not a claim that the pinned inherited Stripe routes
already conform. Runtime implementation begins only after this contract passes specification and
quality/security review. Browser or URL state never grants access, quota, or credit.

## Checkout command

Only the two enabled private-MVP products, Limited Weekly and Limited Monthly, may be purchased.
Their Stripe Price IDs are deployment configuration mapped to immutable plan versions. A request
may name a public plan key; it may not supply a Stripe Price ID, amount, currency, interval,
customer ID, success URL, or cancellation URL. Disabled plans and unknown mappings fail closed.

The authenticated customer sends a high-entropy `Idempotency-Key`. Before calling Stripe, the
server transactionally inserts a billing command unique on customer, command type, and inbound
key. It stores a normalized fingerprint of the plan key, configured currency, and contract
version, plus one opaque server command ID. The server command ID is reused as Stripe's
idempotency key.

- An exact retry returns the original Checkout session, including after a lost HTTP response or
  browser reload.
- Reusing the key with a different normalized fingerprint returns sanitized `409
  idempotency_conflict` and does not call Stripe.
- Concurrent duplicates elect one command owner; waiters recover the same result.
- An indeterminate Stripe call remains recoverable by command ID. It never creates a replacement
  command merely because the browser retried.
- Checkout completion is evidence to reconcile, not sufficient authority to double-grant quota.
  Authoritative subscription and invoice events drive the access lifecycle below.

## Customer Portal command

The server resolves the Stripe Customer from the authenticated dashboard bearer. Customer IDs
supplied by the browser are rejected. The route requires the exact configured Origin; a separate
CSRF token is not an authentication owner for a bearer-authenticated route. The request may select
only a server allowlisted relative return path; arbitrary
URLs, schemes, hosts, protocol-relative paths, and reflected query destinations are rejected.
The response contains only the short-lived Stripe-hosted Portal URL and sanitized expiry data.

## Webhook admission

The webhook is the sole browser-origin/CSRF exception because it uses Stripe endpoint
authentication. Admission follows this order without variation:

1. Read at most 1 MiB of exact raw bytes. Reject an oversized body before allocation or parsing.
2. Read `Stripe-Signature` without logging it. Verify the signature over those exact bytes using
   the environment secret paired with the configured webhook endpoint ID. Require the signed `t`
   value and reject absolute clock skew above the configured 1-300 second tolerance (default 300).
   An unavailable or invalid clock fails closed with `400` before inbox insertion.
3. Only after verification succeeds, parse one JSON event and validate its type and bindings.

Raw payloads and signatures are forbidden in application, access, debug, tracing, audit, and
failure logs. Logs use the event ID, sanitized event type, mode, processing status, and internal
request ID. Errors never echo Stripe objects, endpoint secrets, signatures, customer payment
data, stack traces, or database details.

Before readiness, the server retrieves the configured webhook endpoint ID under the account
resolved by the configured Stripe API key and requires both to match the configured account. The
deployment pairs that endpoint ID with its environment signing secret. Every event must match the
configured live/test mode. `event.account`, when present, must exactly match the configured
account; an absent value is accepted only through the startup-verified endpoint/account binding.
Customer and subscription references must resolve to the same platform customer. Each line item
Price must map through the allowlist to the expected versioned plan, currency, recurrence interval,
and billing period. Browser metadata is a lookup hint only and cannot establish ownership.

## Inbox, order, and transaction ownership

The verified Stripe event ID and SHA-256 of the exact verified bytes are inserted as `received`
before any effect. State transitions are explicit:

- `received`, `deferred`, and `failed-retryable` are retryable. One delivery acquires
  `processing` with a compare-and-set owner lease and resumes the existing row.
- `applied`, `ignored`, and `rejected` are terminal. An exact replay returns HTTP `200` with no
  second effect. Reuse of an event ID with a different payload hash returns sanitized HTTP `409`,
  alerts, and makes no mutation.
- A concurrent duplicate waits for a bounded interval. It returns the terminal HTTP `200` only
  when the owner reaches a terminal state; otherwise it returns HTTP `503` so Stripe retries.
- An expired `processing` lease or a failed effect transaction is recovered through the same
  inbox row. It never inserts a replacement event or grants an effect twice.

HTTP acknowledgement is derived only from durable state. Invalid signature, signature timestamp,
clock, or malformed JSON returns `400` before inbox insertion; an oversized raw body returns `413`.
A verified, parsed event type outside the allowlist is inserted and terminalized as `ignored`
before returning `200`, preventing permanent Stripe redelivery without losing audit evidence.
Inbox persistence failure, a non-terminal retryable state, or effect failure returns `503`. Only
durable `applied`, `ignored`, or `rejected` returns `200`. A response-loss replay therefore observes
the stored state instead of guessing whether the prior effect committed.

Unknown customer, subscription, Price, currency, account, or mode bindings first become
`deferred` and return `503` while bounded monotonic reconciliation checks authoritative Stripe and
platform state. Reconciliation then either applies the event or records a terminal audited
`rejected` state. Out-of-order authentic events follow the same rule. A stale event may become
terminal `ignored`, but cannot reactivate a newer cancellation or roll a billing period backward.

One PostgreSQL transaction owns the inbox processing status, billing-command mutation,
subscription/access transition, mapped immutable plan version, billing-period identity,
exactly-once quota grant/reset, and append-only audit entry. The billing period identity derives
from the Stripe subscription plus Stripe period boundary, not webhook delivery time. There is
exactly one grant/reset per billing-period ID across invoice retries, subscription updates, and
webhook replay.

## Lifecycle effects

| Event | Required effect after all bindings pass |
|---|---|
| `checkout.session.completed` | Bind the known Checkout command, Stripe Customer, and Subscription; do not duplicate a period grant. |
| `checkout.session.expired` | Mark the matching command expired; do not activate access or grant quota. |
| `customer.subscription.created` | Record the subscription and expected Price/period; activation still follows the configured paid-state policy. |
| `customer.subscription.updated` | Apply valid upgrade, downgrade, renewal, scheduled cancellation, status, and period changes monotonically. |
| `customer.subscription.deleted` | Revoke/expire access and audit the terminal subscription state. |
| `invoice.paid` | Activate or renew the bound period and perform its single quota grant/reset. |
| `invoice.payment_failed` | Move access to the configured unpaid state and cancel pre-commit work; later requests reject. |

Cancellation, expiry, and payment failure cancel work that has not committed any customer-visible
response byte. A stream that already committed may finish under its admission snapshot, but the
next request rejects. Upgrade and downgrade effects use the mapped immutable plan version and the
Stripe period; they never trust a dashboard selection after Checkout creation.

## Audit and inherited gap

Audit entries include sanitized command/event IDs, customer/subscription internal IDs, old and new
access states, mapped plan-version ID, period ID, effect classification, and timestamp. They omit
raw Stripe payloads, signatures, payment instruments, API keys, endpoint secrets, and full
customer gateway keys.

The pinned inherited `controller/topup_stripe.go` currently logs the raw Stripe signature and
payload. That behavior is a known nonconformance and must be removed and regression-tested during
Phase 4 before the commercial Stripe routes are enabled. Step 0.3 deliberately does not edit the
runtime controller.
