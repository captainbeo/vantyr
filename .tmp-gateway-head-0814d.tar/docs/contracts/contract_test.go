package contracts_test

import (
	"bytes"
	"fmt"
	"io"
	"os"
	"reflect"
	"sort"
	"strings"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"gopkg.in/yaml.v3"
)

type routeRule struct {
	class, canonical, alias, enforcement, origin, csrf, tenant string
	security                                                   []map[string][]string
}

type customerSchemaBundle struct {
	Schema string                              `yaml:"$schema"`
	Defs   map[string]customerSchemaDefinition `yaml:"$defs"`
}

type customerSchemaDefinition struct {
	Type                 string         `yaml:"type"`
	AdditionalProperties *bool          `yaml:"additionalProperties"`
	Required             []string       `yaml:"required"`
	Properties           map[string]any `yaml:"properties"`
}

func TestCommercialCustomerAPIContract(t *testing.T) {
	openapi, err := os.ReadFile("customer-api.openapi.yaml")
	require.NoError(t, err)
	schemas, err := os.ReadFile("customer-api.schemas.yaml")
	require.NoError(t, err)
	stripe, err := os.ReadFile("stripe-events.md")
	require.NoError(t, err)
	sse, err := os.ReadFile("customer-api.sse.schemas.yaml")
	require.NoError(t, err)
	require.NoError(t, lintContractDocumentsWithSSE(openapi, schemas, sse, stripe))
}

func TestCustomerBrowserSchemaContract(t *testing.T) {
	data, err := os.ReadFile("customer-api.schemas.yaml")
	require.NoError(t, err)
	root, err := decodeYAMLBytes("customer-api.schemas.yaml", data)
	require.NoError(t, err)
	var bundle customerSchemaBundle
	require.NoError(t, root.Decode(&bundle))
	require.Equal(t, "https://json-schema.org/draft/2020-12/schema", bundle.Schema)
	browser := []string{
		"AuthBundleResponse", "BrowserErrorResponse", "CheckoutSessionResponse", "CurrentSubscriptionResponse",
		"CustomerAccountResponse", "CustomerModelListResponse", "GatewayKeyCreatedResponse",
		"GatewayKeyListResponse", "LogoutResponse", "PlanCatalogResponse", "PortalSessionResponse",
		"UsageLogPageResponse", "UsagePeriodsResponse", "UsageStatResponse",
	}
	want := append([]string{}, browser...)
	want = append(want, "CheckoutRequest", "CompactRequest", "CompactResponse", "CompactionItem", "CreateKeyRequest",
		"CustomerJSONValue", "CustomToolCallItem", "CustomToolCallOutputItem", "CustomToolDefinition", "FunctionCallItem", "FunctionCallOutputItem",
		"FunctionToolDefinition", "InputImageContent", "InputTextContent", "JSONSchemaDocument", "LoadableFunctionToolDefinition", "LoadableToolDefinition", "LoginRequest", "MessageContent",
		"MessageInputItem", "MessageOutputItem", "Model", "ModelList", "OpenAIError", "OpenAIErrorDetail", "OutputTextContent", "PortalRequest",
		"NamespaceToolDefinition", "ReasoningConfig", "ReasoningContentItem", "ReasoningInputItem", "ReasoningOutputItem", "ReasoningSummaryItem", "ResponseItem", "ResponseObject", "ResponseOutputItem",
		"ResponseRequest", "ServiceTier", "StripeWebhookPayload", "TextControls", "ToolDefinition", "ToolOutputContent", "ToolSearchCallItem",
		"ToolSearchDefinition", "ToolSearchOutputItem", "Usage")
	sort.Strings(want)
	require.Equal(t, want, sortedKeys(bundle.Defs), "customer schema inventory")
	for _, name := range browser {
		schema := bundle.Defs[name]
		assert.Equal(t, "object", schema.Type, "%s type", name)
		require.NotNil(t, schema.AdditionalProperties, "%s additionalProperties", name)
		assert.False(t, *schema.AdditionalProperties, "%s must be closed", name)
		fields := []string{"data", "message", "success"}
		if name == "BrowserErrorResponse" {
			fields = []string{"code", "message", "success"}
		}
		assertSameStrings(t, schema.Required, fields, name+" required fields")
		assertSameStrings(t, sortedKeys(schema.Properties), fields, name+" property inventory")
	}
}

func TestStripeEventContract(t *testing.T) {
	openapi, err := os.ReadFile("customer-api.openapi.yaml")
	require.NoError(t, err)
	schemas, err := os.ReadFile("customer-api.schemas.yaml")
	require.NoError(t, err)
	stripe, err := os.ReadFile("stripe-events.md")
	require.NoError(t, err)
	sse, err := os.ReadFile("customer-api.sse.schemas.yaml")
	require.NoError(t, err)
	require.NoError(t, lintContractDocumentsWithSSE(openapi, schemas, sse, stripe))
}

func lintContractDocuments(openapiData, schemaData, stripeData []byte) error {
	sseData, err := os.ReadFile("customer-api.sse.schemas.yaml")
	if err != nil {
		return err
	}
	return lintContractDocumentsWithSSE(openapiData, schemaData, sseData, stripeData)
}

func lintContractDocumentsWithSSE(openapiData, schemaData, sseData, stripeData []byte) error {
	if err := lintContractArtifactLineCounts(map[string][]byte{
		"customer-api.openapi.yaml":     openapiData,
		"customer-api.schemas.yaml":     schemaData,
		"customer-api.sse.schemas.yaml": sseData,
		"stripe-events.md":              stripeData,
	}); err != nil {
		return err
	}
	frontmatter, err := frontmatterBytes(stripeData)
	if err != nil {
		return err
	}
	openapi, err := decodeYAMLBytes("customer-api.openapi.yaml", openapiData)
	if err != nil {
		return err
	}
	schemas, err := decodeYAMLBytes("customer-api.schemas.yaml", schemaData)
	if err != nil {
		return err
	}
	sse, err := decodeYAMLBytes("customer-api.sse.schemas.yaml", sseData)
	if err != nil {
		return err
	}
	stripe, err := decodeYAMLBytes("stripe-events.md frontmatter", frontmatter)
	if err != nil {
		return err
	}
	if value(openapi, "openapi") != "3.1.0" {
		return fmt.Errorf("OpenAPI version must be 3.1.0")
	}
	if value(schemas, "$schema") != "https://json-schema.org/draft/2020-12/schema" {
		return fmt.Errorf("external schemas must use JSON Schema 2020-12")
	}
	if err := lintReferences(openapi, schemas, sse, "openapi"); err != nil {
		return err
	}
	if err := lintReferences(schemas, schemas, sse, "schemas"); err != nil {
		return err
	}
	if err := lintOpenAPI(openapi); err != nil {
		return err
	}
	if err := lintOpenAPISchemas(openapi); err != nil {
		return err
	}
	if err := lintStandards(openapiData, schemaData, sseData); err != nil {
		return err
	}
	defs := child(schemas, "$defs")
	if defs == nil || defs.Kind != yaml.MappingNode {
		return fmt.Errorf("$defs must be an object")
	}
	for i := 0; i < len(defs.Content); i += 2 {
		if err := lintSchema(defs.Content[i+1], "$defs."+defs.Content[i].Value); err != nil {
			return err
		}
	}
	if err := lintSchemaPropertyInventoryCoverage(schemas); err != nil {
		return err
	}
	if value(schemas, "$defs", "ResponseRequest", "properties", "tool_choice", "const") != "auto" || !sameStrings(stringsAt(schemas, "$defs", "ServiceTier", "enum"), []string{"default", "priority", "flex"}) {
		return fmt.Errorf("Codex tool_choice or service_tier contract is not pinned to 0.146.0")
	}
	if !sameStrings(stringsAt(schemas, "$defs", "ReasoningConfig", "properties", "effort", "enum"), []string{"none", "minimal", "low", "medium", "high", "xhigh", "max", "ultra"}) || !sameStrings(stringsAt(schemas, "$defs", "ReasoningConfig", "properties", "summary", "enum"), []string{"auto", "concise", "detailed", "none"}) || !sameStrings(stringsAt(schemas, "$defs", "ReasoningConfig", "properties", "context", "enum"), []string{"auto", "current_turn", "all_turns"}) {
		return fmt.Errorf("Codex reasoning contract is not pinned to 0.146.0")
	}
	tools := referenceList(child(schemas, "$defs", "ToolDefinition", "oneOf"))
	if !reflect.DeepEqual(tools, []string{"#/$defs/FunctionToolDefinition", "#/$defs/NamespaceToolDefinition", "#/$defs/ToolSearchDefinition", "#/$defs/CustomToolDefinition"}) {
		return fmt.Errorf("Codex tool union is not pinned to supported 0.146.0 tools")
	}
	toolOutputChoices := child(schemas, "$defs", "ToolOutputContent", "oneOf")
	var toolOutputItems []string
	if toolOutputChoices != nil && len(toolOutputChoices.Content) == 2 {
		toolOutputItems = referenceList(child(toolOutputChoices.Content[1], "items", "oneOf"))
	}
	if !reflect.DeepEqual(toolOutputItems, []string{"#/$defs/InputTextContent", "#/$defs/InputImageContent"}) ||
		!reflect.DeepEqual(stringsAt(schemas, "$defs", "ToolOutputContent", "x-codex-intentionally-unsupported-content-item-types"), []string{"input_audio", "encrypted_content"}) {
		return fmt.Errorf("Codex tool output content contract is not pinned to supported 0.146.0 variants")
	}
	if err := lintPublicErrorCodeAuthority(openapi, schemas, sse); err != nil {
		return err
	}
	if err := lintUsageAccountingAuthority(schemas, sse); err != nil {
		return err
	}
	if err := lintExactSchemaAuthority(schemas, sse, openapi); err != nil {
		return err
	}
	if err := lintSSEContract(sse); err != nil {
		return err
	}
	if err := lintStripe(stripe); err != nil {
		return err
	}
	return lintStripeOpenAPIParity(openapi, stripe)
}

func decodeYAMLBytes(name string, data []byte) (*yaml.Node, error) {
	decoder := yaml.NewDecoder(bytes.NewReader(data))
	var root, extra yaml.Node
	if err := decoder.Decode(&root); err != nil {
		return nil, fmt.Errorf("parse %s: %w", name, err)
	}
	if err := decoder.Decode(&extra); err != io.EOF {
		return nil, fmt.Errorf("%s must contain one YAML document", name)
	}
	if err := lintKeys(&root, name); err != nil {
		return nil, err
	}
	return &root, nil
}

func lintKeys(node *yaml.Node, path string) error {
	if node.Kind == yaml.MappingNode {
		seen := map[string]bool{}
		for i := 0; i < len(node.Content); i += 2 {
			key := node.Content[i]
			if key.Kind != yaml.ScalarNode || seen[key.Value] {
				return fmt.Errorf("%s has duplicate or invalid key %q", path, key.Value)
			}
			seen[key.Value] = true
			if err := lintKeys(node.Content[i+1], path+"."+key.Value); err != nil {
				return err
			}
		}
		return nil
	}
	for _, item := range node.Content {
		if err := lintKeys(item, path); err != nil {
			return err
		}
	}
	return nil
}

func lintReferences(root, external, sse *yaml.Node, owner string) error {
	var walk func(*yaml.Node) error
	walk = func(node *yaml.Node) error {
		if node.Kind == yaml.MappingNode {
			for i := 0; i < len(node.Content); i += 2 {
				key, target := node.Content[i], node.Content[i+1]
				if key.Value == "$ref" {
					if target.Kind != yaml.ScalarNode {
						return fmt.Errorf("%s has non-scalar $ref", owner)
					}
					ref, targetRoot := target.Value, root
					if strings.HasPrefix(ref, "./customer-api.schemas.yaml#/") {
						targetRoot, ref = external, strings.TrimPrefix(ref, "./customer-api.schemas.yaml")
					} else if strings.HasPrefix(ref, "./customer-api.sse.schemas.yaml#/") {
						targetRoot, ref = sse, strings.TrimPrefix(ref, "./customer-api.sse.schemas.yaml")
					} else if !strings.HasPrefix(ref, "#/") {
						return fmt.Errorf("%s has unapproved ref %q", owner, ref)
					}
					resolved := pointerNode(targetRoot, ref)
					if resolved == nil || resolved.Kind != yaml.MappingNode {
						return fmt.Errorf("unresolved or invalid ref %q", target.Value)
					}
				}
				if err := walk(target); err != nil {
					return err
				}
			}
			return nil
		}
		for _, item := range node.Content {
			if err := walk(item); err != nil {
				return err
			}
		}
		return nil
	}
	return walk(root)
}

func lintOpenAPISchemas(root *yaml.Node) error {
	components := child(root, "components", "schemas")
	if components == nil || components.Kind != yaml.MappingNode {
		return fmt.Errorf("components.schemas must be an object")
	}
	for i := 0; i < len(components.Content); i += 2 {
		if err := lintSchema(components.Content[i+1], "components.schemas."+components.Content[i].Value); err != nil {
			return err
		}
	}
	var walk func(*yaml.Node, string) error
	walk = func(node *yaml.Node, path string) error {
		if node.Kind != yaml.MappingNode {
			for _, item := range node.Content {
				if err := walk(item, path); err != nil {
					return err
				}
			}
			return nil
		}
		for i := 0; i < len(node.Content); i += 2 {
			key, item := node.Content[i].Value, node.Content[i+1]
			if key == "schema" {
				if containsMappingKey(item, "$schema") {
					return fmt.Errorf("inline JSON Schema dialect override is forbidden")
				}
				if err := lintSchema(item, path+".schema"); err != nil {
					return err
				}
			} else if err := walk(item, path+"."+key); err != nil {
				return err
			}
		}
		return nil
	}
	return walk(root, "openapi")
}

func lintOpenAPI(root *yaml.Node) error {
	if child(root, "servers") != nil {
		return fmt.Errorf("root OpenAPI servers are forbidden")
	}
	if child(root, "webhooks") != nil {
		return fmt.Errorf("root OpenAPI webhooks are forbidden")
	}
	if value(root, "jsonSchemaDialect") != "https://json-schema.org/draft/2020-12/schema" {
		return fmt.Errorf("root OpenAPI jsonSchemaDialect mismatch")
	}
	paths := child(root, "paths")
	if paths == nil || paths.Kind != yaml.MappingNode {
		return fmt.Errorf("paths must be an object")
	}
	actual, operationIDs := map[string]*yaml.Node{}, map[string]bool{}
	for i := 0; i < len(paths.Content); i += 2 {
		path, item := paths.Content[i].Value, paths.Content[i+1]
		if !strings.HasPrefix(path, "/") || item.Kind != yaml.MappingNode {
			return fmt.Errorf("invalid path %q", path)
		}
		for j := 0; j < len(item.Content); j += 2 {
			method, operation := item.Content[j].Value, item.Content[j+1]
			if method != "get" && method != "post" && method != "delete" {
				return fmt.Errorf("invalid or colliding method %q on %s", method, path)
			}
			key := strings.ToUpper(method) + " " + path
			if actual[key] != nil || operation.Kind != yaml.MappingNode {
				return fmt.Errorf("duplicate or invalid operation %s", key)
			}
			actual[key] = operation
			id := value(operation, "operationId")
			if id == "" || operationIDs[id] {
				return fmt.Errorf("missing or duplicate operationId %q", id)
			}
			operationIDs[id] = true
			if value(operation, "summary") == "" || child(operation, "responses") == nil {
				return fmt.Errorf("incomplete operation %s", key)
			}
			if method == "post" {
				body := child(operation, "requestBody")
				if body == nil || body.Kind != yaml.MappingNode || len(body.Content) == 0 {
					return fmt.Errorf("%s lacks a request body contract", key)
				}
			}
			wantStatuses := expectedStatuses(key)
			responses := child(operation, "responses")
			if responses == nil || !sameStrings(mappingKeys(responses), wantStatuses) {
				return fmt.Errorf("%s response status contract is incomplete", key)
			}
			if err := lintOperationContract(root, operation, key); err != nil {
				return err
			}
		}
	}
	if !sameStrings(sortedKeys(actual), sortedKeys(commercialRouteInventory())) {
		return fmt.Errorf("route inventory mismatch")
	}
	if value(root, "x-commercial-mode", "implementation-status") != "desired-commercial-contract" || decodedValue(root, "x-commercial-mode", "current-router-conformance") != false || decodedValue(root, "x-commercial-mode", "deny-by-default") != true || decodedValue(root, "x-commercial-mode", "browser-state-authoritative") != false {
		return fmt.Errorf("commercial-mode authority contract is invalid")
	}
	if !sameStrings(stringsAt(root, "x-commercial-mode", "customer-hidden-data"), []string{"admin-controls", "channel-configuration", "internal-costs", "other-customer-data", "upstream-credentials", "upstream-provider-identities"}) {
		return fmt.Errorf("customer-hidden-data contract is incomplete")
	}
	for route, want := range commercialRouteInventory() {
		op := actual[route]
		got := routeRule{
			class: value(op, "x-commercial-route-class"), canonical: value(op, "x-canonical-operation"),
			alias: value(op, "x-route-alias"), enforcement: value(op, "x-enforcement-pipeline"),
			origin: value(op, "x-origin-policy"), csrf: value(op, "x-csrf-policy"),
			tenant: value(op, "x-tenant-scope"),
		}
		if security := child(op, "security"); security != nil {
			_ = security.Decode(&got.security)
		}
		if !reflect.DeepEqual(got, want) {
			return fmt.Errorf("%s route policy mismatch", route)
		}
	}
	if err := lintSecuritySchemes(root); err != nil {
		return err
	}
	relayPolicy := map[string]any{
		"authentication.scheme":                      "authorization-bearer-only",
		"authentication.credential-owner":            "platform-gateway-key",
		"authentication.customer-credential-egress":  "forbidden",
		"validation.duplicate-json-keys":             "reject",
		"validation.max-decompressed-body-bytes":     8388608,
		"validation.max-string-bytes":                8388608,
		"validation.remote-media-urls":               "reject",
		"validation.schema-maxLength-unit":           "unicode-code-points",
		"validation.string-byte-count":               "utf8-octets",
		"validation.string-byte-limit-selection":     "operation-x-json-limits-when-present-otherwise-root",
		"validation.effective-string-limit":          "selected-utf8-byte-limit-and-schema-code-point-limit-both-apply",
		"validation.unknown-fields":                  "reject-sanitized-400",
		"validation.unsupported-fields":              "reject-sanitized-400",
		"validation.validation-order":                "decompressed-body-then-selected-string-bytes-then-schema-code-points",
		"request-headers.strip-all-others":           true,
		"response-headers.strip-all-upstream-others": true,
		"commitment.failover-before-commit-only":     true,
		"commitment.replay-after-commit":             false,
		"commitment.max-upstream-attempts":           2,
		"commitment.exclude-attempted-channel":       true,
		"commitment.logical-request-accounting":      "once",
		"timeouts.owner":                             "versioned-endpoint-class-reliability-policy",
		"timeouts.values":                            "positive-bounded-integers",
		"timeouts.attempt-budget":                    "minimum-of-configured-timeout-and-remaining-logical-precommit-budget",
		"timeouts.retry-budget":                      "remaining-logical-precommit-budget-only",
		"timeouts.exhausted-before-commit":           "terminal-timeout-no-further-attempt",
		"non-stream.max-response-bytes":              8388608,
		"non-stream.precommit-emission":              "absolute-silence",
		"non-stream.validation-before-commit":        "complete-bounded-response-and-schema",
		"non-stream.settlement-before-commit":        "durable-final-usage-attempt-and-logical-request",
		"non-stream.postcommit-replay":               false,
		"stream.max-stream-bytes":                    8388608,
		"stream.max-precommit-buffer-bytes":          1048576,
		"stream.precommit-emission":                  "absolute-silence",
		"stream.commitment-point":                    "first-semantic-event-after-durable-commit-fence",
		"stream.postcommit-replay":                   false,
		"stream.successful-terminal":                 "response.completed",
		"stream.successful-terminal-count":           1,
		"stream.committed-json-append":               false,
		"access-snapshot.precommit-revocation":       "cancel",
		"access-snapshot.committed-stream":           "may-finish",
		"access-snapshot.next-request":               "reject",
		"errors.shape":                               "openai-error-envelope",
		"errors.no-channel-code":                     "no_channel_available",
		"errors.no-channel-http-status":              503,
	}
	for path, want := range relayPolicy {
		if got := decodedValue(root, append([]string{"x-relay-contract"}, strings.Split(path, ".")...)...); !reflect.DeepEqual(got, want) {
			return fmt.Errorf("relay policy %s mismatch", path)
		}
	}
	for _, requestBody := range []string{"ResponseRequestBody", "CompactRequestBody"} {
		if got := decodedValue(root, "components", "requestBodies", requestBody, "x-json-limits", "string-bytes"); got != 8388608 {
			return fmt.Errorf("%s string-byte limit mismatch", requestBody)
		}
	}
	if err := lintRelayContractInventory(root); err != nil {
		return err
	}
	bodyOwners := map[string]string{
		"POST /v1/responses": "#/components/requestBodies/ResponseRequestBody", "POST /responses": "#/components/requestBodies/ResponseRequestBody",
		"POST /v1/responses/compact": "#/components/requestBodies/CompactRequestBody", "POST /responses/compact": "#/components/requestBodies/CompactRequestBody",
		"POST /api/user/auth/refresh": "#/components/requestBodies/EmptyCommand", "POST /api/user/auth/logout": "#/components/requestBodies/EmptyCommand",
	}
	for route, owner := range bodyOwners {
		if value(actual[route], "requestBody", "$ref") != owner {
			return fmt.Errorf("%s has wrong request body owner", route)
		}
	}
	for _, pair := range [][2]string{{"POST /v1/responses", "POST /responses"}, {"POST /v1/responses/compact", "POST /responses/compact"}, {"GET /v1/models", "GET /models"}, {"GET /v1/models/{model}", "GET /models/{model}"}} {
		for _, field := range []string{"requestBody", "responses", "security", "parameters", "x-commercial-route-class", "x-canonical-operation", "x-enforcement-pipeline", "x-origin-policy", "x-csrf-policy", "x-tenant-scope"} {
			if !reflect.DeepEqual(decodedValue(actual[pair[0]], field), decodedValue(actual[pair[1]], field)) {
				return fmt.Errorf("alias contract mismatch for %s field %s", pair[1], field)
			}
		}
	}
	inlineBodies := map[string]string{"POST /api/user/login": "#/components/schemas/LoginRequest", "POST /api/token": "#/components/schemas/CreateKeyRequest", "POST /api/subscription/stripe/checkout": "#/components/schemas/CheckoutRequest", "POST /api/subscription/stripe/portal": "#/components/schemas/PortalRequest", "POST /api/stripe/webhook": "./customer-api.schemas.yaml#/$defs/StripeWebhookPayload"}
	for route, owner := range inlineBodies {
		if decodedValue(actual[route], "requestBody", "required") != true || value(actual[route], "requestBody", "content", "application/json", "schema", "$ref") != owner {
			return fmt.Errorf("%s has incomplete inline request body", route)
		}
	}
	if value(root, "components", "responses", "AuthBundleSuccess", "headers", "Set-Cookie", "$ref") != "#/components/headers/RefreshCookieIssued" ||
		value(root, "components", "responses", "LogoutSuccess", "headers", "Set-Cookie", "$ref") != "#/components/headers/RefreshCookieCleared" {
		return fmt.Errorf("refresh cookie response lifecycle is incomplete")
	}
	if value(root, "components", "headers", "RefreshCookieIssued", "schema", "pattern") != refreshCookieIssuedPattern ||
		value(root, "components", "headers", "RefreshCookieCleared", "schema", "const") != refreshCookieClearedValue {
		return fmt.Errorf("refresh cookie wire values do not match the inherited session service")
	}
	return nil
}

func expectedStatuses(route string) []string {
	switch {
	case route == "GET /livez":
		return []string{"200"}
	case strings.Contains(route, "/models/{model}"):
		return strings.Fields("200 401 403 404 503")
	case route == "GET /models" || route == "GET /v1/models":
		return strings.Fields("200 401 403 503")
	case strings.Contains(route, "/responses"):
		return strings.Fields("200 400 401 403 413 415 429 502 503")
	case route == "POST /api/user/login":
		return strings.Fields("200 400 401 429")
	case strings.Contains(route, "/api/user/auth/"):
		return strings.Fields("200 401 403 409")
	case route == "POST /api/token":
		return strings.Fields("201 400 401 403")
	case route == "DELETE /api/token/{id}":
		return strings.Fields("204 401 403 404")
	case route == "POST /api/subscription/stripe/checkout":
		return strings.Fields("200 400 401 403 409 503")
	case route == "POST /api/subscription/stripe/portal":
		return strings.Fields("200 400 401 403")
	case route == "POST /api/stripe/webhook":
		return strings.Fields("200 400 409 413 503")
	default:
		return strings.Fields("200 401")
	}
}

func child(node *yaml.Node, keys ...string) *yaml.Node {
	if node == nil {
		return nil
	}
	if node.Kind == yaml.DocumentNode && len(node.Content) > 0 {
		node = node.Content[0]
	}
	for _, key := range keys {
		if node.Kind != yaml.MappingNode {
			return nil
		}
		var next *yaml.Node
		for i := 0; i < len(node.Content); i += 2 {
			if node.Content[i].Value == key {
				next = node.Content[i+1]
				break
			}
		}
		if next == nil {
			return nil
		}
		node = next
	}
	return node
}

func value(node *yaml.Node, keys ...string) string {
	if node = child(node, keys...); node != nil && node.Kind == yaml.ScalarNode {
		return node.Value
	}
	return ""
}
func decodedValue(node *yaml.Node, keys ...string) any {
	node = child(node, keys...)
	if node == nil {
		return nil
	}
	var result any
	if node.Decode(&result) != nil {
		return nil
	}
	return result
}
func stringsAt(node *yaml.Node, keys ...string) []string {
	node = child(node, keys...)
	if node == nil || node.Kind != yaml.SequenceNode {
		return nil
	}
	result := make([]string, len(node.Content))
	for i, item := range node.Content {
		result[i] = item.Value
	}
	return result
}
func mappingKeys(node *yaml.Node) []string {
	if node == nil || node.Kind != yaml.MappingNode {
		return nil
	}
	result := make([]string, 0, len(node.Content)/2)
	for i := 0; i < len(node.Content); i += 2 {
		result = append(result, node.Content[i].Value)
	}
	return result
}
func sameStrings(left, right []string) bool {
	left, right = append([]string(nil), left...), append([]string(nil), right...)
	sort.Strings(left)
	sort.Strings(right)
	return len(left) == len(right) && strings.Join(left, "\x00") == strings.Join(right, "\x00")
}

func pointerNode(root *yaml.Node, pointer string) *yaml.Node {
	if !strings.HasPrefix(pointer, "#/") {
		return nil
	}
	node := root
	for _, raw := range strings.Split(strings.TrimPrefix(pointer, "#/"), "/") {
		node = child(node, strings.ReplaceAll(strings.ReplaceAll(raw, "~1", "/"), "~0", "~"))
		if node == nil {
			return nil
		}
	}
	return node
}

func frontmatterBytes(data []byte) ([]byte, error) {
	normalized := strings.ReplaceAll(string(data), "\r\n", "\n")
	if !strings.HasPrefix(normalized, "---\n") {
		return nil, fmt.Errorf("stripe-events.md lacks frontmatter")
	}
	end := strings.Index(normalized[4:], "\n---\n")
	if end < 0 {
		return nil, fmt.Errorf("stripe-events.md has no closing frontmatter")
	}
	return []byte(normalized[4 : 4+end]), nil
}

func commercialRouteInventory() map[string]routeRule {
	relay := func(canonical, alias string) routeRule {
		return routeRule{class: "relay", canonical: canonical, alias: alias, enforcement: "gateway-customer-v1", tenant: "gateway-key-customer", security: []map[string][]string{{"GatewayBearer": {}}}}
	}
	read := func() routeRule {
		return routeRule{class: "browser-read", tenant: "authenticated-customer", security: []map[string][]string{{"DashboardBearer": {}}}}
	}
	mutation := func() routeRule {
		return routeRule{class: "browser-mutation", origin: "exact-configured-origin", csrf: "not-applicable-dashboard-bearer", tenant: "authenticated-customer", security: []map[string][]string{{"DashboardBearer": {}}}}
	}
	refreshMutation := func() routeRule {
		return routeRule{class: "browser-refresh-mutation", origin: "exact-configured-origin", csrf: "origin-and-optional-auth-session-binding", tenant: "authenticated-customer", security: []map[string][]string{{"RefreshCookie": {}}}}
	}
	return map[string]routeRule{
		"GET /livez":                             {class: "health", tenant: "none", security: []map[string][]string{}},
		"GET /models":                            relay("models.list", "root-handler"),
		"GET /models/{model}":                    relay("models.retrieve", "root-handler"),
		"GET /v1/models":                         relay("models.list", "canonical-handler"),
		"GET /v1/models/{model}":                 relay("models.retrieve", "canonical-handler"),
		"POST /responses":                        relay("responses.create", "root-handler"),
		"POST /responses/compact":                relay("responses.compact", "root-handler"),
		"POST /v1/responses":                     relay("responses.create", "canonical-handler"),
		"POST /v1/responses/compact":             relay("responses.compact", "canonical-handler"),
		"POST /api/user/login":                   {class: "browser-login", origin: "exact-configured-origin", tenant: "none", security: []map[string][]string{}},
		"POST /api/user/auth/refresh":            refreshMutation(),
		"POST /api/user/auth/logout":             refreshMutation(),
		"GET /api/user/self":                     read(),
		"GET /api/user/models":                   read(),
		"GET /api/subscription/plans":            read(),
		"GET /api/subscription/self":             read(),
		"GET /api/token":                         read(),
		"POST /api/token":                        mutation(),
		"DELETE /api/token/{id}":                 mutation(),
		"GET /api/log/self":                      read(),
		"GET /api/log/self/stat":                 read(),
		"GET /api/data/self":                     read(),
		"POST /api/subscription/stripe/checkout": mutation(),
		"POST /api/subscription/stripe/portal":   mutation(),
		"POST /api/stripe/webhook":               {class: "webhook", tenant: "stripe-event", security: []map[string][]string{{"StripeSignature": {}}}},
	}
}

func successOwners() map[string]string {
	return map[string]string{
		"GET /livez":  "HealthSuccess",
		"GET /models": "ModelListSuccess", "GET /models/{model}": "ModelSuccess",
		"GET /v1/models": "ModelListSuccess", "GET /v1/models/{model}": "ModelSuccess",
		"POST /responses": "ResponseSuccess", "POST /responses/compact": "CompactSuccess",
		"POST /v1/responses": "ResponseSuccess", "POST /v1/responses/compact": "CompactSuccess",
		"POST /api/user/login": "AuthBundleSuccess", "POST /api/user/auth/refresh": "AuthBundleSuccess",
		"POST /api/user/auth/logout": "LogoutSuccess", "GET /api/user/self": "CustomerAccountSuccess",
		"GET /api/user/models": "CustomerModelListSuccess", "GET /api/subscription/plans": "PlanCatalogSuccess",
		"GET /api/subscription/self": "CurrentSubscriptionSuccess", "GET /api/token": "GatewayKeyListSuccess",
		"POST /api/token": "GatewayKeyCreatedSuccess", "GET /api/log/self": "UsageLogPageSuccess",
		"GET /api/log/self/stat": "UsageStatSuccess", "GET /api/data/self": "UsagePeriodsSuccess",
		"POST /api/subscription/stripe/checkout": "CheckoutSessionSuccess",
		"POST /api/subscription/stripe/portal":   "PortalSessionSuccess",
		"DELETE /api/token/{id}":                 "NoContentSuccess",
		"POST /api/stripe/webhook":               "WebhookAcknowledged",
	}
}

func assertSameStrings(t *testing.T, got, want []string, field string) {
	t.Helper()
	got = append([]string(nil), got...)
	want = append([]string(nil), want...)
	sort.Strings(got)
	sort.Strings(want)
	assert.Equal(t, want, got, field)
}

func sortedKeys[T any](values map[string]T) []string {
	keys := make([]string, 0, len(values))
	for key := range values {
		keys = append(keys, key)
	}
	sort.Strings(keys)
	return keys
}
