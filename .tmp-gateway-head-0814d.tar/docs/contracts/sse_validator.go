package contracts

import (
	"bytes"
	"embed"
	"fmt"
	"sync"

	"github.com/QuantumNous/new-api/common"
	"github.com/santhosh-tekuri/jsonschema/v6"
	"gopkg.in/yaml.v3"
)

const (
	customerSchemaResource = "https://contracts.invalid/customer-api.schemas.yaml"
	sseSchemaResource      = "https://contracts.invalid/customer-api.sse.schemas.yaml"
)

//go:embed customer-api.schemas.yaml customer-api.sse.schemas.yaml
var commercialContractFiles embed.FS

var (
	commercialSSESchemaOnce sync.Once
	commercialSSESchema     *jsonschema.Schema
	commercialSSESchemaErr  error

	commercialResponseSchemaOnce sync.Once
	commercialResponseSchema     *jsonschema.Schema
	commercialResponseSchemaErr  error

	commercialCompactResponseSchemaOnce sync.Once
	commercialCompactResponseSchema     *jsonschema.Schema
	commercialCompactResponseSchemaErr  error
)

func ValidateCommercialResponseObject(data []byte) error {
	schema, err := getCommercialResponseObjectSchema()
	if err != nil {
		return err
	}
	var response any
	if err := common.Unmarshal(data, &response); err != nil {
		return fmt.Errorf("commercial response is invalid: %w", err)
	}
	if _, ok := response.(map[string]any); !ok {
		return fmt.Errorf("commercial response is not an object")
	}
	return schema.Validate(response)
}

func ValidateCommercialCompactResponse(data []byte) error {
	schema, err := getCommercialCompactResponseSchema()
	if err != nil {
		return err
	}
	var response any
	if err := common.Unmarshal(data, &response); err != nil {
		return fmt.Errorf("commercial compact response is invalid: %w", err)
	}
	return schema.Validate(response)
}

func ValidateCommercialSSEFrame(eventName string, data []byte) error {
	schema, err := getCommercialSSEFrameSchema()
	if err != nil {
		return err
	}
	var eventData any
	if err := common.Unmarshal(data, &eventData); err != nil {
		return fmt.Errorf("commercial SSE data is invalid: %w", err)
	}
	eventObject, ok := eventData.(map[string]any)
	if !ok {
		return fmt.Errorf("commercial SSE data is not an object")
	}
	dataType, ok := eventObject["type"].(string)
	if !ok || dataType == "" {
		return fmt.Errorf("commercial SSE data type is unavailable")
	}
	if eventName == "" {
		eventName = dataType
	}
	return schema.Validate(map[string]any{"event": eventName, "data": eventData})
}

func getCommercialSSEFrameSchema() (*jsonschema.Schema, error) {
	commercialSSESchemaOnce.Do(func() {
		compiler := jsonschema.NewCompiler()
		compiler.DefaultDraft(jsonschema.Draft2020)
		compiler.UseLoader(commercialContractLoader{})

		customerDocument, err := decodeEmbeddedContract("customer-api.schemas.yaml")
		if err != nil {
			commercialSSESchemaErr = err
			return
		}
		if err := compiler.AddResource(customerSchemaResource, customerDocument); err != nil {
			commercialSSESchemaErr = err
			return
		}
		sseDocument, err := decodeEmbeddedContract("customer-api.sse.schemas.yaml")
		if err != nil {
			commercialSSESchemaErr = err
			return
		}
		if err := compiler.AddResource(sseSchemaResource, sseDocument); err != nil {
			commercialSSESchemaErr = err
			return
		}
		commercialSSESchema, commercialSSESchemaErr = compiler.Compile(sseSchemaResource + "#/$defs/SSEFrame")
	})
	return commercialSSESchema, commercialSSESchemaErr
}

func getCommercialResponseObjectSchema() (*jsonschema.Schema, error) {
	commercialResponseSchemaOnce.Do(func() {
		compiler := jsonschema.NewCompiler()
		compiler.DefaultDraft(jsonschema.Draft2020)
		compiler.UseLoader(commercialContractLoader{})

		customerDocument, err := decodeEmbeddedContract("customer-api.schemas.yaml")
		if err != nil {
			commercialResponseSchemaErr = err
			return
		}
		if err := compiler.AddResource(customerSchemaResource, customerDocument); err != nil {
			commercialResponseSchemaErr = err
			return
		}
		commercialResponseSchema, commercialResponseSchemaErr = compiler.Compile(customerSchemaResource + "#/$defs/ResponseObject")
	})
	return commercialResponseSchema, commercialResponseSchemaErr
}

func getCommercialCompactResponseSchema() (*jsonschema.Schema, error) {
	commercialCompactResponseSchemaOnce.Do(func() {
		compiler := jsonschema.NewCompiler()
		compiler.DefaultDraft(jsonschema.Draft2020)
		compiler.UseLoader(commercialContractLoader{})

		customerDocument, err := decodeEmbeddedContract("customer-api.schemas.yaml")
		if err != nil {
			commercialCompactResponseSchemaErr = err
			return
		}
		if err := compiler.AddResource(customerSchemaResource, customerDocument); err != nil {
			commercialCompactResponseSchemaErr = err
			return
		}
		commercialCompactResponseSchema, commercialCompactResponseSchemaErr = compiler.Compile(customerSchemaResource + "#/$defs/CompactResponse")
	})
	return commercialCompactResponseSchema, commercialCompactResponseSchemaErr
}

func decodeEmbeddedContract(name string) (any, error) {
	data, err := commercialContractFiles.ReadFile(name)
	if err != nil {
		return nil, err
	}
	decoder := yaml.NewDecoder(bytes.NewReader(data))
	var root yaml.Node
	if err := decoder.Decode(&root); err != nil {
		return nil, err
	}
	var document any
	if err := root.Decode(&document); err != nil {
		return nil, err
	}
	return document, nil
}

type commercialContractLoader struct{}

func (commercialContractLoader) Load(resourceURL string) (any, error) {
	return nil, fmt.Errorf("unregistered contract resource %s", resourceURL)
}
