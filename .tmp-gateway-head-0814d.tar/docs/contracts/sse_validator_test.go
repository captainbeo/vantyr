package contracts_test

import (
	"testing"

	contracts "github.com/QuantumNous/new-api/docs/contracts"
	"github.com/stretchr/testify/require"
)

func TestValidateCommercialSSEFrameUsesCanonicalContract(t *testing.T) {
	valid := []byte(`{"type":"response.output_text.delta","sequence_number":1,"item_id":"item_1","output_index":0,"content_index":0,"delta":"hello"}`)
	require.NoError(t, contracts.ValidateCommercialSSEFrame("", valid))
	require.NoError(t, contracts.ValidateCommercialSSEFrame("response.output_text.delta", valid))

	for _, test := range []struct {
		name      string
		eventName string
		data      string
	}{
		{"unknown event", "", `{"type":"vendor.private","secret":"sentinel"}`},
		{"missing required fields", "", `{"type":"response.output_text.delta","delta":"hello"}`},
		{"forbidden vendor field", "", `{"type":"response.output_text.delta","sequence_number":1,"item_id":"item_1","output_index":0,"content_index":0,"delta":"hello","vendor":"sentinel"}`},
		{"event discriminator mismatch", "response.completed", string(valid)},
	} {
		t.Run(test.name, func(t *testing.T) {
			require.Error(t, contracts.ValidateCommercialSSEFrame(test.eventName, []byte(test.data)))
		})
	}
}

func TestValidateCommercialResponseObjectUsesCanonicalContract(t *testing.T) {
	valid := []byte(`{"id":"resp_fixture","object":"response","status":"completed","model":"gpt-5.4","output":[],"usage":{"input_tokens":1,"output_tokens":1,"total_tokens":2}}`)
	require.NoError(t, contracts.ValidateCommercialResponseObject(valid))

	for _, test := range []struct {
		name string
		data string
	}{
		{"missing required model", `{"id":"resp_fixture","object":"response","status":"completed","output":[],"usage":{"input_tokens":1,"output_tokens":1,"total_tokens":2}}`},
		{"non-string model", `{"id":"resp_fixture","object":"response","status":"completed","model":42,"output":[],"usage":{"input_tokens":1,"output_tokens":1,"total_tokens":2}}`},
		{"forbidden vendor field", `{"id":"resp_fixture","object":"response","status":"completed","model":"gpt-5.4","output":[],"usage":{"input_tokens":1,"output_tokens":1,"total_tokens":2},"vendor":"sentinel"}`},
	} {
		t.Run(test.name, func(t *testing.T) {
			require.Error(t, contracts.ValidateCommercialResponseObject([]byte(test.data)))
		})
	}
}
