package contracts_test

import (
	"encoding/json"
	"fmt"
	"strconv"
	"strings"
	"testing/fstest"

	"github.com/pb33f/libopenapi"
	"github.com/pb33f/libopenapi/datamodel"
	"github.com/santhosh-tekuri/jsonschema/v6"
	"gopkg.in/yaml.v3"
)

const customerSchemaResource = "https://contracts.invalid/customer-api.schemas.yaml"
const sseSchemaResource = "https://contracts.invalid/customer-api.sse.schemas.yaml"
const openAPIContractResource = "https://contracts.invalid/customer-api.openapi.yaml"
const openAPI31SchemaResource = "https://spec.openapis.org/oas/3.1/schema/2022-10-07"

func lintStandards(openapiData, schemaData, sseSchemaData []byte) error {
	configuration := datamodel.NewDocumentConfiguration()
	configuration.BasePath = "."
	configuration.LocalFS = fstest.MapFS{
		"customer-api.schemas.yaml":     &fstest.MapFile{Data: schemaData},
		"customer-api.sse.schemas.yaml": &fstest.MapFile{Data: sseSchemaData},
	}
	configuration.AllowFileReferences = true
	configuration.FileFilter = []string{"customer-api.schemas.yaml", "customer-api.sse.schemas.yaml"}
	document, err := libopenapi.NewDocumentWithConfiguration(openapiData, configuration)
	if err != nil {
		return fmt.Errorf("OpenAPI 3.1 parse: %w", err)
	}
	if _, err := document.BuildV3Model(); err != nil {
		return fmt.Errorf("OpenAPI 3.1 validation: %w", err)
	}
	root, err := decodeYAMLBytes("customer-api.schemas.yaml", schemaData)
	if err != nil {
		return err
	}
	var schemaDocument any
	if err := root.Decode(&schemaDocument); err != nil {
		return fmt.Errorf("JSON Schema 2020-12 decode: %w", err)
	}
	compiler := jsonschema.NewCompiler()
	compiler.DefaultDraft(jsonschema.Draft2020)
	compiler.AssertFormat()
	compiler.UseLoader(denyContractURLLoader{})
	if err := compiler.AddResource(customerSchemaResource, schemaDocument); err != nil {
		return fmt.Errorf("JSON Schema 2020-12 resource: %w", err)
	}
	if _, err := compiler.Compile(customerSchemaResource); err != nil {
		return fmt.Errorf("JSON Schema 2020-12 validation: %w", err)
	}
	sseRoot, err := decodeYAMLBytes("customer-api.sse.schemas.yaml", sseSchemaData)
	if err != nil {
		return err
	}
	var sseSchemaDocument any
	if err := sseRoot.Decode(&sseSchemaDocument); err != nil {
		return fmt.Errorf("SSE JSON Schema 2020-12 decode: %w", err)
	}
	if err := compiler.AddResource(sseSchemaResource, sseSchemaDocument); err != nil {
		return fmt.Errorf("SSE JSON Schema 2020-12 resource: %w", err)
	}
	if _, err := compiler.Compile(sseSchemaResource); err != nil {
		return fmt.Errorf("SSE JSON Schema 2020-12 validation: %w", err)
	}
	openapiRoot, err := decodeYAMLBytes("customer-api.openapi.yaml", openapiData)
	if err != nil {
		return err
	}
	if err := validateOpenAPI31Document(openapiRoot); err != nil {
		return err
	}
	if err := validateOpenAPIInlineSchemas(openapiRoot, schemaData, sseSchemaData); err != nil {
		return err
	}
	return nil
}

func validateOpenAPI31Document(root *yaml.Node) error {
	var document any
	if err := root.Decode(&document); err != nil {
		return fmt.Errorf("OpenAPI 3.1 document decode: %w", err)
	}
	var metaDocument any
	if err := json.Unmarshal([]byte(datamodel.OpenAPI31SchemaData), &metaDocument); err != nil {
		return fmt.Errorf("OpenAPI 3.1 metaschema decode: %w", err)
	}
	compiler := jsonschema.NewCompiler()
	compiler.DefaultDraft(jsonschema.Draft2020)
	compiler.AssertFormat()
	if err := compiler.AddResource(openAPI31SchemaResource, metaDocument); err != nil {
		return fmt.Errorf("OpenAPI 3.1 metaschema resource: %w", err)
	}
	metaSchema, err := compiler.Compile(openAPI31SchemaResource)
	if err != nil {
		return fmt.Errorf("OpenAPI 3.1 metaschema compile: %w", err)
	}
	if err := metaSchema.Validate(document); err != nil {
		return fmt.Errorf("OpenAPI 3.1 document validation: %w", err)
	}
	return nil
}

type denyContractURLLoader struct{}

func (denyContractURLLoader) Load(url string) (any, error) {
	return nil, fmt.Errorf("unregistered contract resource %s", url)
}

type openAPISchemaLocation struct {
	pointer, path string
}

func validateOpenAPIInlineSchemas(root *yaml.Node, externalSchemaData, sseSchemaData []byte) error {
	var openapiDocument any
	if err := root.Decode(&openapiDocument); err != nil {
		return fmt.Errorf("OpenAPI inline schema document decode: %w", err)
	}
	externalRoot, err := decodeYAMLBytes("customer-api.schemas.yaml", externalSchemaData)
	if err != nil {
		return err
	}
	var externalDocument any
	if err := externalRoot.Decode(&externalDocument); err != nil {
		return fmt.Errorf("OpenAPI external schema document decode: %w", err)
	}
	compiler := jsonschema.NewCompiler()
	compiler.DefaultDraft(jsonschema.Draft2020)
	compiler.AssertFormat()
	compiler.UseLoader(denyContractURLLoader{})
	if err := compiler.AddResource(openAPIContractResource, openapiDocument); err != nil {
		return fmt.Errorf("OpenAPI inline schema resource: %w", err)
	}
	if err := compiler.AddResource(customerSchemaResource, externalDocument); err != nil {
		return fmt.Errorf("OpenAPI external schema resource: %w", err)
	}
	sseRoot, err := decodeYAMLBytes("customer-api.sse.schemas.yaml", sseSchemaData)
	if err != nil {
		return err
	}
	var sseDocument any
	if err := sseRoot.Decode(&sseDocument); err != nil {
		return fmt.Errorf("OpenAPI SSE schema document decode: %w", err)
	}
	if err := compiler.AddResource(sseSchemaResource, sseDocument); err != nil {
		return fmt.Errorf("OpenAPI SSE schema resource: %w", err)
	}
	for _, location := range collectOpenAPISchemaLocations(root) {
		if _, err := compiler.Compile(openAPIContractResource + "#" + location.pointer); err != nil {
			return fmt.Errorf("OpenAPI inline schema validation at %s: %w", location.path, err)
		}
	}
	return nil
}

func collectOpenAPISchemaLocations(root *yaml.Node) []openAPISchemaLocation {
	locations := []openAPISchemaLocation{}
	var walk func(*yaml.Node, string, string)
	walk = func(node *yaml.Node, pointer, path string) {
		if node.Kind == yaml.DocumentNode {
			walk(node.Content[0], pointer, path)
			return
		}
		if node.Kind == yaml.SequenceNode {
			for index, item := range node.Content {
				segment := strconv.Itoa(index)
				walk(item, pointer+"/"+segment, strings.TrimPrefix(path+"."+segment, "."))
			}
			return
		}
		if node.Kind != yaml.MappingNode {
			return
		}
		for index := 0; index < len(node.Content); index += 2 {
			key, item := node.Content[index].Value, node.Content[index+1]
			itemPointer := pointer + "/" + strings.ReplaceAll(strings.ReplaceAll(key, "~", "~0"), "/", "~1")
			itemPath := strings.TrimPrefix(path+"."+key, ".")
			if key == "schema" || path == "components.schemas" {
				locations = append(locations, openAPISchemaLocation{pointer: itemPointer, path: itemPath})
				continue
			}
			walk(item, itemPointer, itemPath)
		}
	}
	walk(root, "", "")
	return locations
}
