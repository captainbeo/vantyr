package contracts_test

import (
	"os"
	"strings"
	"testing"

	"github.com/stretchr/testify/require"
)

func TestContractLintRejectsUnsafeMutations(t *testing.T) {
	openapi, err := os.ReadFile("customer-api.openapi.yaml")
	require.NoError(t, err)
	schemas, err := os.ReadFile("customer-api.schemas.yaml")
	require.NoError(t, err)
	sse, err := os.ReadFile("customer-api.sse.schemas.yaml")
	require.NoError(t, err)
	stripe, err := os.ReadFile("stripe-events.md")
	require.NoError(t, err)

	tests := []struct {
		name       string
		document   string
		old, new   string
		appendText string
		wantError  string
	}{
		{"nested external ref", "schemas", "success: {type: boolean, const: true}", "success: {$ref: \"#/$defs/Missing\"}", "", `unresolved or invalid ref "#/$defs/Missing"`},
		{"non-scalar ref", "openapi", `schema: {$ref: "#/components/schemas/ModelList"}`, "schema: {$ref: [not, scalar]}", "", "openapi has non-scalar $ref"},
		{"scalar referenced response", "openapi", `BrowserBadRequest: {$ref: "#/components/responses/BrowserError"}`, "BrowserBadRequest: false", "", `unresolved or invalid ref "#/components/responses/BrowserBadRequest"`},
		{"invalid inline schema", "openapi", "status: {type: string, const: ok}", "status: {type: stringish, const: ok}", "", `HealthSuccess.content.application/json.schema.properties.status has invalid type "stringish"`},
		{"unknown root OpenAPI field", "openapi", "openapi: 3.1.0\n", "openapi: 3.1.0\nunknownRoot: true\n", "", "OpenAPI 3.1 document validation"},
		{"invalid inline regex", "openapi", `schema: {type: string, minLength: 1, maxLength: 128, pattern: "^[A-Za-z0-9._-]+$"}`, `schema: {type: string, minLength: 1, maxLength: 128, pattern: "["}`, "", "OpenAPI inline schema validation at components.parameters.PublicModel.schema"},
		{"negative inline bound", "openapi", `schema: {type: string, minLength: 1, maxLength: 128, pattern: "^[A-Za-z0-9._-]+$"}`, `schema: {type: string, minLength: 1, maxLength: -1, pattern: "^[A-Za-z0-9._-]+$"}`, "", "OpenAPI inline schema validation at components.parameters.PublicModel.schema"},
		{"uppercase method", "openapi", "    get:\n", "    GET:\n", "", `invalid or colliding method "GET" on /livez`},
		{"method collision", "openapi", "  /livez:\n    get:\n", "  /livez:\n    GET: {}\n    get:\n", "", `invalid or colliding method "GET" on /livez`},
		{"root server authority", "openapi", "  description: Desired invite-only contract; pinned inherited routers must prove conformance later.\n", "  description: Desired invite-only contract; pinned inherited routers must prove conformance later.\nservers: [{url: https://internal.invalid}]\n", "", "root OpenAPI servers are forbidden"},
		{"root webhook authority", "openapi", "paths:\n", "webhooks:\n  supplierEvent:\n    post:\n      operationId: supplierEvent\n      responses: {\"200\": {description: accepted}}\npaths:\n", "", "root OpenAPI webhooks are forbidden"},
		{"root schema dialect drift", "openapi", "jsonSchemaDialect: https://json-schema.org/draft/2020-12/schema", "jsonSchemaDialect: https://json-schema.org/draft/2019-09/schema", "", "root OpenAPI jsonSchemaDialect mismatch"},
		{"inline schema dialect drift", "openapi", `schema: {type: string, minLength: 1, maxLength: 128, pattern: "^[A-Za-z0-9._-]+$"}`, `schema: {$schema: "https://json-schema.org/draft/2019-09/schema", type: string, minLength: 1, maxLength: 128, pattern: "^[A-Za-z0-9._-]+$"}`, "", "inline JSON Schema dialect override is forbidden"},
		{"wrong alias response owner", "openapi", `{$ref: "#/components/responses/ResponseSuccess"}`, `{$ref: "#/components/responses/CompactSuccess"}`, "", "POST /v1/responses status 200 has wrong response owner"},
		{"alias operation server override", "openapi", "operationId: listModelsRoot", "operationId: listModelsRoot\n      servers: [{url: https://internal.invalid}]", "", "GET /models has unapproved operation field servers"},
		{"wrong relay error response owner", "openapi", `#/components/responses/Unauthorized`, `#/components/responses/Forbidden`, "", "GET /v1/models status 401 has wrong response owner"},
		{"wrong browser error response owner", "openapi", `#/components/responses/BrowserUnauthorized`, `#/components/responses/BrowserForbidden`, "", "POST /api/user/login status 401 has wrong response owner"},
		{"livez response contract drift", "openapi", "status: {type: string, const: ok}", "status: {type: string, const: configured}", "", "GET /livez health response is not detail-free"},
		{"wrong delete success owner", "openapi", `"204": {$ref: "#/components/responses/NoContentSuccess"}`, `"204": {$ref: "#/components/responses/WebhookAcknowledged"}`, "", "DELETE /api/token/{id} status 204 has wrong response owner"},
		{"wrong webhook success owner", "openapi", `"200": {$ref: "#/components/responses/WebhookAcknowledged"}`, `"200": {$ref: "#/components/responses/NoContentSuccess"}`, "", "POST /api/stripe/webhook status 200 has wrong response owner"},
		{"wrong request owner", "openapi", `requestBody: {$ref: "#/components/requestBodies/ResponseRequestBody"}`, `requestBody: {$ref: "#/components/requestBodies/CompactRequestBody"}`, "", "POST /v1/responses has wrong request body owner"},
		{"wrong path parameter owner", "openapi", `- $ref: "#/components/parameters/PublicModel"`, `- $ref: "#/components/parameters/Origin"`, "", "GET /v1/models/{model} has wrong parameter owner"},
		{"incomplete request body", "openapi", `requestBody: {$ref: "#/components/requestBodies/ResponseRequestBody"}`, "requestBody: {}", "", "POST /v1/responses lacks a request body contract"},
		{"duplicate operation id", "openapi", "operationId: listModelsRoot", "operationId: listModelsCanonical", "", `missing or duplicate operationId "listModelsCanonical"`},
		{"wrong cookie response header", "openapi", `Set-Cookie: {$ref: "#/components/headers/RefreshCookieIssued"}`, `Set-Cookie: {$ref: "#/components/headers/RequestID"}`, "", "refresh cookie response lifecycle is incomplete"},
		{"cookie omits expires", "openapi", "Expires=", "Expiry=", "", "refresh cookie wire values do not match the inherited session service"},
		{"size byte limit drift", "openapi", "max-string-bytes: 8388608", "max-string-bytes: 1048576", "", "relay policy validation.max-string-bytes mismatch"},
		{"size unit drift", "openapi", "string-byte-count: utf8-octets", "string-byte-count: characters", "", "relay policy validation.string-byte-count mismatch"},
		{"size precedence drift", "openapi", "string-byte-limit-selection: operation-x-json-limits-when-present-otherwise-root", "string-byte-limit-selection: root-only", "", "relay policy validation.string-byte-limit-selection mismatch"},
		{"operation string limit drift", "openapi", "x-json-limits: {depth: 64, array-items: 4096, string-bytes: 8388608, tools: 128}", "x-json-limits: {depth: 64, array-items: 4096, string-bytes: 1048576, tools: 128}", "", "ResponseRequestBody string-byte limit mismatch"},
		{"turn-state header drift", "openapi", "x-codex-turn-state: {max-bytes: 8192", "x-codex-turn-state: {max-bytes: 1", "", "relay policy request-headers.constraints.x-codex-turn-state.max-bytes mismatch"},
		{"terminal SSE drift", "openapi", "required-terminal-fields: [nonempty-public-response-id, complete-usage]", "required-terminal-fields: [nonempty-public-response-id]", "", "relay policy stream.required-terminal-fields mismatch"},
		{"retryable outcome drift", "openapi", `"503", "504", "524"`, `"503", "504"`, "", "relay policy commitment.retryable-precommit-outcomes mismatch"},
		{"retryable channel configuration outcome drift", "openapi", "channel-model-404", "vendor-model-404", "", "relay policy commitment.retryable-precommit-outcomes mismatch"},
		{"timeout field inventory drift", "openapi", "nonstream_total_timeout_ms, logical_precommit_deadline_ms", "nonstream_total_timeout_ms", "", "relay policy timeouts.required-fields mismatch"},
		{"retry attempt budget drift", "openapi", "retry-budget: remaining-logical-precommit-budget-only", "retry-budget: full-timeout-per-attempt", "", "relay policy timeouts.retry-budget mismatch"},
		{"non-stream response limit drift", "openapi", "max-response-bytes: 8388608", "max-response-bytes: 0", "", "relay policy non-stream.max-response-bytes mismatch"},
		{"non-stream validation drift", "openapi", "validation-before-commit: complete-bounded-response-and-schema", "validation-before-commit: headers-only", "", "relay policy non-stream.validation-before-commit mismatch"},
		{"non-stream settlement durability drift", "openapi", "settlement-before-commit: durable-final-usage-attempt-and-logical-request", "settlement-before-commit: final-usage-attempt-and-logical-request", "", "relay policy non-stream.settlement-before-commit mismatch"},
		{"stream precommit buffer drift", "openapi", "max-precommit-buffer-bytes: 1048576", "max-precommit-buffer-bytes: 0", "", "relay policy stream.max-precommit-buffer-bytes mismatch"},
		{"SSE output widens to vendor fields", "sse", "additionalProperties: false\n    required: [type, sequence_number, response]", "additionalProperties: true\n    required: [type, sequence_number, response]", "", "SSE schema authority mismatch"},
		{"SSE event inventory accepts a vendor event", "sse", "response.completed]", "response.completed, response.vendor.private]", "", "SSE schema authority mismatch"},
		{"SSE encrypted reasoning removed", "schemas", "  ReasoningOutputItem:\n    type: object\n    additionalProperties: false\n    required: [type, id, summary]\n    properties:\n      type: {type: string, const: reasoning}\n      id: {type: string, minLength: 1, maxLength: 256}\n      summary: {type: array, maxItems: 128, items: {$ref: \"#/$defs/ReasoningSummaryItem\"}}\n      content: {type: array, maxItems: 128, items: {$ref: \"#/$defs/ReasoningContentItem\"}}\n      encrypted_content: {type: [string, \"null\"], maxLength: 8388608}\n", "  ReasoningOutputItem:\n    type: object\n    additionalProperties: false\n    required: [type, id, summary]\n    properties:\n      type: {type: string, const: reasoning}\n      id: {type: string, minLength: 1, maxLength: 256}\n      summary: {type: array, maxItems: 128, items: {$ref: \"#/$defs/ReasoningSummaryItem\"}}\n      content: {type: array, maxItems: 128, items: {$ref: \"#/$defs/ReasoningContentItem\"}}\n", "", "$defs.ReasoningOutputItem property inventory mismatch"},
		{"SSE encrypted reasoning widened", "schemas", "  ReasoningOutputItem:\n    type: object\n    additionalProperties: false\n    required: [type, id, summary]\n    properties:\n      type: {type: string, const: reasoning}\n      id: {type: string, minLength: 1, maxLength: 256}\n      summary: {type: array, maxItems: 128, items: {$ref: \"#/$defs/ReasoningSummaryItem\"}}\n      content: {type: array, maxItems: 128, items: {$ref: \"#/$defs/ReasoningContentItem\"}}\n      encrypted_content: {type: [string, \"null\"], maxLength: 8388608}", "  ReasoningOutputItem:\n    type: object\n    additionalProperties: false\n    required: [type, id, summary]\n    properties:\n      type: {type: string, const: reasoning}\n      id: {type: string, minLength: 1, maxLength: 256}\n      summary: {type: array, maxItems: 128, items: {$ref: \"#/$defs/ReasoningSummaryItem\"}}\n      content: {type: array, maxItems: 128, items: {$ref: \"#/$defs/ReasoningContentItem\"}}\n      encrypted_content: {type: [string, \"null\"], maxLength: 8388609}", "", "external schema authority mismatch"},
		{"SSE tool search removed", "schemas", ", {$ref: \"#/$defs/ToolSearchCallItem\"}, {$ref: \"#/$defs/ToolSearchOutputItem\"}", "", "", "external schema authority mismatch"},
		{"SSE tool search widened", "schemas", "{$ref: \"#/$defs/ToolSearchOutputItem\"}]", "{$ref: \"#/$defs/ToolSearchOutputItem\"}, {$ref: \"#/$defs/ResponseItem\"}]", "", "external schema authority mismatch"},
		{"response output owner widened to bidirectional items", "schemas", "output: {type: array, maxItems: 4096, items: {$ref: \"#/$defs/ResponseOutputItem\"}}", "output: {type: array, maxItems: 4096, items: {$ref: \"#/$defs/ResponseItem\"}}", "", "external schema authority mismatch"},
		{"SSE output owner diverges", "sse", "SSEOutputItem:\n    {$ref: \"./customer-api.schemas.yaml#/$defs/ResponseOutputItem\"}", "SSEOutputItem:\n    {$ref: \"./customer-api.schemas.yaml#/$defs/ResponseItem\"}", "", "SSE schema authority mismatch"},
		{"forbidden error data drift", "openapi", "      - credentials\n", "", "", "relay policy errors.forbidden-data mismatch"},
		{"nested leak field", "schemas", "username: {type: string, minLength: 1, maxLength: 128}", "internal_cost: {type: integer, minimum: 0}", "", "$defs.LoginRequest exposes forbidden field internal_cost"},
		{"camelcase internal cost leak", "schemas", "username: {type: string, minLength: 1, maxLength: 128}", "internalCost: {type: integer, minimum: 0}", "", "$defs.LoginRequest exposes forbidden field internalCost"},
		{"plural policy leak", "schemas", "namespace: {type: string, minLength: 1, maxLength: 128}", "internal_costs: {type: integer, minimum: 0}", "", "$defs.FunctionCallItem exposes forbidden field internal_costs"},
		{"camelcase upstream identity leak", "schemas", "namespace: {type: string, minLength: 1, maxLength: 128}", "upstreamProviderIdentity: {type: string}", "", "$defs.FunctionCallItem exposes forbidden field upstreamProviderIdentity"},
		{"generic channel leak", "schemas", "status: {type: string, enum: [active, inactive]}", "channel: {type: string}", "", "$defs.CustomerAccountResponse.properties.data exposes forbidden field channel"},
		{"generic provider leak", "schemas", "status: {type: string, enum: [active, inactive]}", "provider: {type: string}", "", "$defs.CustomerAccountResponse.properties.data exposes forbidden field provider"},
		{"supplier synonym leak", "schemas", "status: {type: string, enum: [active, inactive]}", "status: {type: string, enum: [active, inactive]}\n          supplier: {type: string}", "", "$defs.CustomerAccountResponse.properties.data property inventory mismatch"},
		{"margin synonym leak", "schemas", "quota_limit: {type: [integer, \"null\"], minimum: 1}\n          requests_used: {type: integer, minimum: 0}\n          input_tokens: {type: integer, minimum: 0}\n          output_tokens: {type: integer, minimum: 0}", "quota_limit: {type: [integer, \"null\"], minimum: 1}\n          requests_used: {type: integer, minimum: 0}\n          input_tokens: {type: integer, minimum: 0}\n          output_tokens: {type: integer, minimum: 0}\n          margin_microusd: {type: integer, minimum: 0}", "", "$defs.UsageStatResponse.properties.data property inventory mismatch"},
		{"pattern property leak", "schemas", "required: [success, code, message]\n    properties:\n      success:", "required: [success, code, message]\n    patternProperties: {\"^admin_controls$\": {type: string}}\n    properties:\n      success:", "", "$defs.BrowserErrorResponse exposes forbidden field ^admin_controls$"},
		{"pattern property provider leak", "schemas", "required: [success, code, message]\n    properties:\n      success:", "required: [success, code, message]\n    patternProperties: {\"^providerSlug$\": {type: string}}\n    properties:\n      success:", "", "$defs.BrowserErrorResponse exposes forbidden field ^providerSlug$"},
		{"pattern property supplier leak", "schemas", "required: [success, code, message]\n    properties:\n      success:", "required: [success, code, message]\n    patternProperties: {\"^supplier$\": {type: string}}\n    properties:\n      success:", "", "$defs.BrowserErrorResponse patternProperties are forbidden"},
		{"unnamed response properties", "schemas", "additionalProperties: false\n        required: [id, username, status]", "additionalProperties: {type: string}\n        required: [id, username, status]", "", "$defs.CustomerAccountResponse.properties.data must reject unnamed properties"},
		{"customer status widened to opaque content", "schemas", "status: {type: string, enum: [active, inactive]}", `status: {$ref: "#/$defs/CustomerJSONValue"}`, "", `opaque schema reference "#/$defs/CustomerJSONValue" is forbidden at $defs.CustomerAccountResponse.properties.data.properties.status`},
		{"health response optional supplier", "openapi", "schema: {type: object, additionalProperties: false, required: [status], properties: {status: {type: string, const: ok}}}", "schema: {type: object, additionalProperties: false, required: [status], properties: {status: {type: string, const: ok}, supplier: {type: string}}}", "", "inline response schema authority mismatch"},
		{"conditional subschema leak", "schemas", "status: {type: string, enum: [active, inactive]}", "status: {allOf: [{type: string}, {if: {const: active}, then: {type: object, additionalProperties: false, properties: {upstream_provider_identities: {type: string}}}}]}", "", "$defs.CustomerAccountResponse.properties.data.properties.status.allOf.then exposes forbidden field upstream_provider_identities"},
		{"untrusted opaque marker", "schemas", "additionalProperties: false\n        required: [id, username, status]", "x-customer-content-container: arbitrary\n        additionalProperties: true\n        required: [id, username, status]", "", "$defs.CustomerAccountResponse.properties.data has an unapproved opaque-container marker"},
		{"invalid schema type", "schemas", "type: object", "type: stringish", "", "JSON Schema 2020-12 validation"},
		{"standards validator invalid max length", "schemas", "maxLength: 512", "maxLength: invalid", "", "JSON Schema 2020-12 validation"},
		{"unapproved service tier", "schemas", "enum: [default, priority, flex]", "enum: [default, priority, flex, vendor-private]", "", "Codex tool_choice or service_tier contract is not pinned to 0.146.0"},
		{"unapproved tool choice", "schemas", "tool_choice: {type: string, const: auto}", "tool_choice: {type: string, const: required}", "", "Codex tool_choice or service_tier contract is not pinned to 0.146.0"},
		{"tool output image variant removed", "schemas", "maxItems: 4096\n        items:\n          oneOf:\n            - {$ref: \"#/$defs/InputTextContent\"}\n            - {$ref: \"#/$defs/InputImageContent\"}", "maxItems: 4096\n        items:\n          oneOf:\n            - {$ref: \"#/$defs/InputTextContent\"}", "", "Codex tool output content contract is not pinned to supported 0.146.0 variants"},
		{"response secret marked write only", "schemas", "x-sensitive-response: dashboard-access-token", "writeOnly: true", "", "$defs.AuthBundleResponse.properties.data.access_token has invalid response sensitivity semantics"},
		{"noncanonical gateway-key path grammar", "openapi", `pattern: "^[0-9A-HJKMNP-TV-Z]{25}[048CGMRW]$"`, `pattern: "^[0-9A-HJKMNP-TV-Z]{26}$"`, "", "DELETE /api/token/{id} has incomplete path parameter ownership"},
		{"noncanonical GatewayBearer grammar", "openapi", `x-bearer-pattern: "^sk-pxv1\\.[0-9A-HJKMNP-TV-Z]{25}[048CGMRW]\\.[0-9A-HJKMNP-TV-Z]{51}[0G]$"`, `x-bearer-pattern: "^sk-pxv1\\.[0-9A-HJKMNP-TV-Z]{26}\\.[0-9A-HJKMNP-TV-Z]{52}$"`, "", "security scheme GatewayBearer bearer grammar mismatch"},
		{"noncanonical gateway-key public ID", "schemas", `id: {type: string, pattern: "^[0-9A-HJKMNP-TV-Z]{25}[048CGMRW]$"}`, `id: {type: string, pattern: "^[0-9A-HJKMNP-TV-Z]{26}$"}`, "", "external schema authority mismatch"},
		{"reconstructable masked key", "schemas", `pattern: "^sk-pxv1\\.[0-9A-HJKMNP-TV-Z]{25}[048CGMRW]\\.\\*{4}$"`, `pattern: ".*"`, "", "masked_key may expose secret material"},
		{"noncanonical gateway-key secret", "schemas", `pattern: "^sk-pxv1\\.[0-9A-HJKMNP-TV-Z]{25}[048CGMRW]\\.[0-9A-HJKMNP-TV-Z]{51}[0G]$"`, `pattern: "^sk-pxv1\\.[0-9A-HJKMNP-TV-Z]{26}\\.[0-9A-HJKMNP-TV-Z]{52}$"`, "", "external schema authority mismatch"},
		{"cache-write usage drift", "schemas", "cache_write_tokens: {type: integer", "cache_written_tokens: {type: integer", "", "$defs.Usage.properties.input_tokens_details property inventory mismatch"},
		{"SSE cache-write usage drift", "sse", "cache_write_tokens: {type: integer", "cache_written_tokens: {type: integer", "", "HTTP and SSE usage accounting schemas differ"},
		{"HTTP end-turn drift", "schemas", "      end_turn: {type: boolean}\n", "", "", "$defs.ResponseObject property inventory mismatch"},
		{"SSE end-turn drift", "sse", "      end_turn: {type: boolean}\n", "", "", "SSE schema authority mismatch"},
		{"Stripe Checkout 503 removed", "openapi", "        \"503\": {$ref: \"#/components/responses/BrowserUnavailable\"}\n", "", "", "POST /api/subscription/stripe/checkout response status contract is incomplete"},
		{"Stripe Checkout 503 owner changed", "openapi", "        \"503\": {$ref: \"#/components/responses/BrowserUnavailable\"}", "        \"503\": {$ref: \"#/components/responses/BrowserConflict\"}", "", "POST /api/subscription/stripe/checkout status 503 has wrong response owner"},
		{"stripe checkout auth drift", "stripe", "auth: dashboard-bearer", "auth: none", "", "Stripe contract routes.checkout.auth"},
		{"stripe portal ownership drift", "stripe", "customer_ownership: authenticated-customer-only", "customer_ownership: browser-supplied", "", "Stripe contract portal.customer_ownership"},
		{"stripe parse before signature", "stripe", "    - read-bounded-raw-bytes\n    - verify-signature-over-exact-raw-bytes\n    - parse-json", "    - read-bounded-raw-bytes\n    - parse-json\n    - verify-signature-over-exact-raw-bytes", "", "Stripe contract webhook.verify_sequence"},
		{"stripe binding drift", "stripe", "mode: configured-live-or-test", "mode: event-supplied", "", "Stripe contract bindings.mode"},
		{"stripe command uniqueness drift", "stripe", "command_unique_key: [customer-id, command-type, idempotency-key]", "command_unique_key: [customer-id, idempotency-key]", "", "Stripe checkout command key inventory mismatch"},
		{"stripe command ownership drift", "stripe", "command_ownership: persist-before-stripe-compare-and-set-single-owner", "command_ownership: browser-owner", "", "Stripe contract checkout.command_ownership"},
		{"stripe concurrent command drift", "stripe", "concurrent_duplicate: wait-bounded-then-original-session-or-503", "concurrent_duplicate: create-new-session", "", "Stripe contract checkout.concurrent_duplicate"},
		{"stripe indeterminate command drift", "stripe", "indeterminate_recovery: reconcile-same-command-by-server-command-id-never-create-replacement", "indeterminate_recovery: create-replacement-command", "", "Stripe contract checkout.indeterminate_recovery"},
		{"stripe event inventory drift", "stripe", "  - invoice.payment_failed", "  - charge.failed", "", "Stripe event inventory mismatch"},
		{"stripe checkout completion authority drift", "stripe", "checkout.session.completed: [bind-known-command-customer-subscription, access-no-activation-authority, quota-no-grant-or-reset-authority]", "checkout.session.completed: [bind-known-command-customer-subscription, access-activate, quota-grant]", "", "Stripe event effect checkout.session.completed mismatch"},
		{"stripe checkout expiry effect drift", "stripe", "checkout.session.expired: [expire-known-command, access-no-change, quota-no-grant-or-reset]", "checkout.session.expired: [expire-known-command, access-activate, quota-grant]", "", "Stripe event effect checkout.session.expired mismatch"},
		{"stripe subscription creation effect drift", "stripe", "customer.subscription.created: [record-known-subscription-price-period, access-apply-configured-paid-state-policy, quota-no-grant-or-reset]", "customer.subscription.created: [access-activate, quota-grant]", "", "Stripe event effect customer.subscription.created mismatch"},
		{"stripe upgrade downgrade effect drift", "stripe", "customer.subscription.updated: [access-apply-monotonic-status-and-scheduled-cancellation, plan-apply-allowlisted-versioned-upgrade-or-downgrade, quota-reconcile-exactly-once-only-for-paid-billing-period-id]", "customer.subscription.updated: [access-activate, plan-browser-selected, quota-reset]", "", "Stripe event effect customer.subscription.updated mismatch"},
		{"stripe cancellation effect drift", "stripe", "customer.subscription.deleted: [access-revoke-or-expire, cancel-precommit-next-request-reject, quota-no-grant-or-reset]", "customer.subscription.deleted: [access-remain-active, quota-grant]", "", "Stripe event effect customer.subscription.deleted mismatch"},
		{"stripe renewal effect drift", "stripe", "invoice.paid: [access-activate-or-renew, quota-exactly-once-grant-or-reset-by-billing-period-id]", "invoice.paid: [access-activate-or-renew, quota-blind-increment]", "", "Stripe event effect invoice.paid mismatch"},
		{"stripe payment failure effect drift", "stripe", "invoice.payment_failed: [access-configured-unpaid, cancel-precommit-next-request-reject, quota-no-grant-or-reset]", "invoice.payment_failed: [access-remain-active, quota-grant]", "", "Stripe event effect invoice.payment_failed mismatch"},
		{"stripe transaction scope drift", "stripe", "    - quota-grant-or-reset", "    - quota-grant", "", "Stripe transaction scope mismatch"},
		{"stripe transaction omits subscription state", "stripe", "    - subscription-state\n", "", "", "Stripe transaction scope mismatch"},
		{"stripe endpoint-account binding drift", "stripe", "endpoint_account: configured-webhook-endpoint-id-retrieved-under-configured-account", "endpoint_account: browser-supplied", "", "Stripe contract bindings.endpoint_account"},
		{"stripe signature tolerance widened", "stripe", "maximum_seconds: 300", "maximum_seconds: 3600", "", "Stripe contract webhook.signature_tolerance.maximum_seconds"},
		{"stripe clock failure opens admission", "stripe", "clock_failure: fail-closed-pre-inbox-400", "clock_failure: continue-without-clock", "", "Stripe contract webhook.clock_failure"},
		{"stripe unsupported event becomes retry loop", "stripe", "unsupported_event: verified-parsed-event-persists-terminal-ignored-before-200", "unsupported_event: pre-inbox-400", "", "Stripe contract inbox.unsupported_event"},
		{"stripe known gap drift", "stripe", "behavior: logs-raw-signature-and-payload", "behavior: conforming", "", "Stripe contract known_nonconformance.behavior"},
		{"stripe prose authority drift", "stripe", "prose_role: informational-projection", "prose_role: normative-duplicate", "", "Stripe contract prose_role"},
		{"stripe unowned root authority", "stripe", "prose_role: informational-projection", "prose_role: informational-projection\nalternate_authority: prose", "", "Stripe contract root field inventory mismatch"},
		{"stripe inbox states drift", "stripe", "states: [received, processing, applied, ignored, rejected, deferred, failed-retryable]", "states: [received, processing, applied]", "", "Stripe inbox state inventory mismatch"},
		{"stripe unowned inbox field", "stripe", "recovery: expired-processing-or-failed-effect-resumes-same-inbox-row", "recovery: expired-processing-or-failed-effect-resumes-same-inbox-row\n  bypass: true", "", "Stripe contract inbox field inventory mismatch"},
		{"stripe out-of-order drift", "stripe", "out_of_order: deferred-503-until-monotonic-reconciliation", "out_of_order: apply-immediately", "", "Stripe contract inbox.out_of_order"},
		{"stripe unknown-reference drift", "stripe", "unknown_reference: deferred-503-then-audited-apply-or-terminal-reject", "unknown_reference: ignore", "", "Stripe contract inbox.unknown_reference"},
		{"stripe bad-request cases drift", "stripe", "bad_request_cases: [invalid-signature, malformed-json, invalid-signature-timestamp, clock-unavailable]", "bad_request_cases: [malformed-json]", "", "Stripe acknowledgement case inventory mismatch"},
		{"stripe conflict cases drift", "stripe", "conflict_cases: [event-id-payload-hash-mismatch]", "conflict_cases: [event-id]", "", "Stripe acknowledgement case inventory mismatch"},
		{"stripe too-large cases drift", "stripe", "too_large_cases: [raw-body-limit-exceeded]", "too_large_cases: []", "", "Stripe acknowledgement case inventory mismatch"},
		{"stripe retry cases drift", "stripe", "retry_cases: [inbox-persistence-failed, received, processing-not-terminal-after-bounded-wait, deferred, failed-retryable, effect-transaction-failed]", "retry_cases: [inbox-persistence-failed]", "", "Stripe acknowledgement case inventory mismatch"},
		{"oversized artifact", "openapi", "", "", strings.Repeat("# overflow\n", 801), "lines; contract artifacts must stay under 800"},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			docs := map[string][]byte{"openapi": append([]byte(nil), openapi...), "schemas": append([]byte(nil), schemas...), "sse": append([]byte(nil), sse...), "stripe": append([]byte(nil), stripe...)}
			if test.old != "" {
				require.Contains(t, string(docs[test.document]), test.old)
				docs[test.document] = []byte(strings.Replace(string(docs[test.document]), test.old, test.new, 1))
			}
			docs[test.document] = append(docs[test.document], test.appendText...)
			err := lintContractDocumentsWithSSE(docs["openapi"], docs["schemas"], docs["sse"], docs["stripe"])
			require.ErrorContains(t, err, test.wantError)
		})
	}
}

func TestContractArtifactLineGuardRejectsOversizedHelper(t *testing.T) {
	err := lintContractArtifactLineCounts(map[string][]byte{
		"contract_helper_test.go": []byte(strings.Repeat("// overflow\n", 800)),
	})
	require.ErrorContains(t, err, "contract_helper_test.go has 800 lines")
}
