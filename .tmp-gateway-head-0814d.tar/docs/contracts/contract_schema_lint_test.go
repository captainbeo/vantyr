package contracts_test

import (
	"fmt"
	"strings"
	"unicode"

	"gopkg.in/yaml.v3"
)

func lintSchema(node *yaml.Node, path string) error {
	if node.Kind == yaml.ScalarNode && node.Tag == "!!bool" {
		return nil
	}
	if node.Kind != yaml.MappingNode {
		return fmt.Errorf("%s must be a schema object or boolean", path)
	}
	allowedTypes := map[string]bool{"array": true, "boolean": true, "integer": true, "null": true, "number": true, "object": true, "string": true}
	if typ := child(node, "type"); typ != nil {
		values := []string{}
		if typ.Kind == yaml.ScalarNode {
			values = []string{typ.Value}
		} else if typ.Kind == yaml.SequenceNode {
			for _, item := range typ.Content {
				values = append(values, item.Value)
			}
		} else {
			return fmt.Errorf("%s has invalid type", path)
		}
		seen := map[string]bool{}
		for _, typ := range values {
			if !allowedTypes[typ] || seen[typ] {
				return fmt.Errorf("%s has invalid type %q", path, typ)
			}
			seen[typ] = true
		}
		if seen["object"] && child(node, "additionalProperties") == nil {
			return fmt.Errorf("%s object is not closed", path)
		}
	}
	approvedOpaque := path == "$defs.JSONSchemaDocument" && value(node, "x-customer-content-container") == "function-or-output-json-schema" ||
		path == "$defs.CustomerJSONValue" && value(node, "x-customer-content-container") == "tool-search-arguments" ||
		path == "$defs.StripeWebhookPayload" && value(node, "x-opaque-signed-provider-payload") == "stripe-signature-verified-before-parse"
	if (child(node, "x-customer-content-container") != nil || child(node, "x-opaque-signed-provider-payload") != nil) && !approvedOpaque {
		return fmt.Errorf("%s has an unapproved opaque-container marker", path)
	}
	properties := child(node, "properties")
	for _, keyword := range []string{"properties", "patternProperties"} {
		schemas := child(node, keyword)
		if schemas == nil {
			continue
		}
		if schemas.Kind != yaml.MappingNode {
			return fmt.Errorf("%s %s must be an object", path, keyword)
		}
		for i := 0; i < len(schemas.Content); i += 2 {
			name, schema := schemas.Content[i].Value, schemas.Content[i+1]
			if forbiddenCustomerField(name) {
				return fmt.Errorf("%s exposes forbidden field %s", path, name)
			}
			if (name == "access_token" || name == "secret") && (child(schema, "x-sensitive-response") == nil || child(schema, "writeOnly") != nil) {
				return fmt.Errorf("%s.%s has invalid response sensitivity semantics", path, name)
			}
			if name == "masked_key" && value(schema, "pattern") != `^sk-pxv1\.[0-9A-HJKMNP-TV-Z]{25}[048CGMRW]\.\*{4}$` {
				return fmt.Errorf("masked_key may expose secret material")
			}
			if err := lintSchema(schema, path+"."+keyword+"."+name); err != nil {
				return err
			}
		}
	}
	if child(node, "patternProperties") != nil {
		return fmt.Errorf("%s patternProperties are forbidden", path)
	}
	if properties != nil && strings.HasPrefix(path, "$defs.") {
		additional := child(node, "additionalProperties")
		if additional == nil || additional.Kind != yaml.ScalarNode || additional.Value != "false" {
			return fmt.Errorf("%s must reject unnamed properties", path)
		}
		if err := lintApprovedSchemaProperties(properties, path); err != nil {
			return err
		}
	}
	if required := child(node, "required"); required != nil {
		if required.Kind != yaml.SequenceNode || properties == nil {
			return fmt.Errorf("%s has invalid required", path)
		}
		seen := map[string]bool{}
		for _, item := range required.Content {
			if item.Kind != yaml.ScalarNode || seen[item.Value] || child(properties, item.Value) == nil {
				return fmt.Errorf("%s has invalid required property %q", path, item.Value)
			}
			seen[item.Value] = true
		}
	}
	if additional := child(node, "additionalProperties"); additional != nil {
		if additional.Kind == yaml.ScalarNode && additional.Value == "true" && !approvedOpaque {
			return fmt.Errorf("%s has unnamed opaque properties", path)
		}
		if additional.Kind == yaml.MappingNode {
			if err := lintSchema(additional, path+".additionalProperties"); err != nil {
				return err
			}
		}
	}
	for _, keyword := range []string{"items", "contains", "not", "propertyNames", "if", "then", "else", "contentSchema", "unevaluatedItems", "unevaluatedProperties"} {
		if item := child(node, keyword); item != nil {
			if err := lintSchema(item, path+"."+keyword); err != nil {
				return err
			}
		}
	}
	for _, keyword := range []string{"allOf", "anyOf", "oneOf", "prefixItems"} {
		if choices := child(node, keyword); choices != nil {
			if choices.Kind != yaml.SequenceNode || len(choices.Content) == 0 {
				return fmt.Errorf("%s.%s must be non-empty", path, keyword)
			}
			for _, choice := range choices.Content {
				if err := lintSchema(choice, path+"."+keyword); err != nil {
					return err
				}
			}
		}
	}
	for _, keyword := range []string{"$defs", "dependentSchemas"} {
		schemas := child(node, keyword)
		if schemas == nil {
			continue
		}
		if schemas.Kind != yaml.MappingNode {
			return fmt.Errorf("%s.%s must be an object", path, keyword)
		}
		for i := 0; i < len(schemas.Content); i += 2 {
			if err := lintSchema(schemas.Content[i+1], path+"."+keyword+"."+schemas.Content[i].Value); err != nil {
				return err
			}
		}
	}
	return nil
}

func forbiddenCustomerField(name string) bool {
	var normalized strings.Builder
	characters := []rune(name)
	for index, character := range characters {
		switch {
		case unicode.IsUpper(character):
			if index > 0 && (unicode.IsLower(characters[index-1]) || unicode.IsDigit(characters[index-1]) ||
				unicode.IsUpper(characters[index-1]) && index+1 < len(characters) && unicode.IsLower(characters[index+1])) {
				normalized.WriteByte('_')
			}
			normalized.WriteRune(unicode.ToLower(character))
		case unicode.IsLower(character) || unicode.IsDigit(character):
			normalized.WriteRune(character)
		default:
			normalized.WriteByte('_')
		}
	}
	parts := strings.FieldsFunc(normalized.String(), func(character rune) bool { return character == '_' })
	for i, part := range parts {
		switch {
		case strings.HasSuffix(part, "ies"):
			parts[i] = strings.TrimSuffix(part, "ies") + "y"
		case strings.HasSuffix(part, "s"):
			parts[i] = strings.TrimSuffix(part, "s")
		}
	}
	candidate := "_" + strings.Join(parts, "_") + "_"
	for _, forbidden := range []string{"admin_control", "channel", "channel_configuration", "internal_cost", "provider", "provider_slug", "upstream_credential", "upstream_model", "upstream_provider_identity"} {
		if strings.Contains(candidate, "_"+forbidden+"_") {
			return true
		}
	}
	return false
}
