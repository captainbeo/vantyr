package contracts_test

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"strings"

	"gopkg.in/yaml.v3"
)

// Canonical JSON digests exact-pin required sets, leaf constraints, and $ref targets
// without making YAML formatting or mapping order part of the contract.
const approvedExternalSchemaAuthoritySHA256 = "96d0fe1ac15629bf9ae65392329cbcd1000cbc5023fdbcf8b80e77a848e57813"
const approvedInlineResponseSchemaAuthoritySHA256 = "2072ac9737a987c94a7b1e081ba3fbb06a81d4e8fbaad26396e24722383ed2a5"

var approvedOpaqueSchemaRefLocations = map[string]map[string]bool{
	"#/$defs/JSONSchemaDocument": {
		"$defs.FunctionToolDefinition.properties.parameters":         true,
		"$defs.LoadableFunctionToolDefinition.properties.parameters": true,
		"$defs.TextControls.properties.format.properties.schema":     true,
		"$defs.ToolSearchDefinition.properties.parameters":           true,
	},
	"#/$defs/CustomerJSONValue": {
		"$defs.CustomerJSONValue.oneOf.4.items":                true,
		"$defs.CustomerJSONValue.oneOf.5.additionalProperties": true,
		"$defs.ToolSearchCallItem.properties.arguments":        true,
	},
}

var approvedSchemaPropertyInventory = map[string]string{
	"$defs.OpenAIErrorDetail":                                           "message type param code",
	"$defs.OpenAIError":                                                 "error",
	"$defs.FunctionToolDefinition":                                      "type name description strict defer_loading parameters",
	"$defs.LoadableFunctionToolDefinition":                              "type name description strict defer_loading parameters",
	"$defs.NamespaceToolDefinition":                                     "type name description tools",
	"$defs.ToolSearchDefinition":                                        "type execution description parameters",
	"$defs.CustomToolDefinition":                                        "type name description format",
	"$defs.CustomToolDefinition.properties.format":                      "type syntax definition",
	"$defs.InputTextContent":                                            "type text",
	"$defs.OutputTextContent":                                           "type text",
	"$defs.InputImageContent":                                           "type image_url detail",
	"$defs.MessageInputItem":                                            "type id role phase content",
	"$defs.MessageOutputItem":                                           "type id role phase content",
	"$defs.ReasoningSummaryItem":                                        "type text",
	"$defs.ReasoningContentItem":                                        "type text",
	"$defs.ReasoningInputItem":                                          "type id summary content encrypted_content",
	"$defs.ReasoningOutputItem":                                         "type id summary content encrypted_content",
	"$defs.FunctionCallItem":                                            "type id name namespace arguments call_id",
	"$defs.FunctionCallOutputItem":                                      "type id call_id output",
	"$defs.CustomToolCallItem":                                          "type id status call_id name namespace input",
	"$defs.CustomToolCallOutputItem":                                    "type id call_id name output",
	"$defs.ToolSearchCallItem":                                          "type id call_id status execution arguments",
	"$defs.ToolSearchOutputItem":                                        "type id call_id status execution tools",
	"$defs.CompactionItem":                                              "type id encrypted_content",
	"$defs.ReasoningConfig":                                             "effort summary context",
	"$defs.TextControls":                                                "verbosity format",
	"$defs.TextControls.properties.format":                              "type strict schema name",
	"$defs.ResponseRequest":                                             "model instructions input tools tool_choice parallel_tool_calls reasoning store stream stream_options include service_tier prompt_cache_key text client_metadata background",
	"$defs.ResponseRequest.properties.stream_options":                   "reasoning_summary_delivery",
	"$defs.CompactRequest":                                              "model input instructions tools parallel_tool_calls reasoning service_tier prompt_cache_key text",
	"$defs.Usage":                                                       "input_tokens output_tokens total_tokens input_tokens_details output_tokens_details",
	"$defs.Usage.properties.input_tokens_details":                       "cached_tokens cache_write_tokens",
	"$defs.Usage.properties.output_tokens_details":                      "reasoning_tokens",
	"$defs.ResponseObject":                                              "id object created_at status error instructions model output parallel_tool_calls service_tier store tool_choice tools text usage end_turn",
	"$defs.CompactResponse":                                             "output",
	"$defs.Model":                                                       "id object owned_by",
	"$defs.ModelList":                                                   "object data",
	"$defs.LoginRequest":                                                "username password",
	"$defs.CreateKeyRequest":                                            "name",
	"$defs.CheckoutRequest":                                             "plan",
	"$defs.PortalRequest":                                               "return_path",
	"$defs.BrowserErrorResponse":                                        "success code message",
	"$defs.AuthBundleResponse":                                          "success message data",
	"$defs.AuthBundleResponse.properties.data":                          "access_token token_type access_expires_at user session",
	"$defs.AuthBundleResponse.properties.data.properties.user":          "id username role status",
	"$defs.AuthBundleResponse.properties.data.properties.session":       "sid current login_method ip user_agent created_at last_active_at expires_at",
	"$defs.LogoutResponse":                                              "success message data",
	"$defs.LogoutResponse.properties.data":                              "revoked_sid cookie_cleared",
	"$defs.CustomerAccountResponse":                                     "success message data",
	"$defs.CustomerAccountResponse.properties.data":                     "id username status",
	"$defs.CustomerModelListResponse":                                   "success message data",
	"$defs.CustomerModelListResponse.properties.data.items":             "id display_name",
	"$defs.PlanCatalogResponse":                                         "success message data",
	"$defs.PlanCatalogResponse.properties.data.items":                   "plan_key display_name price_minor currency interval request_quota concurrency image_enabled enabled",
	"$defs.CurrentSubscriptionResponse":                                 "success message data",
	"$defs.CurrentSubscriptionResponse.properties.data":                 "plan_key status period_start period_end request_quota requests_used permitted_models",
	"$defs.GatewayKeyListResponse":                                      "success message data",
	"$defs.GatewayKeyListResponse.properties.data.items":                "id name masked_key status created_at expires_at",
	"$defs.GatewayKeyCreatedResponse":                                   "success message data",
	"$defs.GatewayKeyCreatedResponse.properties.data":                   "id name secret",
	"$defs.UsageLogPageResponse":                                        "success message data",
	"$defs.UsageLogPageResponse.properties.data":                        "items next_cursor",
	"$defs.UsageLogPageResponse.properties.data.properties.items.items": "request_id model input_tokens output_tokens request_count latency_ms timestamp status",
	"$defs.UsageStatResponse":                                           "success message data",
	"$defs.UsageStatResponse.properties.data":                           "period_start period_end quota_type quota_limit requests_used input_tokens output_tokens",
	"$defs.UsagePeriodsResponse":                                        "success message data",
	"$defs.UsagePeriodsResponse.properties.data.items":                  "period_start period_end requests_used input_tokens output_tokens",
	"$defs.CheckoutSessionResponse":                                     "success message data",
	"$defs.CheckoutSessionResponse.properties.data":                     "url expires_at",
	"$defs.PortalSessionResponse":                                       "success message data",
	"$defs.PortalSessionResponse.properties.data":                       "url expires_at",
}

func lintApprovedSchemaProperties(properties *yaml.Node, path string) error {
	want, ok := approvedSchemaPropertyInventory[path]
	if !ok || !sameStrings(mappingKeys(properties), strings.Fields(want)) {
		return fmt.Errorf("%s property inventory mismatch", path)
	}
	return nil
}

func lintSchemaPropertyInventoryCoverage(root *yaml.Node) error {
	for path := range approvedSchemaPropertyInventory {
		node := child(root, strings.Split(path, ".")...)
		if node == nil || child(node, "properties") == nil {
			return fmt.Errorf("%s property inventory has no schema owner", path)
		}
	}
	return nil
}

func lintExactSchemaAuthority(schemas, sse, openapi *yaml.Node) error {
	if err := lintOpaqueSchemaRefLocations(schemas); err != nil {
		return err
	}
	externalDigest, err := canonicalNodeSHA256(child(schemas, "$defs"))
	if err != nil {
		return fmt.Errorf("external schema authority digest: %w", err)
	}
	if externalDigest != approvedExternalSchemaAuthoritySHA256 {
		return fmt.Errorf("external schema authority mismatch: got %s", externalDigest)
	}
	sseDigest, err := canonicalNodeSHA256(sse)
	if err != nil {
		return fmt.Errorf("SSE schema authority digest: %w", err)
	}
	if sseDigest != approvedSSESchemaAuthoritySHA256 {
		return fmt.Errorf("SSE schema authority mismatch: got %s", sseDigest)
	}
	inlineDigest, err := inlineResponseSchemaSHA256(openapi)
	if err != nil {
		return err
	}
	if inlineDigest != approvedInlineResponseSchemaAuthoritySHA256 {
		return fmt.Errorf("inline response schema authority mismatch: got %s", inlineDigest)
	}
	return nil
}

func lintOpaqueSchemaRefLocations(root *yaml.Node) error {
	seen := map[string]map[string]bool{}
	for target := range approvedOpaqueSchemaRefLocations {
		seen[target] = map[string]bool{}
	}
	var walk func(*yaml.Node, string) error
	walk = func(node *yaml.Node, path string) error {
		if node.Kind == yaml.DocumentNode {
			return walk(node.Content[0], path)
		}
		if node.Kind == yaml.SequenceNode {
			for index, item := range node.Content {
				if err := walk(item, fmt.Sprintf("%s.%d", path, index)); err != nil {
					return err
				}
			}
			return nil
		}
		if node.Kind != yaml.MappingNode {
			return nil
		}
		if ref := child(node, "$ref"); ref != nil && ref.Kind == yaml.ScalarNode {
			if approved, tracked := approvedOpaqueSchemaRefLocations[ref.Value]; tracked {
				if !approved[path] {
					return fmt.Errorf("opaque schema reference %q is forbidden at %s", ref.Value, path)
				}
				seen[ref.Value][path] = true
			}
		}
		for index := 0; index < len(node.Content); index += 2 {
			key := node.Content[index].Value
			nextPath := key
			if path != "" {
				nextPath = path + "." + key
			}
			if err := walk(node.Content[index+1], nextPath); err != nil {
				return err
			}
		}
		return nil
	}
	if err := walk(root, ""); err != nil {
		return err
	}
	for target, approved := range approvedOpaqueSchemaRefLocations {
		for path := range approved {
			if !seen[target][path] {
				return fmt.Errorf("opaque schema reference %q is missing from %s", target, path)
			}
		}
	}
	return nil
}

func canonicalNodeSHA256(node *yaml.Node) (string, error) {
	if node == nil {
		return "", fmt.Errorf("schema node is missing")
	}
	var decoded any
	if err := node.Decode(&decoded); err != nil {
		return "", err
	}
	data, err := json.Marshal(decoded)
	if err != nil {
		return "", err
	}
	digest := sha256.Sum256(data)
	return hex.EncodeToString(digest[:]), nil
}

func inlineResponseSchemaSHA256(root *yaml.Node) (string, error) {
	inlineSchemas := map[string]any{}
	for _, location := range collectOpenAPISchemaLocations(root) {
		if !strings.HasPrefix(location.path, "components.responses.") {
			continue
		}
		node := pointerNode(root, "#"+location.pointer)
		if node == nil {
			return "", fmt.Errorf("inline response schema %s is missing", location.path)
		}
		var decoded any
		if err := node.Decode(&decoded); err != nil {
			return "", fmt.Errorf("inline response schema %s: %w", location.path, err)
		}
		inlineSchemas[location.path] = decoded
	}
	data, err := json.Marshal(inlineSchemas)
	if err != nil {
		return "", fmt.Errorf("inline response schema authority digest: %w", err)
	}
	digest := sha256.Sum256(data)
	return hex.EncodeToString(digest[:]), nil
}
