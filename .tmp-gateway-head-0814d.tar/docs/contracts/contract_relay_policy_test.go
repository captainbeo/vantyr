package contracts_test

import (
	"fmt"
	"os"
	"reflect"
	"strings"
	"testing"

	"github.com/stretchr/testify/require"
	"gopkg.in/yaml.v3"
)

const approvedRelayContract = `authentication:
  scheme: authorization-bearer-only
  credential-owner: platform-gateway-key
  alternate-credential-inputs: [cookies, mj-api-secret, query-key, websocket-query, x-api-key, x-goog-api-key]
  customer-credential-egress: forbidden
validation:
  max-compressed-body-bytes: 2097152
  max-decompressed-body-bytes: 8388608
  max-json-depth: 64
  max-array-items: 4096
  max-string-bytes: 8388608
  string-byte-count: utf8-octets
  schema-maxLength-unit: unicode-code-points
  string-byte-limit-selection: operation-x-json-limits-when-present-otherwise-root
  effective-string-limit: selected-utf8-byte-limit-and-schema-code-point-limit-both-apply
  validation-order: decompressed-body-then-selected-string-bytes-then-schema-code-points
  max-tools: 128
  max-output-tokens: 131072
  content-types: [application/json]
  content-encodings: [identity, gzip]
  duplicate-json-keys: reject
  remote-media-urls: reject
  unknown-fields: reject-sanitized-400
  unsupported-fields: reject-sanitized-400
request-headers:
  consume: [authorization]
  validate-and-pseudonymize: [session-id, thread-id, x-client-request-id]
  validate-and-forward: [x-openai-subagent]
  validate-forward-never-log: [x-codex-turn-state]
  validate-protocol: [content-type, content-encoding, accept]
  strip-classes: [authentication, cookies, forwarding, hop-by-hop, proxy]
  strip-all-others: true
  constraints:
    session-id: {max-bytes: 256, encoding: visible-ascii-no-controls, transform: stable-platform-hmac-pseudonym, logging: pseudonym-only}
    thread-id: {max-bytes: 256, encoding: visible-ascii-no-controls, transform: stable-platform-hmac-pseudonym, logging: pseudonym-only}
    x-client-request-id: {max-bytes: 256, encoding: visible-ascii-no-controls, transform: stable-platform-hmac-pseudonym, logging: pseudonym-only}
    x-openai-subagent: {max-bytes: 64, encoding: http-token, transform: forward, logging: bounded}
    x-codex-turn-state: {max-bytes: 8192, encoding: valid-http-field-value, transform: opaque-forward, logging: never}
response-headers:
  platform-request-id: [x-request-id]
  public-model-alias: [openai-model, x-openai-model]
  platform-model-catalog: [x-models-etag]
  gateway-limits-only: [x-ratelimit-*, retry-after]
  gateway-limits-emission: authoritative-gateway-state-only
  validated-pass-through: [x-reasoning-included, x-codex-turn-state]
  strip-all-upstream-others: true
commitment:
  customer-visible-commit-includes: [header, status, body, flush, comment, ping]
  failover-before-commit-only: true
  replay-after-commit: false
  max-upstream-attempts: 2
  exclude-attempted-channel: true
  retryable-request: validated-replay-safe
  retryable-precommit-outcomes: [connect-error, configured-connect-timeout, configured-response-timeout, "408", "429", "500", "502", "503", "504", "524", response-header-timeout, first-semantic-event-timeout, malformed-upstream-response-before-commit, channel-authentication-401, channel-authentication-403, channel-endpoint-404, channel-model-404]
  logical-request-accounting: once
timeouts:
  owner: versioned-endpoint-class-reliability-policy
  required-fields: [connect_timeout_ms, response_header_timeout_ms, first_semantic_event_timeout_ms, stream_idle_timeout_ms, stream_max_duration_ms, nonstream_total_timeout_ms, logical_precommit_deadline_ms]
  values: positive-bounded-integers
  attempt-budget: minimum-of-configured-timeout-and-remaining-logical-precommit-budget
  retry-budget: remaining-logical-precommit-budget-only
  exhausted-before-commit: terminal-timeout-no-further-attempt
non-stream:
  max-response-bytes: 8388608
  precommit-emission: absolute-silence
  validation-before-commit: complete-bounded-response-and-schema
  settlement-before-commit: durable-final-usage-attempt-and-logical-request
  commit-after-settlement: status-headers-body
  postcommit-replay: false
stream:
  max-stream-bytes: 8388608
  max-precommit-buffer-bytes: 1048576
  precommit-emission: absolute-silence
  commitment-point: first-semantic-event-after-durable-commit-fence
  postcommit-replay: false
  successful-terminal: response.completed
  required-terminal-fields: [nonempty-public-response-id, complete-usage]
  successful-terminal-count: 1
  committed-failure: sanitized-response.failed-if-writable
  committed-json-append: false
  terminal-failures: [missing, duplicate, incomplete, missing-usage]
  response-done-normalization: typed-equivalent-with-complete-usage-only
access-snapshot:
  precommit-revocation: cancel
  committed-stream: may-finish
  next-request: reject
errors:
  shape: openai-error-envelope
  code-owner: stable-statuses
  stable-statuses:
    invalid_request_error: 400
    context_length_exceeded: 400
    invalid_prompt: 400
    invalid_api_key: 401
    access_inactive: 403
    model_not_permitted: 403
    not_found: 404
    idempotency_conflict: 409
    request_too_large: 413
    unsupported_media_type: 415
    insufficient_quota: 429
    rate_limit_exceeded: 429
    concurrency_limit_exceeded: 429
    slow_down: 429
    usage_not_included: 502
    limiter_unavailable: 503
    no_channel_available: 503
    server_is_overloaded: 503
  transport-code-subsets:
    http: [invalid_request_error, context_length_exceeded, invalid_prompt, invalid_api_key, access_inactive, model_not_permitted, not_found, idempotency_conflict, request_too_large, unsupported_media_type, insufficient_quota, rate_limit_exceeded, concurrency_limit_exceeded, slow_down, usage_not_included, limiter_unavailable, no_channel_available, server_is_overloaded]
    sse: [context_length_exceeded, insufficient_quota, usage_not_included, rate_limit_exceeded, server_is_overloaded, slow_down, invalid_prompt]
  forbidden-data: [channel-id, credentials, database-details, internal-cost, internal-url, provider-slug, stack-trace, upstream-model-slug, vendor-body]
  no-channel-code: no_channel_available
  no-channel-http-status: 503
  no-channel-retry-after: true
`

func lintRelayContractInventory(root *yaml.Node) error {
	scalars := map[string]any{
		"request-headers.constraints.x-codex-turn-state.max-bytes": 8192,
		"timeouts.owner":                      "versioned-endpoint-class-reliability-policy",
		"timeouts.values":                     "positive-bounded-integers",
		"timeouts.attempt-budget":             "minimum-of-configured-timeout-and-remaining-logical-precommit-budget",
		"timeouts.retry-budget":               "remaining-logical-precommit-budget-only",
		"timeouts.exhausted-before-commit":    "terminal-timeout-no-further-attempt",
		"non-stream.max-response-bytes":       8388608,
		"non-stream.validation-before-commit": "complete-bounded-response-and-schema",
		"non-stream.settlement-before-commit": "durable-final-usage-attempt-and-logical-request",
		"stream.max-precommit-buffer-bytes":   1048576,
	}
	for path, want := range scalars {
		if !reflect.DeepEqual(decodedValue(root, append([]string{"x-relay-contract"}, strings.Split(path, ".")...)...), want) {
			return fmt.Errorf("relay policy %s mismatch", path)
		}
	}
	lists := map[string][]string{
		"stream.required-terminal-fields":         {"nonempty-public-response-id", "complete-usage"},
		"commitment.retryable-precommit-outcomes": {"connect-error", "configured-connect-timeout", "configured-response-timeout", "408", "429", "500", "502", "503", "504", "524", "response-header-timeout", "first-semantic-event-timeout", "malformed-upstream-response-before-commit", "channel-authentication-401", "channel-authentication-403", "channel-endpoint-404", "channel-model-404"},
		"timeouts.required-fields":                {"connect_timeout_ms", "response_header_timeout_ms", "first_semantic_event_timeout_ms", "stream_idle_timeout_ms", "stream_max_duration_ms", "nonstream_total_timeout_ms", "logical_precommit_deadline_ms"},
		"errors.forbidden-data":                   {"channel-id", "credentials", "database-details", "internal-cost", "internal-url", "provider-slug", "stack-trace", "upstream-model-slug", "vendor-body"},
	}
	for path, want := range lists {
		if !sameStrings(stringsAt(root, append([]string{"x-relay-contract"}, strings.Split(path, ".")...)...), want) {
			return fmt.Errorf("relay policy %s mismatch", path)
		}
	}
	approved, err := decodeYAMLBytes("approved relay contract", []byte(approvedRelayContract))
	if err != nil {
		return err
	}
	var got, want any
	if err := child(root, "x-relay-contract").Decode(&got); err != nil {
		return fmt.Errorf("relay contract decode: %w", err)
	}
	if err := approved.Decode(&want); err != nil {
		return fmt.Errorf("approved relay contract decode: %w", err)
	}
	if !reflect.DeepEqual(got, want) {
		return fmt.Errorf("relay contract inventory mismatch")
	}
	return nil
}

func TestRetryablePrecommitOutcomeClassifications(t *testing.T) {
	data, err := os.ReadFile("customer-api.openapi.yaml")
	require.NoError(t, err)
	root, err := decodeYAMLBytes("customer-api.openapi.yaml", data)
	require.NoError(t, err)
	require.Equal(t, []string{
		"connect-error", "configured-connect-timeout", "configured-response-timeout", "408", "429", "500", "502", "503", "504", "524",
		"response-header-timeout", "first-semantic-event-timeout", "malformed-upstream-response-before-commit",
		"channel-authentication-401", "channel-authentication-403", "channel-endpoint-404", "channel-model-404",
	}, stringsAt(root, "x-relay-contract", "commitment", "retryable-precommit-outcomes"))
}

func TestSharedCommitmentAndBoundedResponsePolicies(t *testing.T) {
	root := readContractYAML(t, "customer-api.openapi.yaml")
	require.Equal(t, []string{"header", "status", "body", "flush", "comment", "ping"}, stringsAt(root, "x-relay-contract", "commitment", "customer-visible-commit-includes"))
	require.Equal(t, true, decodedValue(root, "x-relay-contract", "commitment", "failover-before-commit-only"))
	require.Equal(t, false, decodedValue(root, "x-relay-contract", "commitment", "replay-after-commit"))
	require.Equal(t, 2, decodedValue(root, "x-relay-contract", "commitment", "max-upstream-attempts"))
	require.Equal(t, "once", value(root, "x-relay-contract", "commitment", "logical-request-accounting"))
	require.Equal(t, []string{
		"connect_timeout_ms", "response_header_timeout_ms", "first_semantic_event_timeout_ms",
		"stream_idle_timeout_ms", "stream_max_duration_ms", "nonstream_total_timeout_ms",
		"logical_precommit_deadline_ms",
	}, stringsAt(root, "x-relay-contract", "timeouts", "required-fields"))
	require.Equal(t, "versioned-endpoint-class-reliability-policy", value(root, "x-relay-contract", "timeouts", "owner"))
	require.Equal(t, "positive-bounded-integers", value(root, "x-relay-contract", "timeouts", "values"))
	require.Equal(t, "minimum-of-configured-timeout-and-remaining-logical-precommit-budget", value(root, "x-relay-contract", "timeouts", "attempt-budget"))
	require.Equal(t, "remaining-logical-precommit-budget-only", value(root, "x-relay-contract", "timeouts", "retry-budget"))
	require.Equal(t, "terminal-timeout-no-further-attempt", value(root, "x-relay-contract", "timeouts", "exhausted-before-commit"))

	require.Equal(t, 8388608, decodedValue(root, "x-relay-contract", "non-stream", "max-response-bytes"))
	require.Equal(t, "absolute-silence", value(root, "x-relay-contract", "non-stream", "precommit-emission"))
	require.Equal(t, "complete-bounded-response-and-schema", value(root, "x-relay-contract", "non-stream", "validation-before-commit"))
	require.Equal(t, "durable-final-usage-attempt-and-logical-request", value(root, "x-relay-contract", "non-stream", "settlement-before-commit"))
	require.Equal(t, false, decodedValue(root, "x-relay-contract", "non-stream", "postcommit-replay"))

	require.Equal(t, 8388608, decodedValue(root, "x-relay-contract", "stream", "max-stream-bytes"))
	require.Equal(t, 1048576, decodedValue(root, "x-relay-contract", "stream", "max-precommit-buffer-bytes"))
	require.Equal(t, "absolute-silence", value(root, "x-relay-contract", "stream", "precommit-emission"))
	require.Equal(t, "first-semantic-event-after-durable-commit-fence", value(root, "x-relay-contract", "stream", "commitment-point"))
	require.Equal(t, false, decodedValue(root, "x-relay-contract", "stream", "postcommit-replay"))
}
