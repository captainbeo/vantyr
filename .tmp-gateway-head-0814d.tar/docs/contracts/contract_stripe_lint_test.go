package contracts_test

import (
	"fmt"
	"os"
	"reflect"
	"strings"
	"testing"

	"github.com/stretchr/testify/require"
	"gopkg.in/yaml.v3"
)

var approvedStripeEventEffects = map[string][]string{
	"checkout.session.completed":    {"bind-known-command-customer-subscription", "access-no-activation-authority", "quota-no-grant-or-reset-authority"},
	"checkout.session.expired":      {"expire-known-command", "access-no-change", "quota-no-grant-or-reset"},
	"customer.subscription.created": {"record-known-subscription-price-period", "access-apply-configured-paid-state-policy", "quota-no-grant-or-reset"},
	"customer.subscription.updated": {"access-apply-monotonic-status-and-scheduled-cancellation", "plan-apply-allowlisted-versioned-upgrade-or-downgrade", "quota-reconcile-exactly-once-only-for-paid-billing-period-id"},
	"customer.subscription.deleted": {"access-revoke-or-expire", "cancel-precommit-next-request-reject", "quota-no-grant-or-reset"},
	"invoice.paid":                  {"access-activate-or-renew", "quota-exactly-once-grant-or-reset-by-billing-period-id"},
	"invoice.payment_failed":        {"access-configured-unpaid", "cancel-precommit-next-request-reject", "quota-no-grant-or-reset"},
}

func TestStripeCommercialLifecycleAuthority(t *testing.T) {
	data, err := os.ReadFile("stripe-events.md")
	require.NoError(t, err)
	frontmatter, err := frontmatterBytes(data)
	require.NoError(t, err)
	root, err := decodeYAMLBytes("stripe-events.md frontmatter", frontmatter)
	require.NoError(t, err)

	t.Run("command unique key", func(t *testing.T) {
		require.Equal(t, []string{"customer-id", "command-type", "idempotency-key"}, stringsAt(root, "checkout", "command_unique_key"))
	})
	commandFields := []struct {
		name, field, want string
	}{
		{"command ownership", "command_ownership", "persist-before-stripe-compare-and-set-single-owner"},
		{"concurrent duplicate", "concurrent_duplicate", "wait-bounded-then-original-session-or-503"},
		{"indeterminate recovery", "indeterminate_recovery", "reconcile-same-command-by-server-command-id-never-create-replacement"},
	}
	for _, field := range commandFields {
		t.Run(field.name, func(t *testing.T) {
			require.Equal(t, field.want, value(root, "checkout", field.field))
		})
	}

	for event, want := range approvedStripeEventEffects {
		t.Run(event, func(t *testing.T) {
			require.Equal(t, want, stringsAt(root, "event_effects", event))
		})
	}
}

func TestStripeCheckoutBoundedDuplicateWaitHasOpenAPI503(t *testing.T) {
	stripeData, err := os.ReadFile("stripe-events.md")
	require.NoError(t, err)
	frontmatter, err := frontmatterBytes(stripeData)
	require.NoError(t, err)
	stripe, err := decodeYAMLBytes("stripe-events.md frontmatter", frontmatter)
	require.NoError(t, err)
	openapi := readContractYAML(t, "customer-api.openapi.yaml")

	require.Equal(t, "wait-bounded-then-original-session-or-503", value(stripe, "checkout", "concurrent_duplicate"))
	require.Equal(t, "#/components/responses/BrowserUnavailable", value(openapi, "paths", "/api/subscription/stripe/checkout", "post", "responses", "503", "$ref"))
	require.Equal(t, "./customer-api.schemas.yaml#/$defs/BrowserErrorResponse", value(openapi, "components", "responses", "BrowserUnavailable", "content", "application/json", "schema", "$ref"))
	require.Equal(t, "integer", value(openapi, "components", "responses", "BrowserUnavailable", "headers", "Retry-After", "schema", "type"))
}

func TestStripeWebhookAdmissionAndAtomicEffectAuthority(t *testing.T) {
	data, err := os.ReadFile("stripe-events.md")
	require.NoError(t, err)
	frontmatter, err := frontmatterBytes(data)
	require.NoError(t, err)
	root, err := decodeYAMLBytes("stripe-events.md frontmatter", frontmatter)
	require.NoError(t, err)

	require.Equal(t, []string{
		"access-state", "audit-entry", "billing-command", "billing-period", "event-inbox-status",
		"mapped-plan-version", "quota-grant-or-reset", "subscription-state",
	}, stringsAt(root, "transaction", "scope"))
	require.Equal(t, "environment-secret-paired-with-configured-webhook-endpoint-id", value(root, "webhook", "endpoint_secret"))
	require.Equal(t, 1, decodedValue(root, "webhook", "signature_tolerance", "minimum_seconds"))
	require.Equal(t, 300, decodedValue(root, "webhook", "signature_tolerance", "default_seconds"))
	require.Equal(t, 300, decodedValue(root, "webhook", "signature_tolerance", "maximum_seconds"))
	require.Equal(t, "stripe-signature-t", value(root, "webhook", "signature_timestamp_source"))
	require.Equal(t, "absolute-clock-skew-lte-configured-tolerance", value(root, "webhook", "signature_timestamp_rule"))
	require.Equal(t, "fail-closed-pre-inbox-400", value(root, "webhook", "clock_failure"))
	require.Equal(t, "api-account-and-webhook-endpoint-id-match-configured-account-before-readiness", value(root, "bindings", "startup_account_check"))
	require.Equal(t, "configured-webhook-endpoint-id-retrieved-under-configured-account", value(root, "bindings", "endpoint_account"))
	require.Equal(t, "present-must-match-configured-account-absent-requires-verified-endpoint-binding", value(root, "bindings", "event_account"))
	require.Equal(t, "verified-parsed-event-persists-terminal-ignored-before-200", value(root, "inbox", "unsupported_event"))
	require.NotContains(t, stringsAt(root, "acknowledgement", "bad_request_cases"), "unsupported-event-type")
	require.Contains(t, stringsAt(root, "acknowledgement", "success_cases"), "unsupported-event-type-terminal-ignored")
}

func lintStripeOpenAPIParity(openapi, stripe *yaml.Node) error {
	if value(stripe, "checkout", "concurrent_duplicate") != "wait-bounded-then-original-session-or-503" ||
		value(openapi, "paths", "/api/subscription/stripe/checkout", "post", "responses", "503", "$ref") != "#/components/responses/BrowserUnavailable" ||
		value(openapi, "components", "responses", "BrowserUnavailable", "content", "application/json", "schema", "$ref") != "./customer-api.schemas.yaml#/$defs/BrowserErrorResponse" ||
		value(openapi, "components", "responses", "BrowserUnavailable", "headers", "Retry-After", "schema", "type") != "integer" {
		return fmt.Errorf("Stripe Checkout bounded duplicate-wait 503 contract mismatch")
	}
	return nil
}

func lintStripe(root *yaml.Node) error {
	if err := lintStripeFieldInventories(root); err != nil {
		return err
	}
	expected := map[string]any{
		"contract_version": 1, "implementation_status": "desired-commercial-contract",
		"normative_authority": "structured-frontmatter-only", "prose_role": "informational-projection",
		"routes.checkout.method": "POST", "routes.checkout.path": "/api/subscription/stripe/checkout",
		"routes.checkout.auth": "dashboard-bearer", "routes.checkout.origin": "exact-configured-origin", "routes.checkout.csrf": "not-applicable-dashboard-bearer",
		"routes.portal.method": "POST", "routes.portal.path": "/api/subscription/stripe/portal", "routes.portal.auth": "dashboard-bearer",
		"routes.portal.origin": "exact-configured-origin", "routes.portal.csrf": "not-applicable-dashboard-bearer", "routes.portal.return_policy": "allowlisted",
		"routes.webhook.method": "POST", "routes.webhook.path": "/api/stripe/webhook", "routes.webhook.auth": "stripe-signature",
		"routes.webhook.origin": "not-applicable", "routes.webhook.csrf": "not-applicable",
		"checkout.enabled_price_count": 2, "checkout.price_policy": "allowlisted-price-to-versioned-plan",
		"checkout.idempotency_header": "Idempotency-Key", "checkout.persisted_request_fingerprint": true,
		"checkout.exact_retry": "return-original-checkout-session", "checkout.fingerprint_conflict_http": 409,
		"checkout.stripe_idempotency_key": "server-command-id", "checkout.command_ownership": "persist-before-stripe-compare-and-set-single-owner",
		"checkout.concurrent_duplicate":        "wait-bounded-then-original-session-or-503",
		"checkout.indeterminate_recovery":      "reconcile-same-command-by-server-command-id-never-create-replacement",
		"checkout.browser_state_authoritative": false,
		"portal.customer_ownership":            "authenticated-customer-only", "portal.customer_id_input": "forbidden",
		"portal.return_destination": "server-allowlisted-only", "portal.stripe_hosted": true,
		"webhook.max_raw_body_bytes": 1048576, "webhook.signature_header": "Stripe-Signature",
		"webhook.endpoint_secret":                     "environment-secret-paired-with-configured-webhook-endpoint-id",
		"webhook.signature_tolerance.minimum_seconds": 1, "webhook.signature_tolerance.default_seconds": 300,
		"webhook.signature_tolerance.maximum_seconds": 300, "webhook.signature_timestamp_source": "stripe-signature-t",
		"webhook.signature_timestamp_rule": "absolute-clock-skew-lte-configured-tolerance", "webhook.clock_failure": "fail-closed-pre-inbox-400",
		"webhook.raw_payload_logs": "forbidden", "webhook.signature_logs": "forbidden",
		"bindings.startup_account_check": "api-account-and-webhook-endpoint-id-match-configured-account-before-readiness",
		"bindings.endpoint_account":      "configured-webhook-endpoint-id-retrieved-under-configured-account",
		"bindings.event_account":         "present-must-match-configured-account-absent-requires-verified-endpoint-binding",
		"bindings.mode":                  "configured-live-or-test", "bindings.customer": "known-owned-customer",
		"bindings.subscription": "known-owned-subscription", "bindings.price": "allowlisted-price-to-versioned-plan",
		"bindings.currency": "configured-price-currency", "bindings.period": "stripe-billing-period",
		"inbox.unique_key": "stripe-event-id", "inbox.payload_hash": "sha256-exact-verified-bytes", "inbox.persist_before_effect": true,
		"inbox.processing_ownership": "compare-and-set-with-expiring-owner-lease", "inbox.terminal_replay": "same-acknowledgement-no-effect",
		"inbox.retryable_replay": "elect-one-owner-and-resume-existing-row", "inbox.concurrent_duplicate": "wait-bounded-then-terminal-ack-or-503",
		"inbox.payload_mismatch": "security-conflict-409-no-effect", "inbox.recovery": "expired-processing-or-failed-effect-resumes-same-inbox-row",
		"inbox.out_of_order": "deferred-503-until-monotonic-reconciliation", "inbox.unknown_reference": "deferred-503-then-audited-apply-or-terminal-reject",
		"inbox.unsupported_event":      "verified-parsed-event-persists-terminal-ignored-before-200",
		"acknowledgement.success_http": 200, "acknowledgement.bad_request_http": 400, "acknowledgement.conflict_http": 409,
		"acknowledgement.too_large_http": 413, "acknowledgement.retry_http": 503,
		"transaction.billing_period_id_owner": "stripe-subscription-and-period", "transaction.grant_reset_cardinality": "exactly-once-per-billing-period-id",
		"transaction.audit": "append-only-sanitized", "known_nonconformance.file": "controller/topup_stripe.go",
		"known_nonconformance.behavior": "logs-raw-signature-and-payload", "known_nonconformance.repair_phase": 4,
	}
	for path, want := range expected {
		if got := decodedValue(root, strings.Split(path, ".")...); got != want {
			return fmt.Errorf("Stripe contract %s: got %v, want %v", path, got, want)
		}
	}
	if !reflect.DeepEqual(stringsAt(root, "webhook", "verify_sequence"), []string{"read-bounded-raw-bytes", "verify-signature-over-exact-raw-bytes", "parse-json"}) {
		return fmt.Errorf("Stripe contract webhook.verify_sequence is not pinned")
	}
	if !sameStrings(stringsAt(root, "checkout", "enabled_plans"), []string{"limited-weekly", "limited-monthly"}) ||
		!reflect.DeepEqual(stringsAt(root, "checkout", "fingerprint_fields"), []string{"plan-key", "configured-currency", "contract-version"}) {
		return fmt.Errorf("Stripe checkout inventory mismatch")
	}
	if !reflect.DeepEqual(stringsAt(root, "checkout", "command_unique_key"), []string{"customer-id", "command-type", "idempotency-key"}) {
		return fmt.Errorf("Stripe checkout command key inventory mismatch")
	}
	if !sameStrings(stringsAt(root, "events"), []string{"checkout.session.completed", "checkout.session.expired", "customer.subscription.created", "customer.subscription.updated", "customer.subscription.deleted", "invoice.paid", "invoice.payment_failed"}) {
		return fmt.Errorf("Stripe event inventory mismatch")
	}
	if !sameStrings(mappingKeys(child(root, "event_effects")), stringsAt(root, "events")) {
		return fmt.Errorf("Stripe event effect inventory mismatch")
	}
	for event, want := range approvedStripeEventEffects {
		if !reflect.DeepEqual(stringsAt(root, "event_effects", event), want) {
			return fmt.Errorf("Stripe event effect %s mismatch", event)
		}
	}
	if !reflect.DeepEqual(stringsAt(root, "transaction", "scope"), []string{"access-state", "audit-entry", "billing-command", "billing-period", "event-inbox-status", "mapped-plan-version", "quota-grant-or-reset", "subscription-state"}) {
		return fmt.Errorf("Stripe transaction scope mismatch")
	}
	terminal := stringsAt(root, "inbox", "terminal_states")
	success := stringsAt(root, "acknowledgement", "success_states")
	if !sameStrings(stringsAt(root, "inbox", "states"), []string{"received", "processing", "applied", "ignored", "rejected", "deferred", "failed-retryable"}) {
		return fmt.Errorf("Stripe inbox state inventory mismatch")
	}
	if !sameStrings(terminal, []string{"applied", "ignored", "rejected"}) || !sameStrings(success, terminal) || !sameStrings(stringsAt(root, "inbox", "retryable_states"), []string{"received", "deferred", "failed-retryable"}) {
		return fmt.Errorf("Stripe inbox acknowledgement states are inconsistent")
	}
	caseInventories := map[string][]string{
		"success_cases":     {"supported-event-terminal-state", "unsupported-event-type-terminal-ignored"},
		"bad_request_cases": {"invalid-signature", "malformed-json", "invalid-signature-timestamp", "clock-unavailable"},
		"conflict_cases":    {"event-id-payload-hash-mismatch"},
		"too_large_cases":   {"raw-body-limit-exceeded"},
		"retry_cases":       {"inbox-persistence-failed", "received", "processing-not-terminal-after-bounded-wait", "deferred", "failed-retryable", "effect-transaction-failed"},
	}
	for field, want := range caseInventories {
		if !sameStrings(stringsAt(root, "acknowledgement", field), want) {
			return fmt.Errorf("Stripe acknowledgement case inventory mismatch")
		}
	}
	return nil
}

func lintStripeFieldInventories(root *yaml.Node) error {
	inventories := map[string]string{
		"root":                        "contract_version implementation_status normative_authority prose_role routes checkout portal webhook bindings inbox acknowledgement events event_effects transaction known_nonconformance",
		"routes":                      "checkout portal webhook",
		"routes.checkout":             "method path auth origin csrf",
		"routes.portal":               "method path auth origin csrf return_policy",
		"routes.webhook":              "method path auth origin csrf",
		"checkout":                    "enabled_plans enabled_price_count price_policy idempotency_header persisted_request_fingerprint fingerprint_fields exact_retry fingerprint_conflict_http stripe_idempotency_key command_unique_key command_ownership concurrent_duplicate indeterminate_recovery browser_state_authoritative",
		"portal":                      "customer_ownership customer_id_input return_destination stripe_hosted",
		"webhook":                     "max_raw_body_bytes signature_header endpoint_secret signature_tolerance signature_timestamp_source signature_timestamp_rule clock_failure verify_sequence raw_payload_logs signature_logs",
		"webhook.signature_tolerance": "minimum_seconds default_seconds maximum_seconds",
		"bindings":                    "startup_account_check endpoint_account event_account mode customer subscription price currency period",
		"inbox":                       "unique_key payload_hash persist_before_effect states terminal_states retryable_states processing_ownership terminal_replay retryable_replay concurrent_duplicate payload_mismatch out_of_order unknown_reference unsupported_event recovery",
		"acknowledgement":             "success_http success_states success_cases bad_request_http bad_request_cases conflict_http conflict_cases too_large_http too_large_cases retry_http retry_cases",
		"transaction":                 "scope billing_period_id_owner grant_reset_cardinality audit",
		"known_nonconformance":        "file behavior repair_phase",
	}
	for path, fields := range inventories {
		node := child(root)
		if path != "root" {
			node = child(root, strings.Split(path, ".")...)
		}
		if node == nil || node.Kind != yaml.MappingNode || !sameStrings(mappingKeys(node), strings.Fields(fields)) {
			return fmt.Errorf("Stripe contract %s field inventory mismatch", path)
		}
	}
	return nil
}
