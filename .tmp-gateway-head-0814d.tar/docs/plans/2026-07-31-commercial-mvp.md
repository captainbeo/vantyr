# Commercial MVP Execution Plan

- **Status:** Draft for independent review and owner approval
- **Implementation authority:** None until the owner approves this document
- **Goal:** Launch the smallest secure invite-only paid AI API reseller built on
  New API, with Codex CLI streaming, direct-API enforcement, Stripe lifecycle
  handling, two-channel failover, and a thin customer setup page
- **Architecture:** A thin fork of New API remains the only customer-facing API
  gateway. PostgreSQL stores durable access, quota, billing, and audit state.
  Redis atomically enforces concurrency and hourly rate limits. Stripe hosts
  checkout and billing self-service. Channels remain vendor-neutral data.
- **Tech stack:** Go and the inherited React/TypeScript frontend; New API commit
  `66ee6b8f9889050ffef1f863a4314ce4a0516fb9`; PostgreSQL; Redis; Stripe
  Checkout/Customer Portal; Docker Compose; Codex CLI `0.146.0`
- **Baseline/authority refs:**
  `D:\Downloads\Codex_Build_Specification.docx`,
  `docs/specs/2026-07-30-channel-and-codex-compatibility-design.md`,
  `docs/compliance/2026-07-31-new-api-license-compliance.md`, and the pinned New
  API/Codex sources
- **Compatibility boundary:** Support `POST /v1/responses`,
  `POST /v1/responses/compact`, `GET /v1/models`, and the documented root
  aliases required by origin-only Codex configuration. Normal Codex `0.146.0`
  Responses calls use SSE (`stream: true`). No failover is permitted after any
  customer-visible response byte is committed.
- **Verification:** Each phase has a hard test/review gate. A failed gate stops
  execution. Completion requires all 13 proof items in Section 9 with fresh
  command output.

## 1. Product boundary

```mermaid
flowchart LR
    C["Customer or Codex CLI"] -->|"platform API key"| G["Branded New API fork"]
    G --> A["PostgreSQL access and quota state"]
    G --> L["Redis concurrency and rate admission"]
    G --> R["Channel selection and safe failover"]
    R --> P["Primary transfer-station channel"]
    R --> S["Secondary transfer-station channel"]
    T["Stripe Checkout and Portal"] --> W["Verified idempotent webhook"]
    W --> A
```

### Included in the first private commercial release

- Limited Weekly and Limited Monthly only.
- `gpt-5.4` and `gpt-5.5` public aliases with exact `xhigh` entitlement;
  upstream model slugs remain channel configuration.
- Seven editable plan records, with the five unlimited/GPT-5.6 plans disabled.
- Two active named channels. They may share a supplier for initial testing, but
  that is not provider redundancy.
- One-time-display customer keys verified by indexed HMAC; no stored raw key
  and no full-key recovery endpoint.
- PostgreSQL request-quota reservation/settlement and cycle reset.
- Mandatory Redis concurrency leases and independent rolling-hour image-rate
  admission. Image routes remain globally disabled after the limiter proof.
- SSE Responses/compact compatibility for Codex CLI `0.146.0`.
- One safe pre-commit failover, attempted-channel exclusion, basic rolling
  health, request/attempt/cost logs, and a basic 3x-consumption anomaly signal.
- Stripe-hosted Checkout and Customer Portal with an idempotent webhook inbox.
- Existing New API key/quota/usage console plus one thin branded setup page.

### Preserved editable plan catalog

`NULL` means commercially uncapped for that meter, not unmetered physical use.
Image entitlement remains globally disabled in the MVP regardless of the stored
catalog value.

| Plan | Price/cycle | Text entitlement/default | Request or token quota | Concurrency | Image/hour | MVP enabled |
|---|---:|---|---|---:|---:|---|
| Limited Weekly | $10/week | `gpt-5.4`, `gpt-5.5`; `xhigh` | 10,500 requests | 4 | `NULL` | Yes |
| Limited Monthly | $27/month | `gpt-5.4`, `gpt-5.5`; `xhigh` | 45,000 requests | 4 | `NULL` | Yes |
| Unlimited Weekly | $19/week | `gpt-5.4`, `gpt-5.5`; `xhigh` | Unlimited tokens | 4 | `NULL` | No |
| Unlimited Monthly | $65/month | `gpt-5.4`, `gpt-5.5`; `xhigh` | Unlimited tokens | 4 | `NULL` | No |
| Unlimited GPT-5.6 Monthly | $185/month | `gpt-5.6-sol` | Unlimited tokens | 4 | `NULL` | No |
| Unlimited GPT-5.6 Weekly | $65/week | `gpt-5.6-terra` | Unlimited tokens | 3 | 10 | No |
| Unlimited GPT-5.6 Daily | $19/day | `gpt-5.6-terra` | Unlimited tokens | 2 | 10 | No |

All seven records preserve `gpt-image-2` as the configurable product image
alias. A separate global `image_enabled=false` release control and the public
route registry keep that entitlement unreachable in the MVP.

### Explicitly deferred

- Public signup, public launch, SLAs, multi-region, multi-replica HA, Kubernetes,
  Terraform, and gateway-level disaster failover.
- Enabling image generation or any unlimited plan.
- Wallets, top-ups, custom invoices, tax logic, or custom card handling.
- Attribution-free white-labelling, advanced fraud tooling, multiple secret
  managers, arbitrary auth templates, query authentication, and explicit
  outbound proxies.
- Image enablement after Redis state loss. Before images can launch, the system
  must durably replay the active rolling-hour window or quarantine image
  admission fail-closed for the full hour; the private MVP keeps every image
  path disabled.
- SQLite/MySQL compatibility for new commercial-MVP tables. The deployment
  target is PostgreSQL; upstream portability work remains in the hardening
  roadmap.

## 2. Planning checks

### Plan Basis

- **Fact:** New API already provides Responses routes, channel priority/weight,
  model mapping, customer tokens, subscriptions, quota reservation, usage logs,
  and a customer console.
- **Fact:** The pinned source stores upstream and customer keys recoverably,
  exposes full-key recovery routes, has no customer concurrency limiter, treats
  Redis as optional, lacks a complete recurring Stripe event inbox/lifecycle,
  and does not guard retry by downstream commitment.
- **Fact:** Codex CLI `0.146.0` sends normal Responses requests with
  `stream: true`; a non-stream-only release is not a Codex MVP.
- **Assumption:** The private cohort can start in one region and one gateway
  replica. Central Redis enforcement is still required and keeps a later second
  replica possible without changing the admission contract.
- **Unknown:** Live supplier terms, credentials, model slugs/prices, hosting,
  DNS, and Stripe configuration. These block the relevant live gates, not local
  contract-first implementation.

### BaselineUsageDraft

- **Required and acknowledged:** Original DOCX; approved channel/Codex design;
  oversized Step 1 roadmap; pinned New API source/licence; pinned Codex source;
  Kadirr's public Codex integration document.
- **Cited here:** All of the above except Kadirr private internals, which are
  intentionally unknown and irrelevant.
- **Missing:** No requirement authority is missing for planning.
- **Decision:** Continue to independent review.

### Requirement Ready Check

- Goals, private-cohort scenario, enabled plans, security boundaries, 13 proof
  items, and stop conditions are explicit.
- External credentials and commercial agreements are release inputs, not
  reasons to invent architecture.
- **Decision:** Ready for owner review; not ready for implementation until owner
  approval.

### Existence Check

| Proposed surface | Reuse decision | Creation proof |
|---|---|---|
| Customer key/quota/usage UI | Reuse New API | It already exposes these views. |
| Billing UI | Reuse Stripe Checkout/Portal | Stripe owns payment methods, invoices, and cancellation. |
| Customer setup page | Add one inherited-console route | Neither reused surface presents plan status plus safe Codex configuration in one customer-scoped view. |
| Stripe event inbox/access audit | Add PostgreSQL tables | Native code lacks event-ID deduplication and full recurring lifecycle audit. |
| Custom proxy/router | Reject | New API remains the gateway and routing owner. |

### Architecture Integrity Lens

- **Invariant:** One request path owns authentication, subscription checks,
  quota, Redis admission, routing, metering, and sanitized response handling.
- **Canonical owners:** Stripe for billing events; PostgreSQL for durable access
  and request quota; Redis for atomic concurrent/hourly admission; New API for
  customer API enforcement and upstream routing.
- **No overlap:** The browser never grants access, Stripe is never called on the
  request hot path, and no sidecar retries requests behind New API's back.
- **Verdict:** Use existing owners; add only demonstrated gaps.
- **ArchitectureReviewRequired:** yes.

### Plan-Time Complexity Check

- Highest-pressure inherited files are `controller/relay.go`,
  `model/subscription.go`, `middleware/distributor.go`, and
  `router/relay-router.go`.
- Add narrow owner files for gateway-key verification, admission, channel
  attempts, Stripe inbox processing, and setup-page data. Do not grow one
  all-purpose middleware or rewrite the relay stack.
- **Budget result:** At risk but controllable with isolated owner files and
  characterization tests before reuse.

## 3. Locked implementation decisions

1. Import the exact New API commit with history preserved; do not copy a source
   snapshot or track `latest` images.
2. One PostgreSQL database is the durable application/gateway database. Stripe
   webhook processing runs in the same Go service and writes the access
   projection transactionally.
3. Redis is required in commercial mode. Missing, empty, stale, timed-out, or
   script-failing limiter state rejects protected requests with a sanitized
   `503`; there is no in-memory fallback.
4. Gateway keys use `key_id + 256-bit random secret`. Store only a versioned
   HMAC-SHA-256 verifier derived with `GATEWAY_KEY_PEPPER`; compare in constant
   time. Show the raw key once. Pepper compromise requires key reissue.
5. Channel rows store `env://NAME` secret references, never resolved values.
   MVP auth schemes are typed Bearer and validated fixed-header authentication.
6. Production channel URLs require HTTPS, reject user-controlled URLs, redirects,
   proxies, loopback/private/link-local destinations, and DNS rebinding. Test
   mocks use an explicit non-production allowlist.
7. A logical request reserves one request unit by request ID. A successful
   response uses a durable pre-write commit fence to settle one unit before any
   customer write. Delivery is recorded separately because a database
   transaction and socket write cannot be atomic. A crash/write failure between
   fence and first write is conservatively consumed, never automatically
   refunded or replayed. A terminal failure before the fence releases the unit.
   Internal retries never reserve a second unit. The idempotency ID is generated
   by the gateway; a customer-supplied request/correlation ID is never trusted
   as quota identity.
8. Native subscription quota remains the single owner, but pinned-source
   characterization has demonstrated concrete gaps: it selects any active user
   subscription, ignores model/quota type, lacks request fingerprint/commit
   state, and nests refund work outside the owning transaction. Extend
   `SubscriptionPreConsumeRecord` and its transaction narrowly with exact
   access/subscription binding, a versioned request fingerprint, and one-transaction
   compare-and-set `pending -> committed|refunded` transitions. The separate
   enterprise `customer_usage_reservations` table is not created.
9. Concurrency is a Redis lease scoped to the immutable subscription/entitlement
   ID, acquired after access checks and before quota reservation. Issuing or
   rotating keys cannot multiply capacity; key ID remains audit metadata. Every
   active request renews its owned lease until a hard maximum duration; every
   completion, error, and cancellation releases it. TTL is only the process-
   crash backstop. Admission above the exact plan cap is rejected.
10. The image limiter is an independent rolling-hour Redis admission script
    scoped to that same subscription/entitlement ID. It is implemented and
    tested at 10/hour even though image routes and image entitlements remain
    disabled in the private release.
11. Retry is limited to one secondary attempt, excludes attempted channels, and
    applies only to replay-safe Responses requests that have not committed a
    customer byte. No image, background, stored, or other side-effecting request
    is retried.
12. Every upstream attempt is logged separately. One final logical-request row
    owns customer usage and quota settlement. Monetary values use integer
    micro-units and versioned channel cost metadata.
13. Kadirr is used only as public customer-workflow evidence: base URL, platform
    key, and Codex configuration. No private implementation is copied or claimed.
14. Access is decided at request admission. A revocation/payment failure may let
    an already-committed stream finish, but every later request is rejected;
    pre-commit work is cancelled. This rule is part of the public contract and
    prevents mid-stream billing races from creating a second response policy.

## 4. File ownership map

| Area | Expected files after pinned import |
|---|---|
| Public/API contracts | `docs/contracts/customer-api.openapi.yaml`, `docs/contracts/stripe-events.md`, `router/relay-router.go`, `router/api-router.go` |
| Deployment/CI | `deploy/mvp/compose.yaml`, `deploy/mvp/.env.example`, `.github/workflows/ci.yml`, `.gitleaks.toml` |
| Channels/secrets | `model/channel.go`, `service/channel_secret.go`, `service/channel_select.go`, `middleware/distributor.go` |
| Keys/access | `model/token.go`, `service/gateway_key.go`, `middleware/gateway_access.go`, `controller/token.go` |
| Plans/quota | `model/subscription.go`, `service/funding_source.go`, `service/subscription_reset_task.go`, `model/migrations/*` |
| Redis admission | `middleware/gateway_concurrency.go`, `middleware/image_rate_limit.go`, `common/redis.go` |
| Relay/failover | `controller/relay.go`, `service/channel_attempt.go`, `relay/channel/openai/relay_responses.go` |
| Metering/health | `model/gateway_usage.go`, `service/channel_health.go`, `service/log_info_generate.go` |
| Stripe | `controller/subscription_payment_stripe.go`, `controller/stripe_webhook.go`, `model/stripe_event.go`, `model/billing_command.go`, `service/stripe_subscription.go` |
| Thin page | `web/src/routes/_authenticated/integration/index.tsx`, `web/src/features/integration/*` |
| Proof suites | `integration/mvp/*`, `test/load/*`, `testdata/codex/0.146.0/*`, `scripts/verify-*.ps1` |

Final paths may follow an inherited equivalent if the pinned import already has
a clearer owner. Any path change must preserve the ownership boundaries above
and be recorded in the phase review; it is not permission to add a sidecar.

## 5. Execution protocol

- After owner approval, create `codex/commercial-mvp` in an isolated worktree.
- Every product step follows: write focused failing test, run and record RED,
  implement the minimum change, run and record GREEN, then make one scoped
  commit. Unexpected failures use systematic debugging before edits.
- Endpoint and webhook work requires approved API/event contracts first. Schema
  work requires an approved forward/rollback migration contract first.
- Do not advance when a phase gate fails. Fixes return to RED and the affected
  specialist reviews rerun.
- Imported upstream code is not rewritten for style. Fork delta stays narrow.
- Database access is parameterized through the inherited data layer. Customer
  values are never rendered as raw HTML, and cookie-authenticated account/Portal
  mutations retain strict origin/CSRF protections.

## 6. Thirty-five executable steps

### Phase 0 — Pin, contracts, and reproducible foundation

| Step | Change and files | Required proof |
|---|---|---|
| 0.1 | Create the approved worktree; import New API history at the exact SHA; record provenance in `docs/upstream/new-api.md`. | `git rev-parse HEAD` equals the pin; `git status --short` is clean before fork changes; `go test ./...` records the upstream baseline. |
| 0.2 | Apply the licence checklist: preserve notices, add dated fork-origin notice, keep UI attribution/link, and define the exact deployed-source offer. | `rg` finds the required text/link in source and built UI; the source link resolves to the deployed revision without secrets. |
| 0.3 | Write and approve the restricted customer OpenAPI contract, SSE/error/header rules, root aliases, dashboard-cookie origin/CSRF rules, and Stripe event contract. | Contract lint passes; route inventory contains only models, Responses, compact, required auth/account routes, Stripe webhook/portal, and detail-free health. |
| 0.4 | Write the PostgreSQL forward/rollback migration contract for key verifiers, plan entitlements, Stripe inbox/outbound billing commands/audit, channel attempts/health/cost, final logical usage/delivery state, the enforcement epoch, and the minimum native `SubscriptionPreConsumeRecord` state/fingerprint/billing-period extension. | Database and security reviewers approve period binding, transaction/CAS, index, uniqueness, retention, epoch/drain recovery, and rollback behavior before migration code; no duplicate quota-reservation table exists. |
| 0.5 | Add `deploy/mvp/compose.yaml` with pinned gateway build, PostgreSQL, password-protected Redis, and two controllable mock transfer stations; all secrets enter via environment/deployment secrets. | `docker compose ... config` contains no literal secret; `up --build --wait` makes gateway, PostgreSQL, Redis, and both mocks healthy. |
| 0.6 | Establish CI for Go tests/race/vet/static analysis, frontend tests/build, migration tests, dependency audit, secret scan, and Compose integration. | A deliberate failing test and secret sentinel each fail CI; clean baseline passes. |

**Phase 0 gate:** infra, licence/compliance, API-contract, migration, and security
reviews have no blocker; proof 1 passes. Otherwise stop.

### Phase 1 — Working branded gateway and streamed Codex path

| Step | Change and files | Required proof |
|---|---|---|
| 1.1 | Extend native channel records with stable ID/name, enabled state, base URL, typed auth/secret ref, mappings, priority/weight, connect/header/first-event timeouts, retry eligibility, versioned integer request/input/output/cached-token/image cost rates, failure domain, and health state; reject legacy raw `Key` writes and disable native full-channel-key recovery. Inventory every pinned `Channel.Key` reader, including scheduled tests, admin connectivity/balance, task/image paths, retries/adaptors, and Codex refresh. | Migration round-trip and an explicit reader inventory prove editable fields, vendor-neutral cost metadata, reference-only writes, zero resolved/raw secret output, and no unclassified raw-key reader. |
| 1.2 | Add `env://` resolution, validated Bearer/fixed-header injection, SSRF-safe dial checks, bounded transport/response/event sizes, redirect/proxy rejection, allowlisted outbound/request headers, and response-header stripping. Convert allowed relay paths to the resolver and disable unsupported inherited key-reading checks/tasks/refresh paths in commercial mode; add a static regression guard for new `Channel.Key` reads. | Unit/integration/static tests cover every inventory entry plus missing secret, forbidden address, DNS rebind, hostile headers, redirect, oversized/malformed response or SSE event, timeout, and sanitized client errors. No gateway-mode path reads a stored raw channel key. |
| 1.3 | Seed two enabled mock channels with distinct IDs, mappings, priority, weight, secret refs, and attempt capture; label shared failure domains honestly. | Both channels independently complete the same mapped fixture; each sees only its own credential and upstream model slug, while customer JSON/SSE/headers/errors expose only the public alias. |
| 1.4 | Replace recoverable customer-token lookup with indexed HMAC verification and one-time display; disable `/token/:id/key`, `/token/batch/keys`, raw-key search/export, and raw-key logs. | Creation returns the key once; DB/Redis/log/UI scan cannot recover it; authentication, revocation, constant-time verifier, collision, and missing-pepper tests pass. |
| 1.5 | Seed all seven editable plan records and versioned model/effort entitlements; enable only Limited Weekly/Monthly and set 10,500/45,000 request quotas plus concurrency 4. | Seed repeat is idempotent; API/UI expose two enabled plans; disabled plans and image aliases cannot be purchased or used. |
| 1.6 | Install the deny-by-default customer pipeline before token estimation: gateway-generated request IDs, Bearer auth, bounded methods/content types/compressed and decompressed bodies, strict JSON depth/item/string/output/tool limits, duplicate/unknown control rejection, known aliases/parameters/function tools, `store:false`, no background mode, and global image/media-route rejection. Reject every remote `input_image`/`input_file` URL form so no customer value reaches a fetch client. | Both Responses aliases reject alternate relay/auth routes, customer-controlled idempotency IDs, image/web tools, remote media URLs including private/link-local/loopback/DNS-rebind/redirect/proxy cases, decompression bombs, excessive JSON shapes, duplicate/unknown controls, `store:true`, and background requests before token counting, routing, or upstream code. |
| 1.7 | Preserve New API Responses/compact SSE behavior, add both canonical/root aliases, and run real Codex `0.146.0` against the mocks with an isolated `CODEX_HOME`. | Verified Codex binary completes a streamed turn and compact call using only platform base URL/key; capture proves the key never becomes the upstream credential. |

**Phase 1 gate:** code, Go, TypeScript-if-touched, AI, security, infra, and E2E
reviews pass; a fixture key completes the streamed proof 13 path through the
mock channels. Authoritative plan/access proof 2 belongs only to Phase 2.
Otherwise stop before access enforcement.

### Phase 2 — Authoritative access, quota, and fail-closed admission

| Step | Change and files | Required proof |
|---|---|---|
| 2.1 | Add the PostgreSQL access projection tying customer, HMAC key ID, plan version, Stripe customer/subscription IDs, access status, immutable billing-period ID/reset version, and period bounds; no browser field is authoritative. | Transaction tests cover active, trial-if-enabled, unpaid, cancelled, expired, revoked, period rollover, and tenant-isolated transitions. |
| 2.2 | Enforce access status, expiry, plan-version alias/effort scope, and key revocation before Redis admission or channel selection; filter model discovery by the same effective scope. | Direct API matrix proves denied states/models cannot enumerate or call disallowed aliases and produce no upstream attempt. |
| 2.3 | Pin RED characterization fixtures for the demonstrated native gaps, then extend `PreConsumeUserSubscription` to require the authoritative access/subscription ID, immutable billing-period ID/reset version, request-quota type, model/endpoint fingerprint, row lock, and atomic one-unit `pending` reservation; remove the nested refund transaction. | PostgreSQL fixtures prove the wrong period/expired/other-plan subscription cannot be selected, mismatched fingerprints fail, the exact row is locked, and concurrent admission cannot exceed the remaining request quota. |
| 2.4 | Add one-transaction CAS settlement from `pending` to `committed` at the pre-write fence, or to `refunded` on terminal pre-fence failure. A refund decrements current `AmountUsed` only when its stored period version still matches; late old-period commit/refund changes only that reservation/audit record. Reconcile only stale pending rows with no commit fence. | Retry uses one reservation; duplicate ID/fingerprint cannot double consume, commit, or refund; reserve-before-renewal plus commit/refund-after-renewal cannot change concurrent new-period usage; weekly/monthly period IDs and quota reset exactly once. |
| 2.5 | Add atomic Redis Lua concurrency leases per immutable subscription/entitlement ID with the active PostgreSQL enforcement epoch, gateway-generated request IDs, owner-checked renewal through a hard maximum request duration, ownership-safe release, cancellation cleanup, and no in-memory fallback; key ID is audit-only. | At cap 4, multiple keys for one subscription still admit exactly four simultaneous requests and reject the fifth beyond the initial TTL; wrong-owner/old-epoch renewal/release fails; stopping renewal after a crashed process lets TTL recover capacity. |
| 2.6 | Add the independent Redis rolling-hour image limiter at 10/subscription/hour with the same enforcement epoch, but keep image entitlement and every image route disabled. | Multiple test keys bound to one test-only entitlement collectively admit 10 and reject 11, survive concurrency, reject old/empty epochs, and cannot bypass the cap through rotation, sequential calls, or alternate image paths. |
| 2.7 | Add commercial-mode startup/readiness checks and outage injection for Redis/limiter scripts and PostgreSQL access/quota state. Recovery is explicit: close admission, drain the single gateway for the maximum request/lease TTL, bump the PostgreSQL epoch, initialize Redis, then reopen. | Redis down, empty/stale epoch, script error, or PostgreSQL failure rejects protected requests before upstream; the documented drain/reinitialize path restores readiness without claiming transparent live-lease reconstruction. |

**Phase 2 gate:** database, security, performance, code, and E2E reviews pass;
proofs 2–7 pass with direct API and simultaneous-request evidence. Otherwise
stop before live routing work.

### Phase 3 — Safe failover, health, metering, and anomaly signal

| Step | Change and files | Required proof |
|---|---|---|
| 3.1 | Carry an attempted-channel set through selection; exclude prior attempts; select by enabled/model/health/priority then weight; cap one primary plus one secondary attempt. | Unit tests prove no reselection/loop and stable priority/weight behavior with two eligible channels. |
| 3.2 | Classify replay-safe pre-response connection, timeout, selected upstream status, response-header, first-semantic-event, and channel-credential failures; reject retry for customer authentication/authorization, validation, cancellation, stored/background/image, and other side-effecting requests. | Table tests distinguish customer-auth rejection from one channel's unresolved credential, enumerate every retryable/non-retryable class, and prove exactly one attempt for unsafe requests. |
| 3.3 | Add an explicit downstream commitment guard around non-stream and SSE writers. Before any customer-visible header, body byte, or flush, atomically persist `commit_fenced_at` and commit the one request-quota reservation; a persistence failure stays pre-fence and fails closed. After the first write returns, record `first_write_succeeded_at` and delivery status separately. A crash/write failure in the fence-to-write gap is marked delivery-uncertain, remains consumed, and is neither refunded nor replayed. After any successful write, never replay; if the stream later fails and the socket is writable, emit the approved sanitized `response.failed` envelope and close. | SSE/non-stream fixtures prove pre-event failure can fail over, the commit fence precedes the first write, crash/write failure in that exact gap remains consumed with delivery-uncertain audit, post-write failure never replays or appends JSON, and sanitized `response.failed` preserves only the public response ID/stable platform code. |
| 3.4 | Record bounded rolling error rate and p95 first-event latency per channel/model class in Redis; apply cooldown/deprioritization and conservative recovery probes. | Deterministic clock fixtures degrade, deprioritize, recover, and never label two same-supplier rows as independent redundancy. |
| 3.5 | Insert an immutable attempt row before each upstream dispatch, then update its terminal class. Maintain one final logical-usage row with customer ID, non-secret key ID, requested alias, failed/successful channel IDs, input/output tokens, one request unit, latency, timestamp, commit-fence/first-write/delivery status, final status/error class, cost version, and integer estimated upstream cost. Buffer upstream `response.completed` until terminal usage/cost and attempt/final rows commit; persistence failure after earlier SSE output emits sanitized `response.failed`. Keep internal slugs/cost out of customer views. | No upstream observation exists without a prior attempt row; known-token/cost fixtures match exactly; no `response.completed` precedes terminal usage persistence; failover has two attempts and one final usage/quota settlement; customer logs expose no provider/internal cost. |
| 3.6 | Add a scheduled/admin metric comparing per-key token rate with comparable active-customer average, with minimum cohort and token floors; alert at approximately 3x. | Fixtures alert the outlier, suppress tiny cohorts/noise, use bounded-cardinality metrics, and do not auto-ban. |
| 3.7 | Configure two real transfer-station channel rows through secret refs, confirm resale/test authorization, then break primary connection/secret/first-event behavior under concurrent load and exercise secondary completion, all-channels-fail, and post-commit failure. | Real valid pre-commit failures return one clean secondary success before any Stripe work; concurrent failover has no loop, duplicate quota, or mixed bytes; unsafe/post-commit cases do not replay. Shared supplier/failure-domain limits are recorded. |

**Phase 3 gate:** AI, security, performance, database, Go, and E2E reviews pass;
proofs 8, 9, and 12 pass against mocks and the authorized real transfer
station. Otherwise stop before billing.

### Phase 4 — Stripe lifecycle and thin customer page

| Step | Change and files | Required proof |
|---|---|---|
| 4.1 | Implement the approved PostgreSQL migration for unique Stripe event IDs, processed/effect status, outbound billing-command IDs/state, subscription/access identifiers, and append-only access/quota audit entries. | Fresh, rollback, reapply, event/command uniqueness, concurrent insert, and command recovery tests pass on PostgreSQL. |
| 4.2 | Use Stripe Checkout for the two enabled Price IDs. Require an authenticated inbound `Idempotency-Key`; the customer page persists one key per purchase intent across network retry/reload. Before Stripe, persist unique `(customer_id, command_type, key)` with a normalized plan/currency request fingerprint and one server command ID reused as Stripe's `Idempotency-Key`. Exact retries return the original Checkout session; key reuse with another fingerprint returns conflict. Verify webhook signatures on the raw bounded body and bind every event to the configured Stripe account, expected test/live mode, known customer/subscription, and allowlisted Price-to-plan mapping before transactionally processing checkout, active renewal, payment failure, cancellation, expiry, upgrade, or downgrade through the inbox. | Lost-response, reload, and concurrent duplicate HTTP requests create one command/Checkout/effect; fingerprint mismatch conflicts. Official signed fixtures plus wrong account/mode/customer/Price, shuffled, duplicated, concurrent, and stale events yield either rejection or one correct access effect and exactly one billing-period ID/quota grant/reset per Stripe period with a complete audit trail; logs contain neither signature nor raw payload. |
| 4.3 | Add authenticated Stripe Customer Portal session creation with customer ownership checks, strict origin/CSRF enforcement, and an allowlisted return URL. | Cross-customer/forged IDs and cross-origin requests fail; valid user receives a Stripe-hosted URL; no billing secret reaches browser output. |
| 4.4 | Add one page inside New API's authenticated, server-authorized customer session showing plan/status, renewal/expiry, usage/quota, permitted aliases, gateway URL, one-time key creation, clear error state, Portal link, and two copyable Codex `0.146.0` snippets: canonical `/v1` plus documented origin-only compatibility. Secrets stay in the isolated auth/env mechanism, never TOML. | Frontend unit/accessibility tests and two-customer E2E prove server-side tenant authorization, isolation, safe copy flows, no upstream/provider/internal-cost data, no secret in TOML or the bundle, and both snippets emit only the platform Bearer credential. |
| 4.5 | Run checkout-to-Codex E2E and billing/security/compliance reviews, including unpaid cancellation and webhook replay while traffic is active. | Access activates/revokes only from authoritative events; replay grants no duplicate quota/access; in-flight and subsequent direct requests follow the documented transition rule. |

**Phase 4 gate:** proofs 10 and the commercial customer journey pass; payment,
security, compliance, database, frontend, and E2E reviews have no blocker.
Otherwise stop before release validation.

### Phase 5 — Release evidence and private cohort

| Step | Change and files | Required proof |
|---|---|---|
| 5.1 | Run exact-cap/quota/load/failover tests plus source, DB fixture, Redis, logs, responses, browser bundle, image/container, and generated-config secret scans; use distinct prompt/response-content sentinels to prove content appears only at the contracted upstream/customer payload boundaries; reconcile known token/cost fixtures. | `go test -race ./...`, frontend tests/build, Compose integration, k6 exact-cap/concurrent-failover suites, dependency/static scans, and gitleaks all pass with retained reports, no secret echo, and zero prompt/response sentinel occurrence in persistence or observability. |
| 5.2 | Re-run the already-gated real-channel failover and the verified Codex `0.146.0` streamed turn against the final release image/digest; do not introduce a new supplier or routing behavior here. | Proofs 8, 9, and 11–13 remain green on the release candidate; if channels share a failure domain, documentation says so and no HA claim is made. |
| 5.3 | Deploy the private single-region cohort with TLS, encrypted database volumes/backups, secrets injection, backup/restore drill, alerts, source offer, privacy/terms links, and an operator runbook covering issue/revoke, Stripe replay, Redis outage, failover, rollback, and spend/margin review. | Fresh runbook execution passes; restore and rollback are timed; source link works; a small invited customer completes checkout, setup, and a streamed Codex turn while operators monitor errors, anomaly alerts, and margin. |

**Phase 5 gate:** all 13 proofs are fresh, all mandatory reviews have no
unresolved blocker, no diagnostic secret-bearing debris remains, and the owner
approves the private launch. This does not authorize public launch.

## 7. Delivery forecast

The source specification's seven-day target is an aggressive commercial target,
not a security exception or a credible solo-engineer promise. It is considered
only if all external inputs are ready before work starts, the pinned baseline is
green, and at least three experienced owners can run these non-conflicting
workstreams after Phase 0 contracts are approved:

| Workstream | Scope |
|---|---|
| Gateway/security | Phases 1–3, including real channel and Codex proofs |
| Billing/frontend | Phase 4 behind a disabled feature flag; integration waits for Phase 3 |
| Infra/verification | Compose/CI, fixtures, load/security evidence, release runbook |

The hard phase gates remain serial even when preparation runs in parallel.
Reforecast from measured Phase 0 evidence and actual staffing. With one owner or
late credentials/contracts, expect the build to exceed one week. Security
failures move the date; they do not move the gate.

## 8. Exact review routing

- Every product diff: code reviewer.
- Go: Go reviewer. TypeScript/React: TypeScript reviewer.
- Auth, keys, inputs, SSRF, limiters, headers, logs, failover: security reviewer.
- Migrations, quota, event inbox, locks/indexes: database reviewer and migration
  gate.
- Responses/SSE/model mapping/token usage: AI reviewer.
- Stripe, customer data, licence/privacy/payment boundary: compliance reviewer.
- Compose, CI, TLS, secrets, backups: infrastructure reviewer.
- Concurrency/failover/load: performance reviewer.
- Each phase: E2E reviewer and harness audit.
- Any blocking finding returns to a failing regression test and reruns every
  affected review.

## 9. Required proof traceability

| # | Required proof | Owning steps/gate |
|---|---|---|
| 1 | New API starts with PostgreSQL and Redis | 0.5, Phase 0 |
| 2 | Key accesses only permitted model/plan | 1.4–1.7, 2.1–2.2 |
| 3 | Expired/revoked access rejected directly | 2.1–2.2, 4.5 |
| 4 | Quota exhaustion enforced atomically | 2.3–2.4 |
| 5 | Exact concurrency cap holds | 2.5 |
| 6 | Redis/limiter outage fails closed | 2.7 |
| 7 | Independent image limiter blocks rapid calls before enablement | 2.6–2.7 |
| 8 | Broken primary safely fails over before response commitment | 3.1–3.3, 3.7; 5.2 revalidates the release image |
| 9 | Failover works under concurrent load | 3.7; 5.1–5.2 revalidate the release image |
| 10 | Stripe replay cannot duplicate access/quota | 4.1–4.2, 4.5 |
| 11 | Upstream secrets absent from customer and artifacts | 1.1–1.4, 4.4, 5.1–5.2 |
| 12 | Usage/cost logs match known fixtures | 3.5, 5.1–5.2 |
| 13 | Codex CLI 0.146.0 completes through base URL/key | 1.7, 5.2–5.3 |

## 10. External blockers and stop conditions

### Not blockers for local implementation

- Final branding copy, support email wording, and exact cloud vendor, provided
  no live deployment is attempted.
- A second independent supplier; two mocks/two same-supplier channels can prove
  routing mechanics but not provider redundancy.

### Block the relevant live gate

- Upstream base URLs, auth credentials, model slugs, pricing, capability limits,
  and written resale/proxy permission.
- Stripe test/live keys, webhook secret, two Price IDs, Portal configuration,
  and account/business verification.
- Hosting target, TLS hostname/DNS, production secret-injection mechanism,
  backup target, and operational alert destination.
- Customer-facing domain/email, privacy notice, terms/refund/cancellation policy,
  and third-party AI processing disclosure.
- A decision to publish Corresponding Source with attribution or obtain a
  commercial New API licence. Attribution-free white-labelling is blocked
  without permission.

Stop rather than guess if an external input is required by the current gate, a
review rejects the contract, the native quota characterization fails, normal
Codex streaming cannot be reproduced, or the upstream terms prohibit resale.

## 11. Rollback and retirement

- Each schema step has a tested rollback and forward-compatible deployment
  order. Billing/access audit and processed Stripe event IDs are retained even
  if a feature is rolled back.
- A bad release rolls back to the prior image digest, disables Checkout, revokes
  new issuance, preserves audit/quota rows, and keeps customer API access closed
  unless the prior version can enforce the same state safely.
- The old `docs/plans/2026-07-31-step-1-foundation.md` remains the future
  hardening roadmap. After private-MVP evidence, promote only measured needs:
  multi-replica epochs, broader secret managers, independent suppliers,
  advanced health, unlimited-plan economics, images, public signup, and HA.
- Temporary mocks, test-only egress exceptions, sentinel credentials, and
  isolated Codex homes are removed from production artifacts after their proof.

## 12. Approval gate

Owner approval authorizes only Phase 0 implementation in an isolated worktree.
Every later phase remains conditional on the preceding hard gate. No payment
may be accepted and no private customer may be invited until Phase 4 passes; no
private launch may occur until Phase 5 passes.
