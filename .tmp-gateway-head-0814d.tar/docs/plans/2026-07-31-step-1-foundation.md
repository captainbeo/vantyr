# Future Hardening Roadmap: Step 1 Gateway Foundation

> **Status: Future hardening roadmap — non-blocking.** This document is preserved for later
> hardening detail and historical review evidence. It no longer authorizes current implementation
> and must not block the commercial MVP selected by
> `docs/plans/2026-07-31-commercial-mvp.md`.

- **Status:** Superseded as the active execution plan on 2026-07-31
- **Date:** 2026-07-31
- **Approved design:** `docs/specs/2026-07-30-channel-and-codex-compatibility-design.md`
- **Foundation:** `QuantumNous/new-api` commit `66ee6b8f9889050ffef1f863a4314ce4a0516fb9`
- **Delivery scope:** Step 1A control plane and Step 1B minimal non-streaming relay proof

## 1. Outcome

Produce a reproducible thin fork of New API with:

- two editable transfer-station channels;
- typed, secret-reference-only channel authentication and configurable outbound paths;
- seven editable subscription plans and model entitlements;
- hashed, one-time-display customer keys bound to stable subscriptions;
- a deny-by-default Bearer-only public surface for models and stateless Responses;
- strict non-streaming Responses validation, model mapping, response reverse mapping, and a narrow
  primary-to-secondary failover proof;
- PostgreSQL deployment, Redis readiness wiring, controlled mock transfer stations, CI, operator
  documentation, and security evidence.

Step 1 does not claim production quota/concurrency/image enforcement, streaming failover, rolling
health, final cost settlement, Stripe, real-channel redundancy, or hosted production deployment.
Those remain later gated checkpoints.

## 2. Locked Decisions and Assumptions

1. The public image alias seeded now is `gpt-image-2`. Its display label is GPT-2 Image; every
   channel supplies the actual upstream slug later.
2. Customer key issuance and revocation use an offline `gateway-admin` CLI in Step 1. No new admin
   HTTP endpoint is exposed.
3. The local reproducible deployment uses Docker Compose. A hosted deployment requires a later
   owner-provided cloud target, DNS/TLS boundary, and secret-injection mechanism.
4. Production uses PostgreSQL. New persistence code remains compatible with SQLite, MySQL 5.7.8+,
   and PostgreSQL 9.6+ to preserve upstream New API compatibility.
5. Step 1 mock aliases are zero-priced in native New API configuration. Native customer quota
   mutation remains disabled for the new subscription-backed keys; Step 2 adds the authoritative
   reservation/settlement path.
6. No executable step below may add or change more than 50 authored code lines in total, including
   its RED test. Larger behaviors are represented as separate lettered steps with their own files,
   dependencies, risk, and verification. Imported upstream code is provenance, not fork delta.
7. All JSON operations use New API's `common` JSON wrappers. No business code calls
   `encoding/json` marshal/unmarshal directly.
8. Step 1 rejects every explicit channel proxy setting during validation/activation and disables
   ambient outbound proxies in the dedicated transport. A later checkpoint may add only a typed,
   reviewed proxy that enforces the approved destination and credential-redaction policy.

## 3. Execution Rules

- Work only in `C:\Users\z\Documents\worktrees\proxy-step1-foundation` on branch
  `codex/step1-foundation` after the plan is approved.
- Import the pinned upstream commit with history preserved; never copy an unversioned source tree.
- Follow RED -> GREEN -> REFACTOR for every production change. A failing behavioral test is
  committed or recorded before its implementation.
- API and migration contract gates must be approved before route or schema implementation.
- Do not change inherited New API branding, attribution, module paths, or protected metadata.
- Do not modify the inherited web console in Step 1.
- Do not advance between phases if any required verification or specialist review fails.
- Any unexpected failure routes through systematic debugging before a fix is attempted.

## Step 1 Requirement Traceability

| Original Step 1 obligation | Planned evidence |
|---|---|
| Deploy the reviewed New API foundation, not a custom gateway | 0.1, 0.4a-0.5g |
| Configurable channels without hardcoded vendor/auth/path/pricing | 1.1-1.6b, 1.12a-1.12d, 1.25a-1.29c, 1.34b |
| Two active channels and deliberate primary-to-secondary proofs | 1.12d, 1.22a-1.23, 1.41a-1.43c, 1.45g |
| Issued keys mapped through editable subscription tiers/scopes | 1.7a-1.9, 1.13a-1.18f, 1.38a-1.40e |
| One Bearer-only deny-by-default direct API boundary | 1.17a-1.21c, 1.30, 1.37f, 1.46b-1.46c |
| Secret-only auth, validation, SSRF, and sanitized output | 1.3a-1.6b, 1.25a-1.37f, 1.46a-1.46d |
| Durable identity for every authenticated Step 1 request | 1.10a-1.10b, 1.18b-1.18f, 1.43b-1.43c |
| Deployment, Codex evidence, tests, reviews, and runbook | 1.23-1.24c, 1.44a-1.47, Sections 10-12 |

Later checkpoints remain explicit:

- **Step 2:** authoritative request/token reservations, concurrency leases, independent image
  rolling windows, cycle renewal/reset, enforcement-counter projection/rebuild on the Step 1
  Redis fence, and the configurable ~3x per-key/cohort token-rate anomaly alert.
- **Step 3:** real independent channels, rolling error/p95 health, automatic deprioritization,
  connection/status (`408/429/5xx/504/524`)/header/first-semantic-event deadline failover,
  cancellation, streaming commitment, and final per-attempt cost/usage settlement logging.
- **Step 4:** Stripe-hosted checkout plus command/webhook/effect idempotency and audit.
- **Step 5:** exact-cap, quota-leakage, rapid sequential image, failover-storm, and recovery load/
  stress tests.
- **Step 6:** source/runtime/artifact leakage, limiter-outage fail-closed behavior, penetration/static
  scanning, and cost arithmetic against known meters.
- **Step 7:** small private cohort, continuous channel/usage monitoring, daily anomaly review, spend/
  revenue reconciliation, and operator-tested channel swaps.

They are deliberately allocated, not silently omitted.

## Schedule Correction and Milestones

The source specification's one-week target is not a credible promise for production completion of
this security-critical fork. Approval of this plan approves the following milestone correction:

1. **Milestone A (one-week target, not promise):** Phase 0 only; 1.1-1.6b are stretch work only after
   the pinned baseline and contract/migration reviews pass without blocker.
2. **Milestone B:** Phase 1A-I, then Phase 1A-II/III only after each preceding gate is green.
3. **Milestone C:** Phase 1B-I and Phase 1B-II after the controlled deployment is green.
4. **Production programme:** Steps 2-7 remain separate gated milestones; no calendar claim is made
   until Phase 0 exposes inherited-build, staffing, infrastructure, and upstream-integration risk.

Missing a target moves the date or scope to the next milestone; it never lowers a test, security,
or review gate.

## 4. Phase 0: Provenance, Contracts, and Clean Baseline

### 0.1 Create the isolated upstream-tracking worktree

- **Files:** repository history at `C:\Users\z\Documents\Proxy Server`; worktree at
  `C:\Users\z\Documents\worktrees\proxy-step1-foundation`
- **Action:** Create `codex/step1-foundation` from the approved-docs commit, fetch the New API
  upstream, and merge only commit `66ee6b8f9889050ffef1f863a4314ce4a0516fb9` with unrelated
  history allowed. Preserve both parents and do not alter Git identity configuration.
- **Why:** This keeps the fork reviewable and future upstream merges possible while preserving the
  approved architecture commit.
- **Dependencies:** Plan approval.
- **Risk:** High.
- **Verification:** `git worktree list`, clean `git status`, `git merge-base`/parent inspection,
  pinned tree comparison against the reviewed reference clone, and no unapproved source delta.

### 0.2 Freeze the customer API contract

- **Files:** `docs/openapi/customer-gateway.json`,
  `docs/contracts/customer-gateway-errors.md`,
  `integration/contracts/customer_gateway_contract_test.go`
- **Action:** Write the OpenAPI contract for `GET /livez`, both forms of models list/retrieve,
  Responses create/compact, exact Bearer errors, strict request errors, and the Step 1 no-stream
  constraint. Add a contract test that is RED because the route inventory is not implemented.
- **Why:** Route behavior must be reviewable before handlers exist.
- **Dependencies:** 0.1 and the `api-contract-first` gate.
- **Risk:** High.
- **Verification:** OpenAPI lint, contract test failure for only the missing implementation, and
  owner review of methods, paths, schemas, statuses, and error bodies.

### 0.3 Freeze the migration and rollback plan

- **Files:** `docs/migrations/0001-step1-foundation.md`,
  `model/gateway_migration_test.go`
- **Action:** Specify forward, compatibility, rollback, backup, partial-failure, legacy plaintext
  token guard, nullable `channels.key` transition, immutable version data, and three-database test
  strategy. Add RED schema expectations without changing production models.
- **Why:** Authentication and subscription schema changes cannot be improvised safely.
- **Dependencies:** 0.1 and the `data-migration` gate.
- **Risk:** Critical.
- **Verification:** Database reviewer approves the written plan; fresh/upgrade/rollback fixtures
  fail only because schema is not yet implemented.

### 0.4a Embed the pinned source identity

- **Files:** `VERSION`, `common/constants.go`, `common/build_info_test.go`
- **Action:** Add a RED test, then embed the exact upstream SHA and fork patch version in the
  existing version constants. Keep the test plus production delta within 50 authored lines.
- **Why:** Every later artifact must identify the reviewed source rather than an unpinned branch.
- **Dependencies:** 0.1.
- **Risk:** Low.
- **Verification:** The focused test reads the expected full SHA and fork version from the runtime
  build-info value.

### 0.4b Report build identity through the CLI and container

- **Files:** `common/init.go`, `Dockerfile`, `common/build_info_cli_test.go`
- **Action:** Add a RED CLI/container-build fixture, then pass and report the 0.4a identity through
  the inherited version output and Docker build arguments. Keep the test plus production delta
  within 50 authored lines.
- **Why:** Embedded provenance is useless if operators cannot observe it on the deployed binary.
- **Dependencies:** 0.4a.
- **Risk:** Low.
- **Verification:** `go run . --version` and the built container report the same expected pin and
  fork version.

### 0.5a Record the upstream baseline and root Go CI

- **Files:** `.github/workflows/ci.yml`, `docs/baselines/new-api-66ee6b8.md`
- **Action:** Record the clean pinned baseline commands/results, then add root `go test` and focused
  race jobs. Keep the workflow plus evidence-template change within 50 authored lines.
- **Why:** Fork regressions need a reproducible upstream comparison point.
- **Dependencies:** 0.1 and 0.4b.
- **Risk:** Medium.
- **Verification:** Baseline commands match the imported tree; CI runs `go test ./...` and the
  declared race-sensitive package set.

### 0.5b Add independent relaykit build evidence

- **Files:** `.github/workflows/ci.yml`, `scripts/verify-relaykit.ps1`
- **Action:** Add a RED script fixture, then build `relaykit` with `GOWORK=off` in CI. Keep the
  script plus workflow delta within 50 authored lines.
- **Why:** Root-module success does not prove the nested module builds independently.
- **Dependencies:** 0.5a.
- **Risk:** Medium.
- **Verification:** The script and CI both complete `GOWORK=off go build ./...` from `relaykit`.

### 0.5c Add migration database-matrix validation

- **Files:** `deploy/test/db-matrix.compose.yaml`, `.github/workflows/ci.yml`
- **Action:** Add one bounded SQLite/MySQL/PostgreSQL migration test service contract and invoke it
  from CI. Keep the Compose plus workflow delta within 50 authored lines.
- **Why:** New API compatibility requires schema behavior beyond the production PostgreSQL path.
- **Dependencies:** 0.3 and 0.5a.
- **Risk:** High.
- **Verification:** `docker compose -f deploy/test/db-matrix.compose.yaml config` passes and the
  initially RED schema expectations execute on all three dialects.

### 0.5d Add source and artifact secret scanning

- **Files:** `.github/workflows/ci.yml`, `.gitleaks.toml`
- **Action:** Add a sentinel-based RED fixture, then configure source and built-artifact scanning
  with explicit test-fixture allow rules only. Keep configuration plus workflow within 50 authored
  lines.
- **Why:** A clean source tree does not prove generated artifacts are free of credentials.
- **Dependencies:** 0.5a.
- **Risk:** High.
- **Verification:** The scanner rejects the sentinel leak, accepts the removed-leak fixture, and
  runs over source plus produced artifacts.

### 0.5e Enforce Go formatting and pinned static analysis

- **Files:** `.github/workflows/ci.yml`, `scripts/verify-go-lint.ps1`,
  `scripts/verify-go-lint.Tests.ps1`, `docs/baselines/new-api-66ee6b8.md`
- **Action:** RED-test the verifier, then require clean `gofmt` output and the pinned upstream lint/
  static-analysis command for the root module and `relaykit`. Record the exact tool/version in the
  baseline; if the reviewed upstream has no command, pin `staticcheck` explicitly rather than using
  an unversioned latest release. Keep script, test, and workflow delta within 50 authored lines.
- **Why:** Tests do not detect formatting drift, suspicious constructs, or all static defects.
- **Dependencies:** 0.5a and 0.5b.
- **Risk:** High.
- **Verification:** A disposable formatting/static-analysis defect fails locally and in CI; the
  clean pinned baseline passes with no unreviewed suppression or generated-file rewrite.

### 0.5f Enforce `go vet` independently

- **Files:** `.github/workflows/ci.yml`, `scripts/verify-go-vet.ps1`,
  `scripts/verify-go-vet.Tests.ps1`
- **Action:** RED-test argument/module failures, then run `go vet ./...` at the root and with
  `GOWORK=off` in `relaykit`. Keep script, test, and workflow delta within 50 authored lines.
- **Why:** The project quality contract names `go vet`; hiding it inside another linter would make
  the gate unverifiable.
- **Dependencies:** 0.5b and 0.5e.
- **Risk:** Medium.
- **Verification:** A known vet fixture fails, both real modules pass, and CI records both commands.

### 0.5g Add a pinned Go dependency-vulnerability gate

- **Files:** `.github/workflows/ci.yml`, `scripts/verify-go-vulnerabilities.ps1`,
  `scripts/verify-go-vulnerabilities.Tests.ps1`, `docs/security/dependency-scanning.md`
- **Action:** RED-test tool/version/nonzero-result handling, then run a checksum-verified pinned
  `govulncheck` release against the root module and `relaykit` with `GOWORK=off`. Fail on a reported
  reachable vulnerability; any exception requires a dated owner/security review and cannot be
  embedded as a silent script suppression. Keep executable changes within 50 authored lines.
- **Why:** Secret scanning cannot detect vulnerable transitive Go dependencies.
- **Dependencies:** 0.5b and 0.5f.
- **Risk:** High.
- **Verification:** Wrong tool checksum/version and a vulnerable fixture fail closed; both pinned
  modules produce retained machine-readable CI evidence.

### Phase 0 testing strategy

- **Unit:** Build-info values, CLI rendering, and CI helper-script argument/error behavior,
  including lint, vet, and vulnerability-tool failure handling.
- **Integration:** Git provenance/parent inspection, independent `relaykit` build, and the
  SQLite/MySQL/PostgreSQL migration contract harness.
- **E2E:** Build the pinned container from the isolated worktree, query its version output, then run
  formatting, lint/static analysis, vet, dependency-vulnerability, and source/artifact secret
  gates before any production schema or endpoint code starts.

### Phase 0 review gate

- Human approves the API contract and migration plan.
- Architect confirms no drift from the approved channel design.
- Infra reviewer confirms provenance, pinning, worktree, CI, and Compose approach.
- Database reviewer confirms migration portability and rollback limits.
- No production endpoint or schema code begins before all four conditions and the Phase 0 testing
  strategy pass.

## 5. Phase 1A-I: Channel and Commercial Control Plane

### 1.1 Add typed channel references

- **Files:** `model/channel.go`, `model/channel_gateway_test.go`
- **Action:** RED-test and then add `secret_ref`, typed auth/capability JSON text, reliability policy
  ID, cost profile version ID, and failure-domain fields. Remove the `not null` constraint from the
  legacy key column without introducing a second credential owner.
- **Why:** A transfer station must be configuration, not vendor code.
- **Dependencies:** Phase 0 gate.
- **Risk:** Critical.
- **Verification:** Three-database schema assertions and administrative serialization contains
  references only, never resolved credentials.

### 1.2a Define the typed channel-auth DTO

- **Files:** `dto/gateway_channel_auth.go`, `dto/gateway_channel_auth_test.go`
- **Action:** RED-test then define bearer/fixed-header/query/none schemes, exactly one injection
  location, `{api_key}`, and bounded fixed non-secret headers. Keep test plus code within 50
  authored lines.
- **Why:** Authentication must be closed typed data rather than adaptor string interpolation.
- **Dependencies:** 1.1.
- **Risk:** High.
- **Verification:** Unknown schemes, dual/missing locations, invalid names, and misplaced
  placeholders reject deterministically.

### 1.2b Define the typed channel-capability DTO

- **Files:** `dto/gateway_channel_capability.go`, `dto/gateway_channel_capability_test.go`
- **Action:** RED-test then define endpoint-class paths plus streaming, compact, usage, storage,
  compression, and idempotency capability scalars; use pointers where absence differs from zero or
  false. Keep test plus code within 50 authored lines.
- **Why:** Vendor behavior must remain validated channel data, not core routing branches.
- **Dependencies:** 1.2a.
- **Risk:** High.
- **Verification:** Missing/malformed paths, unknown endpoint classes, and invalid scalar
  combinations reject.

### 1.3a Validate typed auth and capability documents

- **Files:** `service/channel_config_validation.go`,
  `service/channel_typed_config_validation_test.go`
- **Action:** RED-test then decode with `common.Unmarshal`, reject unknown keys/control characters,
  and validate the 1.2a/1.2b closed schemas. Keep test plus code within 50 authored lines.
- **Why:** Stored JSON must not bypass the typed DTO contract.
- **Dependencies:** 1.2b.
- **Risk:** Critical.
- **Verification:** Exact valid/unknown/malformed matrix and no decoded secret value in errors.

### 1.3b Reject credential-bearing legacy overrides

- **Files:** `service/channel_config_validation.go`,
  `service/channel_legacy_override_test.go`
- **Action:** RED-test then reject protected header/query/settings locations, interpolation,
  `{api_key}` outside auth config, credential-shaped literals, and proxy/CONNECT settings. Keep
  test plus code within 50 authored lines.
- **Why:** Native override fields otherwise become a second secret or egress owner.
- **Dependencies:** 1.3a.
- **Risk:** Critical.
- **Verification:** Every protected location rejects while the explicit non-secret allowlist passes.

### 1.4a Validate save-time egress origins

- **Files:** `service/channel_egress_policy.go`, `service/channel_egress_policy_test.go`
- **Action:** RED-test then reject non-HTTPS production origins, userinfo, fragments, malformed
  URLs, loopback/private/link-local/metadata addresses, and explicit proxies. Permit non-production
  mocks only through exact named origins plus exact resolved test-network addresses; reject any
  test allowlist in production. Keep test plus code within 50 authored lines.
- **Why:** Compose mocks need a narrow test path without weakening production SSRF policy.
- **Dependencies:** 1.3b.
- **Risk:** Critical.
- **Verification:** Production/public and exact-test-origin matrices pass; wildcard, mixed, changed,
  or production test-network entries reject.

### 1.5a Add immutable reliability-policy versions

- **Files:** `model/channel_policy_version.go`, `model/channel_policy_version_test.go`
- **Action:** RED-test then add an immutable ID/revision plus bounded reliability-policy JSON and
  activation metadata. The test and production delta together stay within 50 authored lines.
- **Why:** Later retry and health behavior needs one auditable policy snapshot per channel attempt.
- **Dependencies:** 0.3 and 1.1.
- **Risk:** High.
- **Verification:** Create/read/immutability and invalid-policy tests on all three databases.

### 1.5b Add immutable cost-profile versions

- **Files:** `model/channel_cost_profile_version.go`,
  `model/channel_cost_profile_version_test.go`
- **Action:** RED-test then add immutable channel/profile identity, revision, currency, rounding
  rule, and activation metadata. Keep test plus model within 50 authored lines.
- **Why:** Every attempt must name one reproducible pricing snapshot.
- **Dependencies:** 0.3, 1.1, and 1.5a.
- **Risk:** High.
- **Verification:** Three-database create/read/uniqueness/immutability and supported currency/
  rounding tests pass.

### 1.5c Add immutable cost-rate rows

- **Files:** `model/channel_cost_rate.go`, `model/channel_cost_rate_test.go`
- **Action:** RED-test then add rows keyed by profile, endpoint class, public alias, upstream model,
  meter dimension, integer numerator, and unit denominator. Keep test plus model within 50 authored
  lines.
- **Why:** A rate without route/model/meter/unit context cannot reproduce cost.
- **Dependencies:** 1.5b.
- **Risk:** High.
- **Verification:** Three-database uniqueness, positive integer units, supported meters, and
  update-in-place rejection.

### 1.6a Add the editable public model catalog

- **Files:** `model/public_model_alias.go`, `model/public_model_alias_test.go`
- **Action:** RED-test then add unique alias, display label, endpoint kind, status, and immutable
  revision metadata. Seed logic, not routing code, owns alias values.
- **Why:** Entitlements and per-channel mappings must use public aliases before upstream slugs.
- **Dependencies:** 0.3.
- **Risk:** High.
- **Verification:** Duplicate/invalid aliases reject across all databases; text and image kinds are
  distinct.

### 1.6b Validate complete production channel activation

- **Files:** `service/channel_activation.go`, `service/channel_activation_test.go`
- **Action:** RED-test then require secret ref, no raw key/proxy, declared failure domain, complete
  capability and model-mapping closure, immutable reliability policy, and complete cost profile/
  rate references before active status. Keep test plus code within 50 authored lines.
- **Why:** A correct seed does not protect later operator-created channels from partial activation.
- **Dependencies:** 1.4a, 1.5a, 1.5c, and 1.6a.
- **Risk:** Critical.
- **Verification:** Remove each required reference in turn and activation fails before routing;
  complete production and exact controlled-mock fixtures pass.

### 1.7a Add immutable subscription-plan versions

- **Files:** `model/subscription_plan_version.go`,
  `model/subscription_plan_version_test.go`
- **Action:** RED-test then add immutable version identity, integer price microunits, cycle,
  nullable request/token/image rate limits, concurrency, and explicit image entitlement. The
  focused test plus model delta stays within 50 authored lines.
- **Why:** The seven plans must remain editable without hardcoded enforcement constants.
- **Dependencies:** 1.6a.
- **Risk:** Critical.
- **Verification:** Seven exact price/cycle/quota/concurrency/image fixtures round-trip without
  binary floating point or ambiguous `NULL` semantics.

### 1.7b Add model and reasoning entitlements

- **Files:** `model/plan_model_entitlement.go`,
  `model/plan_model_entitlement_test.go`
- **Action:** RED-test then add allowed/default public aliases and reasoning efforts keyed to one
  immutable plan version. Keep the focused test plus model delta within 50 authored lines.
- **Why:** Defaults guide clients; only explicit allowlists authorize requests.
- **Dependencies:** 1.7a.
- **Risk:** Critical.
- **Verification:** Limited plans require `xhigh`; GPT-5.6 plans follow approved Sol/Terra defaults
  and reject Luna/cross-variant inference.

### 1.8 Add stable gateway subscriptions

- **Files:** `model/gateway_subscription.go`, `model/gateway_subscription_test.go`
- **Action:** RED-test then add customer, plan-version, provider-period, status, start/end, and audit
  identity fields. Active-plan lookup must snapshot one immutable version.
- **Why:** Renewals and upgrades must not require key rotation or mutate in-flight policy.
- **Dependencies:** 1.7a and 1.7b.
- **Risk:** Critical.
- **Verification:** Active/expired/cancelled and upgrade snapshot tests on all databases.

### 1.9 Add verifier-only customer key records

- **Files:** `model/customer_api_key.go`, `model/customer_api_key_test.go`
- **Action:** RED-test then add public ID, HMAC verifier, pepper version, status, customer/
  subscription IDs, scope ceiling, timestamps, and audit metadata. Add no raw-secret field and
  suppress sensitive serialization.
- **Why:** Platform keys must not be recoverable from database, cache, or admin responses.
- **Dependencies:** 1.8.
- **Risk:** Critical.
- **Verification:** Schema and JSON inspection prove no bearer secret; public ID is uniquely
  indexed.

### 1.10a Add append-only gateway mutation audit events

- **Files:** `model/gateway_audit_event.go`, `model/gateway_audit_event_test.go`
- **Action:** RED-test then add actor, action, object/version, idempotency key, correlation ID,
  redacted details, result, and UTC timestamp. Prohibit ordinary update/delete service methods.
- **Why:** Key, plan, subscription, seed, and channel changes require attributable history.
- **Dependencies:** 1.9.
- **Risk:** High.
- **Verification:** Transaction rollback leaves neither mutation nor orphan audit event; details
  reject known secret fields.

### 1.10b Add the durable Step 1 request record

- **Files:** `model/gateway_request.go`, `model/gateway_request_test.go`
- **Action:** RED-test then add request ID, customer/key/subscription/plan IDs, method, endpoint
  class, public model alias, selected channel ID, outcome/status, validated input/output tokens,
  latency, UTC timestamps, and an explicit non-authoritative settlement state. Store no body,
  bearer, upstream slug, or computed cost in Step 1. Keep test plus model within 50 lines.
- **Why:** Every authenticated public request needs one durable audit identity before the full
  attempt/cost ledger arrives in Step 3.
- **Dependencies:** 1.9 and 1.10a.
- **Risk:** Critical.
- **Verification:** Create/finalize is idempotent, sensitive fields do not exist, and the record is
  never read as quota or billing authority.

### 1.10c Add the durable runtime coordination epoch

- **Files:** `model/gateway_runtime_epoch.go`, `model/gateway_runtime_epoch_test.go`
- **Action:** RED-test then add one environment-scoped, monotonically increasing epoch with seed
  revision, activation status, and UTC audit metadata. Make activation compare-and-set and retain
  prior generations for rollback evidence. Keep test plus model within 50 authored lines.
- **Why:** Redis needs a PostgreSQL-owned fence so an empty, stale, or superseded deployment cannot
  masquerade as current coordination state.
- **Dependencies:** 1.10a.
- **Risk:** Critical.
- **Verification:** Three-database create/advance/stale-CAS/rollback fixtures prove one active epoch
  per environment and no generation reuse.

### 1.11a Register new models portably

- **Files:** `model/gateway_migration.go`, `model/main.go`,
  `model/gateway_migration_test.go`
- **Action:** After migration approval, RED-test then register the new model set through GORM using
  portable text/integer types. Keep test plus production edits within 50 authored lines.
- **Why:** Startup must be repeatable and fail closed on unsafe legacy plaintext state.
- **Dependencies:** 1.1, 1.5a, 1.5b, 1.5c, 1.6a, 1.7b, 1.8, 1.9, 1.10a,
  1.10b, and 1.10c.
- **Risk:** Critical.
- **Verification:** Fresh and repeat migrations create the expected tables/indexes on all three
  databases.

### 1.11b Migrate the legacy channel-key constraint

- **Files:** `model/gateway_migration.go`, `model/gateway_migration_channel_key_test.go`
- **Action:** RED-test then make `channels.key` nullable/empty-compatible using the approved
  dialect-safe procedure and preserve existing data for rollback. Keep the focused test and code
  within 50 authored lines.
- **Why:** Production-active gateway channels must use `secret_ref` without breaking upstream
  compatibility mode.
- **Dependencies:** 1.11a.
- **Risk:** Critical.
- **Verification:** Upgrade and rollback fixtures pass on SQLite, MySQL, and PostgreSQL.

### 1.11c Add the production legacy-plaintext preflight

- **Files:** `model/gateway_migration.go`, `model/gateway_legacy_preflight_test.go`
- **Action:** RED-test then add a production-mode preflight that rejects active raw channel keys or
  native plaintext customer-token rows before readiness. Keep test plus guard within 50 lines.
- **Why:** A successful schema migration must not silently preserve an unsafe credential owner.
- **Dependencies:** 1.11b.
- **Risk:** Critical.
- **Verification:** Safe empty/fresh state passes; each unsafe legacy row fails startup with a
  sanitized count and no credential value.

### 1.11d Disable native plaintext-token mutations in gateway mode

- **Files:** `controller/token.go`, `controller/token_gateway_mutation_test.go`
- **Action:** RED-test then reject every inherited token create/update/rotate mutation in gateway
  mode before a recoverable key can be generated or stored; preserve native mode. Keep test plus
  code within 50 authored lines.
- **Why:** Startup preflight is insufficient if the admin surface can reintroduce plaintext tokens.
- **Dependencies:** 1.11c.
- **Risk:** Critical.
- **Verification:** Enumerated native mutations create zero token rows/keys in gateway mode and
  native-mode regression remains green.

### 1.11e Disable native token search and serialization in gateway mode

- **Files:** `router/api-router.go`, `controller/token.go`,
  `controller/token_gateway_read_test.go`
- **Action:** RED-test then unregister inherited token list/search/retrieve/export routes in gateway
  mode and add a defense-in-depth serializer that never emits a native key. Keep test plus code
  within 50 authored lines.
- **Why:** Recoverable keys must not remain searchable even if an unsafe legacy row appears.
- **Dependencies:** 1.11d.
- **Risk:** Critical.
- **Verification:** Route enumeration and direct serializer tests expose no plaintext token value;
  the offline gateway-admin key surface remains the only gateway-mode owner.

### 1.11f Disable inherited control-plane mutations in gateway mode

- **Files:** `router/api-router.go`, `controller/channel.go`,
  `controller/gateway_control_plane_mutation_test.go`
- **Action:** RED-enumerate then unregister or reject inherited channel, mapping, plan, policy,
  cost, and secret-bearing mutations in gateway mode; preserve native mode. The audited offline
  seed/CLI path remains the sole Step 1 mutation owner. Keep test plus code within 50 authored lines.
- **Why:** An internal admin route that can bypass immutable versions or append-only audit would
  recreate a second, unsafe control plane even if it is absent from the customer listener.
- **Dependencies:** 1.10a, 1.11c, and 1.11e.
- **Risk:** Critical.
- **Verification:** Full inherited mutation-route/service enumeration creates zero gateway control-
  plane changes in gateway mode; native-mode regressions remain green.

### 1.12a Decode the versioned seed schema

- **Files:** `service/gateway_seed_decode.go`, `service/gateway_seed_decode_test.go`,
  `config/seed/step1.json`
- **Action:** RED-test then decode exactly one known schema version with closed top-level sections,
  required scalar bounds, and typed records through `common.Unmarshal`. Keep test plus code within
  50 authored lines; declarative data is reviewed separately.
- **Why:** Day-one configuration must be editable and reproducible, not hardcoded.
- **Dependencies:** 1.6b and 1.11f.
- **Risk:** Critical.
- **Verification:** Unknown version/section/field, malformed typed record, and scalar-bound cases
  reject before a transaction begins.

### 1.12b Validate seed uniqueness and reference closure

- **Files:** `service/gateway_seed_validate.go`, `service/gateway_seed_validate_test.go`
- **Action:** RED-test then validate unique immutable IDs/revisions, exact launch alias set,
  auth/path/policy/cost/mapping/plan reference closure, and unambiguous nullable limits. Keep test
  plus code within 50 authored lines.
- **Why:** Schema-valid records can still reference missing or contradictory control-plane state.
- **Dependencies:** 1.12a.
- **Risk:** Critical.
- **Verification:** Duplicate IDs, missing/cyclic refs, immutable drift, malformed paths, and
  ambiguous image-limit fixtures reject before persistence.

### 1.12c Apply catalog, plans, and entitlements idempotently

- **Files:** `service/gateway_seed_apply.go`, `service/gateway_seed_plan_test.go`,
  `config/seed/step1.json`
- **Action:** RED-test then transactionally apply `gpt-5.4`, `gpt-5.5`, Sol, Terra, Luna, and
  `gpt-image-2`, all seven exact plan versions, and their approved entitlements. Append one
  actor/idempotency/fingerprint-attributed audit event for each actual immutable mutation in the
  same transaction; exact replay creates neither a mutation nor a duplicate event. Keep code plus
  focused test within 50 authored lines.
- **Why:** Commercial configuration must reproduce exactly without compiled constants.
- **Dependencies:** 1.10a and 1.12b.
- **Risk:** Critical.
- **Verification:** First apply inserts matching append-only audit events, second apply changes zero
  rows/events, and immutable drift or injected audit failure aborts the whole transaction.

### 1.12d Apply policies, costs, mappings, and channels idempotently

- **Files:** `service/gateway_seed_apply.go`, `service/gateway_seed_channel_test.go`,
  `config/seed/step1.json`
- **Action:** RED-test then apply a complete mock reliability policy, zero-USD cost profile/rates
  for request/input/output/image meters, and two channels. Each channel includes bearer
  `auth_config`, configured Responses/compact paths, non-streaming Step 1 capabilities, every
  public-alias-to-distinct-mock-slug mapping, policy/cost IDs, distinct `secret_ref`, distinct
  failure domain, and priority/weight 100/100 or 50/100. Append actor/idempotency/fingerprint-
  attributed audit events for every actual policy, cost, mapping, secret-reference, and channel
  mutation in the same transaction. Keep executable code plus test within 50 lines.
- **Why:** Active channel rows are invalid unless every routing, auth, reliability, and cost
  reference is explicit.
- **Dependencies:** 1.5a, 1.5b, 1.5c, 1.6b, 1.10a, 1.12b, and 1.12c.
- **Risk:** Critical.
- **Verification:** Exact DB/audit snapshot, second-apply no-op, complete reference closure, and
  zero partial rows or events after injected data/audit failure.

### 1.12e Activate the runtime epoch for the committed seed revision

- **Files:** `service/gateway_seed_epoch.go`, `service/gateway_seed_epoch_test.go`
- **Action:** RED-test then compare-and-set a new 1.10c epoch only after the exact validated catalog/
  plan/channel seed revision commits, appending the activation audit in the same transaction. Exact
  replay returns the existing epoch; changed seed content requires a new generation. Keep test plus
  code within 50 authored lines.
- **Why:** The Redis fence needs one deterministic, durable producer tied to the configuration it
  protects.
- **Dependencies:** 1.10c, 1.12c, and 1.12d.
- **Risk:** Critical.
- **Verification:** First/replay/changed-revision/stale-CAS/audit-failure fixtures leave exactly one
  correct active generation and no partially activated seed.

### 1.12f Validate the controlled bootstrap customer fixture

- **Files:** `service/gateway_seed_bootstrap.go`,
  `service/gateway_seed_bootstrap_validation_test.go`, `config/seed/step1.test.json`
- **Action:** RED-test then accept one API-only, login-disabled customer plus active subscription
  fixture only in explicit non-production bootstrap mode; require stable external ref, plan version,
  period, and idempotency key. Keep test plus code within 50 authored lines.
- **Why:** A clean controlled deployment needs an issuance target without inventing production
  billing/customer creation.
- **Dependencies:** 1.12e.
- **Risk:** Critical.
- **Verification:** Production mode, login-capable state, missing plan/period/idempotency, and fixture
  drift reject before persistence.

### 1.12g Apply the controlled bootstrap customer and subscription

- **Files:** `service/gateway_seed_bootstrap.go`,
  `service/gateway_seed_bootstrap_apply_test.go`, `config/seed/step1.test.json`
- **Action:** RED-test then transactionally create or match the API-only customer, active
  subscription, and same-transaction audit event. Exact idempotency replay is a no-op; fingerprint
  mismatch fails. Keep test plus code within 50 authored lines.
- **Why:** Key issuance must have one auditable stable subscription after a clean test boot.
- **Dependencies:** 1.10a and 1.12f.
- **Risk:** Critical.
- **Verification:** First/repeat/drift/rollback cases leave exactly one customer, subscription, and
  mutation audit with no login or API secret.

### Phase 1A-I testing strategy

- **Unit:** Typed auth/capability decoding, activation/SSRF/proxy rejection, immutable model
  validation, key-record serialization, native-token disablement, seed/bootstrap validation, and
  exact seven-plan entitlement tables.
- **Integration:** Fresh/repeat/upgrade/rollback migrations on SQLite, MySQL, and PostgreSQL;
  transactional seed failure injection; immutable-version and append-only audit behavior.
- **E2E:** From an empty database, apply the declarative seed twice and inspect exact catalog,
  plans, entitlements, reliability/cost records, mappings, and two active mock-channel rows without
  any resolved credential; apply the non-production bootstrap twice and observe one API-only
  customer/subscription/audit, while production mode rejects that profile.

### Phase 1A-I review gate

- Code reviewer and Go reviewer inspect every product-code diff.
- Security reviewer inspects channel validation, secret isolation, and SSRF controls.
- Database reviewer inspects every model, index, migration, transaction, and dialect path.
- AI reviewer inspects alias/capability semantics.
- Compliance reviewer inspects customer identity and audit records.
- Fresh unit and three-database migration evidence must be green before public routing begins.

## 6. Phase 1A-II: Public Boundary and Customer Authentication

### 1.13a Strictly parse canonical platform keys

- **Files:** `common/customer_key_format.go`, `common/customer_key_format_test.go`
- **Action:** RED-test exact grammar, lengths, ambiguous glyphs, lowercase, trailing pad bits, and
  alternate encodings; then implement strict canonical Crockford decode/re-encode comparison.
  Keep focused test plus parser within 50 authored lines.
- **Why:** Indexed lookup requires one canonical public representation with full entropy.
- **Dependencies:** 1.9.
- **Risk:** Critical.
- **Verification:** Known vectors, exact 16/32-byte decode lengths, canonical re-encode equality,
  and mutation tests.

### 1.13b Generate platform keys from the CSPRNG

- **Files:** `common/customer_key_format.go`, `common/customer_key_generation_test.go`
- **Action:** RED-test entropy-source failure and exact output grammar, then encode 16-byte public
  IDs and 32-byte secrets with the strict codec. Keep test plus generator within 50 lines.
- **Why:** Generation must never fall back to predictable or partially filled randomness.
- **Dependencies:** 1.13a.
- **Risk:** Critical.
- **Verification:** Deterministic injected vectors, short-read failure, and uniqueness smoke check
  without probabilistic pass criteria.

### 1.14 Implement constant-time verifier operations

- **Files:** `common/customer_key_verifier.go`,
  `common/customer_key_verifier_test.go`
- **Action:** RED-test then implement the versioned HMAC-SHA-256 domain separator and
  constant-time verification. Expose no raw verifier in errors.
- **Why:** Database compromise must not reveal usable customer keys.
- **Dependencies:** 1.13a and 1.13b.
- **Risk:** Critical.
- **Verification:** Fixed vectors; wrong public ID, secret, pepper, version, and length all fail.

### 1.15 Load versioned peppers fail-closed

- **Files:** `service/customer_key_pepper.go`, `service/customer_key_pepper_test.go`
- **Action:** RED-test then load active/historical pepper versions from environment references,
  validate minimum strength, and expose only keyed operations to callers.
- **Why:** HMAC verification is only as safe as pepper lifecycle and startup validation.
- **Dependencies:** 1.14.
- **Risk:** Critical.
- **Verification:** Missing, empty, weak, duplicate, unknown, and rotated versions reject without
  logging secret material.

### 1.16a Perform canonical indexed key lookup

- **Files:** `service/customer_key_auth.go`, `service/customer_key_lookup_test.go`
- **Action:** RED-test then parse the canonical public ID and query exactly one indexed verifier-only
  record without native full-key lookup or raw-key cache. Keep test plus code within 50 authored
  lines.
- **Why:** Native New API key parsing and plaintext lookup violate the approved key contract.
- **Dependencies:** 1.9 and 1.13a.
- **Risk:** Critical.
- **Verification:** SQL observation proves one indexed lookup; malformed/unknown/DB-outage cases
  expose the same sanitized external result.

### 1.16b Verify key state and snapshot its ceiling

- **Files:** `service/customer_key_auth.go`, `service/customer_key_verify_test.go`
- **Action:** RED-test then constant-time verify, enforce status/expiry, and return customer/key/
  subscription IDs plus an immutable key-scope ceiling snapshot; attach no raw bearer. Keep test
  plus code within 50 authored lines.
- **Why:** A narrower key must not inherit its subscription's entire entitlement accidentally.
- **Dependencies:** 1.8, 1.14, 1.15, and 1.16a.
- **Risk:** Critical.
- **Verification:** Wrong verifier/pepper, disabled/expired keys, and restricted-scope fixtures fail
  or return the exact non-secret snapshot.

### 1.16c Upgrade historical-pepper verifiers with compare-and-set

- **Files:** `service/customer_key_auth.go`, `service/customer_key_rehash_test.go`
- **Action:** RED-test then compute the active verifier after historical verification and
  compare-and-set verifier/version only when the stored pair still matches. Keep test plus code
  within 50 authored lines.
- **Why:** Old peppers cannot retire safely without race-safe lazy migration.
- **Dependencies:** 1.16b.
- **Risk:** Critical.
- **Verification:** Concurrent use performs one safe upgrade; losing CAS retries authentication
  without corruption and old-pepper removal waits for zero references.

### 1.17a Assign request IDs and reject unsafe outer framing

- **Files:** `middleware/customer_request_framing.go`,
  `middleware/customer_request_framing_test.go`
- **Action:** RED-test then assign a platform request ID and perform constant-bounded method/path,
  duplicate/oversized auth framing, declared `Content-Length`, and supported-encoding checks before
  any database access. Keep test plus code within 50 authored lines.
- **Why:** Attackers must not buy database or decompression work with malformed framing.
- **Dependencies:** API contract approval.
- **Risk:** Critical.
- **Verification:** Exact method/path/size/encoding boundaries reject with zero auth query or body
  read; `/livez` stops after this stateless layer.

### 1.17b Enforce the Bearer-only credential source

- **Files:** `middleware/customer_credential_boundary.go`,
  `middleware/customer_credential_boundary_test.go`
- **Action:** RED-test then accept exactly one Bearer header and reject query keys, `x-api-key`,
  `x-goog-api-key`, `mj-api-secret`, cookies, duplicates, and WebSocket credentials. Keep test plus
  code within 50 authored lines.
- **Why:** Direct API calls must not reach inherited alternate authentication paths.
- **Dependencies:** 1.17a.
- **Risk:** Critical.
- **Verification:** Exact alternate-source matrix; no rejected credential is copied to error/context.

### 1.17c Emit bounded pre-auth security events

- **Files:** `middleware/customer_security_event.go`,
  `middleware/customer_security_event_test.go`
- **Action:** RED-test then emit a fixed-schema structured event containing request ID, coarse
  failure class, and UTC time only, through a fixed-memory process-local token bucket with a dropped
  counter. Keep test plus code within 50 authored lines.
- **Why:** Invalid-auth visibility must not leak credentials or permit unbounded event amplification.
- **Dependencies:** 1.17b.
- **Risk:** High.
- **Verification:** Missing/malformed/invalid storms emit at the configured bound, increment drops,
  and contain no customer ID, source address, header, key fragment, or raw credential.

### 1.18a Authenticate and attach the non-secret key snapshot

- **Files:** `middleware/customer_auth.go`, `middleware/customer_auth_test.go`
- **Action:** RED-test then call 1.16c and attach only customer/key/subscription IDs and immutable key
  scope; route failures through 1.17c. Keep test plus code within 50 authored lines.
- **Why:** Every customer route needs one non-bypassable authentication identity.
- **Dependencies:** 1.16c and 1.17c.
- **Risk:** Critical.
- **Verification:** Valid/restricted keys attach exact non-secret state; invalid/disabled/expired/
  database failures produce the contracted result and bounded security event.

### 1.18b Create the durable authenticated request identity

- **Files:** `middleware/customer_request_audit.go`,
  `middleware/customer_request_audit_create_test.go`
- **Action:** RED-test then insert one pending Step 1 request row immediately after auth using the
  platform request/customer/key/subscription IDs; fail closed on persistence error. Keep test plus
  code within 50 authored lines.
- **Why:** Every later authenticated rejection or route attempt needs a durable correlation owner.
- **Dependencies:** 1.10b and 1.18a.
- **Risk:** Critical.
- **Verification:** Success/rejection paths create exactly one idempotent pending row with no body,
  bearer, upstream slug, cost, or quota authority.

### 1.18c Snapshot the active immutable subscription plan

- **Files:** `middleware/customer_subscription.go`,
  `middleware/customer_subscription_test.go`
- **Action:** RED-test then load and attach exactly one immutable active plan version after request
  identity creation. Keep test plus code within 50 authored lines.
- **Why:** Renewal or upgrade after admission must not change in-flight policy.
- **Dependencies:** 1.18b.
- **Risk:** Critical.
- **Verification:** Renewal, expiry, cancellation, and concurrent upgrade fixtures preserve the
  admitted version or finalize the request as rejected before routing.

### 1.18d Intersect plan entitlement with key scope

- **Files:** `service/customer_effective_entitlement.go`,
  `service/customer_effective_entitlement_test.go`
- **Action:** RED-test then compute an immutable effective alias/endpoint allowlist as plan
  entitlement intersected with the key-scope ceiling. Keep test plus code within 50 authored lines.
- **Why:** Issuing a restricted key must actually reduce authority.
- **Dependencies:** 1.18a and 1.18c.
- **Risk:** Critical.
- **Verification:** Full/restricted/empty scope matrices never grant an alias or endpoint absent
  from either source.

### 1.18e Enforce model and reasoning entitlement on validated input

- **Files:** `service/customer_effective_entitlement.go`,
  `service/customer_entitlement_enforce_test.go`
- **Action:** RED-test then check validated public alias, endpoint kind, and reasoning effort against
  1.18d; accept no raw body. Keep test plus code within 50 authored lines.
- **Why:** Entitlement must run after bounded schema parsing and before channel mapping.
- **Dependencies:** 1.18d.
- **Risk:** Critical.
- **Verification:** Seven-plan plus restricted-key matrix rejects Luna/cross-variant inference and
  enforces exact `xhigh` limited plans.

### 1.18f Finalize the durable request record

- **Files:** `middleware/customer_request_audit.go`,
  `middleware/customer_request_audit_finalize_test.go`
- **Action:** RED-test then compare-and-set pending to one final outcome with plan, public alias,
  selected channel, validated usage, status, and latency. Keep test plus code within 50 authored
  lines; actual response flushing is owned by 1.37e.
- **Why:** Route parity includes durable audit even before the Step 3 attempt/cost ledger.
- **Dependencies:** 1.18e.
- **Risk:** Critical.
- **Verification:** Success/rejection/failover finalize exactly once; persistence failure leaves a
  visible pending record and cannot be reported as success.

### 1.19a Define the closed public route descriptors

- **Files:** `router/customer-public-routes.go`, `router/customer_public_routes_test.go`
- **Action:** RED-test then declare only `/livez`, both models forms, and both Responses/compact
  forms with exact methods, public route IDs, and request-schema kinds; bind no handler, canonical
  endpoint class, or outbound path yet. Keep test plus code within 50 authored lines.
- **Why:** Route inventory must be closed before the full safe pipeline exists.
- **Dependencies:** API contract approval.
- **Risk:** Critical.
- **Verification:** Descriptor snapshot contains no chat/image/task/vendor/realtime/WebSocket/admin
  route and no redirect.

### 1.19b Enforce deny-by-default customer-listener registration

- **Files:** `router/main.go`, `router/customer_public_router_inventory_test.go`
- **Action:** RED-test inherited registration, then make gateway mode construct its customer listener
  only from 1.19a and keep all admin/dashboard/native token routes off it. Keep test plus code within
  50 authored lines.
- **Why:** A forgotten inherited route would bypass current and later enforcement.
- **Dependencies:** 1.19a.
- **Risk:** Critical.
- **Verification:** Full method/path enumeration rejects every non-descriptor route; final customer
  handler binding remains gated at 1.37f.

### 1.20a Reproduce native quota mutation at the service boundary

- **Files:** `service/gateway_billing_boundary_test.go`
- **Action:** Add a RED direct-service fixture that snapshots native user/token/subscription quota
  around inherited pre/post-consume with a gateway auth context; make no production change. Keep
  the test within 50 authored lines.
- **Why:** The inherited mutation must be reproduced without circular dependence on public routes.
- **Dependencies:** 1.18a.
- **Risk:** Critical.
- **Verification:** Failure identifies the exact native mutation/plaintext-token dependency.

### 1.20b Isolate gateway keys from native pre-consume

- **Files:** `service/billing.go`, `service/gateway_billing_preconsume_test.go`,
  `constant/gateway_context_key.go`
- **Action:** RED-test then guard native pre-consume for gateway auth context with zero plaintext
  token lookup or customer quota mutation. Keep test plus code within 50 authored lines.
- **Why:** Admission cannot depend on the superseded native quota owner.
- **Dependencies:** 1.20a.
- **Risk:** Critical.
- **Verification:** Gateway mode bypasses only native customer mutation; native mode is unchanged.

### 1.20c Isolate gateway keys from native post-consume

- **Files:** `service/text_quota.go`, `service/gateway_billing_postconsume_test.go`
- **Action:** RED-test then guard native post-consume while retaining validated upstream usage in
  internal request state for 1.18f. Keep test plus code within 50 authored lines; claim no final
  settlement.
- **Why:** Successful relay must not silently mutate the old quota authority.
- **Dependencies:** 1.20b.
- **Risk:** Critical.
- **Verification:** Success/failure make zero native quota mutations and retain validated usage.

### 1.21a Add detail-free liveness

- **Files:** `controller/liveness.go`, `controller/liveness_test.go`
- **Action:** RED-test then return one fixed dependency-free liveness status/body with no version,
  database, Redis, channel, or environment details. Keep test plus handler within 50 lines.
- **Why:** Container/process liveness must not become an information endpoint.
- **Dependencies:** 1.19b.
- **Risk:** Low.
- **Verification:** Credential-free response is constant across dependency states and rejects
  unsupported methods.

### 1.21b Add the entitled model-list handler

- **Files:** `controller/customer_models.go`, `controller/customer_models_list_test.go`
- **Action:** RED-test then list only active public aliases allowed by the immutable effective
  plan-intersect-key-scope entitlement from 1.18d, with the platform catalog ETag. Keep test plus
  code within 50 authored lines.
- **Why:** Codex needs a catalog that cannot expose unentitled or upstream model names.
- **Dependencies:** 1.6a, 1.18d, and 1.19b.
- **Risk:** High.
- **Verification:** Canonical/root list forms are identical for each plan/full/restricted key and
  contain no alias outside the effective scope, Luna, cross-variant, inactive, or upstream slug.

### 1.21c Add the entitled model-retrieve handler

- **Files:** `controller/customer_models.go`, `controller/customer_models_retrieve_test.go`
- **Action:** RED-test then retrieve one active alias only when the immutable effective plan-
  intersect-key-scope entitlement from 1.18d allows it, returning the same platform ETag semantics
  as list. Keep test plus code within 50 authored lines.
- **Why:** Direct retrieval must not become an entitlement enumeration side channel.
- **Dependencies:** 1.21b.
- **Risk:** High.
- **Verification:** Canonical/root retrieve forms match; unknown, inactive, plan-unentitled, and
  key-scope-excluded aliases return the same contracted non-leaking result.

### Phase 1A-II testing strategy

- **Unit:** Canonical key parsing/generation, verifier/pepper rotation, indexed auth states,
  Bearer-only framing, immutable subscription snapshots, exact entitlements, request-record state
  transitions, liveness constancy, and filtered model handlers.
- **Integration:** Component-order assertions prove outer framing precedes DB auth, request identity
  precedes plan snapshot, effective entitlement intersects key scope, and direct native quota paths
  are isolated without storing a bearer.
- **E2E:** Through a test-only in-memory router built from the closed descriptors, enumerate every
  alternate route/credential source and prove canonical/root model handlers are identical for all
  seven plans plus a restricted key. Production customer binding remains gated at 1.37f.

### Phase 1A-II review gate

- Code reviewer and Go reviewer review every diff.
- Security reviewer signs off key grammar, verifier, pepper loading, credential rejection, route
  enumeration, error uniformity, and absence of raw bearer state.
- Compliance reviewer checks customer identifiers, key lifecycle, and auditability.
- AI reviewer checks model catalog and entitlement semantics.
- Step 1A cannot pass until route inventory, auth-state, seven-plan, and secret-absence tests pass.

## 7. Phase 1A-III: Reproducible Controlled Deployment

### 1.22a Validate mock transfer-station requests

- **Files:** `cmd/mock-transfer-station/main.go`, `cmd/mock-transfer-station/request_test.go`
- **Action:** RED-test then enforce bounded Bearer, method, path, content type, and mapped-model
  expectations without recording body or credential. Keep test plus code within 50 lines.
- **Why:** Selection, mapping, credential substitution, and failover require controllable evidence.
- **Dependencies:** 1.12d.
- **Risk:** Medium.
- **Verification:** Primary/secondary fixtures accept only their configured credential/path/model;
  no credential or prompt is echoed or logged.

### 1.22b Return deterministic mock Responses and failures

- **Files:** `cmd/mock-transfer-station/main.go`, `cmd/mock-transfer-station/response_test.go`
- **Action:** RED-test then return deterministic non-streaming Responses JSON/usage and expose a
  test-only fail-before-response switch. Keep test plus code within 50 lines.
- **Why:** Reverse mapping, usage validation, and transparent failover need stable observations.
- **Dependencies:** 1.22a.
- **Risk:** Medium.
- **Verification:** Exact success JSON, malformed/error fixtures, and fail-before-byte behavior.

### 1.23 Add the Step 1 Compose deployment

- **Files:** `deploy/step1/compose.yaml`, `deploy/step1/.env.example`,
  `deploy/step1/README.md`
- **Action:** Add pinned/buildable gateway, PostgreSQL, Redis, and two mock services with health
  conditions, isolated networks, persistent DB volume, non-secret example variables, and no real
  credentials. Configure only the exact 1.4a named mock origins/test-network addresses and keep
  Postgres/Redis unreachable from external interfaces by default.
- **Why:** Day-one deployment and failure tests must be reproducible without a vendor decision.
- **Dependencies:** 1.11f, 1.12e, 1.12g, 1.19b, and 1.22b.
- **Risk:** High.
- **Verification:** `docker compose config`, cold boot, restart, DB persistence, missing-secret
  failure, and dependency readiness tests.

### 1.23a Initialize and enforce the Step 1 Redis fence

- **Files:** `service/gateway_redis_fence.go`, `service/gateway_redis_fence_test.go`,
  `deploy/step1/compose.yaml`
- **Action:** RED-test then atomically initialize Redis with the active PostgreSQL runtime epoch and
  seed revision. Every Step 1 Redis read/write supplies that epoch and rejects unavailable, empty,
  stale, or superseded state; no caller may recreate it from zero implicitly. Keep test plus code
  within 50 authored lines.
- **Why:** A health check alone does not fence stale processes or distinguish a reachable empty
  Redis from valid coordination state.
- **Dependencies:** 1.10c, 1.12e, and 1.23.
- **Risk:** Critical.
- **Verification:** Unavailable, flushed, stale, newer-epoch, concurrent-init, and restart fixtures
  fail closed; only the exact active epoch permits namespaced operations.

### 1.24a Add the internal readiness service

- **Files:** `service/gateway_readiness.go`, `service/gateway_readiness_test.go`
- **Action:** RED-test then validate DB, the exact 1.23a Redis fence/epoch, seed revision, channel
  configuration, and secret-reference syntax/presence. Do not resolve environment values until
  Step 1B. Keep test plus service within 50 lines.
- **Why:** Orchestration needs truth about dependency state, but customers must not receive an
  information-rich diagnostics endpoint.
- **Dependencies:** 1.19b and 1.23a.
- **Risk:** High.
- **Verification:** Healthy dependencies pass; missing DB/Redis/seed records or malformed channel
  refs fail readiness and new customer admissions remain closed. Step 1B extends this command with
  actual secret resolution before relay acceptance.

### 1.24b Add the internal readiness CLI and Compose health command

- **Files:** `cmd/gateway-ready/main.go`, `cmd/gateway-ready/main_test.go`,
  `deploy/step1/compose.yaml`
- **Action:** RED-test CLI exit/output behavior, then invoke the readiness service from an internal
  command and wire it into Compose. Expose no new HTTP route. Keep code plus test within 50 lines.
- **Why:** Compose needs a non-public, machine-readable readiness signal.
- **Dependencies:** 1.24a.
- **Risk:** High.
- **Verification:** Exit zero only when ready; all failures use one detail-free external message
  while structured internal logs contain no secrets.

### 1.24c Reject public admission when the runtime fence is not serving

- **Files:** `middleware/customer_serving_readiness.go`,
  `middleware/customer_serving_readiness_test.go`
- **Action:** RED-test then consult the bounded local readiness snapshot backed by the exact 1.23a
  epoch after stateless framing and before Bearer authentication. Reject unavailable, empty, stale,
  or superseded Redis with one sanitized `503`; `/livez` remains dependency-free. Keep test plus
  middleware within 50 authored lines.
- **Why:** A Compose health command does not stop a caller from reaching an unready listener
  directly.
- **Dependencies:** 1.17a, 1.23a, and 1.24b.
- **Risk:** Critical.
- **Verification:** Direct requests cannot bypass each bad-fence state, no auth query/body read
  occurs, recovery requires the exact active epoch, and `/livez` stays constant.

### Phase 1A-III testing strategy

- **Unit:** Mock request validation, deterministic mock success/failure fixtures, durable epoch/
  Redis-fence state, readiness service dependency checks, public serving gate, and readiness CLI
  exit/output behavior.
- **Integration:** Compose configuration, isolated network exposure, PostgreSQL persistence, exact
  PostgreSQL/Redis epoch fencing, seed/bootstrap revision, exact non-production egress allowlist, channel
  reference validation, and dependency restart behavior.
- **E2E:** Cold-start from an empty volume, wait through the internal readiness command, confirm two
  active mock services accept only their own sentinel credentials, then inject missing dependency
  and malformed-seed states and observe closed admission.

### Phase 1A final gate

- Fresh Compose starts from an empty volume, applies the production seed once, then the explicit
  non-production bootstrap profile once; repeat applications are no-ops.
- Two active mock channels exist with exact priority/weight and distinct refs/domains.
- Route descriptors/registration exclude every unapproved inherited surface; the test-only harness
  proves hashed fixture authentication while production customer binding remains closed.
- PostgreSQL, Redis, logs, errors, traces, and serialized admin/config output contain no raw
  customer, pepper, or channel sentinel.
- Infra, security, database, AI, compliance, code, and Go reviews have no unresolved blocker, and
  the Phase 1A-III unit/integration/E2E strategy is fresh and green.

## 8. Phase 1B-I: Runtime Secrets and Non-Streaming Responses

### 1.25a Validate resolved addresses at connection time

- **Files:** `service/gateway_egress_resolver.go`, `service/gateway_egress_resolver_test.go`
- **Action:** RED-test then resolve every candidate at dial time through the shared 1.4a policy;
  reject private/link-local/metadata/mixed/rebound answers except exact non-production mock names and
  exact test-network addresses. Keep test plus code within 50 authored lines.
- **Why:** Save-time origin validation alone cannot stop DNS rebinding.
- **Dependencies:** 1.4a, 1.6b, and the Phase 1A final gate.
- **Risk:** Critical.
- **Verification:** Public, forbidden, mixed, rebound, exact-test, changed-test, and production-
  allowlist-rejection matrices pass deterministically.

### 1.25b Dial only a validated address

- **Files:** `service/gateway_http_client.go`, `service/gateway_http_client_dial_test.go`
- **Action:** RED-test then connect only to the validated address while retaining original hostname
  context and propagating cancellation/deadlines. Keep test plus code within 50 authored lines.
- **Why:** Validating one address and dialing another reopens SSRF and rebinding.
- **Dependencies:** 1.25a.
- **Risk:** Critical.
- **Verification:** Dial observation matches the validated IP exactly and cancellation interrupts
  resolution/connect without fallback dialing.

### 1.25c Add the gateway HTTP transport policy

- **Files:** `service/gateway_http_client.go`, `service/gateway_http_client_transport_test.go`
- **Action:** RED-test then preserve original Host/TLS SNI, disable redirects and automatic response
  decompression, set `Proxy` to nil, and reject ambient/explicit proxies in Step 1 gateway mode.
  Keep test plus transport code within 50 authored lines.
- **Why:** Proxy inheritance and redirects can bypass the validating dialer.
- **Dependencies:** 1.25b.
- **Risk:** Critical.
- **Verification:** SNI/Host remain original, redirect never follows, `HTTP_PROXY`/`HTTPS_PROXY`
  have no effect, and a nonempty channel proxy setting fails activation.

### 1.25d Route gateway requests through the protected transport

- **Files:** `relay/channel/api_request.go`, `relay/channel/api_request_gateway_test.go`
- **Action:** RED-test then select the dedicated client only for gateway-mode channel requests,
  preserving native New API behavior elsewhere. Keep test plus integration edit within 50 lines.
- **Why:** A safe client that the relay never uses is security theatre.
- **Dependencies:** 1.25c.
- **Risk:** Critical.
- **Verification:** Gateway request uses the protected round tripper; native-mode regression uses
  the inherited client; cancellation reaches the dialer.

### 1.26a Resolve `env://` channel secrets request-scoped

- **Files:** `service/channel_secret.go`, `service/channel_secret_test.go`
- **Action:** RED-test malformed/missing/empty refs, then resolve `env://` into a request-scoped
  value without writing it to `Channel`, caches, or serializable context. Keep test plus resolver
  within 50 lines.
- **Why:** Transfer-station credentials must exist only briefly at the outbound boundary.
- **Dependencies:** 1.24b, 1.25d, and the Phase 1A final gate.
- **Risk:** Critical.
- **Verification:** Valid ref resolves once per attempt; malformed/missing/empty values fail that
  channel without unauthenticated or customer-authenticated dispatch.

### 1.26b Redact registered secrets centrally

- **Files:** `common/secret_redactor.go`, `common/secret_redactor_test.go`, `logger/logger.go`,
  `common/sys_log.go`
- **Action:** RED-test a sentinel at every log level, then register environment-backed values
  before logging and apply exact-value redaction in the central logger/system-log boundaries.
  Keep focused test plus edits within 50 lines.
- **Why:** Resolver correctness does not prevent a later error path from formatting a secret.
- **Dependencies:** 1.26a.
- **Risk:** Critical.
- **Verification:** Sentinel is absent from info/warn/error/debug/system output and redaction never
  prints a fingerprint or partial secret.

### 1.26c Load the versioned channel-fingerprint keyring

- **Files:** `service/channel_fingerprint_keyring.go`,
  `service/channel_fingerprint_keyring_test.go`
- **Action:** RED-test then load an active version plus optional historical versions from
  environment-level `env://` references. Require at least 32 decoded random bytes per distinct key,
  expose only keyed operations, and fail startup/readiness on missing, weak, duplicate, or unknown
  active material. Rotation installs the new keyring everywhere before changing the active version
  and retains the prior version until the maximum observation TTL has elapsed. Keep test plus code
  within 50 authored lines.
- **Why:** Fingerprints are safe only if their dedicated key has an explicit owner, strength,
  failure policy, and rotation boundary separate from channel credentials and customer peppers.
- **Dependencies:** 1.15, 1.23a, and 1.26b.
- **Risk:** Critical.
- **Verification:** Missing/weak/duplicate/unknown versions fail closed; active/historical overlap
  and retirement-after-TTL fixtures pass without exposing key material.

### 1.26d Compute deterministic channel-secret fingerprints

- **Files:** `service/channel_secret_fingerprint.go`,
  `service/channel_secret_fingerprint_test.go`
- **Action:** RED-test then HMAC a versioned domain separator, channel ID, config revision, and
  resolved channel secret through 1.26c, returning only a fixed-length internal digest tagged with
  key version. Keep test plus code within 50 authored lines.
- **Why:** Instance comparison needs a deterministic, non-reversible value scoped to the exact
  channel configuration.
- **Dependencies:** 1.26a and 1.26c.
- **Risk:** Critical.
- **Verification:** Fixed vectors match only for identical key version/channel/revision/secret;
  every changed component differs and no input/digest appears in output or diagnostics.

### 1.26e Publish and compare fenced fingerprint observations

- **Files:** `service/channel_secret_fingerprint_store.go`,
  `service/channel_secret_fingerprint_store_test.go`
- **Action:** RED-test then atomically publish per-instance observations and compare live peers in
  bounded-TTL Redis keys under the exact 1.23a epoch, channel/config revision, and fingerprint-key
  version. Treat unavailable, empty, stale, cross-version, or indeterminate store state as no
  agreement. Keep test plus code within 50 authored lines.
- **Why:** A local digest does not prove cross-instance credential consistency, and stale Redis
  data must not create a false match.
- **Dependencies:** 1.23a and 1.26d.
- **Risk:** Critical.
- **Verification:** Matching peers agree; mismatch, expiry, flush, stale epoch, version skew, and
  Redis failure return distinct internal non-serving states without exposing a digest.

### 1.26f Isolate mismatches and emit bounded operator alerts

- **Files:** `service/channel_secret_consistency.go`,
  `service/channel_secret_consistency_test.go`
- **Action:** RED-test then mark only the affected instance/channel/config revision unavailable on
  1.26e disagreement and emit a deduplicated fixed-schema operator event containing identifiers,
  key version, and coarse reason only. Never include a secret or fingerprint. Keep test plus code
  within 50 authored lines.
- **Why:** Detection without routing isolation leaves the bad credential live; unrestricted alerts
  can leak or amplify an outage.
- **Dependencies:** 1.26e.
- **Risk:** Critical.
- **Verification:** Match stays eligible; mismatch/version/store states isolate exactly the scoped
  route, alerts are TTL-deduplicated, and values/digests are absent from logs, traces, metrics,
  errors, events, and admin output.

### 1.26g Compute serving readiness from eligible channel coverage

- **Files:** `service/gateway_readiness.go`, `service/gateway_readiness_secret_test.go`
- **Action:** RED-test then mark unresolved or fingerprint-mismatched channels unavailable and
  require at least one fully configured eligible channel for every advertised alias/endpoint class.
  Keep test plus code within 50 authored lines.
- **Why:** One broken primary must not disable a valid secondary or permit unauthenticated fallback.
- **Dependencies:** 1.24b and 1.26f.
- **Risk:** Critical.
- **Verification:** Baseline acceptance requires both seeded channels; serving readiness survives a
  missing primary when secondary coverage is complete, alerts the primary, and fails closed when
  any advertised route has zero eligible channels.

### 1.27 Carry typed channel runtime configuration through selection

- **Files:** `middleware/distributor.go`, `middleware/distributor_gateway_test.go`,
  `constant/gateway_context_key.go`
- **Action:** RED-test then attach validated capability/auth config and secret reference to the
  request-scoped relay context. Bypass `Channel.GetNextEnabledKey` in gateway mode without changing
  native mode behavior.
- **Why:** Adaptors must receive one resolved credential owner and one capability snapshot.
- **Dependencies:** 1.26g.
- **Risk:** Critical.
- **Verification:** Customer bearer never becomes `ApiKey`; missing secret yields a scoped channel
  failure; native mode regression tests remain green.

### 1.28a Build typed outbound authentication mutation

- **Files:** `relay/channel/auth_config.go`, `relay/channel/auth_config_test.go`
- **Action:** RED-test then build bearer, fixed-header, query, none, and fixed non-secret-header
  mutations from validated config; reject control characters and duplicate locations. Keep test
  plus code within 50 lines.
- **Why:** Core routing cannot assume one vendor auth scheme.
- **Dependencies:** 1.27.
- **Risk:** Critical.
- **Verification:** Exact header/query mutation matrix and sanitized error values.

### 1.28b Apply typed auth in the OpenAI-compatible adaptor

- **Files:** `relay/channel/openai/adaptor.go`,
  `relay/channel/openai/adaptor_gateway_auth_test.go`
- **Action:** RED-test then resolve/apply the typed mutation in gateway mode and prohibit legacy
  channel-key reads; preserve native mode. Keep test plus adaptor edit within 50 lines.
- **Why:** The runtime must use the typed contract, not merely validate it.
- **Dependencies:** 1.26g, 1.27, and 1.28a.
- **Risk:** Critical.
- **Verification:** Bearer/fixed-header/query/none test channels observe only configured auth and
  never the customer Bearer.

### 1.28c Convert scheduled and administrative channel checks

- **Files:** `controller/channel-test.go`, `service/gateway_channel_check.go`,
  `service/gateway_channel_check_test.go`
- **Action:** RED-test then route gateway-mode scheduled tests and administrative connectivity
  checks through the request-scoped resolver, typed auth, protected transport, and configured
  endpoint path. Prohibit legacy `Channel.Key` reads and preserve native mode. Keep test plus code
  within 50 authored lines.
- **Why:** A background or admin check using the raw legacy field would keep a second credential
  owner alive even when customer relay is correct.
- **Dependencies:** 1.25d, 1.26g, and 1.28b.
- **Risk:** Critical.
- **Verification:** Scheduled/admin checks observe only the selected secret/config/path, missing
  secrets fail closed, and no check serializes or logs credential material.

### 1.28d Reject unconverted adaptor and endpoint credential paths

- **Files:** `service/channel_activation.go`,
  `service/channel_gateway_credential_capability_test.go`
- **Action:** RED-test then require a registered typed-credential integration for every gateway-
  mode adaptor/endpoint/retry path at activation. In Step 1, reject image, task, vendor-specific,
  and non-OpenAI-compatible adaptors rather than allowing any inherited `Channel.Key` fallback.
  Keep test plus code within 50 authored lines.
- **Why:** Disabled public routes do not make internal jobs or future operator-created channels safe.
- **Dependencies:** 1.6b, 1.27, 1.28b, and 1.28c.
- **Risk:** Critical.
- **Verification:** Every inherited adaptor/endpoint class is enumerated; only the converted Step 1
  OpenAI Responses/compact path activates, and retry never changes credential ownership.

### 1.28e Prove gateway mode has no legacy channel-key reader

- **Files:** `integration/step1/gateway_credential_owner_test.go`
- **Action:** Add a table-driven RED test over customer relay, internal retry, scheduled test,
  administrative connectivity, image/task entry points, and every inherited adaptor. Seed a
  poisoned legacy `Channel.Key`; supported paths must use only `secret_ref`, and unsupported paths
  must fail before dispatch. Make no production change. Keep the test within 50 authored lines.
- **Why:** Local adaptor tests cannot prove the gateway-wide single-credential-owner invariant.
- **Dependencies:** 1.28c and 1.28d.
- **Risk:** Critical.
- **Verification:** No mock observes the poison value; database/log/trace/error output contains no
  legacy value, and native-mode regression still uses its inherited behavior.

### 1.28f Sanitize credential-bearing request URLs

- **Files:** `relay/channel/safe_url.go`, `relay/channel/safe_url_test.go`
- **Action:** RED-test then render diagnostic URLs with configured auth query keys removed and all
  other query values bounded/escaped; return no raw URL formatter to gateway callers. Keep test plus
  code within 50 authored lines.
- **Why:** Query-auth support otherwise turns ordinary URL diagnostics into credential leakage.
- **Dependencies:** 1.28a.
- **Risk:** Critical.
- **Verification:** Exact/mixed/duplicate/encoded query-auth cases expose no full or partial secret.

### 1.28g Use sanitized URLs in logs, traces, metrics, and errors

- **Files:** `relay/channel/api_request.go`, `relay/channel/api_request_query_auth_test.go`
- **Action:** RED-test a test-only query-auth channel sentinel, then require 1.28f for every gateway
  URL-bearing log/trace/error; metrics use bounded channel/endpoint labels and no URL. The mock still
  receives the real query credential. Keep test plus code within 50 authored lines.
- **Why:** A safe formatter has no value if observability paths retain the raw URL.
- **Dependencies:** 1.25d, 1.28b, 1.28e, and 1.28f.
- **Risk:** Critical.
- **Verification:** Mock sees the sentinel once; database, logs, traces, metrics, errors, and process
  output contain neither credential nor raw credential-bearing URL.

### 1.29a Pseudonymize Codex customer metadata headers

- **Files:** `service/customer_metadata_pseudonym.go`,
  `service/customer_metadata_pseudonym_test.go`
- **Action:** RED-test then load a dedicated environment-backed metadata HMAC key and produce
  stable platform-scoped values for valid bounded session/thread/client IDs. Keep test plus code
  within 50 lines.
- **Why:** Authentication replacement is incomplete if customer metadata or alternate credentials
  can leak through the HTTP header map.
- **Dependencies:** 1.17b and 1.26b.
- **Risk:** Critical.
- **Verification:** Stable/non-colliding vectors, invalid length/characters rejected, and key/
  originals absent from logs/errors.

### 1.29b Strip all non-contracted customer headers

- **Files:** `relay/gateway_request_headers.go`,
  `relay/gateway_request_header_strip_test.go`
- **Action:** RED-test then construct a fresh outbound header map that drops customer auth, cookies,
  proxy/forwarding, hop-by-hop, credential alternatives, and every unrecognized name. Keep test plus
  code within 50 authored lines.
- **Why:** Mutating the inherited map risks leaving a forgotten sensitive header.
- **Dependencies:** 1.28g.
- **Risk:** Critical.
- **Verification:** Exact strip matrix with no wildcard-forwarded family or original sentinel.

### 1.29c Validate and transform contracted request headers

- **Files:** `relay/gateway_request_headers.go`,
  `relay/gateway_request_header_allow_test.go`, `relay/channel/openai/adaptor.go`
- **Action:** RED-test then add validated content negotiation/encoding, bounded subagent/turn-state,
  and HMAC-pseudonymized session/thread/client identifiers to the fresh 1.29b map. Keep test plus
  code within 50 authored lines.
- **Why:** Contracted names still need value validation and metadata minimization.
- **Dependencies:** 1.29a and 1.29b.
- **Risk:** Critical.
- **Verification:** Exact allow/replace matrix; original metadata, invalid values, and pseudonym key
  never reach mock observations or diagnostics.

### 1.30 Canonicalize public aliases to endpoint classes

- **Files:** `middleware/gateway_endpoint.go`,
  `middleware/gateway_endpoint_test.go`, `constant/gateway_context_key.go`
- **Action:** RED-test then map canonical/root public paths to the same internal endpoint classes
  while preserving original path as metadata. Do not redirect or hardcode the outbound path.
- **Why:** Compatibility aliases must share one policy chain and channel-configured destination.
- **Dependencies:** 1.19a and 1.19b.
- **Risk:** High.
- **Verification:** Canonical/root descriptor pairs produce the same canonical endpoint class while
  preserving distinct original-path metadata; final parity is proved at 1.37f/1.45c.

### 1.31a Classify Responses-create fields

- **Files:** `relay/responses_create_schema.go`, `relay/responses_create_fields_test.go`
- **Action:** RED-test then classify each pinned field as supported, known-unsupported, or unknown
  with exact `400 invalid_request_error` plus `param`. Keep test plus declarative code within 50
  authored lines.
- **Why:** Native typed reserialization drops fields and raw passthrough accepts unknown control data.
- **Dependencies:** API contract approval and 1.30.
- **Risk:** Critical.
- **Verification:** Full field-name matrix plus the Kadirr-shaped fixture; no silent removal.

### 1.31b Enforce Responses-create field-value policy

- **Files:** `relay/responses_create_schema.go`, `relay/responses_create_values_test.go`
- **Action:** RED-test then reject `background`, `stream:true`, and `store:true`, and normalize
  omitted/false storage to false without changing other supported values. Keep test plus code within
  50 authored lines.
- **Why:** A supported field name can still request deliberately unsupported stateful/streaming work.
- **Dependencies:** 1.31a.
- **Risk:** Critical.
- **Verification:** Exact omitted/false/true and background/stream value matrix.

### 1.31c Classify Responses-compact fields

- **Files:** `relay/responses_compact_schema.go`, `relay/responses_compact_fields_test.go`
- **Action:** RED-test then define compact's smaller supported/known-unsupported/unknown field map
  without inheriting create-only fields. Keep test plus code within 50 authored lines.
- **Why:** Compact is a distinct contract, not create with a different path.
- **Dependencies:** API contract approval and 1.31a.
- **Risk:** Critical.
- **Verification:** Compact field matrix rejects create-only and unknown fields with exact `param`.

### 1.31d Enforce Responses-compact field-value policy

- **Files:** `relay/responses_compact_schema.go`, `relay/responses_compact_values_test.go`
- **Action:** RED-test then enforce compact-specific stateless/non-streaming value rules and preserve
  only supported values. Keep test plus code within 50 authored lines.
- **Why:** Field classification alone does not prevent unsupported compact modes.
- **Dependencies:** 1.31c.
- **Risk:** Critical.
- **Verification:** Exact supported/value-rejection matrix with no create-policy fallback.

### 1.32a Bound accepted content encodings and compressed bytes

- **Files:** `common/request_body_limit.go`, `common/request_body_compressed_test.go`
- **Action:** RED-test then accept only contracted encodings and stop reading at the exact compressed
  byte limit. Keep test plus code within 50 authored lines.
- **Why:** The gateway must cap work before allocating or decompressing attacker input.
- **Dependencies:** 1.17a and 1.31d.
- **Risk:** Critical.
- **Verification:** Unsupported, exact-limit, one-over, declared/actual mismatch, and read-error cases
  stop before decompression/schema.

### 1.32b Bound decompressed bytes and expansion ratio

- **Files:** `common/request_body_limit.go`, `common/request_body_decompressed_test.go`
- **Action:** RED-test then cap decompressed bytes/ratio and reject truncated streams or trailing
  compressed data. Keep test plus code within 50 authored lines.
- **Why:** A small compressed body can expand into resource exhaustion.
- **Dependencies:** 1.32a.
- **Risk:** Critical.
- **Verification:** Exact byte/ratio/truncation/trailing-data boundaries stop before JSON parsing.

### 1.32c Bound JSON container structure

- **Files:** `relay/responses_raw_bounds.go`, `relay/responses_structure_bounds_test.go`
- **Action:** RED-test then cap nesting depth and object/array member counts while traversing the
  retained raw object. Keep test plus code within 50 authored lines.
- **Why:** Small JSON can still trigger pathological traversal.
- **Dependencies:** 1.32b.
- **Risk:** Critical.
- **Verification:** Exact and one-over depth/member cases reject before entitlement or routing.

### 1.32d Bound JSON text and encoding

- **Files:** `relay/responses_raw_bounds.go`, `relay/responses_text_bounds_test.go`
- **Action:** RED-test then cap string lengths and reject invalid UTF-8 or structurally forbidden
  control characters. Keep test plus code within 50 authored lines.
- **Why:** Text validation is a separate memory and header/log safety boundary.
- **Dependencies:** 1.32c.
- **Risk:** Critical.
- **Verification:** Exact length/UTF/control matrix; opaque container content remains data.

### 1.32e Bound tool count and schema size

- **Files:** `relay/responses_semantic_bounds.go`, `relay/responses_tool_bounds_test.go`
- **Action:** RED-test then cap tool count and each/aggregate tool-schema size after structural
  validation. Keep test plus code within 50 authored lines.
- **Why:** Tool amplification can multiply upstream and validation work.
- **Dependencies:** 1.32d.
- **Risk:** Critical.
- **Verification:** Exact per-tool/aggregate/count boundaries reject before entitlement/routing.

### 1.32f Bound numeric output controls

- **Files:** `relay/responses_semantic_bounds.go`, `relay/responses_numeric_bounds_test.go`
- **Action:** RED-test then validate supported output-token integers against inherited maxima,
  rejecting negative, fractional, duplicate, and overflow values. Keep test plus code within 50
  authored lines.
- **Why:** Numeric overflow can bypass resource and later billing assumptions.
- **Dependencies:** 1.32e.
- **Risk:** Critical.
- **Verification:** Exact numeric boundary matrix; failures precede entitlement/channel selection.

### 1.33a Preserve allowlisted raw fields and opaque containers

- **Files:** `relay/responses_raw_transform.go`, `relay/responses_raw_preserve_test.go`
- **Action:** RED-test the pinned Codex fixture, then copy every allowlisted field and validated
  opaque container without semantic conversion while forcing the schema-approved `store:false`.
  Keep test plus code within 50 authored lines.
- **Why:** Codex semantics must survive without opening unknown fields as control-plane input.
- **Dependencies:** 1.31d and 1.32f.
- **Risk:** Critical.
- **Verification:** Semantic JSON comparison proves no supported field, nested tool schema, or
  client metadata value is dropped or invented.

### 1.33b Apply deterministic plan and channel policy overrides

- **Files:** `relay/responses_raw_transform.go`, `relay/responses_policy_transform_test.go`
- **Action:** RED-test allowed/denied `service_tier`, reasoning, storage, and capability cases, then
  apply only the versioned plan/channel policy after entitlement. Keep test plus code within 50
  authored lines.
- **Why:** Policy changes must be explicit and reproducible rather than adaptor side effects.
- **Dependencies:** 1.18e and 1.33a.
- **Risk:** Critical.
- **Verification:** Exact policy matrix; only contracted fields change and no denied value reaches
  a mock.

### 1.33c Map only the explicit request model field

- **Files:** `relay/responses_raw_transform.go`, `relay/responses_model_transform_test.go`
- **Action:** RED-test every public-alias/channel pair, then replace only the top-level `model`
  field with the selected mapping after entitlement succeeds. Keep test plus code within 50
  authored lines.
- **Why:** Global string replacement could corrupt instructions, metadata, or tool arguments.
- **Dependencies:** 1.12d, 1.18e, and 1.33b.
- **Risk:** Critical.
- **Verification:** Every seeded text alias maps correctly on each mock while identical strings in
  all other fields remain unchanged.

### 1.34a Use transformed raw JSON in gateway Responses relay

- **Files:** `relay/responses_handler.go`, `relay/responses_handler_gateway_test.go`
- **Action:** RED-test then disable native typed/raw passthrough only in gateway mode and dispatch
  the validated 1.33c transformed object. Preserve native mode. Keep test plus code within 50
  authored lines.
- **Why:** Native typed mode drops fields while native raw mode bypasses mapping and policy.
- **Dependencies:** 1.29c, 1.31d, 1.32f, and 1.33c.
- **Risk:** Critical.
- **Verification:** Gateway mock receives the transformed fixture exactly; native-mode regression
  retains its inherited request path.

### 1.34b Derive the upstream path from channel capability config

- **Files:** `relay/channel/openai/adaptor.go`,
  `relay/channel/openai/adaptor_gateway_path_test.go`
- **Action:** RED-test then use the selected endpoint-class path from validated
  `capability_config`; reject absent/mismatched paths and never derive upstream routing from the
  customer URL. Keep test plus code within 50 authored lines.
- **Why:** Incoming `/v1` compatibility must not become a hardcoded transfer-station path.
- **Dependencies:** 1.25d, 1.28b, 1.30, and 1.34a.
- **Risk:** Critical.
- **Verification:** Both inbound route forms reach the configured mock path; changing seed path
  changes dispatch without code.

### 1.35a Bound upstream non-stream response bytes

- **Files:** `relay/responses_raw_response.go`, `relay/responses_response_body_test.go`
- **Action:** RED-test then accept only declared response encodings and cap compressed bytes,
  decompressed bytes, and expansion ratio before full buffering. Keep test plus code within 50
  authored lines.
- **Why:** Pre-commit validation must not permit an upstream compression/memory denial of service.
- **Dependencies:** 1.25c and 1.34b.
- **Risk:** Critical.
- **Verification:** Exact/one-over/truncated/trailing/unsupported encoding cases fail before customer
  status/body commitment.

### 1.35b Validate complete non-stream response schema and usage

- **Files:** `relay/responses_raw_response.go`, `relay/responses_response_schema_test.go`
- **Action:** RED-test then parse the bounded body, require the supported response shape and complete
  usage totals, and reject malformed/missing usage rather than settling zero. Keep test plus code
  within 50 authored lines.
- **Why:** A syntactically successful upstream body is not a valid auditable customer response.
- **Dependencies:** 1.35a.
- **Risk:** Critical.
- **Verification:** Complete/malformed/missing/overflow usage fixtures produce exact internal result.

### 1.35c Reverse-map explicit model fields and preserve protocol IDs

- **Files:** `relay/responses_raw_response.go`, `relay/responses_response_rewrite_test.go`,
  `relay/channel/openai/relay_responses.go`
- **Action:** RED-test then rewrite only schema-declared model fields to the request public alias and
  preserve response/item/message/function/tool IDs exactly. Keep test plus code within 50 authored
  lines.
- **Why:** Global replacement could corrupt content while changed IDs break tool references.
- **Dependencies:** 1.35b.
- **Risk:** Critical.
- **Verification:** Upstream slug is absent, identical strings in content remain, and all protocol
  IDs/usage totals are unchanged.

### 1.36a Strip non-contracted upstream response headers

- **Files:** `relay/gateway_response_headers.go`, `relay/gateway_response_header_filter_test.go`
- **Action:** RED-test the full upstream header matrix, then copy only explicitly contracted header
  names and discard auth, vendor, forwarding, cookie, hop-by-hop, and unrecognized headers. Keep
  test plus code within 50 authored lines.
- **Why:** Headers can leak supplier identity or upstream account capacity even when JSON is clean.
- **Dependencies:** 1.35c.
- **Risk:** High.
- **Verification:** Exact allow/strip matrix with unique upstream sentinels and no wildcard family.

### 1.36b Rewrite contracted response headers to platform values

- **Files:** `relay/gateway_response_headers.go`, `relay/gateway_response_header_rewrite_test.go`
- **Action:** RED-test then replace request ID, model, and catalog ETag with request-scoped platform
  values and validate approved reasoning/turn-state headers. Emit no Step 1 `x-ratelimit-*` or
  success `Retry-After`; strip their upstream values. Keep test plus code within 50 authored lines.
- **Why:** Even an allowed header name must not expose upstream identities or account limits.
- **Dependencies:** 1.36a.
- **Risk:** High.
- **Verification:** Exact platform-value matrix; upstream request/model/catalog/rate sentinels are
  absent and no unauthoritative rate header is synthesized.

### 1.37a Map stable gateway error status and behavior

- **Files:** `service/gateway_error.go`, `service/gateway_error_mapping_test.go`
- **Action:** RED-test then map structured/malformed outcomes to contracted HTTP status, approved
  stable code, optional sanitized `Retry-After`, and platform request ID. Keep test plus code within
  50 authored lines.
- **Why:** Codex behavior depends on stable classes without vendor-specific branching.
- **Dependencies:** 1.34b, 1.35c, and 1.36b.
- **Risk:** Critical.
- **Verification:** Every approved code, malformed body, connection failure, and unknown status has
  exact status/code/retry behavior.

### 1.37b Replace upstream detail with fixed platform messages

- **Files:** `service/gateway_error.go`, `service/gateway_error_redaction_test.go`
- **Action:** RED-test then build fixed messages that exclude vendor prose, host/model/account/
  channel identifiers, bodies, stack details, and credentials. Keep test plus code within 50
  authored lines.
- **Why:** Correct status mapping alone can still leak transfer-station details.
- **Dependencies:** 1.37a.
- **Risk:** Critical.
- **Verification:** Unique sentinels across every source field are absent from the final object.

### 1.37c Apply sanitization after retry classification

- **Files:** `service/error.go`, `controller/relay.go`,
  `controller/relay_gateway_error_test.go`
- **Action:** RED-test then invoke 1.37b only after internal retry classification and before any
  uncommitted customer write; preserve native mode. Keep test plus code within 50 authored lines.
- **Why:** Sanitizing too early destroys routing signals; too late leaks the upstream body.
- **Dependencies:** 1.37b.
- **Risk:** Critical.
- **Verification:** Retry classification stays internal/correct and final errors expose only the
  contracted sanitized shape.

### 1.37d Buffer the validated non-stream customer response

- **Files:** `relay/gateway_response_recorder.go`, `relay/gateway_response_recorder_test.go`
- **Action:** RED-test then retain only the already bounded/validated status, closed headers, and
  rewritten body in a hard-capped recorder that cannot write to the customer directly. Keep test
  plus code within 50 authored lines.
- **Why:** Outer middleware cannot finalize durable audit if the handler has already committed bytes.
- **Dependencies:** 1.35c, 1.36b, and 1.37c.
- **Risk:** Critical.
- **Verification:** Recorder enforces one result, hard byte cap, no flush/hijack, and zero downstream
  bytes before commit coordination.

### 1.37e Finalize audit before flushing a successful response

- **Files:** `relay/gateway_response_commit.go`, `relay/gateway_response_commit_test.go`
- **Action:** RED-test then finalize through 1.18f before flushing 1.37d; on persistence failure,
  discard the buffered success and emit a sanitized platform failure. Keep test plus code within 50
  authored lines.
- **Why:** Step 1 must never produce an unlogged success or lie about durable audit completion.
- **Dependencies:** 1.18f and 1.37d.
- **Risk:** Critical.
- **Verification:** Success finalizes then writes once; injected DB failure writes no upstream body,
  leaves a visible pending row, and returns only the sanitized failure.

### 1.37f Bind the exact final customer request pipeline

- **Files:** `router/customer-public-router.go`,
  `router/customer_public_pipeline_test.go`
- **Action:** RED-test then bind customer descriptors in this order: request ID/stateless framing;
  fenced serving-readiness gate; Bearer/auth; durable request creation; plan snapshot; bounded read/
  decompression/route schema; effective entitlement; endpoint canonicalization/channel selection;
  native quota guards; protected relay; bounded response validation/buffering; durable audit
  finalization; flush. Keep internal retries disabled until 1.43a. Keep test plus wiring within 50
  authored lines.
- **Why:** Independently safe helpers do not prevent bypass unless one ordered public chain owns them.
- **Dependencies:** 1.18f, 1.19b, 1.20c, 1.21c, 1.24c, 1.27, 1.29c, 1.30,
  1.32f, 1.34b, and 1.37e.
- **Risk:** Critical.
- **Verification:** Order-spy integration proves every customer method/path takes the exact chain;
  a bad Redis fence stops before auth, authenticated success/rejection finalizes before its
  response, `/livez` takes only 1.17a, and no native/admin/alternate route binds.

### Phase 1B-I testing strategy

- **Unit:** Connection-time DNS/IP/test-allowlist validation, transport proxy/redirect/SNI rules,
  secret resolution/redaction/fingerprints/coverage, typed auth plus query-URL redaction, header
  contracts, strict schemas/bounds/transforms, response size/ID/usage validation, commit recording,
  and final error sanitization.
- **Integration:** Exact final middleware order, distributor-to-adaptor secret/config propagation,
  configured path dispatch, request-header pseudonymization, response size/schema validation,
  reverse mapping, sanitized errors, and audit-before-flush commit coordination.
- **E2E:** With one healthy mock, exercise both route forms, every production-entitled text alias,
  Luna only through an explicit test-only entitlement absent from production seed, the Kadirr-shaped
  request, compact, malformed/oversized input/response, header sentinels, missing usage, and every
  stable error; no upstream byte or identifier escapes the contract.

### Phase 1B-I review gate

- Code and Go reviewers inspect every change.
- Security reviewer signs off secret lifetime/redaction, header/body bounds, input classes, and
  outbound auth separation.
- AI reviewer signs off pinned Codex fields, model mapping, Responses schemas, and ID preservation.
- Database reviewer confirms no raw secret or native quota mutation path was introduced.
- Deployment conformance proves both seeded channels resolve/match; serving-readiness failure
  injection separately proves one valid secondary preserves every advertised route.
- Full unit/integration suite is fresh and green before failover work begins.

## 9. Phase 1B-II: Issuance, Narrow Failover, and Codex Evidence

### 1.38a Validate requested key-scope ceilings

- **Files:** `service/customer_key_scope.go`, `service/customer_key_scope_test.go`
- **Action:** RED-test then canonicalize an explicit full or restricted alias/endpoint scope and
  require it to be a subset of the active subscription plan. Keep test plus code within 50 authored
  lines.
- **Why:** A stored ceiling is only useful if issuance cannot exceed the subscription.
- **Dependencies:** 1.12g and 1.18d.
- **Risk:** Critical.
- **Verification:** Full/restricted/empty/unknown/cross-plan matrices produce the exact immutable
  ceiling or reject before key generation.

### 1.38b Implement one transactional key-issuance attempt

- **Files:** `service/customer_key_issue.go`, `service/customer_key_issue_test.go`
- **Action:** RED-test then generate one candidate, persist only verifier/public ID/subscription plus
  the 1.38a ceiling, and append its issue audit in one transaction. Return the full candidate only
  after commit. Keep test plus code within 50 authored lines.
- **Why:** Rollback must not create an orphan key, audit event, or prematurely exposed secret.
- **Dependencies:** 1.10a, 1.10b, 1.13b, 1.14, 1.15, and 1.38a.
- **Risk:** Critical.
- **Verification:** Commit returns one usable key once; injected rollback returns no key and leaves
  no key/audit row or DB/log secret.

### 1.38c Handle issuance public-ID collisions safely

- **Files:** `service/customer_key_issue.go`, `service/customer_key_issue_collision_test.go`
- **Action:** RED-test a deterministic unique-index collision, then retry with a fresh full
  candidate only for that classified conflict and stop at a bounded attempt count. Keep test plus
  code within 50 authored lines.
- **Why:** Retrying the transaction with the same candidate cannot resolve a collision and can
  expose ambiguous issuance state.
- **Dependencies:** 1.38b.
- **Risk:** Critical.
- **Verification:** One collision yields one committed replacement and one audit event; unrelated
  database errors and retry exhaustion expose no full key.

### 1.39 Implement transactional revocation

- **Files:** `service/customer_key_revoke.go`, `service/customer_key_revoke_test.go`
- **Action:** RED-test then revoke by key ID/public ID with compare-and-set status and a same-
  transaction audit event. Make repeated revocation an audited no-op.
- **Why:** Revocation must be immediate, idempotent, and attributable.
- **Dependencies:** 1.38c.
- **Risk:** Critical.
- **Verification:** Revoked key fails the next authentication; concurrent revocations produce one
  state transition.

### 1.40a Add secure gateway-admin command parsing and I/O

- **Files:** `cmd/gateway-admin/main.go`, `cmd/gateway-admin/main_test.go`
- **Action:** RED-test command/flag parsing and stdout/stderr separation, then create the offline CLI
  shell with dependency configuration accepted only through environment/config references. Reject
  secret-bearing command-line values. Keep test plus code within 50 authored lines.
- **Why:** Every subcommand needs one non-networked, shell-history-safe operator boundary.
- **Dependencies:** 1.24b.
- **Risk:** Critical.
- **Verification:** Unknown/duplicate/secret flags fail; usage and sanitized errors go to stderr;
  no process argument contains a credential.

### 1.40b Add the gateway-admin seed subcommand

- **Files:** `cmd/gateway-admin/seed.go`, `cmd/gateway-admin/seed_test.go`
- **Action:** RED-test then invoke the production seed or explicit non-production `step1-test`
  profile (including 1.12g bootstrap) and print only revision/result/audit identifiers. Keep test
  plus code within 50 authored lines.
- **Why:** Operators need a reproducible control-plane bootstrap without direct SQL.
- **Dependencies:** 1.12e, 1.12g, and 1.40a.
- **Risk:** High.
- **Verification:** First/second apply behavior matches the seed service and stdout/stderr contains
  no resolved secret.

### 1.40c Add the gateway-admin key-issue subcommand

- **Files:** `cmd/gateway-admin/key_issue.go`, `cmd/gateway-admin/key_issue_test.go`
- **Action:** RED-test then issue for a stable subscription and explicit full/restricted scope
  ceiling, print the full new key exactly once after commit, and print the audit ID to stderr. Keep
  test plus code within 50 authored lines.
- **Why:** One-time display must remain explicit and scriptable without persistence.
- **Dependencies:** 1.38c and 1.40a.
- **Risk:** Critical.
- **Verification:** Captured stdout contains one key only on success; rollback/collision exhaustion
  prints none, and stderr/logs never contain it.

### 1.40d Add the gateway-admin masked key-list subcommand

- **Files:** `cmd/gateway-admin/key_list.go`, `cmd/gateway-admin/key_list_test.go`
- **Action:** RED-test then list key ID, canonical public ID/masked label, status, subscription, and
  non-sensitive scope summary/timestamps only; require `--masked` and expose no verifier. Keep test
  plus code within 50 authored lines.
- **Why:** Administration must locate keys without creating a recovery surface.
- **Dependencies:** 1.9 and 1.40a.
- **Risk:** Critical.
- **Verification:** Golden output contains no secret/verifier/pepper value and stable pagination or
  ordering is deterministic.

### 1.40e Add the gateway-admin key-revoke subcommand

- **Files:** `cmd/gateway-admin/key_revoke.go`, `cmd/gateway-admin/key_revoke_test.go`
- **Action:** RED-test then revoke by key/public ID, report the audit/result identifiers, and treat
  repeated revocation as the service's audited no-op. Keep test plus code within 50 authored lines.
- **Why:** Immediate revocation needs an operator path without accepting a raw key.
- **Dependencies:** 1.39 and 1.40a.
- **Risk:** Critical.
- **Verification:** Issue/authenticate/revoke/authenticate-fails flow passes; neither CLI stream nor
  process arguments contain a raw key.

### 1.41a Exclude attempted channels in uncached selection

- **Files:** `service/channel_select.go`, `service/channel_select_test.go`
- **Action:** First RED-reproduce same-channel reselection with caching disabled, then filter an
  excluded-ID set before priority/weight selection. Keep test plus code within 50 authored lines.
- **Why:** The database selection path must not retry the failed primary.
- **Dependencies:** 1.12d.
- **Risk:** Critical.
- **Verification:** Uncached weighted/priority cases always select the eligible secondary and
  return no route when all eligible IDs are excluded.

### 1.41b Exclude attempted channels in cached selection

- **Files:** `model/channel_cache.go`, `model/channel_cache_gateway_test.go`
- **Action:** RED-reproduce cached reselection, then apply the same excluded-ID filter before cached
  priority/weight choice. Keep test plus code within 50 authored lines.
- **Why:** Cache configuration must not change failover correctness.
- **Dependencies:** 1.41a.
- **Risk:** Critical.
- **Verification:** Cached/uncached decisions match for the same candidate snapshot, including all-
  excluded and weighted secondary cases.

### 1.42 Carry attempt exclusion through the relay loop

- **Files:** `controller/relay.go`, `controller/relay_gateway_test.go`
- **Action:** RED-test then record the selected ID before dispatch, pass exclusions into every
  retry selection, and retain a maximum of two attempts for one inbound Step 1 request.
- **Why:** Request-scoped retry ownership belongs at the gateway.
- **Dependencies:** 1.41a and 1.41b.
- **Risk:** Critical.
- **Verification:** Attempt sequence is exactly `[primary, secondary]`; no third attempt and no
  customer-visible first response.

### 1.43a Add the narrow pre-response retry classification

- **Files:** `service/error.go`, `controller/relay_gateway_retry_test.go`
- **Action:** RED-test then add only the missing connection/pre-response failure classification for
  Step 1 gateway mode and enable exactly one retry only after 1.42 exclusion is present. Do not add
  latency health, streaming commitment, or post-commit replay. Keep test plus code within 50
  authored lines.
- **Why:** The relay loop needs one explicit safe signal before it can select the secondary.
- **Dependencies:** 1.37f and 1.42.
- **Risk:** Critical.
- **Verification:** Connection failure before any downstream write is retryable; validation,
  committed, native-mode, and unrelated upstream failures retain their contracted behavior.

### 1.43b Prove narrow non-streaming failover end to end

- **Files:** `integration/step1/failover_test.go`
- **Action:** Start with the failing controlled-primary fixture, then verify the completed flow using
  existing production behavior only. Keep the focused E2E test within 50 authored lines.
- **Why:** Two configured rows and a unit retry signal do not prove one transparent response.
- **Dependencies:** 1.22b, 1.37f, and 1.43a.
- **Risk:** Critical.
- **Verification:** Exactly two upstream observations, one successful customer JSON response, no
  partial primary bytes, zero native quota mutations, exactly one durable explicitly
  non-authoritative Step 1 request record, and no channel reselection.

### 1.43c Prove unresolved-primary-secret failover

- **Files:** `integration/step1/secret_failover_test.go`
- **Action:** RED-test then remove only the primary secret while retaining complete secondary route
  coverage and exercise the final public pipeline with no production change. Keep the focused test
  within 50 authored lines.
- **Why:** Channel-scoped secret failure must not become gateway-wide downtime or auth fallback.
- **Dependencies:** 1.26g and 1.43b.
- **Risk:** Critical.
- **Verification:** Serving readiness stays true, primary is unavailable/alerted with zero dispatch,
  secondary receives exactly one correctly authenticated request, and customer receives one success.

### 1.44a Pin Codex 0.146.0 compatibility fixtures

- **Files:** `testdata/codex/0.146.0/manifest.json`,
  `testdata/codex/0.146.0/compatibility-config.toml`,
  `testdata/codex/0.146.0/recommended-config.toml`,
  `testdata/codex/0.146.0/project/.codex/config.toml`,
  `testdata/codex/0.146.0/request.json`
- **Action:** Add the exact release/source/artifact/checksum metadata, safe configuration snippets,
  a repository-local conflicting provider sentinel, and Kadirr-shaped non-streaming request fixture
  with non-secret sentinels only. Add no executable code or key and never replace a real
  `auth.json`.
- **Why:** Compatibility claims must bind to one immutable client and safe public fixtures.
- **Dependencies:** 0.4b.
- **Risk:** High.
- **Verification:** JSON/TOML parsers accept every fixture; manifest values match the approved
  design, the project sentinel is unmistakable, and no fixture contains a credential-shaped literal.

### 1.44b Verify the pinned Codex artifact before execution

- **Files:** `scripts/verify-codex-0.146.0.ps1`,
  `scripts/verify-codex-0.146.0.Tests.ps1`
- **Action:** RED-test wrong checksum/version/artifact inputs, then refuse execution unless the
  manifest SHA-256 and `codex --version` match. Use a disposable download and isolated
  `CODEX_HOME`. Keep test plus script within 50 authored lines.
- **Why:** A fixture pin does not prevent a different local binary from creating false evidence.
- **Dependencies:** 1.44a.
- **Risk:** High.
- **Verification:** Wrong artifact/checksum/version fails closed; verified artifact parses both
  configs with no unknown-key warning.

### 1.44c Prove user-level provider precedence over project configuration

- **Files:** `integration/codex/codex_0146_config_precedence_test.go`,
  `testdata/codex/0.146.0/project/.codex/config.toml`
- **Action:** With the verified binary and disposable `CODEX_HOME`, RED-test from inside the
  fixture project, then prove the repository-local conflicting custom-provider definition neither
  overrides nor supplies the user-level provider. Keep the focused test within 50 authored lines.
- **Why:** Parsing two user configurations does not prove the pinned client's documented config
  precedence or protect customers from a misleading repository-local snippet.
- **Dependencies:** 1.44a and 1.44b.
- **Risk:** High.
- **Verification:** Inventory test 25 records the effective provider/base URL from the user-level
  config, never the project sentinel, with no unknown-key warning or mutation of either fixture.

### 1.45a Capture Codex compatibility-mode authentication

- **Files:** `integration/codex/codex_0146_compat_auth_test.go`
- **Action:** With the verified real binary and isolated temporary `CODEX_HOME`, RED-test then prove
  the compatibility configuration parses and emits the platform key as one Bearer header to a
  controlled capture endpoint without modifying unrelated auth state. Keep the focused test within
  50 authored lines.
- **Why:** Kadirr-shape compatibility is a client-wire claim, not a TOML inspection claim.
- **Dependencies:** 1.44c.
- **Risk:** Critical.
- **Verification:** The compatibility half of inventory test 26 passes; capture contains only the
  sentinel customer Bearer and the temporary auth file remains isolated.

### 1.45b Capture Codex environment-key authentication and Step 1 rejection

- **Files:** `integration/codex/codex_0146_env_auth_test.go`
- **Action:** RED-test then prove the recommended provider configuration reads only
  `OUR_PLATFORM_API_KEY`, emits one Bearer header, and receives the contracted `stream:true` Step 1
  rejection; do not claim a completed Codex turn. Keep the focused test within 50 authored lines.
- **Why:** Normal Codex turns remain blocked until Step 3 implements and verifies streaming.
- **Dependencies:** 1.37f, 1.44b, and 1.45a.
- **Risk:** Critical.
- **Verification:** Environment-key half of inventory test 26 and the documented streaming
  rejection pass with no unknown-config warning.

### 1.45c Prove non-stream route and catalog parity

- **Files:** `integration/step1/gateway_routes_test.go`
- **Action:** RED-test canonical/root Responses and models routes, exact plan filtering, and the
  published non-streaming curl shape with no production changes. Keep the focused test within 50
  authored lines.
- **Why:** Client config and auth capture do not prove both public route forms share one contract.
- **Dependencies:** 1.21c, 1.37f, 1.40c, and 1.44b.
- **Risk:** Critical.
- **Verification:** Inventory tests 2, 3, 7, and 27 pass for both route forms.

### 1.45d Prove model mapping and credential isolation

- **Files:** `integration/step1/mock_mapping_test.go`
- **Action:** RED-test every production-entitled text alias on both mocks; test Luna mapping only
  through an explicit test-only plan version never applied by the production seed. Assert each
  observation has only selected channel auth/path/model. Keep the test within 50 authored lines.
- **Why:** Correct routing must not leak the customer credential or rely on one channel's slug.
- **Dependencies:** 1.12d, 1.29c, 1.33c, 1.37f, and 1.45c.
- **Risk:** Critical.
- **Verification:** Inventory tests 4, 5, and 8 pass for both active mocks.

### 1.45e Prove strict non-stream request behavior

- **Files:** `integration/step1/gateway_schema_test.go`
- **Action:** RED-test supported field preservation, omitted/false/true storage, and known/unknown
  field rejection with no production changes. Keep the focused test within 50 authored lines.
- **Why:** A successful status can hide silent request-field loss or permissive passthrough.
- **Dependencies:** 1.31d, 1.32f, 1.33b, and 1.45d.
- **Risk:** Critical.
- **Verification:** Inventory tests 28 and 41 pass and the supported pinned request remains
  semantically identical after approved transforms.

### 1.45f Prove strict non-stream response and error behavior

- **Files:** `integration/step1/gateway_response_test.go`
- **Action:** RED-test reverse model mapping, response ID/usage preservation, and every stable
  sanitized error class with unique upstream sentinels. Keep the focused test within 50 authored
  lines.
- **Why:** Valid JSON can still expose supplier identity or corrupt Codex reference IDs.
- **Dependencies:** 1.35c, 1.36b, 1.37f, and 1.45e.
- **Risk:** Critical.
- **Verification:** Inventory tests 6 and 9(a) pass; all protocol IDs/usage survive and no upstream
  slug or vendor sentinel reaches the client.

### 1.45g Reconcile the complete Step 1 compatibility inventory

- **Files:** `integration/step1/step1_inventory_test.go`,
  `integration/step1/failover_test.go`
- **Action:** RED-test the remaining inventory assertions, then compose existing fixtures to prove
  pinned identity, deliberate primary connection/secret failures, no reselection, and exactly one
  non-authoritative request record. Keep the new orchestration test within 50 authored lines.
- **Why:** Passing isolated fixtures is not evidence that the checkpoint contract is complete.
- **Dependencies:** 1.43c, 1.45a, 1.45b, 1.45c, 1.45d, 1.45e, and 1.45f.
- **Risk:** Critical.
- **Verification:** Approved design inventory tests 1-8, 9(a), 14(a), 25-28, and 41 report explicit
  passing evidence; 1.46b-1.46c owns test 40, and normal Codex streaming remains rejected.

### 1.46a Prove runtime secret and content-observability absence with sentinels

- **Files:** `integration/step1/security_leakage_test.go`
- **Action:** Seed unique customer/channel/query-auth/pepper/metadata sentinels plus distinct prompt
  and mock-response content sentinels. Exercise success and every failure class, then scan database,
  Redis, logs, traces, metrics, errors, process output, and config/admin serialization. Inspect the
  controlled upstream request and customer response separately as the only permitted content
  boundaries. Keep the focused test within 50 authored lines.
- **Why:** Secret isolation and default prompt/response non-logging are observable absence claims,
  not code-inspection claims.
- **Dependencies:** 1.45g.
- **Risk:** Critical.
- **Verification:** Credential/metadata sentinels have zero full or partial occurrences outside
  controlled test inputs; prompt/response sentinels occur only in the expected upstream/customer
  payloads and nowhere in persistence or observability output.

### 1.46b Prove negative routes stay closed

- **Files:** `integration/step1/security_routes_test.go`
- **Action:** Enumerate every inherited native/vendor/admin/WebSocket method/path from the approved
  registry contract and assert rejection before customer auth/relay. Keep the focused table-driven
  test within 50 authored lines.
- **Why:** Any forgotten route bypasses the one gateway pipeline.
- **Dependencies:** 1.19b, 1.37f, 1.45g, and API contract approval.
- **Risk:** Critical.
- **Verification:** Inventory test 40 has zero unexpected public method/path.

### 1.46c Prove alternate credential sources stay closed

- **Files:** `integration/step1/security_credentials_test.go`
- **Action:** Enumerate Bearer duplicates/malformed values plus every inherited query/header/cookie/
  WebSocket credential source and assert rejection before indexed auth or relay. Keep the focused
  table-driven test within 50 authored lines.
- **Why:** A second credential parser bypasses key grammar, audit, and later limiters.
- **Dependencies:** 1.17b, 1.37f, and 1.46b.
- **Risk:** Critical.
- **Verification:** Inventory test 40 accepts exactly one canonical Bearer source and emits only the
  bounded pre-auth security event for failures.

### 1.46d Enforce source and artifact secret scans in final CI

- **Files:** `.gitleaks.toml`, `.github/workflows/ci.yml`,
  `scripts/verify-no-step1-secrets.ps1`
- **Action:** RED-test a disposable sentinel artifact, then scan source, binaries/images, generated
  configs, and retained test reports; allow only narrowly documented test inputs. Keep script plus
  configuration/workflow delta within 50 authored lines.
- **Why:** Runtime tests do not inspect every packaged or generated delivery artifact.
- **Dependencies:** 0.5d, 1.46a, and 1.46c.
- **Risk:** Critical.
- **Verification:** Deliberate leak fails, clean rebuild passes, and scanner output does not echo the
  secret value.

### 1.47 Write and execute the Step 1 operator runbook

- **Files:** `docs/step1-operations.md`, `deploy/step1/README.md`
- **Action:** Document clean boot, secret injection, seed, issue, configure Codex, call both route
  forms, inspect masked records, deliberately break primary connection and secret separately,
  verify secondary, revoke, inspect audit evidence, recover, upgrade, rollback, and shut down. Use
  only the explicit `step1-test` bootstrap profile from a clean Compose state.
- **Why:** A deployment that only its author can operate is not a checkpoint.
- **Dependencies:** 1.23, 1.23a, 1.24c, 1.40b, 1.40c, 1.40d, 1.40e, 1.43c,
  and 1.46d.
- **Risk:** High.
- **Verification:** Every command is copied from a fresh successful run; no real secret appears in
  the document or shell history fixture.

### Phase 1B-II testing strategy

- **Unit:** Issuance transaction/collision paths, idempotent revocation, every offline CLI
  subcommand, cached/uncached exclusion, relay attempt-set propagation, and narrow retry
  classification.
- **Integration:** Issue/authenticate/revoke lifecycle, deliberate primary failure with one
  secondary response and request record, missing-primary-secret coverage failover, real Codex
  0.146.0 config/auth capture, route/schema/model inventory, negative-route/credential enumeration,
  user-vs-project configuration precedence, and credential/metadata/prompt/response sentinel
  scanning across persistence and observability.
- **E2E:** Execute the clean Compose operator runbook from seed through key issuance, canonical/root
  calls, controlled primary break, successful secondary response, audit inspection, revocation,
  restart/recovery, and final source/artifact secret scan.

## 10. Final Review and Verification Gate

The following reviews are cumulative and mandatory after implementation:

1. **Code reviewer:** all authored product diffs; no drive-by refactor or orphan fork code.
2. **Go reviewer:** every `.go` change, including errors, contexts, races, and pointer semantics.
3. **Security reviewer:** auth, keys, peppers, secrets, input, SSRF, routing, headers, logs, and
   direct-route bypass.
4. **Database reviewer:** schema, migrations, indexes, immutable versions, transactions, and
   cross-database behavior.
5. **AI reviewer:** Responses/Codex compatibility, model mapping, field preservation, usage, and
   retry semantics.
6. **Compliance reviewer:** customer identifiers, audit events, retention assumptions, and
   third-party transfer-station boundary.
7. **Infra reviewer:** Docker, networks, health/readiness, CI, pinning, and secret injection.
8. **E2E reviewer:** real customer key flow, route parity, direct bypass rejection, and deliberate
   primary failure.
9. **Performance reviewer:** only Step 1 bounded-input and obvious regression checks; full load/
   latency audit remains Step 5.
10. **Harness audit:** confirm every required gate ran using actual command output.

Any review blocker returns to RED with a regression test. Reviews are rerun after the fix.

Fresh final verification commands, run after the last change:

```powershell
git diff --check
& .\scripts\verify-go-lint.ps1
go vet ./...
& .\scripts\verify-go-vet.ps1
& .\scripts\verify-go-vulnerabilities.ps1
go test ./...
go test -race ./common ./model ./service ./middleware ./controller ./relay/...
Push-Location relaykit
$env:GOWORK='off'
go build ./...
Pop-Location
docker compose -f deploy/test/db-matrix.compose.yaml up --build --abort-on-container-exit
docker compose -f deploy/step1/compose.yaml config
docker compose -f deploy/step1/compose.yaml up --build --wait
go test ./integration/step1 ./integration/codex
& .\scripts\verify-codex-0.146.0.ps1
& .\scripts\verify-no-step1-secrets.ps1
docker compose -f deploy/step1/compose.yaml down
```

After verification, remove generated logs, traces, dumps, temporary `CODEX_HOME`, downloaded client
artifact, and test secrets. Preserve only intentional test reports and source fixtures.

## 11. Success Criteria

- [ ] Fork history proves the exact New API upstream commit and isolated fork delta.
- [ ] API and migration contracts were approved before implementation.
- [ ] Fresh/upgrade/repeat migrations pass on SQLite, MySQL, and PostgreSQL.
- [ ] Seven editable plans and approved entitlements seed exactly, including `gpt-image-2`.
- [ ] Two active mock channels seed at 100/100 and 50/100 with distinct refs/domains.
- [ ] PostgreSQL owns a monotonic runtime epoch; empty, stale, superseded, or unavailable Redis
  rejects public admission and cannot accept Step 1 coordination writes.
- [ ] Production activation requires secret/policy/cost/capability/mapping/failure-domain closure,
  rejects raw keys/proxies, and rejects non-production egress allowlists.
- [ ] Native plaintext-token mutations/routes/serialization are disabled in gateway mode.
- [ ] Gateway-mode relay, retry, scheduled tests, administrative checks, and unsupported endpoint/
  adaptor paths cannot read a legacy channel key; control-plane mutations use only audited owners.
- [ ] The explicit test bootstrap creates one login-disabled customer/subscription/audit and cannot
  run in production.
- [ ] Full customer keys are displayed once and never persist in DB, Redis, logs, or responses.
- [ ] Restricted keys enforce plan entitlement intersected with their immutable scope ceiling.
- [ ] Model list and retrieve use that same effective scope and cannot enumerate excluded aliases.
- [ ] Only Bearer credentials and the approved customer route registry are accepted.
- [ ] Canonical/root model and Responses routes share identical enforcement.
- [ ] Strict non-streaming Responses preserves supported Codex fields and rejects unsupported input.
- [ ] Every production-entitled text alias maps per channel; Luna uses only the isolated test plan;
  all supported customer JSON reverse-maps.
- [ ] Validated non-stream response size/schema/usage is bounded and durable audit finalizes before
  any success byte; Step 1 emits no unauthoritative rate headers.
- [ ] Deliberate primary connection and secret failures each return exactly one secondary success;
  readiness uses route coverage and cross-instance fingerprint mismatch isolates one channel.
- [ ] Pinned Codex 0.146.0 parses both documented auth modes and emits the expected platform Bearer
  into a controlled capture; project-local provider config cannot override the user-level provider;
  its normal streaming turn receives the documented Step 1 rejection.
- [ ] Prompt and response content appear only at the contracted upstream/customer payload
  boundaries, never in persistence or observability output by default.
- [ ] Formatting, pinned static analysis, explicit vet, dependency-vulnerability, secret, test, and
  race gates are freshly green.
- [ ] All mandatory specialist reviews have no unresolved blocker.
- [ ] All final verification commands are freshly green and diagnostic debris is removed.

## 12. Explicit Stop Conditions

Stop and request owner input instead of guessing if:

- a real hosted deployment is required before cloud, DNS/TLS, and secret-injection targets exist;
- a real transfer-station credential or URL is needed before the user supplies it through the
  approved secret workflow;
- a requested change broadens Step 1 into streaming, production limiters, billing, or dashboard
  work;
- the API or migration reviewer rejects the approved contract;
- the pinned upstream baseline fails before fork changes and cannot be reproduced safely.
