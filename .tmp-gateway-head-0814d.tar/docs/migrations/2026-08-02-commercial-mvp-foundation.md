---
contract_version: 1
dialect: postgresql
implementation_status: desired-contract-only
normative_authority: structured-frontmatter-only
schema:
  altered_tables:
    - channels
    - subscription_pre_consume_records
    - tokens
    - user_subscriptions
  new_tables:
    - billing_commands
    - channel_attempts
    - channel_cost_profiles
    - channel_cost_rates
    - channel_health_transitions
    - channel_reliability_policies
    - commercial_access_projections
    - commercial_audit_events
    - commercial_billing_periods
    - commercial_plan_entitlements
    - commercial_plan_versions
    - enforcement_epochs
    - logical_request_usages
    - stripe_event_effects
    - stripe_event_inbox
  forbidden_tables:
    - customer_usage_reservations
  required_uniqueness:
    - "billing_commands(customer_id,command_type,idempotency_key)"
    - "billing_commands(provider_idempotency_key)"
    - "channel_attempts(request_id,attempt_index)"
    - "channel_cost_profiles(channel_id,id)"
    - "channel_cost_profiles(channel_id,version)"
    - "channel_cost_rates(cost_profile_id,endpoint_class,public_model_alias,upstream_model,meter_dimension)"
    - "channel_health_transitions(event_id)"
    - "channel_reliability_policies(channel_id,id)"
    - "channel_reliability_policies(channel_id,version)"
    - "commercial_access_projections(token_id)"
    - "commercial_audit_events(event_id)"
    - "commercial_billing_periods(provider,provider_subscription_id,period_start,period_end)"
    - "commercial_billing_periods(user_subscription_id,id,reset_version,plan_version_id)"
    - "commercial_billing_periods(user_subscription_id,reset_version)"
    - "commercial_plan_entitlements(plan_version_id,model_alias,reasoning_effort)"
    - "commercial_plan_versions(plan_id,version)"
    - "enforcement_epochs(singleton_id)"
    - "logical_request_usages(request_id)"
    - "stripe_event_effects(stripe_event_inbox_id,effect_type)"
    - "stripe_event_effects(effect_type,effect_key)"
    - "stripe_event_inbox(provider,provider_event_id)"
    - "subscription_pre_consume_records(request_id)"
    - "tokens(gateway_public_id)"
    - "tokens(gateway_verifier_digest)"
    - "tokens(id,user_id)"
    - "tokens(key) where key is not null"
    - "user_subscriptions(id,user_id)"
  required_indexes:
    - "billing_commands(status,next_attempt_at)"
    - "channel_attempts(channel_id,started_at)"
    - "channel_health_transitions(channel_id,created_at)"
    - "commercial_access_projections(user_subscription_id,status)"
    - "commercial_audit_events(object_type,object_id,created_at)"
    - "logical_request_usages(customer_id,created_at)"
    - "stripe_event_inbox(status,received_at)"
    - "stripe_event_inbox(status,processing_lease_expires_at)"
    - "subscription_pre_consume_records(billing_period_id,status)"
    - "subscription_pre_consume_records(commercial_record,updated_at)"
    - "subscription_pre_consume_records(status,hard_expires_at)"
  required_foreign_keys:
    - "billing_commands(customer_id)->users(id):restrict"
    - "channel_attempts(channel_id)->channels(id):restrict"
    - "channel_attempts(channel_id,cost_profile_id)->channel_cost_profiles(channel_id,id):restrict"
    - "channel_attempts(customer_id)->users(id):restrict"
    - "channel_attempts(customer_key_id)->tokens(id):restrict"
    - "channel_cost_profiles(channel_id)->channels(id):restrict"
    - "channel_cost_rates(cost_profile_id)->channel_cost_profiles(id):restrict"
    - "channel_health_transitions(channel_id)->channels(id):restrict"
    - "channel_reliability_policies(channel_id)->channels(id):restrict"
    - "channels(id,active_cost_profile_id)->channel_cost_profiles(channel_id,id):restrict:deferrable"
    - "channels(id,reliability_policy_id)->channel_reliability_policies(channel_id,id):restrict:deferrable"
    - "commercial_access_projections(customer_id)->users(id):restrict"
    - "commercial_access_projections(plan_version_id)->commercial_plan_versions(id):restrict"
    - "commercial_access_projections(token_id)->tokens(id):restrict"
    - "commercial_access_projections(token_id,customer_id)->tokens(id,user_id):restrict"
    - "commercial_access_projections(user_subscription_id)->user_subscriptions(id):restrict"
    - "commercial_access_projections(user_subscription_id,customer_id)->user_subscriptions(id,user_id):restrict"
    - "commercial_access_projections(user_subscription_id,billing_period_id,reset_version,plan_version_id)->commercial_billing_periods(user_subscription_id,id,reset_version,plan_version_id):restrict"
    - "commercial_billing_periods(plan_version_id)->commercial_plan_versions(id):restrict"
    - "commercial_billing_periods(user_subscription_id)->user_subscriptions(id):restrict"
    - "commercial_plan_entitlements(plan_version_id)->commercial_plan_versions(id):restrict"
    - "commercial_plan_versions(plan_id)->subscription_plans(id):restrict"
    - "logical_request_usages(successful_channel_id,cost_profile_id)->channel_cost_profiles(channel_id,id):restrict"
    - "logical_request_usages(customer_id)->users(id):restrict"
    - "logical_request_usages(customer_key_id)->tokens(id):restrict"
    - "logical_request_usages(customer_key_id,customer_id)->tokens(id,user_id):restrict"
    - "logical_request_usages(successful_channel_id)->channels(id):restrict"
    - "logical_request_usages(user_subscription_id)->user_subscriptions(id):restrict"
    - "logical_request_usages(user_subscription_id,customer_id)->user_subscriptions(id,user_id):restrict"
    - "logical_request_usages(user_subscription_id,billing_period_id,reset_version,plan_version_id)->commercial_billing_periods(user_subscription_id,id,reset_version,plan_version_id):restrict"
    - "logical_request_usages(request_id)->subscription_pre_consume_records(request_id):restrict"
    - "stripe_event_effects(stripe_event_inbox_id)->stripe_event_inbox(id):restrict"
    - "subscription_pre_consume_records(plan_version_id)->commercial_plan_versions(id):restrict"
    - "subscription_pre_consume_records(user_subscription_id)->user_subscriptions(id):restrict"
    - "subscription_pre_consume_records(user_subscription_id,user_id)->user_subscriptions(id,user_id):restrict"
    - "subscription_pre_consume_records(user_subscription_id,billing_period_id,reset_version,plan_version_id)->commercial_billing_periods(user_subscription_id,id,reset_version,plan_version_id):restrict"
    - "tokens(user_id)->users(id):restrict"
    - "channel_attempts(customer_key_id,customer_id)->tokens(id,user_id):restrict"
    - "user_subscriptions(plan_version_id)->commercial_plan_versions(id):restrict"
    - "user_subscriptions(id,current_billing_period_id,quota_reset_version,plan_version_id)->commercial_billing_periods(user_subscription_id,id,reset_version,plan_version_id):restrict:deferrable"
  required_checks:
    - "billing_commands:request-fingerprint-32-bytes-status-in-pending-processing-succeeded-failed-retryable-and-attempt-count-nonnegative"
    - "billing_commands:provider-idempotency-key-nonempty-server-derived-from-command-id-and-request-fingerprint-mismatch-conflicts"
    - "billing_commands:version-nonnegative-and-state-transitions-use-versioned-cas"
    - "channel_attempts:status-in-pending-final-and-meters-cost-latencies-nonnegative"
    - "channel_attempts:input-output-tokens-and-cost-in-0-to-1000000000"
    - "channel_attempts:actor-type-customer-or-system-customer-requires-owner-system-requires-null-owner"
    - "channel_attempts:latency-ttft-http-status-and-outcome-bounded-by-final-state"
    - "channel_cost_rates:price-numerator-nonnegative-and-unit-denominator-positive"
    - "channel_cost_rates:price-numerator-in-0-to-1000000000-and-unit-denominator-in-1-to-1000000000"
    - "channel_health_transitions:states-allowlisted-sample-count-nonnegative-error-rate-0-to-10000-and-latencies-nonnegative"
    - "channel_reliability_policies:timeouts-positive-at-most-10000-precommit-bytes-at-most-1048576-stream-and-response-bytes-at-most-8388608-thresholds-0-to-10000-and-recovery-counts-positive"
    - "channel_reliability_policies:retry-statuses-window-buckets-percentiles-histogram-and-hysteresis-validated"
    - "channels:commercial-channel-requires-null-key-nonnull-reference-auth-policy-cost-and-positive-config-version"
    - "channels:commercial-secret-ref-is-env-name-auth-type-in-bearer-fixed-header-and-header-name-is-validated"
    - "commercial_access_projections:status-allowlisted-reset-version-positive-and-expiry-after-period-start-when-present"
    - "commercial_billing_periods:period-end-after-period-start-reset-version-positive-and-status-allowlisted"
    - "commercial_plan_versions:money-and-quotas-bounded-integers-concurrency-positive-and-effective-before-retired"
    - "commercial_plan_versions:price-and-quota-values-in-0-to-1000000000"
    - "enforcement_epochs:singleton-id-is-one-epoch-and-version-positive-state-in-closed-draining-active"
    - "logical_request_usages:meters-request-units-latency-and-cost-nonnegative-and-delivery-status-allowlisted"
    - "logical_request_usages:meters-and-cost-in-0-to-1000000000-and-request-units-exactly-1"
    - "logical_request_usages:plan-period-state-image-units-quota-delta-charge-and-hard-expiry-bound"
    - "logical_request_usages:success-requires-successful-channel-and-cost-profile-failure-requires-null-success-and-cost-channel-bindings"
    - "commercial_access_projections:versioned-cas-event-watermark-monotonic-rejects-stale-status-change"
    - "stripe_event_inbox:state-allowlisted-payload-hash-32-bytes-normalized-effect-object-at-most-16384-bytes-version-nonnegative-and-processing-requires-owner-and-lease"
    - "stripe_event_inbox:duplicate-event-compares-provider-event-id-account-mode-type-occurred-at-and-payload-hash-exact-match-no-op-any-mismatch-rejects-and-audits-without-mutation"
    - "stripe_event_inbox:normalized-effect-data-canonicalized-from-verified-payload-before-insert-and-immutable"
    - "stripe_event_effects:effect-fingerprint-32-bytes-and-effect-key-nonempty"
    - "stripe_event_effects:duplicate-effect-type-key-compares-fingerprint-exact-match-no-op-mismatch-rejects-and-audits-without-mutation"
    - "subscription_pre_consume_records:commercial-record-requires-32-byte-fingerprint-status-pending-committed-refunded-and-nonnull-bindings-legacy-record-requires-status-consumed-refunded"
    - "subscription_pre_consume_records:pre-consumed-and-amount-used-in-0-to-1000000000"
    - "subscription_pre_consume_records:legacy-status-preserves-native-consumed-refunded-default-and-commercial-writers-set-pending-explicitly"
    - "subscription_pre_consume_records:commercial-pending-has-no-terminal-time-commercial-terminal-states-have-finalized-at-and-refunded-has-refunded-at"
    - "tokens:commercial-key-requires-null-legacy-key-canonical-public-id-positive-version-and-32-byte-verifier"
    - "billing-and-quota-arithmetic:checked-before-bigint-multiplication-and-addition"
    - "logical_request_usages:usage-status-in-reported-estimated-unknown-cost-status-in-computed-estimated-not-billable-unknown-success-requires-known-usage-and-nonnull-known-cost-and-unknown-only-for-nonsuccess"
    - "commercial_audit_events:redacted-details-allowlisted-object-at-most-4096-bytes-and-forbids-raw-payloads-signatures-credentials-headers-prompts-responses-urls-upstream-errors"
  immutability_rules:
    - "billing-period-identity-bounds-plan-and-reset-version:database-trigger-reject-update-and-delete-while-status-changes-use-versioned-cas"
    - "billing-commands:database-trigger-reject-customer-command-type-idempotency-key-request-fingerprint-provider-idempotency-key-update-delete-and-terminal-result-rewrite-while-state-transitions-use-versioned-cas"
    - "channel-cost-profiles-and-rates:database-trigger-reject-economic-update-and-delete-allow-only-retired-at-null-to-nonnull"
    - "channel-health-transitions:database-trigger-reject-update-delete"
    - "channel-reliability-policies:database-trigger-reject-update-delete"
    - "commercial-audit-events:database-trigger-reject-update-delete"
    - "commercial-plan-versions-and-entitlements:database-trigger-reject-economic-or-entitlement-update-and-delete-allow-only-enabled-true-to-false-and-retired-at-null-to-nonnull"
    - "logical-request-usages:insert-final-once-database-trigger-reject-update-delete"
    - "terminal-channel-attempts:database-trigger-reject-terminal-rewrite-or-delete"
    - "terminal-stripe-event-effects:database-trigger-reject-update-delete"
    - "stripe-event-inbox:database-trigger-reject-provider-provider-event-id-account-mode-event-type-occurred-at-payload-hash-normalized-effect-data-update-or-delete"
  forward_order:
    - create-reference-version-ledger-and-recovery-tables
    - make-legacy-key-columns-nullable-and-replace-token-key-unique-index
    - add-alter-table-columns-with-nullable-or-safe-default-compatible-shapes
    - backfill-commercial-discriminators-false-and-native-reset-versions-zero
    - build-required-indexes-concurrently-outside-the-schema-transaction
    - add-not-valid-checks-and-restricting-foreign-keys
    - validate-checks-and-foreign-keys
    - deploy-compatible-writers-before-commercial-activation
tables:
  channels:
    action: alter
    purpose: retain the native routing owner while adding reference-only commercial configuration
    columns:
      id: {type: integer, nullable: false, default: "identity", primary_key: true}
      key: {type: text, nullable: true, default: "none"}
      commercial_channel: {type: boolean, nullable: false, default: "false"}
      secret_ref: {type: "varchar(255)", nullable: true, default: "none"}
      auth_type: {type: "varchar(32)", nullable: true, default: "none"}
      auth_header_name: {type: "varchar(128)", nullable: true, default: "none"}
      failure_domain: {type: "varchar(128)", nullable: true, default: "none"}
      reliability_policy_id: {type: bigint, nullable: true, default: "none"}
      active_cost_profile_id: {type: bigint, nullable: true, default: "none"}
      config_version: {type: bigint, nullable: false, default: "0"}
  subscription_pre_consume_records:
    action: alter
    purpose: remain the sole durable request-quota reservation and settlement owner
    columns:
      id: {type: integer, nullable: false, default: "identity", primary_key: true}
      request_id: {type: "varchar(64)", nullable: false, default: "none"}
      user_id: {type: integer, nullable: false, default: "none"}
      user_subscription_id: {type: integer, nullable: false, default: "none"}
      pre_consumed: {type: bigint, nullable: false, default: "0"}
      status: {type: "varchar(32)", nullable: false, default: "none"}
      commercial_record: {type: boolean, nullable: false, default: "false"}
      fingerprint_version: {type: smallint, nullable: true, default: "none"}
      fingerprint_digest: {type: bytea, nullable: true, default: "none"}
      quota_type: {type: "varchar(32)", nullable: true, default: "none"}
      model_alias: {type: "varchar(128)", nullable: true, default: "none"}
      endpoint_class: {type: "varchar(64)", nullable: true, default: "none"}
      plan_version_id: {type: bigint, nullable: true, default: "none"}
      billing_period_id: {type: bigint, nullable: true, default: "none"}
      reset_version: {type: bigint, nullable: false, default: "0"}
      hard_expires_at: {type: bigint, nullable: true, default: "none"}
      commit_fenced_at: {type: bigint, nullable: true, default: "none"}
      finalized_at: {type: bigint, nullable: true, default: "none"}
      refunded_at: {type: bigint, nullable: true, default: "none"}
      created_at: {type: bigint, nullable: false, default: "0"}
      updated_at: {type: bigint, nullable: false, default: "0"}
  tokens:
    action: alter
    purpose: add one-time-display commercial gateway keys without breaking non-commercial compatibility
    columns:
      id: {type: integer, nullable: false, default: "identity", primary_key: true}
      user_id: {type: integer, nullable: false, default: "none"}
      key: {type: "varchar(128)", nullable: true, default: "none"}
      gateway_public_id: {type: "varchar(64)", nullable: true, default: "none"}
      gateway_verifier_version: {type: smallint, nullable: true, default: "none"}
      gateway_verifier_digest: {type: bytea, nullable: true, default: "none"}
      commercial_key: {type: boolean, nullable: false, default: "false"}
  user_subscriptions:
    action: alter
    purpose: bind native quota totals to one immutable commercial plan and billing-period reset version
    columns:
      id: {type: integer, nullable: false, default: "identity", primary_key: true}
      user_id: {type: integer, nullable: false, default: "none"}
      plan_id: {type: integer, nullable: false, default: "none"}
      plan_version_id: {type: bigint, nullable: true, default: "none"}
      current_billing_period_id: {type: bigint, nullable: true, default: "none"}
      quota_reset_version: {type: bigint, nullable: false, default: "0"}
      amount_used: {type: bigint, nullable: false, default: "0"}
  billing_commands:
    action: create
    purpose: make outbound Stripe mutations durable and idempotent before provider calls
    columns:
      id: {type: bigint, nullable: false, default: "identity", primary_key: true}
      customer_id: {type: integer, nullable: false, default: "none"}
      command_type: {type: "varchar(64)", nullable: false, default: "none"}
      idempotency_key: {type: "varchar(128)", nullable: false, default: "none"}
      request_fingerprint: {type: bytea, nullable: false, default: "none"}
      provider_idempotency_key: {type: "varchar(128)", nullable: false, default: "none"}
      status: {type: "varchar(32)", nullable: false, default: "pending"}
      attempt_count: {type: integer, nullable: false, default: "0"}
      next_attempt_at: {type: timestamptz, nullable: true, default: "none"}
      provider_result_id: {type: "varchar(255)", nullable: true, default: "none"}
      error_class: {type: "varchar(64)", nullable: true, default: "none"}
      version: {type: bigint, nullable: false, default: "0"}
      created_at: {type: timestamptz, nullable: false, default: "now"}
      completed_at: {type: timestamptz, nullable: true, default: "none"}
  channel_attempts:
    action: create
    purpose: preserve one sanitized operator record for every upstream dispatch attempt
    columns:
      id: {type: bigint, nullable: false, default: "identity", primary_key: true}
      request_id: {type: "varchar(64)", nullable: false, default: "none"}
      attempt_index: {type: smallint, nullable: false, default: "none"}
      actor_type: {type: "varchar(16)", nullable: false, default: "customer"}
      customer_id: {type: integer, nullable: true, default: "none"}
      customer_key_id: {type: integer, nullable: true, default: "none"}
      channel_id: {type: integer, nullable: false, default: "none"}
      public_model_alias: {type: "varchar(128)", nullable: false, default: "none"}
      upstream_model: {type: "varchar(255)", nullable: false, default: "none"}
      endpoint_class: {type: "varchar(64)", nullable: false, default: "none"}
      status: {type: "varchar(32)", nullable: false, default: "pending"}
      outcome_class: {type: "varchar(64)", nullable: true, default: "none"}
      http_status: {type: integer, nullable: true, default: "none"}
      retry_reason: {type: "varchar(64)", nullable: true, default: "none"}
      latency_ms: {type: bigint, nullable: true, default: "none"}
      ttft_ms: {type: bigint, nullable: true, default: "none"}
      input_tokens: {type: bigint, nullable: true, default: "none"}
      output_tokens: {type: bigint, nullable: true, default: "none"}
      cost_profile_id: {type: bigint, nullable: true, default: "none"}
      cost_microusd: {type: bigint, nullable: true, default: "none"}
      cost_status: {type: "varchar(32)", nullable: false, default: "unknown"}
      downstream_committed: {type: boolean, nullable: false, default: "false"}
      started_at: {type: timestamptz, nullable: false, default: "now"}
      completed_at: {type: timestamptz, nullable: true, default: "none"}
  channel_cost_profiles:
    action: create
    purpose: retain immutable channel pricing and rounding versions
    columns:
      id: {type: bigint, nullable: false, default: "identity", primary_key: true}
      channel_id: {type: integer, nullable: false, default: "none"}
      version: {type: bigint, nullable: false, default: "none"}
      currency: {type: "char(3)", nullable: false, default: "USD"}
      rounding_rule: {type: "varchar(32)", nullable: false, default: "half-up-at-attempt-total"}
      effective_at: {type: timestamptz, nullable: false, default: "none"}
      retired_at: {type: timestamptz, nullable: true, default: "none"}
      created_at: {type: timestamptz, nullable: false, default: "now"}
  channel_cost_rates:
    action: create
    purpose: bind integer rate dimensions to one immutable channel cost profile
    columns:
      id: {type: bigint, nullable: false, default: "identity", primary_key: true}
      cost_profile_id: {type: bigint, nullable: false, default: "none"}
      endpoint_class: {type: "varchar(64)", nullable: false, default: "none"}
      public_model_alias: {type: "varchar(128)", nullable: false, default: "none"}
      upstream_model: {type: "varchar(255)", nullable: false, default: "none"}
      meter_dimension: {type: "varchar(64)", nullable: false, default: "none"}
      price_numerator: {type: bigint, nullable: false, default: "none"}
      unit_denominator: {type: bigint, nullable: false, default: "none"}
      created_at: {type: timestamptz, nullable: false, default: "now"}
  channel_health_transitions:
    action: create
    purpose: retain sanitized durable evidence of channel health state changes
    columns:
      id: {type: bigint, nullable: false, default: "identity", primary_key: true}
      event_id: {type: uuid, nullable: false, default: "generated"}
      channel_id: {type: integer, nullable: false, default: "none"}
      public_model_alias: {type: "varchar(128)", nullable: false, default: "none"}
      endpoint_class: {type: "varchar(64)", nullable: false, default: "none"}
      model_class: {type: "varchar(128)", nullable: false, default: "none"}
      config_version: {type: bigint, nullable: false, default: "none"}
      previous_state: {type: "varchar(32)", nullable: false, default: "none"}
      next_state: {type: "varchar(32)", nullable: false, default: "none"}
      reason_class: {type: "varchar(64)", nullable: false, default: "none"}
      sample_count: {type: integer, nullable: false, default: "0"}
      error_rate_bps: {type: integer, nullable: false, default: "0"}
      p95_first_event_ms: {type: bigint, nullable: false, default: "0"}
      created_at: {type: timestamptz, nullable: false, default: "now"}
  channel_reliability_policies:
    action: create
    purpose: version bounded timeout retry and health thresholds outside core routing logic
    columns:
      id: {type: bigint, nullable: false, default: "identity", primary_key: true}
      channel_id: {type: integer, nullable: false, default: "none"}
      version: {type: bigint, nullable: false, default: "none"}
      connect_timeout_ms: {type: integer, nullable: false, default: "none"}
      response_header_timeout_ms: {type: integer, nullable: false, default: "none"}
      first_semantic_event_timeout_ms: {type: integer, nullable: false, default: "none"}
      stream_idle_timeout_ms: {type: integer, nullable: false, default: "none"}
      stream_max_duration_ms: {type: integer, nullable: false, default: "none"}
      nonstream_total_timeout_ms: {type: integer, nullable: false, default: "none"}
      logical_precommit_deadline_ms: {type: integer, nullable: false, default: "none"}
      max_precommit_buffer_bytes: {type: integer, nullable: false, default: "none"}
      max_stream_bytes: {type: integer, nullable: false, default: "none"}
      max_response_bytes: {type: integer, nullable: false, default: "none"}
      retryable_statuses: {type: "integer[]", nullable: false, default: "empty-array"}
      window_seconds: {type: integer, nullable: false, default: "none"}
      bucket_seconds: {type: integer, nullable: false, default: "none"}
      degraded_error_rate_bps: {type: integer, nullable: false, default: "none"}
      open_error_rate_bps: {type: integer, nullable: false, default: "none"}
      degraded_p95_ms: {type: integer, nullable: false, default: "none"}
      recovery_p95_ms: {type: integer, nullable: false, default: "none"}
      minimum_samples: {type: integer, nullable: false, default: "none"}
      consecutive_failure_limit: {type: integer, nullable: false, default: "none"}
      cooldown_seconds: {type: integer, nullable: false, default: "none"}
      recovery_successes: {type: integer, nullable: false, default: "none"}
      latency_bucket_bounds_ms: {type: "integer[]", nullable: false, default: "empty-array"}
      created_at: {type: timestamptz, nullable: false, default: "now"}
  commercial_access_projections:
    action: create
    purpose: authorize each commercial gateway key from server-owned subscription state
    columns:
      id: {type: bigint, nullable: false, default: "identity", primary_key: true}
      customer_id: {type: integer, nullable: false, default: "none"}
      token_id: {type: integer, nullable: false, default: "none"}
      user_subscription_id: {type: integer, nullable: false, default: "none"}
      plan_version_id: {type: bigint, nullable: false, default: "none"}
      billing_period_id: {type: bigint, nullable: false, default: "none"}
      reset_version: {type: bigint, nullable: false, default: "none"}
      provider_customer_id: {type: "varchar(255)", nullable: false, default: "none"}
      provider_subscription_id: {type: "varchar(255)", nullable: false, default: "none"}
      status: {type: "varchar(32)", nullable: false, default: "none"}
      expires_at: {type: timestamptz, nullable: true, default: "none"}
      last_event_occurred_at: {type: timestamptz, nullable: true, default: "none"}
      version: {type: bigint, nullable: false, default: "1"}
      updated_at: {type: timestamptz, nullable: false, default: "now"}
  commercial_audit_events:
    action: create
    purpose: preserve append-only actor-attributed security billing and quota mutations
    columns:
      id: {type: bigint, nullable: false, default: "identity", primary_key: true}
      event_id: {type: uuid, nullable: false, default: "generated"}
      actor_type: {type: "varchar(32)", nullable: false, default: "none"}
      actor_id: {type: "varchar(128)", nullable: false, default: "none"}
      action: {type: "varchar(64)", nullable: false, default: "none"}
      object_type: {type: "varchar(64)", nullable: false, default: "none"}
      object_id: {type: "varchar(128)", nullable: false, default: "none"}
      object_version: {type: bigint, nullable: false, default: "none"}
      idempotency_key: {type: "varchar(128)", nullable: true, default: "none"}
      correlation_id: {type: "varchar(64)", nullable: false, default: "none"}
      result: {type: "varchar(32)", nullable: false, default: "none"}
      redacted_details: {type: jsonb, nullable: false, default: "empty-object"}
      created_at: {type: timestamptz, nullable: false, default: "now"}
  commercial_billing_periods:
    action: create
    purpose: pin provider period boundaries and one monotonic quota reset version
    columns:
      id: {type: bigint, nullable: false, default: "identity", primary_key: true}
      user_subscription_id: {type: integer, nullable: false, default: "none"}
      plan_version_id: {type: bigint, nullable: false, default: "none"}
      provider: {type: "varchar(32)", nullable: false, default: "stripe"}
      provider_subscription_id: {type: "varchar(255)", nullable: false, default: "none"}
      period_start: {type: timestamptz, nullable: false, default: "none"}
      period_end: {type: timestamptz, nullable: false, default: "none"}
      reset_version: {type: bigint, nullable: false, default: "none"}
      status: {type: "varchar(32)", nullable: false, default: "none"}
      created_at: {type: timestamptz, nullable: false, default: "now"}
  commercial_plan_entitlements:
    action: create
    purpose: bind explicit model reasoning-effort and image permissions to an immutable plan version
    columns:
      id: {type: bigint, nullable: false, default: "identity", primary_key: true}
      plan_version_id: {type: bigint, nullable: false, default: "none"}
      model_alias: {type: "varchar(128)", nullable: false, default: "none"}
      reasoning_effort: {type: "varchar(32)", nullable: false, default: "none"}
      image_allowed: {type: boolean, nullable: false, default: "false"}
      created_at: {type: timestamptz, nullable: false, default: "now"}
  commercial_plan_versions:
    action: create
    purpose: preserve immutable commercial price cycle quota and concurrency decisions
    columns:
      id: {type: bigint, nullable: false, default: "identity", primary_key: true}
      plan_id: {type: integer, nullable: false, default: "none"}
      version: {type: bigint, nullable: false, default: "none"}
      code: {type: "varchar(64)", nullable: false, default: "none"}
      display_name: {type: "varchar(128)", nullable: false, default: "none"}
      currency: {type: "char(3)", nullable: false, default: "USD"}
      price_microusd: {type: bigint, nullable: false, default: "none"}
      billing_cycle: {type: "varchar(32)", nullable: false, default: "none"}
      request_quota: {type: bigint, nullable: true, default: "none"}
      token_quota: {type: bigint, nullable: true, default: "none"}
      concurrency_limit: {type: integer, nullable: false, default: "none"}
      image_hour_limit: {type: integer, nullable: true, default: "none"}
      default_model_alias: {type: "varchar(128)", nullable: false, default: "none"}
      default_reasoning_effort: {type: "varchar(32)", nullable: false, default: "none"}
      enabled: {type: boolean, nullable: false, default: "false"}
      effective_at: {type: timestamptz, nullable: false, default: "none"}
      retired_at: {type: timestamptz, nullable: true, default: "none"}
      created_at: {type: timestamptz, nullable: false, default: "now"}
  enforcement_epochs:
    action: create
    purpose: fence Redis admission state behind one PostgreSQL recovery authority
    columns:
      singleton_id: {type: smallint, nullable: false, default: "1", primary_key: true}
      epoch: {type: bigint, nullable: false, default: "1"}
      state: {type: "varchar(16)", nullable: false, default: "closed"}
      drain_started_at: {type: timestamptz, nullable: true, default: "none"}
      activated_at: {type: timestamptz, nullable: true, default: "none"}
      version: {type: bigint, nullable: false, default: "1"}
      updated_at: {type: timestamptz, nullable: false, default: "now"}
  logical_request_usages:
    action: create
    purpose: retain exactly one final customer usage delivery and cost result per logical request
    columns:
      id: {type: bigint, nullable: false, default: "identity", primary_key: true}
      request_id: {type: "varchar(64)", nullable: false, default: "none"}
      customer_id: {type: integer, nullable: false, default: "none"}
      customer_key_id: {type: integer, nullable: false, default: "none"}
      user_subscription_id: {type: integer, nullable: false, default: "none"}
      plan_version_id: {type: bigint, nullable: false, default: "none"}
      billing_period_id: {type: bigint, nullable: false, default: "none"}
      reset_version: {type: bigint, nullable: false, default: "none"}
      public_model_alias: {type: "varchar(128)", nullable: false, default: "none"}
      failed_channel_ids: {type: "integer[]", nullable: false, default: "empty-array"}
      successful_channel_id: {type: integer, nullable: true, default: "none"}
      input_tokens: {type: bigint, nullable: false, default: "0"}
      output_tokens: {type: bigint, nullable: false, default: "0"}
      usage_status: {type: "varchar(32)", nullable: false, default: "unknown"}
      request_units: {type: integer, nullable: false, default: "1"}
      image_units: {type: integer, nullable: false, default: "0"}
      quota_delta: {type: bigint, nullable: false, default: "0"}
      customer_charge_microusd: {type: bigint, nullable: true, default: "none"}
      latency_ms: {type: bigint, nullable: false, default: "0"}
      hard_expires_at: {type: timestamptz, nullable: false, default: "none"}
      state: {type: "varchar(32)", nullable: false, default: "final"}
      commit_fenced_at: {type: timestamptz, nullable: true, default: "none"}
      first_write_succeeded_at: {type: timestamptz, nullable: true, default: "none"}
      delivery_status: {type: "varchar(32)", nullable: false, default: "none"}
      final_status: {type: "varchar(32)", nullable: false, default: "none"}
      error_class: {type: "varchar(64)", nullable: true, default: "none"}
      cost_profile_id: {type: bigint, nullable: true, default: "none"}
      estimated_cost_microusd: {type: bigint, nullable: true, default: "none"}
      cost_status: {type: "varchar(32)", nullable: false, default: "unknown"}
      created_at: {type: timestamptz, nullable: false, default: "now"}
      finalized_at: {type: timestamptz, nullable: false, default: "none"}
  stripe_event_effects:
    action: create
    purpose: apply each verified Stripe event effect once inside the owning transaction
    columns:
      id: {type: bigint, nullable: false, default: "identity", primary_key: true}
      stripe_event_inbox_id: {type: bigint, nullable: false, default: "none"}
      effect_type: {type: "varchar(64)", nullable: false, default: "none"}
      effect_key: {type: "varchar(255)", nullable: false, default: "none"}
      effect_fingerprint: {type: bytea, nullable: false, default: "none"}
      object_type: {type: "varchar(64)", nullable: false, default: "none"}
      object_id: {type: "varchar(128)", nullable: false, default: "none"}
      applied_at: {type: timestamptz, nullable: false, default: "now"}
  stripe_event_inbox:
    action: create
    purpose: deduplicate verified Stripe events without retaining raw secret-bearing payloads
    columns:
      id: {type: bigint, nullable: false, default: "identity", primary_key: true}
      provider: {type: "varchar(32)", nullable: false, default: "stripe"}
      provider_event_id: {type: "varchar(255)", nullable: false, default: "none"}
      provider_account_id: {type: "varchar(255)", nullable: false, default: "none"}
      livemode: {type: boolean, nullable: false, default: "none"}
      event_type: {type: "varchar(128)", nullable: false, default: "none"}
      payload_hash: {type: bytea, nullable: false, default: "none"}
      normalized_effect_data: {type: jsonb, nullable: true, default: "none"}
      occurred_at: {type: timestamptz, nullable: false, default: "none"}
      received_at: {type: timestamptz, nullable: false, default: "now"}
      status: {type: "varchar(32)", nullable: false, default: "received"}
      processing_owner: {type: uuid, nullable: true, default: "none"}
      processing_lease_expires_at: {type: timestamptz, nullable: true, default: "none"}
      version: {type: bigint, nullable: false, default: "0"}
      processed_at: {type: timestamptz, nullable: true, default: "none"}
      error_class: {type: "varchar(64)", nullable: true, default: "none"}
quota:
  sole_reservation_owner: subscription_pre_consume_records
  states:
    - pending
    - committed
    - refunded
  transitions:
    - pending->committed
    - pending->refunded
  fingerprint_binding:
    - version
    - digest
    - quota_type
    - model_alias
    - endpoint_class
  period_binding:
    - user_subscription_id
    - plan_version_id
    - billing_period_id
    - reset_version
  reservation_transaction: lock-exact-bound-subscription-and-reserve-once-in-one-transaction
  settlement_cas: compare-and-set-pending-to-one-terminal-state
  settlement_transaction: terminal-cas-and-period-conditional-native-usage-update-in-one-postgresql-transaction
  refund_period_rule: decrement-current-usage-only-when-stored-period-and-reset-version-still-match
  commit_fence_rule: commit-before-first-customer-write-and-never-refund-delivery-uncertain
billing:
  inbox_states:
    - received
    - processing
    - applied
    - ignored
    - rejected
    - deferred
    - failed-retryable
  processing_ownership: versioned-compare-and-set-owner-with-lease-compared-to-postgresql-transaction-time
  recovery_data: bounded-validated-normalized-effect-fields-plus-exact-payload-hash
  normalized_effect_fields:
    - provider_object_id
    - internal_customer_id
    - internal_subscription_id
    - plan_version_id
    - billing_period_start
    - billing_period_end
    - provider_status
    - cancel_at_period_end
    - billing_command_id
  normalized_effect_max_bytes: 16384
  effect_transaction: inbox-terminal-state-effect-access-period-quota-and-audit-in-one-postgresql-transaction
  logical_effect_uniqueness: effect-type-and-server-derived-logical-effect-key
  effect_fingerprint_binding: sha-256-of-canonical-effect-type-key-object-and-verified-normalized-effect-data
  effect_replay_policy: exact-type-key-and-fingerprint-no-op-mismatch-rejects-audits-without-mutation
compatibility:
  token_legacy_key: nullable-with-partial-unique-index-where-key-is-not-null
  commercial_token_check: commercial_key-requires-null-key-and-nonnull-public-id-version-and-32-byte-verifier
  channel_legacy_key: nullable-and-forbidden-for-commercial-active-channels
  commercial_channel_check: commercial_channel-requires-null-key-and-nonnull-secret-ref-auth-type-policy-cost-profile-and-positive-config-version
security:
  gateway_key_verifier: versioned-hmac-sha-256-with-pepper
  legacy_plaintext_compatibility: non-commercial-mode-only-until-separate-retirement
  channel_secret_storage: validated-reference-only-never-resolved-secret
  durable_error_storage: sanitized-classification-only
  stripe_payload_storage: bounded-normalized-effect-fields-and-payload-hash-only
  audit_detail_fields:
    - reason_class
    - previous_status
    - next_status
    - plan_version_id
    - billing_period_id
    - reset_version
    - request_id
    - provider_event_id_hash
    - command_id
  audit_detail_max_bytes: 4096
recovery:
  epoch_states:
    - closed
    - draining
    - active
  admission_policy: fail-closed-unless-postgresql-and-redis-epochs-match-active
  activation_sequence:
    - close-admission
    - drain-for-maximum-request-and-lease-ttl
    - compare-and-set-increment-postgresql-epoch
    - initialize-redis-at-new-epoch
    - compare-and-set-activate-postgresql-epoch
retention:
  no_automatic_deletion:
    - billing_commands
    - channel_attempts
    - channel_cost_profiles
    - channel_cost_rates
    - commercial_access_projections
    - commercial_audit_events
    - commercial_billing_periods
    - commercial_plan_entitlements
    - commercial_plan_versions
    - logical_request_usages
    - stripe_event_effects
    - stripe_event_inbox
    - subscription_pre_consume_records
  health_transition_minimum_days: 90
  pending_reservation_rule: retain-until-terminal-and-never-delete-pending-or-delivery-uncertain
  commercial_reservation_predicate: commercial_record-equals-true
  legacy_cleanup_policy: age-cleanup-may-delete-only-commercial_record-equals-false
rollback:
  pre_activation: physical-revert-allowed-only-before-commercial-activation-and-after-empty-state-proof
  post_activation: disable-commercial-writes-and-preserve-schema-and-data
  physical_cleanup: separate-explicitly-approved-destructive-migration
  preserve:
    - audit
    - billing
    - quota
    - usage
    - attempt
sql:
  executable: forbidden-in-step-0.4
  destructive: forbidden-without-separate-scoped-approval
---

# Commercial MVP PostgreSQL Foundation Contract

## Status and boundary

This document defines the desired Step 0.4 database contract. It is not a migration and does not
authorize a database operation. The YAML frontmatter is normative; this prose explains it in
plain language.

PostgreSQL is the only required commercial deployment database. MySQL and SQLite parity are not
part of this step. Migration code begins only after the database and security reviews approve this
contract.

## Forward behavior

The native token, channel, subscription, and pre-consume tables remain their existing owners. The
commercial additions narrow those owners instead of creating a parallel gateway, channel store, or
quota system.

Commercial gateway keys store a public identifier and a versioned HMAC verifier derived with the
deployment pepper. Their raw secret is returned once and is not stored. The inherited plaintext
token key column remains temporarily for non-commercial compatibility only. Commercial reads,
writes, searches, exports, and logs must not use it.
Owner columns retained for audit and authorization are also relationally bound: composite keys
tie each token and subscription to its owning user, so a valid identifier from another customer
cannot be combined into an access, reservation, attempt, or usage row.

Channel rows store a validated secret reference and typed authentication configuration. The
inherited plaintext channel key column also remains only for non-commercial compatibility until a
later reader inventory permits retirement. A commercial row never stores a resolved secret.
Cost profiles and reliability policies are versioned by channel with composite ownership keys.
Channel pointers and every attempt/final-usage cost reference must match the channel ID, so one
channel cannot select or record another channel's economic or retry policy.

Plan economic/default fields, entitlements, reliability policies, and cost rates are immutable
after activation. Audited retirement may only disable a plan and set its retirement time, or set a
cost profile's retirement time; it does not rewrite facts already referenced by a subscription,
attempt, or usage row. Currency and cost calculations use bounded integers, never binary floating
point. Plan prices, quota totals, reservations, meters, rates, and stored costs are bounded to
0..1,000,000,000; request usage is exactly one unit, and application arithmetic checks bounds
before bigint multiplication or addition.

Stripe events are verified before entering the inbox. The inbox retains bounded identifiers,
validated allowlisted effect fields, and a payload hash, not the raw signed request or signature.
A versioned compare-and-set owner resumes the same inbox row and compares lease expiry against
PostgreSQL transaction time. Normalized recovery data is an allowlisted JSON object capped at 16
KiB. That normalized effect data is canonicalized from the verified payload before insertion and
is immutable with the event identity. Event effects are also unique by a server-derived logical
effect key, so different Stripe event types cannot apply the same billing-period reset twice. An
effect fingerprint binds the canonical effect type, key, object, and verified normalized data;
an exact effect replay is a no-op, while reuse with another fingerprint rejects and audits without
mutation. Each outbound billing command has a separate uniqueness boundary, so retries cannot
issue a provider command twice. Command identity, request fingerprint, and provider idempotency
key are immutable after insertion. Status transitions use a versioned compare-and-set, deletion
is rejected, and a terminal provider result cannot be rewritten. An exact event replay must match
provider, provider event ID, provider account, live/test mode, event type, occurrence time, and
payload hash. Any mismatch is rejected and audited without mutation, and every field in that
replay identity is immutable. Provider idempotency keys are non-empty, unique, server-derived from
the command ID, and a reused logical key with a different request fingerprint conflicts.

## Quota and delivery behavior

`subscription_pre_consume_records` is the only request-quota reservation owner. The older
`customer_usage_reservations` proposal is intentionally forbidden for this MVP.

Reservation, the exact subscription row lock, its current plan and billing-period validation, and
the one-unit native usage increment occur in one PostgreSQL transaction. Composite foreign keys
bind the subscription, billing period, reset version, and plan version as one tuple. Reuse of a
request ID is accepted only when its versioned fingerprint and all bindings match the stored row.

Commercial rows use pending, committed, and refunded; legacy non-commercial rows retain their
existing consumed/refunded states and native no-default behavior. Commercial writers set pending
explicitly. Commercial settlement is one PostgreSQL transaction containing
both the compare-and-set transition and any period-conditional native usage update. Commit happens
durably before the first customer write. A write failure after that fence is delivery-uncertain and
stays consumed. A refund changes current native usage only when the stored billing period and reset
version still match; a late old-period result closes its reservation and audit record without
changing the new period's usage.

Every upstream dispatch has an attempt identity inserted before network I/O and one terminal
compare-and-set update. Attempt rows retain bounded HTTP status, outcome, latency, and time-to-first
semantic-event evidence. Customer attempts bind to a real customer and key; operator-funded
synthetic recovery probes use a system actor and null customer ownership, never fake tenant rows.
Exactly one final logical usage row records the customer result and carries the immutable plan,
billing-period, reset-version, state, image-unit, quota-delta, charge, and hard-expiry identity
used for settlement. Its cost reference is composite-bound to the successful channel. Raw upstream
errors, headers, URLs, and credentials are never durable fields. Explicit usage and cost statuses
distinguish genuine zero meters or zero cost from unavailable data. A successful result requires
reported or estimated usage plus a known, non-null cost result; `unknown` usage or cost is allowed
only for a non-successful result.

The final usage row is bound by request ID to the one native pre-consume reservation. A successful
row must carry both its successful channel and cost profile; a non-successful row must carry
neither, so nullable composite keys cannot bypass attempt reconciliation. Access projection
updates use a monotonic versioned compare-and-set against the stored provider-event occurrence
watermark and reject stale event status changes.

Commercial audit details are a JSON object capped at 4 KiB and restricted to the frontmatter's
field allowlist. They never contain raw provider payloads, signatures, credentials, headers,
prompts, responses, URLs, or upstream errors.

## Epoch recovery

Protected admission is open only when PostgreSQL says the epoch is active and Redis holds that
same epoch. Recovery closes admission, drains for the configured maximum request and lease TTL,
increments the PostgreSQL epoch by compare-and-set, initializes Redis at that epoch, and then
activates it by compare-and-set. Missing, empty, stale, or indeterminate state rejects new work.

This private single-replica process does not claim transparent reconstruction of live leases or
image admissions.

## Rollback and retention

Before commercial activation, a later executable migration may define a physical rollback only
after proving that all new commercial tables are empty and no commercial key or channel row uses
the new columns.

After any commercial write, rollback is operational: disable Checkout and new key issuance, close
admission, and return to the prior compatible application image while retaining the schema and
all billing, audit, quota, attempt, and usage evidence. Physical cleanup then requires a separate
destructive migration with exact targets, backup evidence, and explicit scoped approval.

The existing seven-day reservation cleanup must not delete commercial reservation rows. Pending
or delivery-uncertain rows are never age-deleted. Immutable commercial facts listed in the
frontmatter have no automatic deletion in the MVP; sanitized health transitions remain available
for at least ninety days.

## Required proof before migration code

The database review must approve table ownership, PostgreSQL transaction boundaries, compare-and-
set transitions, indexes, uniqueness, period-safe refunds, retention, recovery, and rollback. The
security review must approve verifier storage, secret references, Stripe metadata, redaction, and
fail-closed recovery. Any blocker returns to a focused failing contract check; minor hardening
findings are recorded without broadening this step.
