package migrations_test

import (
	"bytes"
	"io"
	"os"
	"regexp"
	"sort"
	"testing"

	"github.com/stretchr/testify/require"
	"gopkg.in/yaml.v3"
)

const foundationContract = "2026-08-02-commercial-mvp-foundation.md"

type migrationContract struct {
	ContractVersion      int                      `yaml:"contract_version"`
	Dialect              string                   `yaml:"dialect"`
	ImplementationStatus string                   `yaml:"implementation_status"`
	NormativeAuthority   string                   `yaml:"normative_authority"`
	Schema               schema                   `yaml:"schema"`
	Tables               map[string]tableContract `yaml:"tables"`
	Quota                quota                    `yaml:"quota"`
	Billing              billing                  `yaml:"billing"`
	Compatibility        compatibility            `yaml:"compatibility"`
	Security             security                 `yaml:"security"`
	Recovery             recovery                 `yaml:"recovery"`
	Retention            retention                `yaml:"retention"`
	Rollback             rollback                 `yaml:"rollback"`
	SQL                  sqlPolicy                `yaml:"sql"`
}

type tableContract struct {
	Action  string                    `yaml:"action"`
	Purpose string                    `yaml:"purpose"`
	Columns map[string]columnContract `yaml:"columns"`
}

type columnContract struct {
	Type       string `yaml:"type"`
	Nullable   bool   `yaml:"nullable"`
	Default    string `yaml:"default"`
	PrimaryKey bool   `yaml:"primary_key"`
}

type schema struct {
	AlteredTables       []string `yaml:"altered_tables"`
	NewTables           []string `yaml:"new_tables"`
	ForbiddenTables     []string `yaml:"forbidden_tables"`
	RequiredUniqueness  []string `yaml:"required_uniqueness"`
	RequiredIndexes     []string `yaml:"required_indexes"`
	RequiredForeignKeys []string `yaml:"required_foreign_keys"`
	RequiredChecks      []string `yaml:"required_checks"`
	ImmutabilityRules   []string `yaml:"immutability_rules"`
	ForwardOrder        []string `yaml:"forward_order"`
}

type quota struct {
	SoleReservationOwner   string   `yaml:"sole_reservation_owner"`
	States                 []string `yaml:"states"`
	Transitions            []string `yaml:"transitions"`
	FingerprintBinding     []string `yaml:"fingerprint_binding"`
	PeriodBinding          []string `yaml:"period_binding"`
	ReservationTransaction string   `yaml:"reservation_transaction"`
	SettlementCAS          string   `yaml:"settlement_cas"`
	SettlementTransaction  string   `yaml:"settlement_transaction"`
	RefundPeriodRule       string   `yaml:"refund_period_rule"`
	CommitFenceRule        string   `yaml:"commit_fence_rule"`
}

type billing struct {
	InboxStates              []string `yaml:"inbox_states"`
	ProcessingOwnership      string   `yaml:"processing_ownership"`
	RecoveryData             string   `yaml:"recovery_data"`
	NormalizedEffectFields   []string `yaml:"normalized_effect_fields"`
	NormalizedEffectMaxBytes int      `yaml:"normalized_effect_max_bytes"`
	EffectTransaction        string   `yaml:"effect_transaction"`
	LogicalEffectUniqueness  string   `yaml:"logical_effect_uniqueness"`
	EffectFingerprintBinding string   `yaml:"effect_fingerprint_binding"`
	EffectReplayPolicy       string   `yaml:"effect_replay_policy"`
}

type compatibility struct {
	TokenLegacyKey         string `yaml:"token_legacy_key"`
	CommercialTokenCheck   string `yaml:"commercial_token_check"`
	ChannelLegacyKey       string `yaml:"channel_legacy_key"`
	CommercialChannelCheck string `yaml:"commercial_channel_check"`
}

type security struct {
	GatewayKeyVerifier           string   `yaml:"gateway_key_verifier"`
	LegacyPlaintextCompatibility string   `yaml:"legacy_plaintext_compatibility"`
	ChannelSecretStorage         string   `yaml:"channel_secret_storage"`
	DurableErrorStorage          string   `yaml:"durable_error_storage"`
	StripePayloadStorage         string   `yaml:"stripe_payload_storage"`
	AuditDetailFields            []string `yaml:"audit_detail_fields"`
	AuditDetailMaxBytes          int      `yaml:"audit_detail_max_bytes"`
}

type recovery struct {
	EpochStates        []string `yaml:"epoch_states"`
	AdmissionPolicy    string   `yaml:"admission_policy"`
	ActivationSequence []string `yaml:"activation_sequence"`
}

type retention struct {
	NoAutomaticDeletion            []string `yaml:"no_automatic_deletion"`
	HealthTransitionMinimumDays    int      `yaml:"health_transition_minimum_days"`
	PendingReservationRule         string   `yaml:"pending_reservation_rule"`
	CommercialReservationPredicate string   `yaml:"commercial_reservation_predicate"`
	LegacyCleanupPolicy            string   `yaml:"legacy_cleanup_policy"`
}

type rollback struct {
	PreActivation   string   `yaml:"pre_activation"`
	PostActivation  string   `yaml:"post_activation"`
	PhysicalCleanup string   `yaml:"physical_cleanup"`
	Preserve        []string `yaml:"preserve"`
}

type sqlPolicy struct {
	Executable  string `yaml:"executable"`
	Destructive string `yaml:"destructive"`
}

func TestCommercialMVPFoundationMigrationContract(t *testing.T) {
	contract := readMigrationContract(t)

	require.Equal(t, 1, contract.ContractVersion)
	require.Equal(t, "postgresql", contract.Dialect)
	require.Equal(t, "desired-contract-only", contract.ImplementationStatus)
	require.Equal(t, "structured-frontmatter-only", contract.NormativeAuthority)

	require.ElementsMatch(t, []string{
		"channels",
		"subscription_pre_consume_records",
		"tokens",
		"user_subscriptions",
	}, contract.Schema.AlteredTables)
	require.ElementsMatch(t, []string{
		"billing_commands",
		"channel_attempts",
		"channel_cost_profiles",
		"channel_cost_rates",
		"channel_health_transitions",
		"channel_reliability_policies",
		"commercial_access_projections",
		"commercial_audit_events",
		"commercial_billing_periods",
		"commercial_plan_entitlements",
		"commercial_plan_versions",
		"enforcement_epochs",
		"logical_request_usages",
		"stripe_event_effects",
		"stripe_event_inbox",
	}, contract.Schema.NewTables)
	require.Equal(t, []string{"customer_usage_reservations"}, contract.Schema.ForbiddenTables)
	allTables := append(append([]string{}, contract.Schema.AlteredTables...), contract.Schema.NewTables...)
	requireNoDuplicateNames(t, allTables)
	require.ElementsMatch(t, allTables, sortedMapKeys(contract.Tables))
	for _, name := range contract.Schema.AlteredTables {
		require.Equal(t, "alter", contract.Tables[name].Action, name)
		require.NotEmpty(t, contract.Tables[name].Purpose, name)
		require.NotEmpty(t, contract.Tables[name].Columns, name)
	}
	for _, name := range contract.Schema.NewTables {
		require.Equal(t, "create", contract.Tables[name].Action, name)
		require.NotEmpty(t, contract.Tables[name].Purpose, name)
		require.NotEmpty(t, contract.Tables[name].Columns, name)
	}
	require.ElementsMatch(t, []string{"id", "user_id", "key", "gateway_public_id", "gateway_verifier_version", "gateway_verifier_digest", "commercial_key"}, columnNames(contract.Tables["tokens"]))
	require.ElementsMatch(t, []string{"id", "key", "commercial_channel", "secret_ref", "auth_type", "auth_header_name", "failure_domain", "reliability_policy_id", "active_cost_profile_id", "config_version"}, columnNames(contract.Tables["channels"]))
	require.ElementsMatch(t, []string{"id", "user_id", "plan_id", "plan_version_id", "current_billing_period_id", "quota_reset_version", "amount_used"}, columnNames(contract.Tables["user_subscriptions"]))
	require.ElementsMatch(t, []string{
		"id", "request_id", "user_id", "user_subscription_id", "pre_consumed", "status",
		"commercial_record",
		"fingerprint_version", "fingerprint_digest", "quota_type", "model_alias", "endpoint_class",
		"plan_version_id", "billing_period_id", "reset_version", "hard_expires_at",
		"commit_fenced_at", "finalized_at", "refunded_at", "created_at", "updated_at",
	}, columnNames(contract.Tables["subscription_pre_consume_records"]))

	require.Equal(t, "subscription_pre_consume_records", contract.Quota.SoleReservationOwner)
	require.ElementsMatch(t, []string{"pending", "committed", "refunded"}, contract.Quota.States)
	require.ElementsMatch(t, []string{"pending->committed", "pending->refunded"}, contract.Quota.Transitions)
	require.ElementsMatch(t, []string{"version", "digest", "quota_type", "model_alias", "endpoint_class"}, contract.Quota.FingerprintBinding)
	require.ElementsMatch(t, []string{"user_subscription_id", "plan_version_id", "billing_period_id", "reset_version"}, contract.Quota.PeriodBinding)
	require.Equal(t, "lock-exact-bound-subscription-and-reserve-once-in-one-transaction", contract.Quota.ReservationTransaction)
	require.Equal(t, "compare-and-set-pending-to-one-terminal-state", contract.Quota.SettlementCAS)
	require.Equal(t, "terminal-cas-and-period-conditional-native-usage-update-in-one-postgresql-transaction", contract.Quota.SettlementTransaction)
	require.Equal(t, "decrement-current-usage-only-when-stored-period-and-reset-version-still-match", contract.Quota.RefundPeriodRule)
	require.Equal(t, "commit-before-first-customer-write-and-never-refund-delivery-uncertain", contract.Quota.CommitFenceRule)

	require.Equal(t, "versioned-hmac-sha-256-with-pepper", contract.Security.GatewayKeyVerifier)
	require.Equal(t, "non-commercial-mode-only-until-separate-retirement", contract.Security.LegacyPlaintextCompatibility)
	require.Equal(t, "validated-reference-only-never-resolved-secret", contract.Security.ChannelSecretStorage)
	require.Equal(t, "sanitized-classification-only", contract.Security.DurableErrorStorage)
	require.Equal(t, "bounded-normalized-effect-fields-and-payload-hash-only", contract.Security.StripePayloadStorage)

	require.ElementsMatch(t, []string{"closed", "draining", "active"}, contract.Recovery.EpochStates)
	require.Equal(t, "fail-closed-unless-postgresql-and-redis-epochs-match-active", contract.Recovery.AdmissionPolicy)
	require.Equal(t, []string{
		"close-admission",
		"drain-for-maximum-request-and-lease-ttl",
		"compare-and-set-increment-postgresql-epoch",
		"initialize-redis-at-new-epoch",
		"compare-and-set-activate-postgresql-epoch",
	}, contract.Recovery.ActivationSequence)

	require.ElementsMatch(t, []string{
		"billing_commands",
		"channel_attempts",
		"channel_cost_profiles",
		"channel_cost_rates",
		"commercial_access_projections",
		"commercial_audit_events",
		"commercial_billing_periods",
		"commercial_plan_entitlements",
		"commercial_plan_versions",
		"logical_request_usages",
		"stripe_event_effects",
		"stripe_event_inbox",
		"subscription_pre_consume_records",
	}, contract.Retention.NoAutomaticDeletion)
	require.GreaterOrEqual(t, contract.Retention.HealthTransitionMinimumDays, 90)
	require.Equal(t, "retain-until-terminal-and-never-delete-pending-or-delivery-uncertain", contract.Retention.PendingReservationRule)
	require.Equal(t, "commercial_record-equals-true", contract.Retention.CommercialReservationPredicate)
	require.Equal(t, "age-cleanup-may-delete-only-commercial_record-equals-false", contract.Retention.LegacyCleanupPolicy)

	require.Equal(t, "physical-revert-allowed-only-before-commercial-activation-and-after-empty-state-proof", contract.Rollback.PreActivation)
	require.Equal(t, "disable-commercial-writes-and-preserve-schema-and-data", contract.Rollback.PostActivation)
	require.Equal(t, "separate-explicitly-approved-destructive-migration", contract.Rollback.PhysicalCleanup)
	require.ElementsMatch(t, []string{"audit", "billing", "quota", "usage", "attempt"}, contract.Rollback.Preserve)
	require.Equal(t, "forbidden-in-step-0.4", contract.SQL.Executable)
	require.Equal(t, "forbidden-without-separate-scoped-approval", contract.SQL.Destructive)
}

func TestFoundationMigrationContractPinsRequiredIndexes(t *testing.T) {
	contract := readMigrationContract(t)
	require.ElementsMatch(t, []string{
		"billing_commands(customer_id,command_type,idempotency_key)",
		"billing_commands(provider_idempotency_key)",
		"channel_attempts(request_id,attempt_index)",
		"channel_cost_profiles(channel_id,id)",
		"channel_cost_profiles(channel_id,version)",
		"channel_cost_rates(cost_profile_id,endpoint_class,public_model_alias,upstream_model,meter_dimension)",
		"channel_health_transitions(event_id)",
		"channel_reliability_policies(channel_id,id)",
		"channel_reliability_policies(channel_id,version)",
		"commercial_access_projections(token_id)",
		"commercial_audit_events(event_id)",
		"commercial_billing_periods(provider,provider_subscription_id,period_start,period_end)",
		"commercial_billing_periods(user_subscription_id,id,reset_version,plan_version_id)",
		"commercial_billing_periods(user_subscription_id,reset_version)",
		"commercial_plan_entitlements(plan_version_id,model_alias,reasoning_effort)",
		"commercial_plan_versions(plan_id,version)",
		"enforcement_epochs(singleton_id)",
		"logical_request_usages(request_id)",
		"stripe_event_effects(stripe_event_inbox_id,effect_type)",
		"stripe_event_effects(effect_type,effect_key)",
		"stripe_event_inbox(provider,provider_event_id)",
		"subscription_pre_consume_records(request_id)",
		"tokens(gateway_public_id)",
		"tokens(gateway_verifier_digest)",
		"tokens(id,user_id)",
		"tokens(key) where key is not null",
		"user_subscriptions(id,user_id)",
	}, contract.Schema.RequiredUniqueness)
	require.ElementsMatch(t, []string{
		"billing_commands(status,next_attempt_at)",
		"channel_attempts(channel_id,started_at)",
		"channel_health_transitions(channel_id,created_at)",
		"commercial_access_projections(user_subscription_id,status)",
		"commercial_audit_events(object_type,object_id,created_at)",
		"logical_request_usages(customer_id,created_at)",
		"stripe_event_inbox(status,received_at)",
		"stripe_event_inbox(status,processing_lease_expires_at)",
		"subscription_pre_consume_records(billing_period_id,status)",
		"subscription_pre_consume_records(commercial_record,updated_at)",
		"subscription_pre_consume_records(status,hard_expires_at)",
	}, contract.Schema.RequiredIndexes)
}

func TestFoundationSchemaIsImplementationReady(t *testing.T) {
	contract := readMigrationContract(t)
	require.Equal(t, []string{
		"create-reference-version-ledger-and-recovery-tables",
		"make-legacy-key-columns-nullable-and-replace-token-key-unique-index",
		"add-alter-table-columns-with-nullable-or-safe-default-compatible-shapes",
		"backfill-commercial-discriminators-false-and-native-reset-versions-zero",
		"build-required-indexes-concurrently-outside-the-schema-transaction",
		"add-not-valid-checks-and-restricting-foreign-keys",
		"validate-checks-and-foreign-keys",
		"deploy-compatible-writers-before-commercial-activation",
	}, contract.Schema.ForwardOrder)

	for tableName, table := range contract.Tables {
		primaryKeys := 0
		for columnName, column := range table.Columns {
			require.NotEmpty(t, column.Type, "%s.%s type", tableName, columnName)
			require.NotEmpty(t, column.Default, "%s.%s default policy", tableName, columnName)
			if column.PrimaryKey {
				primaryKeys++
				require.False(t, column.Nullable, "%s.%s primary key nullability", tableName, columnName)
			}
		}
		require.Equal(t, 1, primaryKeys, "%s must declare one primary key", tableName)
	}

	requireColumn(t, contract, "tokens", "key", "varchar(128)", true, "none")
	requireColumn(t, contract, "tokens", "gateway_verifier_digest", "bytea", true, "none")
	requireColumn(t, contract, "channels", "key", "text", true, "none")
	requireColumn(t, contract, "commercial_plan_versions", "price_microusd", "bigint", false, "none")
	requireColumn(t, contract, "channel_cost_rates", "price_numerator", "bigint", false, "none")
	requireColumn(t, contract, "channel_cost_rates", "unit_denominator", "bigint", false, "none")

	require.ElementsMatch(t, requiredFoundationForeignKeys(), contract.Schema.RequiredForeignKeys)
	require.ElementsMatch(t, requiredFoundationChecks(), contract.Schema.RequiredChecks)
	require.Less(t, forwardOrderPosition(contract.Schema.ForwardOrder, "build-required-indexes-concurrently-outside-the-schema-transaction"), forwardOrderPosition(contract.Schema.ForwardOrder, "add-not-valid-checks-and-restricting-foreign-keys"))
	require.ElementsMatch(t, []string{
		"billing-period-identity-bounds-plan-and-reset-version:database-trigger-reject-update-and-delete-while-status-changes-use-versioned-cas",
		"billing-commands:database-trigger-reject-customer-command-type-idempotency-key-request-fingerprint-provider-idempotency-key-update-delete-and-terminal-result-rewrite-while-state-transitions-use-versioned-cas",
		"channel-cost-profiles-and-rates:database-trigger-reject-economic-update-and-delete-allow-only-retired-at-null-to-nonnull",
		"channel-health-transitions:database-trigger-reject-update-delete",
		"channel-reliability-policies:database-trigger-reject-update-delete",
		"commercial-audit-events:database-trigger-reject-update-delete",
		"commercial-plan-versions-and-entitlements:database-trigger-reject-economic-or-entitlement-update-and-delete-allow-only-enabled-true-to-false-and-retired-at-null-to-nonnull",
		"logical-request-usages:insert-final-once-database-trigger-reject-update-delete",
		"terminal-channel-attempts:database-trigger-reject-terminal-rewrite-or-delete",
		"terminal-stripe-event-effects:database-trigger-reject-update-delete",
		"stripe-event-inbox:database-trigger-reject-provider-provider-event-id-account-mode-event-type-occurred-at-payload-hash-normalized-effect-data-update-or-delete",
	}, contract.Schema.ImmutabilityRules)
}

func TestQuotaSettlementAndRefundAreAtomic(t *testing.T) {
	contract := readMigrationContract(t)
	require.Equal(t, "compare-and-set-pending-to-one-terminal-state", contract.Quota.SettlementCAS)
	require.Equal(t, "terminal-cas-and-period-conditional-native-usage-update-in-one-postgresql-transaction", contract.Quota.SettlementTransaction)
	require.Equal(t, "decrement-current-usage-only-when-stored-period-and-reset-version-still-match", contract.Quota.RefundPeriodRule)
}

func TestCommercialOwnerTuplesAreRelationallyBound(t *testing.T) {
	contract := readMigrationContract(t)
	require.Contains(t, contract.Schema.RequiredForeignKeys, "commercial_access_projections(token_id,customer_id)->tokens(id,user_id):restrict")
	require.Contains(t, contract.Schema.RequiredForeignKeys, "commercial_access_projections(user_subscription_id,customer_id)->user_subscriptions(id,user_id):restrict")
	require.Contains(t, contract.Schema.RequiredForeignKeys, "subscription_pre_consume_records(user_subscription_id,user_id)->user_subscriptions(id,user_id):restrict")
	require.Contains(t, contract.Schema.RequiredForeignKeys, "channel_attempts(customer_key_id,customer_id)->tokens(id,user_id):restrict")
	require.Contains(t, contract.Schema.RequiredForeignKeys, "logical_request_usages(customer_key_id,customer_id)->tokens(id,user_id):restrict")
	require.Contains(t, contract.Schema.RequiredForeignKeys, "logical_request_usages(user_subscription_id,customer_id)->user_subscriptions(id,user_id):restrict")
	require.Contains(t, contract.Schema.RequiredUniqueness, "tokens(id,user_id)")
	require.Contains(t, contract.Schema.RequiredUniqueness, "user_subscriptions(id,user_id)")
}

func TestAccountingValuesHaveFiniteBounds(t *testing.T) {
	contract := readMigrationContract(t)
	for _, check := range []string{
		"commercial_plan_versions:price-and-quota-values-in-0-to-1000000000",
		"subscription_pre_consume_records:pre-consumed-and-amount-used-in-0-to-1000000000",
		"channel_attempts:input-output-tokens-and-cost-in-0-to-1000000000",
		"channel_cost_rates:price-numerator-in-0-to-1000000000-and-unit-denominator-in-1-to-1000000000",
		"logical_request_usages:meters-and-cost-in-0-to-1000000000-and-request-units-exactly-1",
		"billing-and-quota-arithmetic:checked-before-bigint-multiplication-and-addition",
	} {
		require.Contains(t, contract.Schema.RequiredChecks, check)
	}
}

func TestStripeReplayAndProviderIdempotencyAreExplicit(t *testing.T) {
	contract := readMigrationContract(t)
	require.Contains(t, contract.Schema.RequiredChecks, "stripe_event_inbox:duplicate-event-compares-provider-event-id-account-mode-type-occurred-at-and-payload-hash-exact-match-no-op-any-mismatch-rejects-and-audits-without-mutation")
	require.Contains(t, contract.Schema.RequiredChecks, "billing_commands:provider-idempotency-key-nonempty-server-derived-from-command-id-and-request-fingerprint-mismatch-conflicts")
	require.Contains(t, contract.Schema.RequiredUniqueness, "billing_commands(provider_idempotency_key)")
	require.Contains(t, columnNames(contract.Tables["billing_commands"]), "version")
	require.Contains(t, contract.Schema.RequiredChecks, "billing_commands:version-nonnegative-and-state-transitions-use-versioned-cas")
	require.Contains(t, contract.Schema.ImmutabilityRules, "billing-commands:database-trigger-reject-customer-command-type-idempotency-key-request-fingerprint-provider-idempotency-key-update-delete-and-terminal-result-rewrite-while-state-transitions-use-versioned-cas")
	require.Contains(t, contract.Schema.ImmutabilityRules, "stripe-event-inbox:database-trigger-reject-provider-provider-event-id-account-mode-event-type-occurred-at-payload-hash-normalized-effect-data-update-or-delete")
}

func TestSuccessfulUsageCannotSilentlyDefaultMissingMetersOrCost(t *testing.T) {
	contract := readMigrationContract(t)
	require.Contains(t, columnNames(contract.Tables["logical_request_usages"]), "usage_status")
	require.Contains(t, columnNames(contract.Tables["logical_request_usages"]), "cost_status")
	require.Contains(t, contract.Schema.RequiredChecks, "logical_request_usages:usage-status-in-reported-estimated-unknown-cost-status-in-computed-estimated-not-billable-unknown-success-requires-known-usage-and-nonnull-known-cost-and-unknown-only-for-nonsuccess")
}

func TestAuditDetailsAreAllowlistedBoundedAndNonSensitive(t *testing.T) {
	contract := readMigrationContract(t)
	require.ElementsMatch(t, []string{
		"reason_class", "previous_status", "next_status", "plan_version_id",
		"billing_period_id", "reset_version", "request_id", "provider_event_id_hash", "command_id",
	}, contract.Security.AuditDetailFields)
	require.Equal(t, 4096, contract.Security.AuditDetailMaxBytes)
	require.Contains(t, contract.Schema.RequiredChecks, "commercial_audit_events:redacted-details-allowlisted-object-at-most-4096-bytes-and-forbids-raw-payloads-signatures-credentials-headers-prompts-responses-urls-upstream-errors")
}

func TestChannelAndUsageLedgersBindOwnersAndCaptureRequiredState(t *testing.T) {
	contract := readMigrationContract(t)
	t.Run("channel-owned profile and policy references", func(t *testing.T) {
		for _, uniqueness := range []string{
			"channel_cost_profiles(channel_id,id)",
			"channel_reliability_policies(channel_id,id)",
		} {
			require.Contains(t, contract.Schema.RequiredUniqueness, uniqueness)
		}
		for _, foreignKey := range []string{
			"channels(id,active_cost_profile_id)->channel_cost_profiles(channel_id,id):restrict:deferrable",
			"channels(id,reliability_policy_id)->channel_reliability_policies(channel_id,id):restrict:deferrable",
			"channel_attempts(channel_id,cost_profile_id)->channel_cost_profiles(channel_id,id):restrict",
			"logical_request_usages(successful_channel_id,cost_profile_id)->channel_cost_profiles(channel_id,id):restrict",
		} {
			require.Contains(t, contract.Schema.RequiredForeignKeys, foreignKey)
		}
	})
	t.Run("attempt evidence", func(t *testing.T) {
		for _, column := range []string{"latency_ms", "ttft_ms", "http_status"} {
			require.Contains(t, columnNames(contract.Tables["channel_attempts"]), column)
		}
		require.Contains(t, contract.Schema.RequiredChecks, "channel_attempts:latency-ttft-http-status-and-outcome-bounded-by-final-state")
	})
	t.Run("operator probe ownership", func(t *testing.T) {
		require.Contains(t, columnNames(contract.Tables["channel_attempts"]), "actor_type")
		require.True(t, contract.Tables["channel_attempts"].Columns["customer_id"].Nullable)
		require.True(t, contract.Tables["channel_attempts"].Columns["customer_key_id"].Nullable)
		require.Contains(t, contract.Schema.RequiredChecks, "channel_attempts:actor-type-customer-or-system-customer-requires-owner-system-requires-null-owner")
	})
	t.Run("versioned reliability policy", func(t *testing.T) {
		for _, column := range []string{
			"retryable_statuses", "window_seconds", "bucket_seconds", "degraded_p95_ms",
			"recovery_p95_ms", "consecutive_failure_limit", "latency_bucket_bounds_ms",
		} {
			require.Contains(t, columnNames(contract.Tables["channel_reliability_policies"]), column)
		}
		require.Contains(t, contract.Schema.RequiredChecks, "channel_reliability_policies:retry-statuses-window-buckets-percentiles-histogram-and-hysteresis-validated")
	})
	t.Run("logical usage settlement identity", func(t *testing.T) {
		for _, column := range []string{
			"plan_version_id", "billing_period_id", "reset_version", "image_units", "quota_delta",
			"customer_charge_microusd", "hard_expires_at", "state",
		} {
			require.Contains(t, columnNames(contract.Tables["logical_request_usages"]), column)
		}
		require.Contains(t, contract.Schema.RequiredForeignKeys, "logical_request_usages(request_id)->subscription_pre_consume_records(request_id):restrict")
		require.Contains(t, contract.Schema.RequiredForeignKeys, "logical_request_usages(user_subscription_id,billing_period_id,reset_version,plan_version_id)->commercial_billing_periods(user_subscription_id,id,reset_version,plan_version_id):restrict")
		for _, check := range []string{
			"logical_request_usages:plan-period-state-image-units-quota-delta-charge-and-hard-expiry-bound",
			"logical_request_usages:success-requires-successful-channel-and-cost-profile-failure-requires-null-success-and-cost-channel-bindings",
		} {
			require.Contains(t, contract.Schema.RequiredChecks, check)
		}
	})
}

func TestLegacyReservationStatusPreservesNativeDefault(t *testing.T) {
	contract := readMigrationContract(t)
	require.Equal(t, "none", contract.Tables["subscription_pre_consume_records"].Columns["status"].Default)
	require.Contains(t, contract.Schema.RequiredChecks, "subscription_pre_consume_records:legacy-status-preserves-native-consumed-refunded-default-and-commercial-writers-set-pending-explicitly")
}

func TestStripeInboxRecoveryAndLogicalEffectIdempotency(t *testing.T) {
	contract := readMigrationContract(t)
	require.ElementsMatch(t, []string{"received", "processing", "applied", "ignored", "rejected", "deferred", "failed-retryable"}, contract.Billing.InboxStates)
	require.Equal(t, "versioned-compare-and-set-owner-with-lease-compared-to-postgresql-transaction-time", contract.Billing.ProcessingOwnership)
	require.Equal(t, "bounded-validated-normalized-effect-fields-plus-exact-payload-hash", contract.Billing.RecoveryData)
	require.ElementsMatch(t, []string{
		"provider_object_id", "internal_customer_id", "internal_subscription_id", "plan_version_id",
		"billing_period_start", "billing_period_end", "provider_status", "cancel_at_period_end", "billing_command_id",
	}, contract.Billing.NormalizedEffectFields)
	require.Equal(t, 16384, contract.Billing.NormalizedEffectMaxBytes)
	require.Equal(t, "inbox-terminal-state-effect-access-period-quota-and-audit-in-one-postgresql-transaction", contract.Billing.EffectTransaction)
	require.Equal(t, "effect-type-and-server-derived-logical-effect-key", contract.Billing.LogicalEffectUniqueness)
	require.Equal(t, "sha-256-of-canonical-effect-type-key-object-and-verified-normalized-effect-data", contract.Billing.EffectFingerprintBinding)
	require.Equal(t, "exact-type-key-and-fingerprint-no-op-mismatch-rejects-audits-without-mutation", contract.Billing.EffectReplayPolicy)
	require.Contains(t, contract.Schema.RequiredChecks, "stripe_event_effects:duplicate-effect-type-key-compares-fingerprint-exact-match-no-op-mismatch-rejects-and-audits-without-mutation")
	require.Contains(t, contract.Schema.RequiredChecks, "stripe_event_inbox:normalized-effect-data-canonicalized-from-verified-payload-before-insert-and-immutable")
	require.Contains(t, columnNames(contract.Tables["commercial_access_projections"]), "last_event_occurred_at")
	require.Contains(t, contract.Schema.RequiredChecks, "commercial_access_projections:versioned-cas-event-watermark-monotonic-rejects-stale-status-change")
	require.ElementsMatch(t, []string{"processing_owner", "processing_lease_expires_at", "version", "normalized_effect_data"}, []string{
		mustColumn(t, contract, "stripe_event_inbox", "processing_owner"),
		mustColumn(t, contract, "stripe_event_inbox", "processing_lease_expires_at"),
		mustColumn(t, contract, "stripe_event_inbox", "version"),
		mustColumn(t, contract, "stripe_event_inbox", "normalized_effect_data"),
	})
	require.Contains(t, columnNames(contract.Tables["stripe_event_effects"]), "effect_key")
	require.Contains(t, contract.Schema.RequiredUniqueness, "stripe_event_effects(effect_type,effect_key)")
	require.Equal(t, "bounded-normalized-effect-fields-and-payload-hash-only", contract.Security.StripePayloadStorage)
}

func TestLegacyPlaintextColumnsHaveSafeTransitions(t *testing.T) {
	contract := readMigrationContract(t)
	require.Equal(t, "nullable-with-partial-unique-index-where-key-is-not-null", contract.Compatibility.TokenLegacyKey)
	require.Equal(t, "commercial_key-requires-null-key-and-nonnull-public-id-version-and-32-byte-verifier", contract.Compatibility.CommercialTokenCheck)
	require.Equal(t, "nullable-and-forbidden-for-commercial-active-channels", contract.Compatibility.ChannelLegacyKey)
	require.Equal(t, "commercial_channel-requires-null-key-and-nonnull-secret-ref-auth-type-policy-cost-profile-and-positive-config-version", contract.Compatibility.CommercialChannelCheck)
	require.Contains(t, contract.Schema.RequiredUniqueness, "tokens(key) where key is not null")
}

func TestBillingPeriodTupleIsRelationallyBound(t *testing.T) {
	contract := readMigrationContract(t)
	require.Contains(t, contract.Schema.RequiredUniqueness, "commercial_billing_periods(user_subscription_id,reset_version)")
	require.Contains(t, contract.Schema.RequiredUniqueness, "commercial_billing_periods(user_subscription_id,id,reset_version,plan_version_id)")
	for _, foreignKey := range []string{
		"commercial_access_projections(user_subscription_id,billing_period_id,reset_version,plan_version_id)->commercial_billing_periods(user_subscription_id,id,reset_version,plan_version_id):restrict",
		"subscription_pre_consume_records(user_subscription_id,billing_period_id,reset_version,plan_version_id)->commercial_billing_periods(user_subscription_id,id,reset_version,plan_version_id):restrict",
		"user_subscriptions(id,current_billing_period_id,quota_reset_version,plan_version_id)->commercial_billing_periods(user_subscription_id,id,reset_version,plan_version_id):restrict:deferrable",
	} {
		require.Contains(t, contract.Schema.RequiredForeignKeys, foreignKey)
	}
	require.Contains(t, columnNames(contract.Tables["commercial_access_projections"]), "reset_version")
	require.Contains(t, columnNames(contract.Tables["commercial_billing_periods"]), "plan_version_id")
}

func TestHealthScopeAndTimeoutOwnersAreComplete(t *testing.T) {
	contract := readMigrationContract(t)
	for _, column := range []string{"public_model_alias", "endpoint_class", "config_version"} {
		require.Contains(t, columnNames(contract.Tables["channel_health_transitions"]), column)
	}
	for _, column := range []string{"stream_idle_timeout_ms", "stream_max_duration_ms"} {
		require.Contains(t, columnNames(contract.Tables["channel_reliability_policies"]), column)
	}
}

func TestCommercialReservationCleanupIsIsolated(t *testing.T) {
	contract := readMigrationContract(t)
	require.Contains(t, columnNames(contract.Tables["subscription_pre_consume_records"]), "commercial_record")
	require.Equal(t, "commercial_record-equals-true", contract.Retention.CommercialReservationPredicate)
	require.Equal(t, "age-cleanup-may-delete-only-commercial_record-equals-false", contract.Retention.LegacyCleanupPolicy)
	require.Contains(t, contract.Schema.RequiredIndexes, "subscription_pre_consume_records(commercial_record,updated_at)")
}

func TestFoundationMigrationContractContainsNoExecutableSQL(t *testing.T) {
	data, err := os.ReadFile(foundationContract)
	require.NoError(t, err)
	require.NotContains(t, string(data), "```sql")
	executableStatement := regexp.MustCompile(`(?mi)^\s*(create|alter|drop|truncate|delete|update|insert)\s+(table|index|from|into)\b`)
	require.Empty(t, executableStatement.Find(data), "Step 0.4 must stay contract-only")
}

func readMigrationContract(t *testing.T) migrationContract {
	t.Helper()
	data, err := os.ReadFile(foundationContract)
	require.NoError(t, err)
	frontmatter := extractFrontmatter(t, data)
	decoder := yaml.NewDecoder(bytes.NewReader(frontmatter))
	decoder.KnownFields(true)
	var contract migrationContract
	require.NoError(t, decoder.Decode(&contract))
	var extra any
	require.ErrorIs(t, decoder.Decode(&extra), io.EOF)
	return contract
}

func extractFrontmatter(t *testing.T, data []byte) []byte {
	t.Helper()
	require.True(t, bytes.HasPrefix(data, []byte("---\n")), "contract must start with YAML frontmatter")
	end := bytes.Index(data[4:], []byte("\n---\n"))
	require.GreaterOrEqual(t, end, 0, "contract frontmatter must be closed")
	return data[4 : 4+end]
}

func requireNoDuplicateNames(t *testing.T, names []string) {
	t.Helper()
	sorted := append([]string{}, names...)
	sort.Strings(sorted)
	for i := 1; i < len(sorted); i++ {
		require.NotEqual(t, sorted[i-1], sorted[i], "duplicate table owner")
	}
}

func requireColumn(t *testing.T, contract migrationContract, tableName, columnName, wantType string, wantNullable bool, wantDefault string) {
	t.Helper()
	table, ok := contract.Tables[tableName]
	require.True(t, ok, tableName)
	column, ok := table.Columns[columnName]
	require.True(t, ok, "%s.%s", tableName, columnName)
	require.Equal(t, wantType, column.Type, "%s.%s type", tableName, columnName)
	require.Equal(t, wantNullable, column.Nullable, "%s.%s nullable", tableName, columnName)
	require.Equal(t, wantDefault, column.Default, "%s.%s default", tableName, columnName)
}

func mustColumn(t *testing.T, contract migrationContract, tableName, columnName string) string {
	t.Helper()
	table, ok := contract.Tables[tableName]
	require.True(t, ok, tableName)
	_, ok = table.Columns[columnName]
	require.True(t, ok, "%s.%s", tableName, columnName)
	return columnName
}

func columnNames(table tableContract) []string {
	keys := make([]string, 0, len(table.Columns))
	for key := range table.Columns {
		keys = append(keys, key)
	}
	sort.Strings(keys)
	return keys
}

func requiredFoundationForeignKeys() []string {
	return []string{
		"billing_commands(customer_id)->users(id):restrict",
		"channel_attempts(channel_id)->channels(id):restrict",
		"channel_attempts(channel_id,cost_profile_id)->channel_cost_profiles(channel_id,id):restrict",
		"channel_attempts(customer_id)->users(id):restrict",
		"channel_attempts(customer_key_id)->tokens(id):restrict",
		"channel_cost_profiles(channel_id)->channels(id):restrict",
		"channel_cost_rates(cost_profile_id)->channel_cost_profiles(id):restrict",
		"channel_health_transitions(channel_id)->channels(id):restrict",
		"channel_reliability_policies(channel_id)->channels(id):restrict",
		"channels(id,active_cost_profile_id)->channel_cost_profiles(channel_id,id):restrict:deferrable",
		"channels(id,reliability_policy_id)->channel_reliability_policies(channel_id,id):restrict:deferrable",
		"commercial_access_projections(customer_id)->users(id):restrict",
		"commercial_access_projections(plan_version_id)->commercial_plan_versions(id):restrict",
		"commercial_access_projections(token_id)->tokens(id):restrict",
		"commercial_access_projections(token_id,customer_id)->tokens(id,user_id):restrict",
		"commercial_access_projections(user_subscription_id)->user_subscriptions(id):restrict",
		"commercial_access_projections(user_subscription_id,customer_id)->user_subscriptions(id,user_id):restrict",
		"commercial_access_projections(user_subscription_id,billing_period_id,reset_version,plan_version_id)->commercial_billing_periods(user_subscription_id,id,reset_version,plan_version_id):restrict",
		"commercial_billing_periods(plan_version_id)->commercial_plan_versions(id):restrict",
		"commercial_billing_periods(user_subscription_id)->user_subscriptions(id):restrict",
		"commercial_plan_entitlements(plan_version_id)->commercial_plan_versions(id):restrict",
		"commercial_plan_versions(plan_id)->subscription_plans(id):restrict",
		"logical_request_usages(successful_channel_id,cost_profile_id)->channel_cost_profiles(channel_id,id):restrict",
		"logical_request_usages(customer_id)->users(id):restrict",
		"logical_request_usages(customer_key_id)->tokens(id):restrict",
		"logical_request_usages(successful_channel_id)->channels(id):restrict",
		"logical_request_usages(user_subscription_id)->user_subscriptions(id):restrict",
		"logical_request_usages(user_subscription_id,billing_period_id,reset_version,plan_version_id)->commercial_billing_periods(user_subscription_id,id,reset_version,plan_version_id):restrict",
		"logical_request_usages(request_id)->subscription_pre_consume_records(request_id):restrict",
		"stripe_event_effects(stripe_event_inbox_id)->stripe_event_inbox(id):restrict",
		"subscription_pre_consume_records(plan_version_id)->commercial_plan_versions(id):restrict",
		"subscription_pre_consume_records(user_subscription_id)->user_subscriptions(id):restrict",
		"subscription_pre_consume_records(user_subscription_id,user_id)->user_subscriptions(id,user_id):restrict",
		"subscription_pre_consume_records(user_subscription_id,billing_period_id,reset_version,plan_version_id)->commercial_billing_periods(user_subscription_id,id,reset_version,plan_version_id):restrict",
		"channel_attempts(customer_key_id,customer_id)->tokens(id,user_id):restrict",
		"logical_request_usages(customer_key_id,customer_id)->tokens(id,user_id):restrict",
		"logical_request_usages(user_subscription_id,customer_id)->user_subscriptions(id,user_id):restrict",
		"tokens(user_id)->users(id):restrict",
		"user_subscriptions(plan_version_id)->commercial_plan_versions(id):restrict",
		"user_subscriptions(id,current_billing_period_id,quota_reset_version,plan_version_id)->commercial_billing_periods(user_subscription_id,id,reset_version,plan_version_id):restrict:deferrable",
	}
}

func requiredFoundationChecks() []string {
	return []string{
		"billing_commands:request-fingerprint-32-bytes-status-in-pending-processing-succeeded-failed-retryable-and-attempt-count-nonnegative",
		"billing_commands:provider-idempotency-key-nonempty-server-derived-from-command-id-and-request-fingerprint-mismatch-conflicts",
		"billing_commands:version-nonnegative-and-state-transitions-use-versioned-cas",
		"channel_attempts:status-in-pending-final-and-meters-cost-latencies-nonnegative",
		"channel_attempts:input-output-tokens-and-cost-in-0-to-1000000000",
		"channel_attempts:actor-type-customer-or-system-customer-requires-owner-system-requires-null-owner",
		"channel_attempts:latency-ttft-http-status-and-outcome-bounded-by-final-state",
		"channel_cost_rates:price-numerator-nonnegative-and-unit-denominator-positive",
		"channel_cost_rates:price-numerator-in-0-to-1000000000-and-unit-denominator-in-1-to-1000000000",
		"channel_health_transitions:states-allowlisted-sample-count-nonnegative-error-rate-0-to-10000-and-latencies-nonnegative",
		"channel_reliability_policies:timeouts-positive-at-most-10000-precommit-bytes-at-most-1048576-stream-and-response-bytes-at-most-8388608-thresholds-0-to-10000-and-recovery-counts-positive",
		"channel_reliability_policies:retry-statuses-window-buckets-percentiles-histogram-and-hysteresis-validated",
		"channels:commercial-channel-requires-null-key-nonnull-reference-auth-policy-cost-and-positive-config-version",
		"channels:commercial-secret-ref-is-env-name-auth-type-in-bearer-fixed-header-and-header-name-is-validated",
		"commercial_access_projections:status-allowlisted-reset-version-positive-and-expiry-after-period-start-when-present",
		"commercial_billing_periods:period-end-after-period-start-reset-version-positive-and-status-allowlisted",
		"commercial_plan_versions:money-and-quotas-bounded-integers-concurrency-positive-and-effective-before-retired",
		"commercial_plan_versions:price-and-quota-values-in-0-to-1000000000",
		"enforcement_epochs:singleton-id-is-one-epoch-and-version-positive-state-in-closed-draining-active",
		"logical_request_usages:meters-request-units-latency-and-cost-nonnegative-and-delivery-status-allowlisted",
		"logical_request_usages:meters-and-cost-in-0-to-1000000000-and-request-units-exactly-1",
		"logical_request_usages:plan-period-state-image-units-quota-delta-charge-and-hard-expiry-bound",
		"logical_request_usages:success-requires-successful-channel-and-cost-profile-failure-requires-null-success-and-cost-channel-bindings",
		"commercial_access_projections:versioned-cas-event-watermark-monotonic-rejects-stale-status-change",
		"stripe_event_inbox:state-allowlisted-payload-hash-32-bytes-normalized-effect-object-at-most-16384-bytes-version-nonnegative-and-processing-requires-owner-and-lease",
		"stripe_event_inbox:duplicate-event-compares-provider-event-id-account-mode-type-occurred-at-and-payload-hash-exact-match-no-op-any-mismatch-rejects-and-audits-without-mutation",
		"stripe_event_inbox:normalized-effect-data-canonicalized-from-verified-payload-before-insert-and-immutable",
		"stripe_event_effects:effect-fingerprint-32-bytes-and-effect-key-nonempty",
		"stripe_event_effects:duplicate-effect-type-key-compares-fingerprint-exact-match-no-op-mismatch-rejects-and-audits-without-mutation",
		"subscription_pre_consume_records:commercial-record-requires-32-byte-fingerprint-status-pending-committed-refunded-and-nonnull-bindings-legacy-record-requires-status-consumed-refunded",
		"subscription_pre_consume_records:pre-consumed-and-amount-used-in-0-to-1000000000",
		"subscription_pre_consume_records:legacy-status-preserves-native-consumed-refunded-default-and-commercial-writers-set-pending-explicitly",
		"subscription_pre_consume_records:commercial-pending-has-no-terminal-time-commercial-terminal-states-have-finalized-at-and-refunded-has-refunded-at",
		"billing-and-quota-arithmetic:checked-before-bigint-multiplication-and-addition",
		"logical_request_usages:usage-status-in-reported-estimated-unknown-cost-status-in-computed-estimated-not-billable-unknown-success-requires-known-usage-and-nonnull-known-cost-and-unknown-only-for-nonsuccess",
		"commercial_audit_events:redacted-details-allowlisted-object-at-most-4096-bytes-and-forbids-raw-payloads-signatures-credentials-headers-prompts-responses-urls-upstream-errors",
		"tokens:commercial-key-requires-null-legacy-key-canonical-public-id-positive-version-and-32-byte-verifier",
	}
}

func sortedMapKeys(values map[string]tableContract) []string {
	keys := make([]string, 0, len(values))
	for key := range values {
		keys = append(keys, key)
	}
	sort.Strings(keys)
	return keys
}

func forwardOrderPosition(order []string, step string) int {
	for index, current := range order {
		if current == step {
			return index
		}
	}
	return -1
}
