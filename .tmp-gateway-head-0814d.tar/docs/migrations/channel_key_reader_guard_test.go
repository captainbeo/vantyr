package migrations_test

import (
	"bytes"
	"fmt"
	"go/ast"
	"go/format"
	"go/parser"
	"go/token"
	"os"
	"path/filepath"
	"reflect"
	"sort"
	"strings"
	"testing"
)

// commercialChannelKeyReaderInventory is keyed by stable source ownership,
// not line number. It includes the inventory's known unrelated Key fields so a
// new selector cannot evade review through local variable naming.
var commercialChannelKeyReaderInventory = map[string]int{
	"controller/channel-billing.go|updateChannelAIGC2DBalance|channel.Key":                                                   1,
	"controller/channel-billing.go|updateChannelAIProxyBalance|channel.Key":                                                  1,
	"controller/channel-billing.go|updateChannelAPI2GPTBalance|channel.Key":                                                  1,
	"controller/channel-billing.go|updateChannelBalance|channel.Key":                                                         2,
	"controller/channel-billing.go|updateChannelCloseAIBalance|channel.Key":                                                  1,
	"controller/channel-billing.go|updateChannelDeepSeekBalance|channel.Key":                                                 1,
	"controller/channel-billing.go|updateChannelMoonshotBalance|channel.Key":                                                 1,
	"controller/channel-billing.go|updateChannelOpenAISBBalance|channel.Key":                                                 2,
	"controller/channel-billing.go|updateChannelOpenRouterBalance|channel.Key":                                               1,
	"controller/channel-billing.go|updateChannelSiliconFlowBalance|channel.Key":                                              1,
	"controller/channel.go|AddChannel|addChannelRequest.Channel.Key":                                                         8,
	"controller/channel.go|AddChannel|localChannel.Key":                                                                      4,
	"controller/channel.go|FetchModels|req.Key":                                                                              1,
	"controller/channel.go|GetChannelKey|channel.Key":                                                                        1,
	"controller/channel.go|ManageMultiKeys|channel.GetKeys":                                                                  3,
	"controller/channel.go|ManageMultiKeys|channel.Key":                                                                      2,
	"controller/channel.go|OllamaDeleteModel|channel.Key":                                                                    1,
	"controller/channel.go|OllamaPullModelStream|channel.Key":                                                                1,
	"controller/channel.go|OllamaPullModel|channel.Key":                                                                      1,
	"controller/channel.go|OllamaVersion|channel.Key":                                                                        1,
	"controller/channel.go|UpdateChannel|channel.Key":                                                                        8,
	"controller/channel.go|UpdateChannel|originChannel.Key":                                                                  5,
	"controller/channel.go|buildAdvancedCustomModelPreviewChannel|req.Key":                                                   1,
	"controller/channel.go|validateChannel|channel.Key":                                                                      2,
	"controller/channel_authz.go|channelHasSensitiveChanges|channel.Key":                                                     2,
	"controller/channel_authz.go|channelHasSensitiveChanges|origin.Key":                                                      1,
	"controller/channel_upstream_update.go|fetchAdvancedCustomUpstreamModelIDs|channel.GetNextEnabledKey":                    1,
	"controller/channel_upstream_update.go|fetchChannelUpstreamModelIDs|channel.GetNextEnabledKey":                           2,
	"controller/channel_upstream_update.go|fetchChannelUpstreamModelIDs|channel.Key":                                         1,
	"controller/codex_usage.go|fetchCodexChannelWhamData|ch.Key":                                                             1,
	"controller/midjourney.go|runMidjourneyTaskUpdateOnce|midjourneyChannel.Key":                                             1,
	"controller/option.go|UpdateOption|option.Key":                                                                           5,
	"controller/ratio_sync.go|FetchUpstreamRatios|dbCh.GetNextEnabledKey":                                                    1,
	"controller/subscription_payment_stripe.go|genStripeSubscriptionLink|stripe.Key":                                         1,
	"controller/token.go|buildMaskedTokenResponse|maskedToken.Key":                                                           1,
	"controller/topup_stripe.go|genStripeLink|stripe.Key":                                                                    1,
	"controller/user.go|TopUp|req.Key":                                                                                       2,
	"controller/video_proxy.go|VideoProxy|channel.Key":                                                                       1,
	"controller/video_proxy.go|VideoProxy|task.PrivateData.Key":                                                              1,
	"controller/video_proxy_gemini.go|getVertexTaskKey|channel.GetKeys":                                                      1,
	"controller/video_proxy_gemini.go|getVertexTaskKey|channel.Key":                                                          1,
	"controller/video_proxy_gemini.go|getVertexTaskKey|task.PrivateData.Key":                                                 1,
	"middleware/audit.go|finishAdminAudit|p.Key":                                                                             1,
	"middleware/auth.go|SetupContextForToken|token.Key":                                                                      1,
	"middleware/auth.go|TokenAuthReadOnly|token.Key":                                                                         1,
	"middleware/distributor.go|SetupContextForSelectedChannel|channel.GetNextEnabledKey":                                     1,
	"model/channel.go|*Channel.GetKeys|channel.Key":                                                                          3,
	"model/channel.go|*Channel.GetNextEnabledKey|channel.GetKeys":                                                            1,
	"model/channel.go|*Channel.GetNextEnabledKey|channel.Key":                                                                1,
	"model/channel.go|*Channel.Update|channel.Key":                                                                           2,
	"model/channel.go|*Channel.Update|existing.Key":                                                                          1,
	"model/channel.go|handlerMultiKeyUpdate|channel.GetKeys":                                                                 1,
	"model/channel_cache.go|InitChannelCache|channel.GetKeys":                                                                1,
	"model/channel_commercial.go|*Channel.BeforeDelete|channel.Key":                                                          1,
	"model/channel_commercial.go|*Channel.ValidateCommercialWrite|channel.Key":                                               1,
	"model/option.go|loadOptionsFromDatabase|option.Key":                                                                     1,
	"model/task.go|InitTask|privateData.Key":                                                                                 1,
	"model/token.go|*Token.Clean|token.Key":                                                                                  1,
	"model/token.go|*Token.Delete|token.Key":                                                                                 1,
	"model/token.go|*Token.GetFullKey|token.Key":                                                                             1,
	"model/token.go|*Token.GetMaskedKey|token.Key":                                                                           1,
	"model/token.go|BatchDeleteTokens|t.Key":                                                                                 1,
	"model/token.go|invalidateTokensCache|t.Key":                                                                             2,
	"model/token_cache.go|cacheGetTokenByKey|token.Key":                                                                      1,
	"model/token_cache.go|cacheSetToken|token.Key":                                                                           1,
	"relay/common/override.go|buildRequestHeadersContext|item.Key":                                                           2,
	"relay/common/override.go|parseConditionOperations|item.Key":                                                             1,
	"relay/mjproxy_handler.go|RelayMidjourneySubmit|channel.Key":                                                             1,
	"relay/mjproxy_handler.go|RelayMidjourneyTaskImageSeed|channel.Key":                                                      1,
	"relay/relay_task.go|ResolveOriginTask|ch.GetNextEnabledKey":                                                             1,
	"relay/relay_task.go|tryRealtimeFetch|channelModel.Key":                                                                  1,
	"relaykit/relayconvert/internal/oai_responses/to_oai_chat_stream_resp.go|*ResponsesToChatStreamState.toolDelta|tool.Key": 1,
	"service/authz/role.go|Roles|spec.Key":                                                                                   1,
	"service/authz/role.go|roleGrants|spec.Key":                                                                              1,
	"service/authz/role.go|roleSpec|spec.Key":                                                                                1,
	"service/authz/seed.go|resetBuiltInRolePolicies|spec.Key":                                                                1,
	"service/authz/seed.go|seedBuiltInRoles|spec.Key":                                                                        1,
	"service/authz/seed.go|seedDefaultPolicies|spec.Key":                                                                     2,
	"service/channel_affinity.go|GetPreferredChannelByAffinity|usedSource.Key":                                               1,
	"service/channel_affinity.go|extractChannelAffinityValue|src.Key":                                                        6,
	"service/codex_channel_models.go|fetchCodexChannelModels|channel.Key":                                                    1,
	"service/codex_credential_refresh.go|RefreshCodexChannelCredential|ch.Key":                                               1,
	"service/codex_credential_refresh_task.go|runCodexCredentialAutoRefreshOnce|ch.Key":                                      1,
	"service/task_billing.go|resolveTokenKey|token.Key":                                                                      1,
	"service/task_polling.go|updateSunoTasks|ch.Key":                                                                         1,
	"service/task_polling.go|updateVideoSingleTask|privateData.Key":                                                          2,
	"service/task_polling.go|updateVideoSingleTask|ch.Key":                                                                   1,
	"service/task_polling.go|updateVideoTasks|cacheGetChannel.Key":                                                           1,
}

func TestCommercialChannelKeyReaderInventory(t *testing.T) {
	repoRoot := commercialReaderRepoRoot(t)
	got := collectCommercialChannelKeyReaders(t, repoRoot)
	if reflect.DeepEqual(got, commercialChannelKeyReaderInventory) {
		return
	}

	t.Fatalf(
		"production channel-key reader inventory changed; classify the source against docs/migrations/2026-08-10-commercial-channel-key-reader-inventory.md before updating the allowlist:\n%s",
		formatCommercialReaderInventoryDiff(commercialChannelKeyReaderInventory, got),
	)
}

func collectCommercialChannelKeyReaders(t *testing.T, repoRoot string) map[string]int {
	t.Helper()
	readers := make(map[string]int)
	err := filepath.WalkDir(repoRoot, func(path string, entry os.DirEntry, walkErr error) error {
		if walkErr != nil {
			return walkErr
		}
		if entry.IsDir() {
			if path != repoRoot && (strings.HasPrefix(entry.Name(), ".") || entry.Name() == "node_modules" || entry.Name() == "vendor") {
				return filepath.SkipDir
			}
			return nil
		}
		if !strings.HasSuffix(path, ".go") || strings.HasSuffix(path, "_test.go") {
			return nil
		}

		return collectCommercialReadersFromFile(repoRoot, path, readers)
	})
	if err != nil {
		t.Fatalf("scan production Go files: %v", err)
	}
	return readers
}

func collectCommercialReadersFromFile(repoRoot, path string, readers map[string]int) error {
	fset := token.NewFileSet()
	file, err := parser.ParseFile(fset, path, nil, 0)
	if err != nil {
		return fmt.Errorf("parse %s: %w", path, err)
	}
	relPath, err := filepath.Rel(repoRoot, path)
	if err != nil {
		return fmt.Errorf("relativize %s: %w", path, err)
	}
	relPath = filepath.ToSlash(relPath)

	for _, decl := range file.Decls {
		function, ok := decl.(*ast.FuncDecl)
		if !ok || function.Body == nil {
			continue
		}
		owner := commercialReaderFunctionName(function)
		ast.Inspect(function.Body, func(node ast.Node) bool {
			selector, ok := node.(*ast.SelectorExpr)
			if !ok || !isCommercialChannelKeyCandidate(selector) {
				return true
			}
			expression := renderCommercialReaderExpression(fset, selector)
			readers[relPath+"|"+owner+"|"+expression]++
			return true
		})
	}
	return nil
}

func isCommercialChannelKeyCandidate(selector *ast.SelectorExpr) bool {
	switch selector.Sel.Name {
	case "Key", "GetKeys", "GetNextEnabledKey":
		return true
	default:
		return false
	}
}

func commercialReaderFunctionName(function *ast.FuncDecl) string {
	if function.Recv == nil || len(function.Recv.List) == 0 {
		return function.Name.Name
	}
	return renderCommercialReaderExpression(token.NewFileSet(), function.Recv.List[0].Type) + "." + function.Name.Name
}

func renderCommercialReaderExpression(fset *token.FileSet, node ast.Node) string {
	var buffer bytes.Buffer
	if err := format.Node(&buffer, fset, node); err != nil {
		return "<unrenderable>"
	}
	return buffer.String()
}

func formatCommercialReaderInventoryDiff(want, got map[string]int) string {
	changes := make([]string, 0)
	for reader, count := range got {
		if want[reader] != count {
			changes = append(changes, fmt.Sprintf("+ %q: %d", reader, count))
		}
	}
	for reader, count := range want {
		if got[reader] != count {
			changes = append(changes, fmt.Sprintf("- %q: %d", reader, count))
		}
	}
	sort.Strings(changes)
	return strings.Join(changes, "\n")
}

func commercialReaderRepoRoot(t *testing.T) string {
	t.Helper()
	dir, err := os.Getwd()
	if err != nil {
		t.Fatalf("get working directory: %v", err)
	}
	for {
		if _, err := os.Stat(filepath.Join(dir, "go.mod")); err == nil {
			return dir
		}
		parent := filepath.Dir(dir)
		if parent == dir {
			t.Fatal("go.mod not found above test directory")
		}
		dir = parent
	}
}
