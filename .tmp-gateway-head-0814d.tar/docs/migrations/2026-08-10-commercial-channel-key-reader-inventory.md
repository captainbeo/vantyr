# Commercial Channel.Key Reader Inventory (Step 1.1)

## Scope and method

This inventory covers the pinned New API fork on `codex/commercial-mvp` and the
commercial-mode boundary in Step 1.1. It distinguishes the persisted native
`model.Channel.Key` field from unrelated Go fields named `Key` (customer token,
OTP, authz, and option data). The inventory was built by searching the pinned
tree for `.Key`, `GetKeys`, `GetNextEnabledKey`, full-key recovery routes,
`selectAll=true` channel loads, and channel cache copies, then tracing each
result to its caller and downstream sink.

The inventory is a gate input, not permission to resolve or expose a secret.
The only current request-scoped credential seam is the channel-selection path
that places a selected credential in request context. Step 1.2 must replace
that raw source with the typed secret resolver before commercial activation.

## Canonical owner and shared seams

| Location | Evidence | Classification | Step 1 disposition |
|---|---|---|---|
| `model/channel.go` | `:25-28`, `:175-203`, `:532-570`, `:647-710` | Persisted field, key parsing, multi-key state, and writes | Keep native field nullable for non-commercial compatibility; reject commercial raw-key writes and route commercial reads to reference-only metadata/resolver seams. |
| `model/channel_cache.go` | `:26-36`, `:82-95`, `:239-250` | Secret-bearing DB loads and cache copies | Add a commercial secret-free projection; do not cache resolved values as channel objects. |
| `middleware/distributor.go` | `:469-482` | Current selected-key request seam | Preserve for legacy mode; Step 1.2 replaces the source with request-scoped `secret_ref` resolution and centralized redaction. |
| `relay/common/relay_info.go` | `:194-215` | Downstream request metadata carrying the selected credential | Keep as a short-lived transport value only after the resolver owns its production; never persist or serialize it. |
| `controller/channel-test.go` | `:177`, `:960-966`, `:1002` | Channel test setup and full-key channel load | Commercial channel tests use the Step 1.2 resolver; `selectAll=true` is secret-bearing and must not be used for commercial projections. |
| `model/channel_commercial.go` | `:34-35`, `:135-136` | Commercial raw-key rejection guards | Safe guard reads only: compare `Channel.Key` to reject commercial writes/deletes; never consume, resolve, expose, or forward the value. |

## Direct production readers and sinks

| Surface | Evidence | Current behavior | Commercial disposition |
|---|---|---|---|
| Origin-task retry key reselection | `relay/relay_task.go:82-106` | Loads the full origin channel, requires enabled status, calls `GetNextEnabledKey()`, and places the returned key into `ContextKeyChannelKey` and `info.ApiKey` for the retry task | Disable for commercial mode in Step 1.1; Step 1.2 must use a resolver-owned retry scope and must not persist the resolved value in task data |
| Scheduled task polling and task retry | `service/task_polling.go:217-244`, `:390-418`, `:456-465`; `relay/relay_task.go:430-452` | Passes `Channel.Key` or persisted task key into task adaptors and retries | Disable for commercial mode until resolver-backed task scope exists in Step 1.2; never persist a resolved key in `TaskPrivateData`. |
| Task persistence and video proxy | `model/task.go:177-191`; `controller/video_proxy.go:92-120`; `controller/video_proxy_gemini.go:148-225` | Stores or rehydrates task credentials and may fall back to `channel.Key` | Reject commercial task/image paths in Step 1.1/1.2 boundary; keep image routes disabled and remove raw-key fallback from commercial paths. |
| Midjourney proxy and scheduled poll | `relay/mjproxy_handler.go:295-315`, `:467-486`; `controller/midjourney.go:90-122` | Injects `channel.Key` into headers or request URLs | Legacy-only until a typed resolver-backed adaptor is approved; never log or persist the resolved value. |
| Channel balance and billing probes | `controller/channel-billing.go:169-357`, `:394-410`, `:455-475` | Uses raw key in auth headers/URLs and loads full channels | Keep legacy non-commercial behavior; commercial mode uses an operator-only resolver with redacted errors, or disables unsupported balance probes. |
| Upstream model refresh | `controller/channel_upstream_update.go:335-460` | Reads first or selected raw key for model discovery | Step 1.2 resolver-backed operator path; commercial metadata reads must not include `key`. |
| Ratio synchronization | `controller/ratio_sync.go:263-279`, `:988` | Loads full channels and sends selected raw credentials | Resolver-backed only after Step 1.2; commercial metadata queries must use secret-free projections. |
| Codex model and credential refresh | `service/codex_channel_models.go:49-73`; `service/codex_credential_refresh.go:42-100`; `service/codex_credential_refresh_task.go:69-121`; `controller/codex_usage.go:67-140` | Parses, refreshes, writes, and returns provider credential JSON in `Channel.Key` | Disable inherited plaintext OAuth refresh/usage in commercial mode; future resolver-backed support must use a typed secret broker and no raw-key database write. |
| Admin key reveal/edit/copy and multi-key management | `controller/channel.go:419-453`, `:473-500`, `:528-545` (legacy Codex JSON key validation), `:601-704`, `:976-1117`, `:1137` (raw-key comparison for audit), `:1493-1938`; `controller/channel_authz.go:16`, `:59-74` | Reveals, compares, normalizes, audits, previews, or rewrites raw key material | Commercial admin API returns only `secret_ref`, auth metadata, and config revision; full-key recovery, reveal, preview, and raw-key edit paths are disabled. Commercial writes bypass the legacy Codex raw-key JSON validator; the `:1137` comparison remains legacy-only and is not a commercial resolver read. |
| Admin Ollama operations | `controller/channel.go:1994-2213` | Reads the first raw key for connectivity/model operations | Legacy-only or resolver-backed in Step 1.2; no commercial raw-key fallback. |
| Advanced-custom model preview | `controller/channel.go:1225-1290`, `:1303-1347` | `buildAdvancedCustomModelPreviewChannel` loads a saved channel with `GetChannelById(..., true)` and passes the resulting channel, including `Key`, to `fetchChannelUpstreamModelIDs` | Commercial preview must use a resolver-backed operator path or be disabled; `selectAll=true` must not expose commercial credentials to the preview adaptor |

## Downstream adaptor sinks

The following consumers receive a credential parameter or `RelayInfo.ApiKey` but
do not own the `Channel.Key` source. They must be covered by the Step 1.2
resolver migration tests after their callers are classified:

- `relay/channel/api_request.go:182` and adaptor request builders.
- Task adaptor fetch functions used by `service/task_polling.go` and
  `relay/relay_task.go`, including Gemini, Vertex, Doubao, and related task
  paths.
- `relay/channel/advancedcustom/adaptor_test.go`,
  `relay/channel/aws/relay_aws_test.go`, and
  `relay/channel/tencent/dispatch_test.go` fixture-only credential parameters.

## Test fixtures and unrelated key fields

Fixture-only `Channel.Key` values remain valid test data until commercial-mode
negative coverage is added:

- `model/model_owner_test.go:30-39`;
- `model/pricing_endpoint_test.go:34-40`, `:264-267`;
- `controller/model_list_test.go:343-346`;
- `controller/channel_upstream_update_test.go:20-33`, `:180-182`, `:399-401`;
- `controller/channel_test_internal_test.go:140-143`, `:189`;
- `controller/channel_authz_test.go:21-24`, `:31-45`;
- `service/task_polling_test.go:135-140`, `:385-389`; and
- `service/task_billing_test.go:114`.

These are not `Channel.Key` owners:

- `model/token.go` customer-token key;
- `common/otp.go:25` OTP key; and
- option/authz role keys and other map/cache key names.

## Gate status and follow-up

- No unclassified production `Channel.Key` reader was found in the pinned
  inventory. `GetChannelById(..., true)`, `CacheGetChannel`, and
  `GetAllChannels(..., selectAll=true)` are treated as secret-bearing loads
  even where the immediate caller does not reference `.Key`.
- Step 1.1 owns the nullable legacy column, typed commercial channel fields,
  activation checks, and the explicit inventory. It does not claim that all
  readers are already resolver-safe.
- Step 1.2 owns resolver migration for every commercial reader above, the
  static guard against new raw-key reads, and centralized redaction.
- Commercial activation remains blocked until the Step 1.2 resolver coverage,
  capability/health-owner decisions, and full-key recovery disablement pass
  their focused tests and specialist reviews.
