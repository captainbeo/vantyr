# Migration: Commercial Channel Foundation (Step 1.1)

## Status and authorization

This is an executable migration plan for Step 1.1 of the Commercial MVP execution plan. It is a
contract for review and implementation; it does not authorize live execution, production
activation, or post-activation destructive cleanup.

The migration targets PostgreSQL only. It extends the native `channels` table and adds the approved
versioned cost and reliability configuration owners. Native channel routing remains the owner of
identity, enablement, base URL, public aliases, model mappings, priority, and weight.

## Authority and scope decisions

Authority is applied in this order:

1. `docs/plans/2026-07-31-commercial-mvp.md`, Step 1.1 and its execution protocol.
2. `docs/specs/2026-07-30-channel-and-codex-compatibility-design.md`, Sections 5, 7, and 8.
3. `docs/migrations/2026-08-02-commercial-mvp-foundation.md`, including its channel, cost,
   reliability, compatibility, forward-order, retention, and rollback rules.

The following fields already exist on the native channel and require no new column in this step:
`id`, `name`, `status` (operator enabled state), `type`/adaptor, `base_url`, `models`,
`model_mapping`, `group`, `priority`, `weight`, `setting`, `settings`, `header_override`, and
`param_override`.

The additive commercial channel fields are exactly:

| Table | Column | Shape and initial meaning |
|---|---|---|
| `channels` | `commercial_channel` | `boolean NOT NULL DEFAULT false`; discriminator |
| `channels` | `secret_ref` | `varchar(255) NULL`; validated reference, never resolved secret |
| `channels` | `auth_type` | `varchar(32) NULL`; approved Step 1 values are `bearer` and `fixed-header` |
| `channels` | `auth_header_name` | `varchar(128) NULL`; required and validated for fixed-header |
| `channels` | `failure_domain` | `varchar(128) NULL`; operator redundancy label |
| `channels` | `reliability_policy_id` | `bigint NULL`; channel-owned versioned policy pointer |
| `channels` | `active_cost_profile_id` | `bigint NULL`; channel-owned immutable pricing snapshot pointer |
| `channels` | `config_version` | `bigint NOT NULL DEFAULT 0`; positive revision required at activation |
| `channels` | `key` | existing plaintext key becomes nullable; retained for non-commercial compatibility |

The approved supporting structures are `channel_cost_profiles`, `channel_cost_rates`, and
`channel_reliability_policies` with the columns, bounds, uniqueness, and immutability described in
the foundation contract. `channel_attempts` and `channel_health_transitions` are deliberately
deferred: they are runtime ledgers for later Step 3 and no approved foreign-key dependency makes
them necessary to add the Step 1.1 channel pointers.

### Authority ambiguities (must be resolved before activation)

- The design lists a typed `capability_config`, but the approved foundation `channels` schema does
  not contain that column. This migration does not invent it. Step 1.1 activation is blocked until
  an approved follow-up contract either maps capabilities to existing typed configuration or adds a
  versioned column/table with its own migration and rollback.
- Step 1.1 says "health state." The design makes runtime state Redis-owned and keyed by channel,
  alias, endpoint class, and config revision; the foundation's durable health-transition table is a
  later ledger. This plan uses native `channels.status` only for operator enablement and adds no
  `health_state` column or transition table. Activation is blocked unless the runtime health owner
  and Redis failure behavior are accepted by the Step 1.1/1.2 review.
- The design describes query-parameter and no-auth schemes, while the approved foundation check
  names `bearer` and `fixed-header` for the first commercial contract. Only the latter two are
  activation-eligible here; query/none require an approved contract amendment.

## Risk level

**High (additive, compatibility-sensitive).** New nullable columns and new tables are additive,
but making `channels.key` nullable, adding channel-owned foreign keys, and changing the commercial
activation invariant affect credential handling and routing. No existing commercial data should
exist at this gate. The migration is designed to be low downtime, but `ALTER TABLE` and constraint
attachment still require short metadata locks.

## Preconditions and activation guard

Run these checks against a PostgreSQL staging clone before applying UP. Record the result with the
migration evidence; a failing check stops the migration.

```sql
SELECT current_setting('server_version_num')::int >= 140000 AS postgres_supported;
SELECT to_regclass('public.channels') IS NOT NULL AS channels_present;
SELECT EXISTS (
  SELECT 1 FROM information_schema.columns
  WHERE table_schema = 'public' AND table_name = 'channels'
    AND column_name = 'commercial_channel'
) AS discriminator_already_present;
```

If `discriminator_already_present` is true, run the commercial-row count only after resolving and
validating that column's definition; a first-run preflight must not reference a column that does not
yet exist.

The implementation must use an explicit schema-qualified preflight for every object. A first run
requires every *new plan-created* table, column, index, constraint, trigger, and migration ID to be
absent; the required native `public.channels` table and its existing legacy columns are the only
pre-existing schema owner. It must fail on any other pre-existing object, even one that appears
compatible. A later retry may continue only when the migration ID and an operator-owned object
ledger prove that the object was created by this exact migration attempt. It must never silently
reuse or later drop an unrelated object.

Before commercial activation (a separate gate after compatible writers and reader inventory), all
commercial channels must satisfy this guard:

```sql
SELECT id, key, secret_ref, auth_type, auth_header_name,
       reliability_policy_id, active_cost_profile_id, config_version
FROM public.channels
WHERE commercial_channel IS TRUE
  AND (key IS NOT NULL OR secret_ref IS NULL
       OR auth_type IS NULL OR auth_type NOT IN ('bearer', 'fixed-header')
       OR (auth_type = 'fixed-header' AND (auth_header_name IS NULL OR btrim(auth_header_name) = ''))
       OR reliability_policy_id IS NULL OR active_cost_profile_id IS NULL
       OR config_version <= 0);
```

The query must return zero rows. The activation review also requires the complete pinned
`Channel.Key` reader inventory, a static guard against new commercial raw-key reads, reference-only
admin output, compatible writers deployed, and the unresolved capability/health decisions above
closed. A database check cannot disable native key recovery or scheduled/admin readers by itself.

## UP: exact order

The migration runner must record a migration ID and execute these phases in order. Phases marked
transactional run in one transaction; concurrent index creation runs outside a transaction.

### 1. Preflight and lock budget (read-only)

1. Acquire the migration-wide session advisory lock before any object-absence check:
   `SELECT pg_advisory_lock(19860810, 1011)`. The dedicated migration-runner session must retain
   this lock through every UP phase, concurrent index build, validation, and migration ownership
   ledger update, then release it only after the run is recorded. A second runner must wait for this
   lock and must not perform preflight concurrently. Record the runner backend PID and verify the
   lock is held; if the session ends, the lock is released automatically and any partial state is
   handled only by the phase-aware recovery rule below.
2. Verify a recent restorable backup exists and record its backup ID, timestamp, restore check, and
   retention window. Capture `SELECT COUNT(*)` for `public.channels`, counts of any pre-existing
   objects named by this plan, the nullable-key count, and a schema-only `pg_dump`.
3. Inspect every planned table and column through `information_schema` before referencing it. A
   first-run database has no `commercial_channel` column or supporting tables; missing objects are
   recorded as absent and created by UP. Any existing object, index, constraint, trigger, or partial
   migration state is a hard stop for operator resolution unless the migration ID's ownership
   ledger proves it belongs to this exact retry.
4. Only when the discriminator already exists, conditionally verify that
   `public.channels.commercial_channel IS NOT TRUE` for every row. Only when each supporting table
   exists, conditionally verify it is empty; only when pointer columns exist, conditionally verify
   they are null. Never issue a query against a not-yet-created object.
5. Set a bounded `lock_timeout` and `statement_timeout`; schedule the metadata-lock phase in the
   lowest-traffic window. Monitor `pg_stat_activity`, `pg_locks`, and blocked-backend counts.

### 2. Create versioned supporting tables (transactional)

Create the following schema-qualified tables with identity primary keys and the exact foundation
columns. Every `CREATE TABLE` must use the `public.` qualifier and the migration runner's fixed
`search_path` must not be relied upon:

- `public.channel_cost_profiles`: `id bigint` identity primary key NOT NULL, `channel_id integer`
  NOT NULL, `version bigint` NOT NULL, `currency char(3)` NOT NULL default `USD`,
  `rounding_rule varchar(32)` NOT NULL default `half-up-at-attempt-total`,
  `effective_at timestamptz` NOT NULL, nullable `retired_at`, and `created_at timestamptz` NOT NULL
  default `now()`.
- `public.channel_cost_rates`: `id bigint` identity primary key NOT NULL, `cost_profile_id bigint`
  NOT NULL, `endpoint_class varchar(64)` NOT NULL, `public_model_alias varchar(128)` NOT NULL,
  `upstream_model varchar(255)` NOT NULL, `meter_dimension varchar(64)` NOT NULL,
  `price_numerator bigint` NOT NULL, `unit_denominator bigint` NOT NULL, and `created_at timestamptz`
  NOT NULL default `now()`.
- `public.channel_reliability_policies`: `id bigint` identity primary key NOT NULL, `channel_id integer`
  NOT NULL, `version bigint` NOT NULL, and positive
  bounded timeout/byte fields (`connect_timeout_ms`, `response_header_timeout_ms`,
  `first_semantic_event_timeout_ms`, `stream_idle_timeout_ms`, `stream_max_duration_ms`,
  `nonstream_total_timeout_ms`, `logical_precommit_deadline_ms`, `max_precommit_buffer_bytes`,
  `max_stream_bytes`, `max_response_bytes`), `retryable_statuses integer[]`, health-window and
  hysteresis fields (`window_seconds`, `bucket_seconds`, `degraded_error_rate_bps`,
  `open_error_rate_bps`, `degraded_p95_ms`, `recovery_p95_ms`, `minimum_samples`,
  `consecutive_failure_limit`, `cooldown_seconds`, `recovery_successes`,
  `latency_bucket_bounds_ms`), and `created_at timestamptz`.

Every reliability-policy field listed above, including `channel_id`, `version`, all bounded numeric
fields, arrays, and `created_at`, is `NOT NULL`; only `channel_cost_profiles.retired_at` is nullable.
`retryable_statuses` and `latency_bucket_bounds_ms` default to an empty integer array, and
`created_at` defaults to `now()`; the other reliability fields have no default. The migration runner
must record the exact column nullability/default contract in its ownership ledger before creating
each table.

All new tables are empty after creation. Do not create attempts, usage, health-transition,
capability, or parallel quota-reservation tables in this step.

### 3. Add native channel compatibility columns (transactional)

1. `ALTER TABLE public.channels ALTER COLUMN key DROP NOT NULL` (preserve existing values for legacy
   non-commercial channels).
2. Add the nullable reference/config columns and safe defaults exactly as listed above. The
   `commercial_channel` default is `false`; `config_version` default is `0`. No backfill resolves a
   secret, creates a commercial row, or changes native routing behavior.

### 4. Build unique indexes (non-transactional, concurrently)

On each target table, run `CREATE UNIQUE INDEX CONCURRENTLY` with deterministic names:

```sql
CREATE UNIQUE INDEX CONCURRENTLY ux_channel_cost_profiles_channel_id
  ON public.channel_cost_profiles (channel_id, id);
CREATE UNIQUE INDEX CONCURRENTLY ux_channel_cost_profiles_channel_version
  ON public.channel_cost_profiles (channel_id, version);
CREATE UNIQUE INDEX CONCURRENTLY ux_channel_cost_rates_dimension
  ON public.channel_cost_rates
    (cost_profile_id, endpoint_class, public_model_alias, upstream_model, meter_dimension);
CREATE UNIQUE INDEX CONCURRENTLY ux_channel_reliability_policies_channel_id
  ON public.channel_reliability_policies (channel_id, id);
CREATE UNIQUE INDEX CONCURRENTLY ux_channel_reliability_policies_channel_version
  ON public.channel_reliability_policies (channel_id, version);
```

If an index build fails, stop and remove only the invalid index after confirming
`pg_index.indisvalid = false`; do not proceed to constraints. No `CREATE INDEX CONCURRENTLY` is
run inside a transaction. The unique indexes provide the composite ownership keys required by the
foreign keys and are also the lookup paths for channel/version selection.

PostgreSQL renames a backing index when it is attached with `UNIQUE USING INDEX`: for example,
`ux_channel_cost_profiles_channel_id` becomes `uq_channel_cost_profiles_channel_id`. The ownership
ledger retains the logical phase-4 `ux_*` object name and records state `attached`; a retry must
verify that the corresponding `uq_*` constraint owns the renamed index and must not recreate a
redundant `ux_*` index. An invalid concurrent-build residue may be dropped and rebuilt only when
the exact migration ledger row and definition hash already own that `ux_*` name; an unowned or
valid mismatched object is a hard stop.

### 5. Add checks and foreign keys as `NOT VALID` (transactional)

Add `NOT VALID` checks, then validate in the next phase. Checks must enforce:

- `commercial_channel` implies `key IS NULL`, non-null `secret_ref`, non-null `auth_type`,
  non-null reliability and cost pointers, and `config_version > 0`.
- Commercial `secret_ref` matches the approved `env://NAME` grammar and contains no credential
  value. The auth checks explicitly require `auth_type IS NOT NULL` before the
  `bearer`/`fixed-header` allowlist; fixed-header requires a validated, non-empty header name with
  no control characters.
- Cost numerators are `0..1000000000`; denominators are `1..1000000000`.
- Reliability durations and health thresholds are positive and `<= 10000` where the approved
  contract bounds them. `max_precommit_buffer_bytes` is positive and `<= 1048576`;
  `max_stream_bytes` and `max_response_bytes` are positive and `<= 8388608`. Recovery thresholds
  provide hysteresis; status arrays and histogram bounds are allowlisted, ordered, and bounded.

The histogram predicate uses the schema-qualified immutable, strict
`public.fn_channel_latency_bucket_bounds_valid(integer[])` helper because PostgreSQL forbids a
subquery directly inside a `CHECK` constraint. The helper requires a one-dimensional array of at
most 32 strictly increasing values in `1..10000`. It is a plan-created phase-5 function with its
exact signature and definition hash recorded in the ownership ledger; retries cannot reuse a
pre-existing or mismatched function.

Use these deterministic names for the checks, each added with `NOT VALID` and validated in phase 6:
`ck_channels_commercial_activation`, `ck_channels_commercial_secret_ref`,
`ck_channels_commercial_auth`, `ck_channel_cost_rates_bounds`, and
`ck_channel_reliability_policies_bounds`. The migration ownership ledger must record each
constraint's schema-qualified table, name, normalized predicate-expression hash, and validation
result. The predicates are the exact boolean forms of the requirements listed above; no unnamed or
implicitly generated check may be used. These names are part of the rollback contract.

Attach the unique indexes to named constraints, then add these foreign keys with `ON DELETE
RESTRICT`. The names are part of the rollback contract:

```sql
ALTER TABLE public.channel_cost_profiles
  ADD CONSTRAINT uq_channel_cost_profiles_channel_id UNIQUE USING INDEX ux_channel_cost_profiles_channel_id;
ALTER TABLE public.channel_cost_profiles
  ADD CONSTRAINT uq_channel_cost_profiles_channel_version UNIQUE USING INDEX ux_channel_cost_profiles_channel_version;
ALTER TABLE public.channel_cost_rates
  ADD CONSTRAINT uq_channel_cost_rates_dimension UNIQUE USING INDEX ux_channel_cost_rates_dimension;
ALTER TABLE public.channel_reliability_policies
  ADD CONSTRAINT uq_channel_reliability_policies_channel_id UNIQUE USING INDEX ux_channel_reliability_policies_channel_id;
ALTER TABLE public.channel_reliability_policies
  ADD CONSTRAINT uq_channel_reliability_policies_channel_version UNIQUE USING INDEX ux_channel_reliability_policies_channel_version;

ALTER TABLE public.channel_cost_profiles
  ADD CONSTRAINT fk_channel_cost_profiles_channel_id FOREIGN KEY (channel_id)
  REFERENCES public.channels(id) ON DELETE RESTRICT;
ALTER TABLE public.channel_cost_rates
  ADD CONSTRAINT fk_channel_cost_rates_profile_id FOREIGN KEY (cost_profile_id)
  REFERENCES public.channel_cost_profiles(id) ON DELETE RESTRICT;
ALTER TABLE public.channel_reliability_policies
  ADD CONSTRAINT fk_channel_reliability_policies_channel_id FOREIGN KEY (channel_id)
  REFERENCES public.channels(id) ON DELETE RESTRICT;
ALTER TABLE public.channels
  ADD CONSTRAINT fk_channels_active_cost_profile FOREIGN KEY (id, active_cost_profile_id)
  REFERENCES public.channel_cost_profiles(channel_id, id)
  ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;
ALTER TABLE public.channels
  ADD CONSTRAINT fk_channels_reliability_policy FOREIGN KEY (id, reliability_policy_id)
  REFERENCES public.channel_reliability_policies(channel_id, id)
  ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;
```

The two pointer constraints are deferrable so a channel and its first version can be seeded in one
transaction; they still reject cross-channel references at commit. Do not add a foreign key to a
deferred runtime ledger.

The foundation immutability rules are database-owned and must be installed in this phase:

- `trg_channel_cost_profiles_immutable` rejects DELETE and every UPDATE except a single
  `retired_at: NULL -> non-NULL` transition; all economic/version/ownership fields are unchanged.
- `trg_channel_cost_rates_immutable` rejects UPDATE and DELETE.
- `trg_channel_reliability_policies_immutable` rejects UPDATE and DELETE.

Each trigger is `BEFORE UPDATE OR DELETE FOR EACH ROW`, schema-qualified, and raises a stable
migration error. The trigger DDL must include the explicit `FOR EACH ROW` clause; statement-level
defaults are not acceptable because the immutability function evaluates `OLD` and `NEW` values.
The trigger functions and trigger names are recorded in the migration ID so a rerun cannot silently
replace a pre-existing incompatible trigger. The allowed retirement transition is the only mutation
permitted for a cost profile after activation; no rate or reliability fact is rewritten.

### 6. Validate and hand off (transactional)

Run `VALIDATE CONSTRAINT` for every check and foreign key. Re-run the activation guard, verify all
new tables remain empty, and record `pg_constraint.convalidated`, `pg_indexes`, and the final
schema-only dump. Only after this plan's review gate may compatible application writers create
commercial channel configuration. This document does not authorize that deployment or activation.

This byte-bound correction is part of the original pre-release migration definition. No live or
production database has been authorized to run the earlier definition. A disposable local or test
database whose ownership ledger contains the earlier `ck_channel_reliability_policies_bounds`
definition hash must be discarded and recreated before this migration runs. The migration keeps
failing closed on every mismatched or unknown owned-object hash; it must not replace an applied
constraint in place. If the earlier hash is ever found on a non-disposable database, stop and use a
separately reviewed repair migration under the same advisory-lock, backup, verification, and
pre-activation empty-state rules. The existing conditional physical DOWN remains the rollback only
for a fully owned, pre-activation disposable installation.

## Conditional physical DOWN (pre-activation only)

Physical rollback is permitted only before any commercial write or activation and only after a
single locked proof. It is not a post-activation cleanup procedure. The migration ownership ledger
must prove that UP phases 1 through 6 completed for this migration ID and that every object being
dropped was created by it; if any phase is incomplete, any expected object is missing, or any object
pre-dates the migration or has unknown ownership, the generic DOWN procedure is forbidden and stops
without deletion. An interrupted partial UP requires a separately approved, phase-aware recovery
procedure that inspects the ownership ledger and reverses only confirmed completed phases in reverse
order; this plan does not authorize that recovery.

1. Acquire `SELECT pg_advisory_lock(19860810, 1011)` in the dedicated DOWN runner session before
   rechecking the ownership ledger. Retain it through the destructive transaction and DOWN ledger
   completion, then release it only after the outcome is recorded.
2. Close the application and direct database write paths. Acquire
   `LOCK TABLE public.channels, public.channel_cost_rates, public.channel_cost_profiles,
   public.channel_reliability_policies IN ACCESS EXCLUSIVE MODE` in that order and keep the lock
   until commit.
3. Assert, in the same transaction, that `public.channels.commercial_channel` is false for every
   row; all three new tables are empty; all channel pointers are null; and
   `COUNT(*) WHERE public.channels.key IS NULL = 0`.
4. Drop the pointer and child foreign-key constraints, the immutability triggers/functions, and all
   added checks. Drop the named unique constraints; their concurrently-built backing indexes are
   removed automatically with their owning constraints. Drop the three supporting tables.
5. Drop the added channel columns and restore `public.channels.key` to `NOT NULL`.
6. Commit only if every assertion passed; otherwise roll back without deleting anything. Record the
   pre/post schema dump and row counts. The migration ownership ledger is retained and marked
   `rolled_back` as the completion record; a later UP may reuse it only after revalidating the exact
   migration owner and object hashes. This guarded DOWN must never run after a commercial key,
   channel configuration, policy, or cost profile has been written.

## Post-activation operational rollback and retention

After the first commercial write, physical DOWN is forbidden. On a failed activation or runtime
regression:

1. Disable Checkout and new commercial key issuance.
2. Close admission and drain the gateway for the maximum request/lease TTL.
3. Return to the prior compatible application image while retaining this schema and every billing,
   audit, quota, usage, attempt, and cost/policy fact.
4. Preserve pending and delivery-uncertain commercial reservations until terminal recovery; never
   apply the legacy age-cleanup predicate to `commercial_record = true`.
5. Reopen only through the PostgreSQL/Redis epoch recovery sequence. Any physical cleanup requires a
   separate destructive migration, backup evidence, exact targets, and explicit scoped approval.

## Dry run and PostgreSQL verification

Dry-run uses two disposable PostgreSQL clones restored from the same schema/data-consistent staging
backup, never production. Clone A runs the preflight, UP phases, constraint/trigger validation, and
conditional DOWN with only legacy non-commercial rows; it must return to the captured baseline after
DOWN. Clone B runs UP and validation, then exercises a non-commercial channel with a legacy key and
a commercial fixture with a null key, reference-only secret, one cost profile/rate, and one
reliability policy. Clone B verifies a cross-channel pointer fails, invalid rates/policies fail,
immutability triggers reject UPDATE/DELETE, and the activation guard returns zero rows for valid
configuration. Before any commercial fixture is activated, run the prior committed application
image against Clone B and prove its non-commercial channel reads/writes and startup migration path
remain compatible with the nullable `public.channels.key` and additive tables. Clone B is not
rolled back physically. No real secret is loaded.

Required PostgreSQL evidence:

```sql
SELECT table_name, column_name, data_type, is_nullable, column_default
FROM information_schema.columns
WHERE table_schema = 'public'
  AND (table_name IN ('channels', 'channel_cost_profiles', 'channel_cost_rates',
                      'channel_reliability_policies'))
ORDER BY table_name, ordinal_position;

SELECT n.nspname AS table_schema, c.relname AS table_name,
       con.conname, con.contype, con.convalidated
FROM pg_constraint AS con
JOIN pg_class AS c ON c.oid = con.conrelid
JOIN pg_namespace AS n ON n.oid = c.relnamespace
WHERE n.nspname = 'public'
  AND c.relname IN ('channels', 'channel_cost_profiles', 'channel_cost_rates',
                    'channel_reliability_policies')
ORDER BY n.nspname, c.relname, con.conname;

SELECT n.nspname AS table_schema, c.relname AS table_name,
       i.relname AS index_name, x.indisvalid, x.indisready
FROM pg_index AS x
JOIN pg_class AS c ON c.oid = x.indrelid
JOIN pg_class AS i ON i.oid = x.indexrelid
JOIN pg_namespace AS n ON n.oid = c.relnamespace
WHERE n.nspname = 'public'
  AND c.relname IN ('channels', 'channel_cost_profiles', 'channel_cost_rates',
                    'channel_reliability_policies')
ORDER BY n.nspname, c.relname, i.relname;

SELECT l.pid, n.nspname AS relation_schema, c.relname AS relation_name,
       l.mode, l.granted
FROM pg_locks AS l
JOIN pg_class AS c ON c.oid = l.relation
JOIN pg_namespace AS n ON n.oid = c.relnamespace
WHERE l.relation IS NOT NULL
ORDER BY l.granted, n.nspname, c.relname, l.pid;

SELECT pid, classid, objid, mode, granted
FROM pg_locks
WHERE locktype = 'advisory'
  AND classid = 19860810
  AND objid = 1011
  AND mode = 'ExclusiveLock'
  AND granted IS TRUE;

SELECT n.nspname AS table_schema, c.relname AS table_name,
       t.tgname, t.tgenabled, ((t.tgtype & 1) = 1) AS is_row_level,
       pn.nspname AS function_schema, p.proname AS function_name
FROM pg_trigger AS t
JOIN pg_class AS c ON c.oid = t.tgrelid
JOIN pg_namespace AS n ON n.oid = c.relnamespace
JOIN pg_proc AS p ON p.oid = t.tgfoid
JOIN pg_namespace AS pn ON pn.oid = p.pronamespace
WHERE NOT t.tgisinternal
  AND n.nspname = 'public'
  AND t.tgname IN ('trg_channel_cost_profiles_immutable',
                   'trg_channel_cost_rates_immutable',
                   'trg_channel_reliability_policies_immutable')
ORDER BY n.nspname, c.relname, t.tgname;
```

Also verify: row counts before/after for `channels`; zero commercial channels before activation;
zero NULL legacy keys before a physical DOWN; zero invalid checks/FKs; composite pointer ownership;
unique `(channel_id, version)` and rate-dimension behavior; no resolved secret in rows, dumps, or
logs; and no unclassified `Channel.Key` reader in the pinned inventory.

## Explicit non-goals

- No live execution, commercial activation, Checkout enablement, key issuance, or production writer
  deployment.
- No `channel_attempts`, `channel_health_transitions`, logical usage, billing, subscription,
  token-verifier, Redis epoch, or quota-reservation schema work.
- No `capability_config` invention; no health-state column or durable health ledger.
- No provider URLs, credentials, model slugs, prices, or resolved secrets in migration data.
- No rename, drop, backfill of legacy channel keys, or removal of non-commercial `Channel.Key`
  compatibility.
- No destructive post-activation cleanup, retention deletion, or physical rollback after commercial
  writes.
