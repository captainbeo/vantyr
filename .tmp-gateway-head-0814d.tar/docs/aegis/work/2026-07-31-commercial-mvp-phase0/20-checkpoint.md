# Commercial MVP Phase 0 execution - Checkpoint

- Task ID: 2026-07-31-commercial-mvp-phase0
- Updated: 2026-08-10
- Current todo: Commit the verified Step 0.6 commercial MVP CI gate.
- Completed todos:
  - Step 0.1 pinned New API import and provenance baseline.
  - Step 0.2 local licence, attribution, source-offer, and publication-retirement implementation.
  - Step 0.3 restricted customer API, SSE, browser-auth, and Stripe event contracts.
  - Step 0.4 PostgreSQL forward/rollback migration contract and specialist database/security review.
  - Step 0.5 reproducible five-service Compose environment and independent specification/quality review.
  - Step 0.6 CI with positive baseline coverage, deliberate test/secret negative controls, and independent specification/quality-security reviews.
- Active slice: Step 0.6 evidence and separate commit closure.
- Evidence refs:
  - `docs/aegis/work/2026-07-31-commercial-mvp-phase0/90-evidence.md`
  - `docs/aegis/work/2026-07-31-commercial-mvp-phase0/evidence-bundle-draft-step-0-2.json`
  - `docs/aegis/work/2026-07-31-commercial-mvp-phase0/evidence-bundle-draft-step-0-3.json`
  - `docs/aegis/work/2026-07-31-commercial-mvp-phase0/evidence-bundle-draft-step-0-4.json`
  - `docs/aegis/work/2026-07-31-commercial-mvp-phase0/evidence-bundle-draft-step-0-5.json`
  - `docs/aegis/work/2026-07-31-commercial-mvp-phase0/evidence-bundle-draft-step-0-6.json`
- Blocked on: Public source, final image, deployment, and browser evidence remains release-only; hosted CI execution may remain unavailable until pushing is separately authorized.
- Next step: Commit Step 0.6 separately, then begin Phase 1 only under the approved plan and its applicable contract, security, database, and E2E gates.

## ResumeStateHint

- Resume from branch `codex/commercial-mvp` after the separate Step 0.6 commit.
- Do not rerun the frozen Step 0.6 local gate unless its committed inputs change.
- Hosted GitHub CI has not run because pushing is not authorized.
- Phase 0 review evidence does not authorize deployment, payment activation, customer invitation, push, or launch.

## DriftCheckDraft

- Scope status: Step 0.6 implementation, focused scanner RED/GREEN repairs, exact staged-tree secret proof, and independent reviews are complete; the separate Step 0.6 commit is the remaining local action.
- Compatibility status: The CI extends the pinned New API fork, preserves the Step 0.3 and 0.4 contracts and Step 0.5 Compose owner, and adds no runtime API, database, payment, quota, or routing behavior.
- Retirement status: No runtime owner, fallback, adapter, or duplicate path was added; ignored top-level Gitleaks allowlists were replaced by rule-scoped exact exceptions.
- New risk signals:
  - Deferred Minor: `UsageLogPageResponse` exposes `next_cursor` while `GET /api/log/self` accepts no cursor parameter.
  - Deferred Minor: equal Stripe `occurred_at` timestamps have no documented deterministic tie-break rule.
  - Deferred Minor: the mock OpenAPI server examples use `http://mock` instead of the two concrete Compose service names.
  - Deferred Minor: flat backend-network and rootful-runtime hardening remain later deployment concerns.
  - Inherited Stripe signature/raw-payload logging remains a Phase 4 repair gate and was not changed in Step 0.3.
  - Deferred Step 0.6 Minors: the manual failing-test control relies on runner-provided Go, the bounded workflow-dispatch choice is interpolated into a shell command, and some CI contract assertions are marker-based.
  - Real public-source, final-image, deployment, and browser evidence remain external release gaps.
- Advisory decision: continue
