# Commercial MVP Phase 0 execution - Intent

## TaskIntentDraft

- Requested outcome: Execute approved Phase 0 only, including all proofs and independent reviews, and stop before Phase 1 unless the gate is green.
- Goal: Produce a reproducible licensed New API foundation with reviewed API and migration contracts, PostgreSQL, fail-closed Redis inputs, two mock channels, and CI negative controls.
- Success evidence:
- Steps 0.1 through 0.6 each have fresh command evidence, risk-proportionate independent review at the project-defined gates, scoped commits, and the Phase 0 specialist gate has no blocker.
- Stop condition: Done only when the Phase 0 gate is green; otherwise stop as blocked, needs-verification, or scope-exceeded without entering Phase 1.
- Non-goals:
- Implement Phase 1 access, quota, limiter, routing, billing, or customer-dashboard behavior.
- Scope: Phase 0 of docs/plans/2026-07-31-commercial-mvp.md in codex/commercial-mvp worktree.
- Change kinds:
- implementation
- Risk hints:
- AGPL source-offer compliance, API exposure, schema authority, secret leakage, and false-positive infrastructure proofs.

## BaselineReadSetHint

- docs/plans/2026-07-31-commercial-mvp.md
- docs/specs/2026-07-30-channel-and-codex-compatibility-design.md
- docs/compliance/2026-07-31-new-api-license-compliance.md
- docs/upstream/new-api.md

## BaselineUsageDraft

- Required baseline refs:
- docs/plans/2026-07-31-commercial-mvp.md
- docs/specs/2026-07-30-channel-and-codex-compatibility-design.md
- docs/compliance/2026-07-31-new-api-license-compliance.md
- docs/upstream/new-api.md
- Acknowledged before plan:
- none
- Cited in plan:
- none
- Missing refs:
- docs/plans/2026-07-31-commercial-mvp.md
- docs/specs/2026-07-30-channel-and-codex-compatibility-design.md
- docs/compliance/2026-07-31-new-api-license-compliance.md
- docs/upstream/new-api.md
- Advisory decision: needs-baseline-readback

## ImpactStatementDraft

- Compatibility boundary: Codex CLI 0.146.0 normal Responses calls are SSE; retry is allowed only before customer-visible bytes are committed.
- Affected layers:
- documentation
- infrastructure
- contracts
- Owners:
- Platform owner
- Invariants:
- No Phase 1 implementation begins until every Phase 0 proof and review is green.
- Non-goals:
- Implement Phase 1 access, quota, limiter, routing, billing, or customer-dashboard behavior.

These records are Method Pack drafts / hints, not authoritative runtime decisions.

## Review procedure decision

- On 2026-08-02 the owner confirmed that the repository `AGENTS.md` risk-proportionate review policy controls Phase 0 execution.
- Step 0.3 uses one combined independent requirements/security/quality review and, after a material repair, one focused closure recheck of the repaired surface. A second broad reviewer is not required after that combined review passes.
- Specialist gates remain required for executable authentication, payment, database migration, quota, and secrets work.

## BaselineUsageDraft

- Required baseline refs:
- docs/plans/2026-07-31-commercial-mvp.md
- docs/specs/2026-07-30-channel-and-codex-compatibility-design.md
- docs/compliance/2026-07-31-new-api-license-compliance.md
- docs/upstream/new-api.md
- Delivered context refs:
- none
- Acknowledged before plan:
- docs/plans/2026-07-31-commercial-mvp.md
- docs/specs/2026-07-30-channel-and-codex-compatibility-design.md
- docs/compliance/2026-07-31-new-api-license-compliance.md
- docs/upstream/new-api.md
- Cited in plan:
- docs/plans/2026-07-31-commercial-mvp.md
- docs/specs/2026-07-30-channel-and-codex-compatibility-design.md
- docs/compliance/2026-07-31-new-api-license-compliance.md
- docs/upstream/new-api.md
- Missing refs:
- none
- Advisory decision: continue
