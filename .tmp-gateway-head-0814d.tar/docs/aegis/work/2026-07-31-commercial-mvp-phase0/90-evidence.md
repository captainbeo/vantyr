# Commercial MVP Phase 0 execution - Evidence

## Step 0.2 frozen state

- HEAD: `85fd43564632b09e45cda515b254ef2739cee396`
- Working-diff fingerprint: `fd59e359c9fe333d65b3122dc1a994f70617fce47155fe75bce6e6dafb2898b5`
- Fingerprint definition: canonical UTF-8 `git diff --binary HEAD` plus sorted untracked-file SHA-256 hashes.
- The fingerprint was recomputed after the final gate and was unchanged.

## Focused repair evidence

- Declared licence/provenance and rendered root-shell suite: 37 passed, 0 failed.
- Rendered states: normal, root error, not found, setup, authenticated, custom home, and custom footer.
- Targeted formatting, fork-introduced lint surfaces, Bash syntax, and five retired-workflow YAML documents passed.
- Remaining whole-file lint findings in `sync-i18n.mjs` and `footer.tsx` are inherited lines outside the fork delta; the delta lint passed with only those exact baseline rules scoped out.

## Final Step 0.2 gate

- `bun run license:test`: 37 passed, 0 failed.
- `bun run typecheck`: passed.
- Production frontend build with an immutable test source URL: passed once on the frozen diff.
- Missing and mutable production source URLs: both rejected with the exact required diagnostics.
- Configured artifact strings: attribution, upstream URL, and exact source URL present; the checker explicitly does not claim runtime or deployment proof.
- Targeted `oxfmt` and fork-delta `oxlint`: passed.
- `bash -n scripts/build-release-image.sh`: passed.
- Five retired GitHub workflow YAML files: parsed successfully.
- `git diff --check`: passed.
- Pinned `LICENSE`, `NOTICE`, and `THIRD-PARTY-LICENSES.md` Git blobs match upstream exactly.
- SHA-256: `LICENSE` `6f1e622c82a380075843bb084a7ec3b1f1d12a4a02526d75e78b0924a860aa75`; `NOTICE` `903b9ca441be6912459551f39b70338ee7a410eba6cce097043cf006622bd6bc`; `THIRD-PARTY-LICENSES.md` `4b2df02355ec9c5b4a4bd96d17c3960e0f0be183cafe100fccdd7395efd3f01b`; `FORK-NOTICE.md` `f0ff0f9f08c23eddc686832ad216a11802b7b3135a85cf593eeb900a5d697df9`.
- High-confidence secret scan: 43 Step 0.2 files scanned, 0 hits.

## Independent reviews

- Compliance re-review: PASS; no Critical, Important, or Minor findings.
- Code-quality/security review: PASS; no Critical or Important findings.
- Deferred Minor notes:
  - `FORK-NOTICE.md` names the two inherited image-publication workflows although five inherited artifact publishers are retired; the statement is narrower but not false and has no compliance impact.
  - Verify `scripts/build-release-image.sh` is staged with mode `100755` because the worktree has `core.filemode=false`.

## Uncovered release evidence

- Docker is unavailable on this host. Direct Docker-build rejection, a positive image build, OCI revision-label inspection, and `/licenses` inspection remain unverified rather than failed.
- No public fork/deployed commit, resolvable production Corresponding Source URL, published image digest, deployment record, or deployed signed-in/signed-out browser proof exists.
- The immutable test URL is build-configuration evidence only and must never be represented as production source evidence.

Local Step 0.2 implementation status: passed both reviews. External release status: blocked. Confidence: B, bounded by Docker and real deployment evidence.

## Step 0.3 frozen contract state

- Parent HEAD: `a46bb5438b73b19a829c8b7708ea301363f790fe`.
- Raw staged binary-diff SHA-256: `e8eb4761b02db76917383d7b1ce03f7dd80062e4bdb335ce73268e70f895fabb`.
- Fingerprint definition: raw bytes from `git diff --cached --binary`, hashed with SHA-256.
- Frozen scope: 18 staged files, zero unstaged files, and zero untracked files.
- The fingerprint was recomputed after the final gate and remained unchanged.

## Step 0.3 focused RED/GREEN evidence

- `TestAuthBundleResponseAcceptsPinnedLoginAndRefreshWireFields` initially failed because numeric `user.role/status` and `session.login_method/ip/user_agent` were rejected; it passed after the schema-only repair.
- `TestBrowserErrorResponseAcceptsPinnedTopLevelConflictCode` initially failed because the schema required nested `data.code`; it passed after `code` was moved to the runtime-compatible top level.
- The earlier focused regressions for the approved two-field SSE error and cold-cookie refresh/logout recovery also passed in the final package run.
- The external schema authority guard failed with the expected new digest and was updated to `96d0fe1ac15629bf9ae65392329cbcd1000cbc5023fdbcf8b80e77a848e57813` only after the schema repair.

## Final Step 0.3 gate

- `go test ./docs/contracts -count=1`: passed.
- `go vet ./docs/contracts`: passed.
- `go mod tidy -diff`: passed with no diff.
- `gofmt` check: 11 staged Go files clean.
- `git diff --cached --check`: passed.
- High-confidence secret scan: 18 staged files, 0 hits.

## Step 0.3 independent review

- One combined requirements/compliance, security, and quality review plus one focused closure recheck passed with no Critical or Important finding.
- The reviewer confirmed the auth response schemas preserve the pinned frontend/session wire fields, remain closed, and do not expose unrelated inherited user fields.
- Earlier SSE and refresh/logout findings remain closed.
- No runtime owner, fallback, duplicate path, retirement action, or ADR signal was introduced.
- Deferred Minor: `UsageLogPageResponse` exposes `next_cursor` while `GET /api/log/self` accepts no cursor parameter.

## Review procedure decision

- On 2026-08-02 the owner confirmed that the repository `AGENTS.md` risk-proportionate review policy controls this work.
- Step 0.3 therefore used one combined independent requirements/security/quality review and one focused repair closure recheck. No second broad reviewer was required after that pass.
- Specialist gates remain required for executable authentication, payment, database migration, quota, and secrets work.

## Step 0.3 boundaries and residual evidence

- This step defines the desired commercial contracts only; endpoint, webhook, and migration implementation remain unstarted.
- Live Codex and Stripe conformance are later implementation/integration gates.
- The inherited Stripe signature/raw-payload logging nonconformance remains assigned to Phase 4.
- Docker and real public source/image/deployment/browser evidence remain explicit external release gaps.

Local Step 0.3 contract status: passed the required gate and combined independent review. Phase 0 remains active at Step 0.4.

## Step 0.4 frozen migration-contract state

- Parent HEAD: `34c962efb7347a6635a8b49141ba246ef5527cf2`.
- Raw staged binary-diff bytes: `93854`.
- Raw staged binary-diff SHA-256: `595dd9d1fdce4f57b4f881844c81c00a04301407a38121c0280379b00b527e98`.
- Fingerprint definition: raw bytes from `git diff --cached --binary`, hashed with SHA-256.
- Frozen reviewed scope: two staged files, zero unstaged files, and zero untracked files.
- The fingerprint was recomputed after the final gate and remained unchanged.

## Step 0.4 focused RED/GREEN evidence

- Security RED checks first failed for incomplete Stripe replay identity, missing-versus-zero final usage/cost state, and unbounded audit detail persistence; the repaired contract passed.
- Database RED subtests then independently failed for cross-channel cost/policy references, omitted attempt latency/status evidence, incomplete reliability policy ownership, fake-tenant system probes, and incomplete logical-usage settlement identity; the repaired contract passed.
- Further focused RED checks failed for foreign-key ordering, native-reservation linkage, success/failure channel-cost binding, stale access-event ordering, mutable outbound billing-command identity/result, and divergent Stripe effect reuse; each passed after its minimum contract repair.
- No migration SQL, runtime database operation, deployment action, duplicate quota-reservation table, or new dependency was introduced.

## Final Step 0.4 gate

- `go test ./docs/migrations -count=1`: passed.
- `go vet ./docs/migrations`: passed.
- `go mod tidy -diff`: passed with no diff.
- `gofmt` check: the staged migration Go test is clean.
- `git diff --cached --check`: passed.
- High-confidence secret scan: two staged files scanned, 0 hits.
- Final fingerprint check: `93854` bytes and SHA-256 `595dd9d1fdce4f57b4f881844c81c00a04301407a38121c0280379b00b527e98`; zero unstaged and zero untracked files.

## Step 0.4 independent specialist reviews

- Database closure review: PASS on the final fingerprint; no Critical or Important findings.
- Security/quality closure review: PASS on the final fingerprint; no Critical or Important findings.
- Reviewers confirmed PostgreSQL owner binding, transaction/CAS and forward-order rules, retention/rollback, fail-closed epoch recovery, tenant isolation, missing-versus-zero accounting, immutable command/event/effect identity, deterministic replay behavior, and bounded non-sensitive audit details.
- Deferred Minor: equal Stripe `occurred_at` timestamps have no documented deterministic tie-break rule.

## Step 0.4 boundaries and residual evidence

- This step defines and approves the desired PostgreSQL migration contract only; executable migration SQL and runtime model/service changes remain unstarted.
- The native `subscription_pre_consume_records` table remains the sole request-quota reservation owner; `customer_usage_reservations` remains forbidden for this MVP.
- The inherited Stripe signature/raw-payload logging nonconformance remains assigned to the Phase 4 implementation gate.
- Docker and real public source/image/deployment/browser evidence remain explicit later-step or release gaps.

Local Step 0.4 contract status: passed the required final gate and both specialist reviews. Phase 0 remains active at Step 0.5.

## Step 0.5 frozen implementation state

- Parent HEAD: `2564b32266b931733a5322bb215eaabffe0558aa`.
- Reviewed implementation raw staged binary-diff bytes: `47948`.
- Reviewed implementation raw staged binary-diff SHA-256: `05aaa0ac65cc5adb5b7c6a620ca3e71334492f6c1c7085e3cc369f6debed185a`.
- Fingerprint definition: raw bytes from `git diff --cached --binary`, hashed with SHA-256.
- Frozen reviewed scope: 13 staged implementation files, zero unstaged files, and zero untracked files.
- The implementation fingerprint was recomputed after the exact staged-tree live proof and remained unchanged.

## Step 0.5 focused RED/GREEN evidence

- Relay and authenticated control trailing-overflow regressions first returned `400` instead of the contracted `413`; preserving the second JSON decode error and classifying `http.MaxBytesError` made both pass without mutating control state.
- The reproducibility regression first failed because the gateway runtime used moving Debian repositories. Immutable Debian snapshot URLs, disabled stale-metadata expiry, and four exact package versions passed after querying the pinned snapshot's actual candidates.
- The immutable-context regressions first found no Redis archived build context and a mutable gateway entrypoint mount. Gateway/Redis entrypoints are now image-owned, while Redis and both mock builds consume the same archived source context as the gateway.
- No customer endpoint, migration, billing, quota, routing, or production deployment behavior was added.

## Final Step 0.5 gate

- `go test ./deploy/mvp/... -count=1`: passed.
- `go vet ./deploy/mvp/...`: passed.
- `go mod tidy -diff`: passed with no diff.
- `gofmt` check: all three staged Go files are clean.
- Shell syntax: the three POSIX scripts and Bash verifier passed.
- `git diff --cached --check`: passed.
- High-confidence staged secret scan: 13 implementation files, 0 hits.
- Rendered Compose config: 5 services, required loopback bindings, `5714` bytes, and 0 generated-secret hits.
- Exact staged-tree verification commit `31c83182374ce61bd65fb8448ccf48bc13213a5a` built the gateway, Redis wrapper, and both mock stations from one immutable archive.
- `docker compose ... up --build --wait`: gateway, PostgreSQL, password-protected Redis, and both mocks became healthy; PostgreSQL, Redis, and mock relay ports remained unpublished.
- Both authenticated mock controls returned distinct expected `X-Mock-Station-ID` values in unavailable and normal modes.
- The disposable proof helper exited successfully and invoked project-scoped container/volume/temp-context cleanup.

## Step 0.5 independent reviews

- Specification/compliance closure review: PASS on the final implementation fingerprint; no Critical or Important findings.
- Quality/security/infrastructure closure review: PASS on the final implementation fingerprint; no Critical or Important findings.
- Reviewers confirmed the five-service topology, immutable source/runtime fence, digest and Debian-package pins, deployment-secret flow, loopback exposure, bounded authenticated mocks, and proof identity.
- Deferred Minor: the mock OpenAPI server examples use `http://mock` rather than the two concrete Compose service names.
- Deferred Minor: flat backend-network and rootful-runtime hardening remain later deployment concerns.

## Step 0.5 boundaries and residual evidence

- This is a local Phase 0 foundation only; no deployment, payment activation, customer invitation, push, or launch occurred.
- The local build used a syntactically valid immutable source URL for artifact checks; public Corresponding Source resolution remains a release-only evidence gap.
- Docker emitted a non-blocking Compose Bake/buildx warning; the direct Compose build and health proof still passed.

Local Step 0.5 status: passed the required final gate and both independent reviews. Phase 0 remains active at Step 0.6.

## Step 0.6 frozen CI state

- Parent HEAD: `a2dabb8534329055bb9b29ed996a677f011e5e35`.
- Reviewed staged tree: `aae4a43c3b56672c0d4565f9d8d3953bfb8b6dba`.
- Raw staged binary-diff bytes: `22496`.
- Raw staged binary-diff SHA-256: `157a22e379725c799a8b5193c631e66c780e29630136ddc01dc6fc6255be9787`.
- Fingerprint definition: raw bytes from `git diff --cached --binary`, hashed with SHA-256; the staged tree contains exactly four Step 0.6 files and no unstaged tracked changes. An unrelated untracked scanner scratch directory was kept outside the staged fingerprint and is removed after verification.

## Step 0.6 focused RED/GREEN evidence

- The pinned Gitleaks v8.24.2 baseline initially found five clean-tree false positives because the policy used ignored top-level allowlists, did not match `/repo` container paths, and treated exact multiline/private-key and masking fixtures too broadly.
- The focused repair moved exceptions to rule-scoped `[[rules.allowlists]]`, anchored each to an exact path suffix and line/match, split protocol/example literals in the contract test, and used an exact multiline private-key match.
- Before the repair, the pinned scanner failed on the clean staged tree. After the repair, the exact staged archive scan exited `0` with `no leaks found`.
- An adversarial extracted-tree edit adding dummy PEM-like material to an allowlisted Vertex line and a generic API-key literal produced two findings and exit `1`, proving the exceptions remain fail-closed.

## Step 0.6 final local gate

- `go test ./ci ./docs/migrations ./deploy/mvp/... -count=1`: passed.
- `go vet ./ci ./docs/migrations ./deploy/mvp/...`: passed.
- `go mod tidy -diff`: passed with no diff.
- `gofmt` check for `ci/ci_contract_test.go`: passed.
- `bash -n scripts/ci/negative-control.sh`: passed.
- Exact staged archive pinned Gitleaks scan: passed with zero leaks.
- Clean negative control: exit `0`; production-policy secret sentinel: exit `1` with one detected leak.
- `git diff --cached --check`: passed.

## Step 0.6 independent reviews

- Specification/compliance review: PASS on the exact staged tree, with no Critical or Important findings.
- Quality/security/infrastructure review: PASS on the exact staged tree, with no Critical or Important findings.
- Both reviewers confirmed the CI jobs and pinned tools are wired, the secret policy is scoped narrowly, and the scanner still detects changed secret material in previously allowlisted locations.
- Deferred Minors: the manual failing-test control relies on runner-provided Go; the bounded workflow-dispatch choice is interpolated into a shell argument; and some CI contract assertions are marker-based. These do not block Step 0.6 acceptance.

## Step 0.6 boundaries and evidence gaps

- Hosted GitHub execution, frontend/dependency audit, and Compose CI execution remain external runner evidence; local equivalents for the affected Go and scanner paths passed where available.
- No deployment, payment activation, customer invitation, push, or launch occurred.

Local Step 0.6 status: passed the required final gate and both independent reviews; ready for the separate Step 0.6 commit. Phase 0 remains active pending that commit.
