# Commercial MVP rescope and plan review - Intent

## TaskIntentDraft

- Requested outcome: Replace the oversized Step 1 execution plan with a concise secure commercial MVP plan while preserving the former plan as a non-blocking hardening roadmap.
- Goal: Produce an owner-reviewable commercial MVP plan with explicit gates for streaming Codex compatibility, direct-API enforcement, billing idempotency, fail-closed Redis limits, failover, and secret isolation.
- Success evidence:
- Concise plan and supporting scope/compliance artifacts pass mechanical validation and independent minimality, security, and traceability reviews with no unresolved blockers.
- Stop condition: Stop at the owner approval gate before product implementation; report external blockers separately; stop earlier only for conflicting authority or unverifiable requirements.
- Non-goals:
- Implement product code, import the upstream source into this repository, configure live credentials, or deploy infrastructure.
- Scope: Planning, compliance, project routing, and continuation records only; no product source, schema, deployment, or live external-system changes.
- Change kinds:
- plan
- Risk hints:
- A lean plan must not defer commercially essential SSE, access controls, Redis fail-closed enforcement, Stripe lifecycle idempotency, or failover proof.

## BaselineReadSetHint

- D:\Downloads\Codex_Build_Specification.docx
- docs/specs/2026-07-30-channel-and-codex-compatibility-design.md
- docs/plans/2026-07-31-step-1-foundation.md
- INIT.md
- .agent-sync/TEAM.md
- .agent-sync/ROUTING.md

## BaselineUsageDraft

- Required baseline refs:
- D:\Downloads\Codex_Build_Specification.docx
- docs/specs/2026-07-30-channel-and-codex-compatibility-design.md
- docs/plans/2026-07-31-step-1-foundation.md
- INIT.md
- .agent-sync/TEAM.md
- .agent-sync/ROUTING.md
- Acknowledged before plan:
- none
- Cited in plan:
- none
- Missing refs:
- D:\Downloads\Codex_Build_Specification.docx
- docs/specs/2026-07-30-channel-and-codex-compatibility-design.md
- docs/plans/2026-07-31-step-1-foundation.md
- INIT.md
- .agent-sync/TEAM.md
- .agent-sync/ROUTING.md
- Advisory decision: needs-baseline-readback

## ImpactStatementDraft

- Compatibility boundary: Codex CLI 0.146.0 normal Responses requests are SSE streaming; failover is allowed only before customer-visible response bytes are committed.
- Affected layers:
- documentation
- governance
- Owners:
- Platform owner
- Invariants:
- No product implementation begins before independent review and owner approval of the concise MVP plan.
- New API remains the gateway and enforcement boundary; PostgreSQL is durable state and Redis is mandatory for atomic concurrency and rate limiting.
- Non-goals:
- Implement product code, import the upstream source into this repository, configure live credentials, or deploy infrastructure.

These records are Method Pack drafts / hints, not authoritative runtime decisions.

## BaselineUsageDraft

- Required baseline refs:
- D:\Downloads\Codex_Build_Specification.docx
- docs/specs/2026-07-30-channel-and-codex-compatibility-design.md
- docs/plans/2026-07-31-step-1-foundation.md
- INIT.md
- .agent-sync/TEAM.md
- .agent-sync/ROUTING.md
- Delivered context refs:
- none
- Acknowledged before plan:
- D:\Downloads\Codex_Build_Specification.docx
- docs/specs/2026-07-30-channel-and-codex-compatibility-design.md
- docs/plans/2026-07-31-step-1-foundation.md
- INIT.md
- .agent-sync/TEAM.md
- .agent-sync/ROUTING.md
- Cited in plan:
- D:\Downloads\Codex_Build_Specification.docx
- docs/specs/2026-07-30-channel-and-codex-compatibility-design.md
- docs/plans/2026-07-31-step-1-foundation.md
- docs/compliance/2026-07-31-new-api-license-compliance.md
- Missing refs:
- none
- Advisory decision: continue
