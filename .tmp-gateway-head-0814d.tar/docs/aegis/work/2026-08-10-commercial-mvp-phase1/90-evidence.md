# Commercial MVP Phase 1 execution - Evidence

Evidence is recorded per step below.

## EvidenceBundleDraft

- Artifact key: step-1-1-migration-review
- Type: independent-review
- Source: /root/step11_migration_review
- Summary: Fresh 2026-08-10T19:26:41+02:00 review: no Critical, Important, or Minor findings; PASS for the Step 1.1 migration-plan/database gate.
- Verifier: independent-database-reviewer

## EvidenceBundleDraft

- Artifact key: step-1-1
- Type: verification-and-independent-specification-quality-security-reviews
- Source: Frozen staged Step 1.1 code diff at parent HEAD df39693ff3b40d1115e4a206dc584b6610d23a39, 48 staged files, and SHA-256 d969214b0a2735dd5e9b56a394d1afd6a50e4ab2a94ee796da6f6551797156c8
- Summary: Focused RED/GREEN checks passed for the commercial activation fence, reference-only writes, pre-migration compatibility, commercial and inactive channel filtering with orphan-model compatibility, raw-credential reader guards, migration structure, and controller/service/middleware boundaries. Independent specification/compliance and consolidated quality/security reviews reported no Critical or Important findings. Live PostgreSQL runtime migration proof remains unavailable and is not claimed.
- Verifier: Primary agent and independent specification/compliance and quality/security reviewers on 2026-08-11

## EvidenceBundleDraft

- Artifact key: step-1-2
- Type: verification-and-independent-specification-quality-security-reviews
- Source: Frozen staged Step 1.2 implementation diff at parent HEAD `2b0d5b0fd4ea56fad586f1c38959436d6ad69a82`; specification/compliance PASS at SHA-256 `9726ccbd071710532e211d1b4f56af2c6a8b0c6003c71e7299d8dbda5808c192`; final quality/security PASS at 46 staged files and SHA-256 `6bd1c83ea213737edbb1a491ab29b70969551359f076b8a9f003985814db02ce`.
- Summary: Focused RED/GREEN checks passed for reference-only environment-secret resolution, activation fencing, typed authentication, commercial adaptor eligibility, SSRF-safe transport, bounded request/response/SSE handling, sanitized errors and headers, unsupported legacy-path disablement, and static raw-key-reader protection. The final real-path regression first failed because eager SSE headers mislabeled a malformed-first-frame JSON error, then passed after commercial headers remained deferred to the validated stream owner. Independent reviews reported no Critical or Important findings. Two Minor debug-log findings are recorded and deferred.
- Verifier: Primary agent and independent specification/compliance and quality/security reviewers on 2026-08-11

## EvidenceBundleDraft

- Artifact key: step-1-3
- Type: verification-and-targeted-quality-security-review
- Source: Reviewer-approved staged Step 1.3 source tree `7cadfe8b8f295704e488d6699a61cc7a39896897` and canonical binary-diff SHA-256 `47d3bb0eeeaaf13a6d598869470c91f95ec920bfdde60a82525545591ca2a139` at parent HEAD `d62131ed2cf5e4491f3ee962fffbd5eb984a0758`; the later delta is mechanical evidence only.
- Summary: Focused RED/GREEN and affected checks passed for strict commercial `ResponseObject` output, exact request-scoped upstream-model matching in JSON/SSE, exact immutable cost-rate sets, transactional PostgreSQL conflict rollback with unchanged row counts, disposable database consent, direct JSON/SSE fixtures for both mock stations, and nil-safe inherited non-commercial Responses handling. The targeted independent recheck closed all five Important findings and the final one-line compatibility delta with no remaining Critical or Important finding. Focused Step 1.3 and affected package tests, affected `go vet`, `gofmt`, staged diff hygiene, JSON parsing, Aegis structure, and a 28-file focused staged secret scan passed with only two reviewed test fixtures. Unknown/duplicate seed JSON keys and equal relay credential values remain deferred Minor findings. Customer-authenticated gateway E2E remains assigned to Steps 1.4-1.7. The exact-tree Compose release build was attempted once and stopped because Docker BuildKit storage became read-only; WSL subsequently failed with `CreateInstance/E_FAIL`, so Compose and final Bash syntax evidence are not claimed as passed.
- Verifier: Primary agent and independent quality/security reviewer on 2026-08-12

## EvidenceBundleDraft

- Artifact key: thin-new-api-private-mvp-final
- Type: verification-and-targeted-security-review
- Source: Current codex/commercial-mvp worktree at HEAD 0a12e587 plus the unstaged thin private-MVP diff; staged gateway-key foundation remains preserved and out of scope.
- Summary: On 2026-08-13, the focused RED test for a completed response followed by a schema-valid duplicate sequence emitted one response.failed before the fix. Moving the commercial terminal guard before sequence monotonicity made the focused sequence/terminal tests pass. Fresh affected tests passed: go test ./model ./service ./middleware ./controller ./router ./relay/channel/openai -count=1; go test ./docs/contracts ./relay/helper -count=1; go test ./deploy/mvp -count=1. Both affected go vet groups passed, gofmt -l reported no files across 53 Go files, and git diff --check plus git diff --cached --check passed. Independent security/SSE re-review found no Critical or Important findings. After the authorized reboot restored D-backed Ubuntu WSL2, the exact command `wsl.exe bash -lc "cd /mnt/c/Users/z/Documents/worktrees/commercial-mvp; bash deploy/mvp/verify-compose.sh up"` passed: all five services became healthy, `config_port_bindings=passed`, `secret_value_hits=0`, `mock_channel_seed=passed counts=2|2|2|8`, `mock_control_identity=passed`, `mock_relay_isolation=passed`, and `compose_up_proof=passed` at source revision `0a12e5876ec613996c3f7eb431c2e349dac2fe00`. The Docker Bake/buildx warning was non-blocking. A read-only `golang:1.26.1-bookworm` full affected `-race` run passed model, middleware, controller, router, and relay/channel/openai but exposed unrelated inherited service task-polling races in `logger.logHelper` and Task state; the MVP-focused `Commercial|PrivateMVP|Gateway|AppendRequestPath` race selection passed all six packages. Ubuntu itself has no `go` or `gcc`, so the complete inherited race suite remains an evidence gap rather than a thin-MVP code failure.
- Verifier: Primary agent and independent security/SSE reviewer on 2026-08-13

## EvidenceBundleDraft

- Artifact key: thin-new-api-private-mvp-runtime-retry
- Type: external-runtime-verification
- Source: 2026-08-13 read-only host checks from the codex/commercial-mvp worktree; no source or staged files changed.
- Summary: D-backed WSL runtime check: D:\\WSL\\Ubuntu exists with ext4.vhdx (48,888,807,424 bytes) and D: reports approximately 3.4 TB free of 4.0 TB. wsl.exe --status succeeds and reports Ubuntu/WSL2 as default, but wsl.exe --list --verbose and wsl.exe --distribution Ubuntu --exec /bin/true fail with Wsl/EnumerateDistros/Service/CreateInstance/E_ACCESSDENIED. Windows service inspection reports WslService Running and LxssManager Stopped. No Compose up or WSL race retry was claimed; no distro re-registration/import/reset/delete was attempted.
- Verifier: Primary agent on 2026-08-13

## EvidenceBundleDraft

- Artifact key: thin-new-api-private-mvp-runtime-recovery
- Type: external-runtime-verification
- Source: 2026-08-13 host-recovery attempts from codex/commercial-mvp; no repository source or staged file changes.
- Summary: After confirming D:\\WSL\\Ubuntu and ext4.vhdx are present, wsl.exe --shutdown completed but wsl.exe --distribution Ubuntu --exec /bin/true and wsl.exe --list --verbose continued to fail with Wsl/Service/CreateInstance/E_ACCESSDENIED. Start-Service LxssManager was denied by Windows permissions. No WSL service restart, distro re-registration/import/reset/delete, Compose up retry, or WSL race test was performed after the denial.
- Verifier: Primary agent on 2026-08-13

## EvidenceBundleDraft

- Artifact key: thin-new-api-private-mvp-admin-recovery
- Type: external-runtime-verification
- Source: 2026-08-13 elevated host recovery attempts; repository and D-backed distro files were not modified.
- Summary: After wsl.exe --shutdown failed to restore Ubuntu access, elevated Start-Service LxssManager failed because Windows could not open the service, and elevated Restart-Service WslService failed because Windows could not stop/open the service. WSL remains unavailable for Compose up and race verification. No distro re-registration/import/reset/delete or host reboot was attempted.
- Verifier: Primary agent on 2026-08-13

## EvidenceBundleDraft

- Artifact key: thin-new-api-private-mvp-runtime-compose-pass
- Type: external-runtime-verification
- Source: compose-proof-2026-08-13
- Summary: D-backed Ubuntu WSL2 was running and the exact-tree Compose up proof passed via wsl.exe bash -lc with deploy/mvp/verify-compose.sh up. All five services became healthy; config_port_bindings=passed, secret_value_hits=0, mock_channel_seed=passed counts=2|2|2|8, mock_control_identity=passed, mock_relay_isolation=passed, and compose_up_proof=passed source_revision=0a12e5876ec613996c3f7eb431c2e349dac2fe00. Docker Bake/buildx warning was non-blocking.
- Verifier: Primary agent on 2026-08-13

## EvidenceBundleDraft

- Artifact key: thin-new-api-private-mvp-race
- Type: linux-race-verification
- Source: golang-1.26.1-bookworm-read-only-bind-2026-08-13
- Summary: A read-only golang:1.26.1-bookworm run with go test -race over ./model ./service ./middleware ./controller ./router ./relay/channel/openai passed model, middleware, controller, router, and relay/channel/openai, while inherited service task-polling tests reported races in logger.logHelper and Task state. The MVP-focused -run Commercial|PrivateMVP|Gateway|AppendRequestPath selection passed all six packages. Ubuntu itself has no go or gcc; the container supplied the race-capable toolchain. Full inherited race evidence remains unresolved and no unrelated service fix was made.
- Verifier: Primary agent on 2026-08-13

## EvidenceBundleDraft

- Artifact key: thin-new-api-private-mvp-handoff-refresh
- Type: resume-reconciliation-and-affected-gate
- Source: Resumed `codex/commercial-mvp` worktree on 2026-08-13; source and index were not mutated by the verification commands.
- Summary: `wsl.exe --distribution Ubuntu --exec /bin/true` passed. The exact `bash deploy/mvp/verify-compose.sh config` proof passed with PostgreSQL/Redis and loopback bindings, `secret_value_hits=0`, and source revision `0a12e5876ec613996c3f7eb431c2e349dac2fe00`. A read-only `golang:1.26.1-bookworm` container with the WSL module cache mounted read-only passed `go test ./model ./service ./middleware ./controller ./router ./relay/channel/openai ./docs/contracts ./relay/helper ./deploy/mvp -count=1` and `go vet` over the same packages; container `gofmt -l` reported no files. `git diff --check`, `git diff --cached --check`, and the Aegis `check`/`bundle` commands passed. The staged gateway-key/UI foundation, unstaged thin private-MVP changes, untracked artifacts, and separate Proxy Server worktree remain preserved. The inherited unfiltered service `-race` finding remains explicitly deferred.
- Verifier: Primary agent on 2026-08-13

## EvidenceBundleDraft

- Artifact key: thin-new-api-private-mvp-commit
- Type: isolated-commit-and-post-commit-verification
- Source: commit `1759e8b32ecfed510f820a53239dcc906166312d` on `codex/commercial-mvp`, parent `0a12e5876ec613996c3f7eb431c2e349dac2fe00`.
- Summary: The commit contains only the approved thin private-MVP source, tests, deployment contract, and Aegis evidence. The real index was reconstructed with the pre-existing 41 gateway-key/UI entries still staged; model bootstrap changes remain unstaged and uncommitted. Post-commit `go test ./model ./service ./middleware ./controller ./router ./relay/channel/openai ./docs/contracts ./relay/helper ./deploy/mvp -count=1` passed in the read-only cached Go container, `bash deploy/mvp/verify-compose.sh config` passed at the new revision, `git diff HEAD^ HEAD --check`, staged/unstaged diff checks, and Aegis check/bundle passed. The inherited full service race finding remains separate and deferred.
- Verifier: Primary agent on 2026-08-13
