# Commercial MVP Phase 1 execution - Intent

## TaskIntentDraft

- Requested outcome: Implement the approved Phase 1 working branded gateway and streamed Codex path in ordered, review-gated steps.
- Goal: Complete Phase 1 Steps 1.1 through 1.7 without expanding beyond the thin New API fork.
- Success evidence:
- Each Phase 1 step has focused RED/GREEN evidence and required specialist reviews.
- The Phase 1 gate passes with a fixture key completing the streamed Codex path through mock channels.
- Stop condition: Stop as done, blocked, needs-verification, or scope-exceeded at each step gate; do not deploy or launch.
- Non-goals:
- No live migration, production database operation, deployment, payment activation, customer invitation, push, or launch.
- No Step 1.2 runtime secret resolution or SSRF transport implementation in Step 1.1.
- Scope: Local implementation and testing of Phase 1 Steps 1.1 through 1.7 on codex/commercial-mvp.
- Change kinds:
- schema
- security
- gateway
- integration
- Risk hints:
- Channel secrets and legacy raw-key readers must not leak or bypass commercial mode.
- Schema changes require approved forward/rollback planning and PostgreSQL proof.

## BaselineReadSetHint

- docs/plans/2026-07-31-commercial-mvp.md
- docs/specs/2026-07-30-channel-and-codex-compatibility-design.md
- docs/migrations/2026-08-02-commercial-mvp-foundation.md
- docs/compliance/2026-07-31-new-api-license-compliance.md

## BaselineUsageDraft

- Required baseline refs:
- docs/plans/2026-07-31-commercial-mvp.md
- docs/specs/2026-07-30-channel-and-codex-compatibility-design.md
- docs/migrations/2026-08-02-commercial-mvp-foundation.md
- docs/compliance/2026-07-31-new-api-license-compliance.md
- Acknowledged before plan:
- none
- Cited in plan:
- none
- Missing refs:
- docs/plans/2026-07-31-commercial-mvp.md
- docs/specs/2026-07-30-channel-and-codex-compatibility-design.md
- docs/migrations/2026-08-02-commercial-mvp-foundation.md
- docs/compliance/2026-07-31-new-api-license-compliance.md
- Advisory decision: needs-baseline-readback

## ImpactStatementDraft

- Compatibility boundary: Preserve inherited non-commercial channel behavior while commercial mode rejects raw-key writes and full-key recovery.
- Affected layers:
- PostgreSQL channel configuration
- New API channel selection and relay
- Customer gateway authentication and routing
- Owners:
- Native New API Channel model remains the routing owner.
- PostgreSQL stores durable commercial channel configuration.
- Invariants:
- Commercial channels store only secret references and never resolved or raw secrets.
- Legacy Channel.Key remains non-commercial compatibility only until the reader inventory is closed.
- Non-goals:
- No live migration, production database operation, deployment, payment activation, customer invitation, push, or launch.
- No Step 1.2 runtime secret resolution or SSRF transport implementation in Step 1.1.

These records are Method Pack drafts / hints, not authoritative runtime decisions.

## BaselineUsageDraft

- Required baseline refs:
- docs/plans/2026-07-31-commercial-mvp.md
- docs/specs/2026-07-30-channel-and-codex-compatibility-design.md
- docs/migrations/2026-08-02-commercial-mvp-foundation.md
- docs/compliance/2026-07-31-new-api-license-compliance.md
- Delivered context refs:
- none
- Acknowledged before plan:
- docs/plans/2026-07-31-commercial-mvp.md
- docs/specs/2026-07-30-channel-and-codex-compatibility-design.md
- docs/migrations/2026-08-02-commercial-mvp-foundation.md
- docs/compliance/2026-07-31-new-api-license-compliance.md
- Cited in plan:
- docs/migrations/2026-08-10-commercial-channel-foundation.md
- Missing refs:
- none
- Advisory decision: continue
