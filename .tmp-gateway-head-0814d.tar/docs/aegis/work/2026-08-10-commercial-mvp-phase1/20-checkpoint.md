# Commercial MVP Phase 1 execution - Checkpoint

- Task ID: 2026-08-10-commercial-mvp-phase1
- Current todo: Prepare and review the Step 1.1 channel migration and raw-key reader inventory.
- Active slice: Step 1.1 migration planning and reader inventory before schema edits.
- Blocked on: Independent database/security approval of the executable migration plan before schema code.
- Next step: Finish the reader inventory, review the migration plan, then begin focused RED tests for Step 1.1.

## Checkpoint Update

- Current todo: Write and run focused failing Step 1.1 tests.
- Active slice: Step 1.1 strict RED tests before schema and model implementation.
- Completed todos:
- Migration contract and raw-key reader inventory prepared.
- Independent database migration review passed with no findings.
- Evidence refs:
- docs/migrations/2026-08-10-commercial-channel-foundation.md
- docs/migrations/2026-08-10-commercial-channel-key-reader-inventory.md
- docs/aegis/work/2026-08-10-commercial-mvp-phase1/evidence-bundle-draft-step-1-1-migration-review.json
- Blocked on: none
- Next step: Dispatch one Step 1.1 implementer with the approved contract and require focused RED evidence before implementation.

## DriftCheckDraft

- Scope status: Step 1.1 plan and inventory only; no Step 1.2 runtime work.
- Compatibility status: Non-commercial raw Channel.Key behavior remains supported; commercial raw-key writes/recovery must be rejected.
- Retirement status: Legacy raw-key readers are inventoried for Step 1.2 migration; no reader is silently retired in Step 1.1.
- New risk signals:
- PostgreSQL Clone A/B round-trip and prior-image compatibility remain required implementation evidence.
- Advisory decision: continue

## Checkpoint Update

- Current todo: Commit the verified Step 1.1 commercial channel foundation.
- Active slice: Step 1.1 evidence and separate commit closure.
- Completed todos:
- Migration contract and Channel.Key reader inventory prepared and independently approved.
- Commercial channel PostgreSQL migration, ownership ledger, guarded rollback, reference-only model, and activation fence implemented.
- Focused RED/GREEN compatibility, raw-credential fence, migration, model, controller, service, relay, and middleware evidence passed.
- Independent specification/compliance review and consolidated quality/security review passed with no Critical or Important findings.
- Evidence refs:
- docs/migrations/2026-08-10-commercial-channel-foundation.md
- docs/migrations/2026-08-10-commercial-channel-key-reader-inventory.md
- docs/aegis/work/2026-08-10-commercial-mvp-phase1/evidence-bundle-draft-step-1-1-migration-review.json
- docs/aegis/work/2026-08-10-commercial-mvp-phase1/evidence-bundle-draft-step-1-1.json
- Blocked on: Live PostgreSQL Clone A/B runtime proof remains unavailable; this is an explicit external evidence gap, not a local commit blocker.
- Next step: Run structural and affected final checks, commit Step 1.1 separately, then begin Step 1.2 under the approved plan.

## DriftCheckDraft

- Scope status: Step 1.1 commercial channel foundation is implemented and reviewed; no Step 1.2 resolver or transport work is included.
- Compatibility status: Legacy non-commercial and orphan-ability behavior is preserved while existing disabled and commercial channels are excluded from selection and model availability.
- Retirement status: Legacy raw-key readers remain non-commercial compatibility only and are fenced for commercial channels; Step 1.2 owns resolver conversion or central commercial-mode disablement.
- New risk signals:
- Live PostgreSQL Clone A/B runtime proof is unavailable for the latest migration implementation.
- Commercial activation remains blocked until Step 1.2 resolver and transport gates pass.
- Advisory decision: continue

## Checkpoint Update

- Current todo: Run the structural and affected final Step 1.2 checks, then commit the step separately.
- Active slice: Step 1.2 evidence and separate commit closure.
- Completed todos:
- Added fail-closed `env://` resolution, typed commercial authentication, request/response header policy, and bounded SSRF-safe transport behavior.
- Disabled unsupported inherited commercial relay, task, probe, and credential-refresh paths while preserving non-commercial compatibility.
- Added exact commercial SSE schema, byte-limit, timeout, sanitization, and delayed-header validation.
- Focused RED/GREEN regressions passed, including the real `DoApiRequest` malformed-first-frame path.
- Independent specification/compliance and consolidated quality/security reviews passed with no Critical or Important findings.
- Evidence refs:
- docs/migrations/2026-08-10-commercial-channel-key-reader-inventory.md
- docs/aegis/work/2026-08-10-commercial-mvp-phase1/evidence-bundle-draft-step-1-2.json
- Blocked on: No local Step 1.2 blocker. Live supplier credentials, resale authorization, and production egress configuration remain later external gates.
- Next step: Run the Aegis structural checks and affected final gate once, commit Step 1.2 separately, then begin Step 1.3.

## DriftCheckDraft

- Scope status: Step 1.2 commercial secret resolution, transport, header, error, and supported-relay boundaries are implemented and reviewed; no Step 1.3 channel seeding or routing work is included.
- Compatibility status: Inherited non-commercial channel behavior remains available; commercial mode is limited to Codex Responses/compact through OpenAI and Codex adaptors and fails closed elsewhere.
- Retirement status: Commercial request paths no longer depend on stored raw channel keys. Unsupported inherited key-reading jobs and relay modes are centrally rejected or skipped in commercial mode; their non-commercial behavior is retained.
- New risk signals:
- Commercial debug mode can still log transformed prompt bodies.
- Commercial debug transport logs can still include upstream hostnames.
- Live supplier and production egress behavior remain unverified external evidence.
- Advisory decision: continue

## Checkpoint Update

- Current todo: Add and run focused failing Step 1.3 regressions.
- Active slice: Step 1.3 mock-channel seed, credential/model isolation, attempt capture, and public-alias response proof.
- Completed todos:
- Step 1.2 was committed separately at `d62131ed2cf5e4491f3ee962fffbd5eb984a0758`.
- Step 1.3 plan, compatibility baseline, current checkpoint, startup fence, channel policy owners, mock server, and Responses handlers were read back.
- Blocked on: none
- Next step: Add tests only, record deterministic RED output, then implement the smallest GREEN change.

### Slice Card

- Goal: Seed two enabled mock channels after the existing restart fence and prove independent mapped JSON/SSE relay attempts without exposing credentials, internal model slugs, station headers, or raw upstream errors.
- Parent plan/spec: `docs/plans/2026-07-31-commercial-mvp.md` Step 1.3 and `docs/specs/2026-07-30-channel-and-codex-compatibility-design.md` Step 1 deliverables.
- Files: focused seed service/tests, Compose fixture/config, mock fixture/tests/contract, Responses handler/tests, startup wiring, and existing Phase 1 evidence records.
- Boundary: No schema migration, failover, health scoring, durable attempt rows, customer-key work, Step 1.4, or non-commercial behavior change.
- Verification: Focused RED/GREEN for seeding, mock credential/model capture, Compose wiring, and commercial JSON/SSE alias rewriting; then one frozen targeted review and one affected final gate.
- Stop: Step 1.3 committed separately, or precisely blocked by a remaining Critical/Important finding or unavailable required infrastructure.

### Complexity Budget

- Artifact class: Source, test, and deployment configuration complexity.
- Target files / artifacts: A new focused seed owner, existing small mock server and Responses handler, Compose fixture/config, and focused tests.
- Current pressure: The migration owner is already oversized and immutable cost/reliability records require exact idempotent handling; the mock and response owners remain cohesive.
- Projected post-change pressure: Seed logic stays out of the migration owner; mock capture keeps only bounded aggregate/last-attempt metadata; response rewriting adds one commercial-only helper path.
- Budget result: within-budget
- Planned governance: Add one seed owner file, reject ambiguous configuration, preserve immutable version rows, and avoid new routing/failover abstractions.

### Pre-Edit Complexity Check

- Safer edit boundary: Deployment seeding belongs in the service layer after `model.InitDB`; mock validation/capture belongs in `deploy/mvp/mock`; public alias rewriting belongs beside the OpenAI Responses handlers.
- Decision: add owner file for seeding; edit existing cohesive mock and response owners in place.

## DriftCheckDraft

- Scope status: The planned Step 1.3 slice remains inside the accepted two-mock fixture and reverse-mapping proof.
- Compatibility status: Non-commercial relay output remains byte-preserving; only commercial Responses output will rewrite the model field to the request-scoped public alias.
- Retirement status: No fallback, adapter, or old path is added or retired; the existing migration restart activation fence remains authoritative.
- New risk signals: Attempt capture must never retain raw credentials or bodies; immutable cost/reliability seed records must fail on configuration drift rather than mutate history.
- Advisory decision: continue

## Checkpoint Update

- Current todo: Commit Step 1.3 separately.
- Active slice: Step 1.3 separate commit closure.
- Completed todos:
- Step 1.2 was committed separately at d62131ed2cf5e4491f3ee962fffbd5eb984a0758.
- Two commercial mock channels, restart activation fence, credential/model isolation, bounded attempt capture, and public alias rewriting were implemented.
- All five consolidated Important review findings were repaired with focused RED/GREEN evidence.
- Disposable PostgreSQL seed idempotency, exact rate-set conflict, transaction rollback, and unchanged row-count proof passed.
- The affected package gate exposed a nil `ChannelMeta` panic in inherited non-commercial Responses billing tests; a one-line nil-safe commercial-mode check passed the focused inherited and commercial JSON/SSE regressions.
- The targeted independent quality/security delta recheck passed source tree `7cadfe8b8f295704e488d6699a61cc7a39896897` and canonical binary-diff SHA-256 `47d3bb0eeeaaf13a6d598869470c91f95ec920bfdde60a82525545591ca2a139` with no remaining Critical or Important findings.
- Focused Step 1.3 tests, affected package tests and `go vet`, formatting, staged-diff hygiene, JSON parsing, Aegis structure, and the focused staged secret scan passed.
- Evidence refs:
- docs/aegis/work/2026-08-10-commercial-mvp-phase1/evidence-bundle-draft-step-1-3.json
- Blocked on: Exact-tree Compose `up` proof is unavailable because Docker BuildKit/containerd storage became read-only and WSL restart failed with `CreateInstance/E_FAIL`. Focused code, contract, mock, and disposable PostgreSQL evidence passed; the Compose result is not claimed.
- Next step: Commit Step 1.3 separately, then begin Step 1.4.

## DriftCheckDraft

- Scope status: Step 1.3 remains limited to two mock-channel seed and restart activation, isolated credentials/models, bounded attempt capture, and commercial JSON/SSE public-alias output.
- Compatibility status: Non-commercial response handling remains unchanged; commercial JSON and SSE fail closed unless the selected upstream model and canonical customer contract match.
- Retirement status: No legacy subsystem was newly retired. The restart activation fence and Step 1.2 commercial resolver remain authoritative; customer-key and full gateway traversal work remains in Steps 1.4-1.7.
- New risk signals:
- Exact-tree Compose `up` remains unverified because Docker/WSL storage failed read-only during the release build.
- Seed JSON unknown/duplicate keys and equal configured relay credential values are deferred Minor hardening findings.
- Advisory decision: continue

## Checkpoint Update

- Current todo: Close the thin New API private MVP review and evidence gate without touching deferred staged work.
- Active slice: Thin New API private MVP final review, evidence, and structural proof closure.
- Completed todos:
- Private-mode route allowlisting, root aliases, Bearer-only enforcement, and legacy-route rejection are implemented and tested.
- Commercial-only channel/model selection, alias mapping, JSON/SSE/compact sanitization, bounded streaming, and sequence ordering are implemented and tested.
- The security review finding for a post-completed duplicate/decreasing SSE sequence was reproduced RED, fixed by guard reordering, and reverified GREEN.
- Affected tests, vet, gofmt, staged/unstaged diff checks, and Aegis index repair passed on 2026-08-13.
- Evidence refs:
- docs/aegis/work/2026-08-10-commercial-mvp-phase1/evidence-bundle-draft-thin-new-api-private-mvp-final.json
- docs/aegis/work/2026-08-10-commercial-mvp-phase1/90-evidence.md
- Blocked on: Compose structural config proof passed, but the exact-tree `up` proof timed out after 124 seconds and the subsequent WSL invocation returned `CreateInstance/E_ACCESSDENIED`; Windows Go race evidence is unavailable because CGO is disabled. These are explicit external evidence gaps; no local affected-gate blocker remains.
- Next step: Run Aegis check and bundle, confirm the final worktree fingerprint and review result, then hand off the separate private-MVP diff while preserving staged and untracked user work.

## DriftCheckDraft

- Scope status: The slice remains limited to the approved thin New API private route, model, relay, deployment-contract, and proof boundary; no payments, public launch, or second gateway owner was added.
- Compatibility status: Native New API token/group/model/quota/usage ownership remains canonical; non-commercial behavior and the staged deferred gateway-key work are preserved.
- Retirement status: Unsupported private legacy routes remain centrally unavailable rather than deleted; the staged gateway-key and broader commercial hardening tracks remain explicit deferred work.
- New risk signals:
- Compose config proof passed, but Compose/WSL `up` and race evidence remain external gaps; a bounded sequence-max failure edge remains Minor and deferred.
- Advisory decision: continue

## Checkpoint Update

- Current todo: Restore D-backed WSL runtime access or record the external blocker without changing the private MVP code.
- Active slice: D-backed WSL runtime recovery check for the exact Compose and race evidence gate.
- Completed todos:
- Verified D:\\WSL\\Ubuntu exists with ext4.vhdx and ample free space; no C: path assumption was used.
- wsl.exe --status reports Ubuntu as the default WSL2 distribution, but --list --verbose and --distribution Ubuntu --exec /bin/true fail with CreateInstance/E_ACCESSDENIED.
- Confirmed the existing local code/test/Aegis gate remains unchanged; no code, staged work, or untracked work was modified in this runtime slice.
- Evidence refs:
- docs/aegis/work/2026-08-10-commercial-mvp-phase1/evidence-bundle-draft-thin-new-api-private-mvp-runtime-retry.json
- docs/aegis/work/2026-08-10-commercial-mvp-phase1/90-evidence.md
- Blocked on: WSL service access is denied when enumerating or starting the D-backed Ubuntu distro. The local code gate is green; exact Compose up and WSL race evidence cannot run until WSL access recovers.
- Next step: Have the WSL service/distro access restored externally, then rerun verify-compose.sh up and the affected Go tests with -race inside WSL. Do not re-register, import, reset, or delete the D-backed distro from this slice.

## DriftCheckDraft

- Scope status: The runtime slice remains limited to host proof for the approved thin New API private MVP; no application owner, route, schema, or deployment contract was changed.
- Compatibility status: Native New API ownership, non-commercial compatibility, staged deferred gateway-key work, and all user changes remain preserved.
- Retirement status: No legacy path or runtime distribution was retired; D-backed WSL state was inspected only, with no re-registration or destructive recovery attempted.
- New risk signals:
- D:\\WSL\\Ubuntu exists, but WSL CreateInstance/EnumerateDistros returns E_ACCESSDENIED; exact Compose up and WSL race evidence need external recovery.
- Advisory decision: needs-verification

## Historical Checkpoint Update (superseded by the final handoff record below)

- Current todo: Hand off the thin New API private MVP evidence slice with the inherited full-race gap explicit.
- Active slice: Resume reconciliation and affected-gate refresh; no application-code or index mutation.
- Completed todos:
- Reconciled the live worktree against the checkpoint: the staged gateway-key/UI foundation, unstaged thin private-MVP changes, untracked evidence/cache artifacts, and the separate Proxy Server worktree remain preserved.
- Confirmed D-backed Ubuntu WSL2 starts successfully; `/bin/true` and the Compose structural proof passed after resume.
- Fresh read-only container verification passed all affected tests, `go vet`, container `gofmt -l`, `git diff --check`, and `git diff --cached --check`.
- Evidence refs:
- docs/aegis/work/2026-08-10-commercial-mvp-phase1/evidence-bundle-draft-thin-new-api-private-mvp-handoff-refresh.json
- docs/aegis/work/2026-08-10-commercial-mvp-phase1/90-evidence.md
- Blocked on: The unfiltered Linux `-race` suite remains non-green only in inherited service task-polling tests (`logger.logHelper` and `Task` state); the MVP-focused race selection remains passed. No thin-MVP local gate is blocked.
- Next step: Keep the thin private-MVP diff as a local handoff until explicit authority is given to isolate and commit it; do not stage, commit, push, deploy, or launch the preserved gateway-key or unrelated work.

## DriftCheckDraft

- Scope status: The refresh stayed within the approved thin private route/model/relay/deployment proof and handoff boundary; no payments, public launch, or second gateway owner was added.
- Compatibility status: Native New API token, group, model, quota, usage, and routing ownership remains canonical; staged gateway-key work and all unrelated changes remain untouched.
- Retirement status: Unsupported private legacy routes remain centrally unavailable rather than deleted; the inherited task-polling race and broader commercial hardening remain deferred.
- New risk signals:
- The complete inherited Linux `-race` suite remains unresolved outside this slice; Ubuntu has no native Go toolchain, so the focused evidence uses a read-only cached Go container.
- A bounded sequence-max failure edge and the non-blocking Docker Bake/buildx warning remain Minor/deferred.
- Advisory decision: needs-verification

## Checkpoint Update

- Current todo: Preserve the isolated thin private-MVP commit and the staged gateway-key/UI foundation as separate tracks.
- Active slice: Post-commit handoff verification.
- Completed todos:
- Created commit `1759e8b32ecfed510f820a53239dcc906166312d` with only the approved thin private-MVP source, tests, deployment contract, and handoff evidence.
- Reconstructed the real index so the pre-existing 41 gateway-key/UI entries remain staged; the three overlapping deployment files retain only their gateway-key hunks in the index.
- Post-commit affected tests, Compose config, Git diff checks, and Aegis check/bundle passed.
- Evidence refs:
- docs/aegis/work/2026-08-10-commercial-mvp-phase1/evidence-bundle-draft-thin-new-api-private-mvp-commit.json
- docs/aegis/work/2026-08-10-commercial-mvp-phase1/90-evidence.md
- Blocked on: The inherited unfiltered Linux `-race` suite remains non-green only in unrelated service task-polling tests; the focused private-MVP race selection and post-commit affected gate pass.
- Next step: Review the isolated commit and decide the next commercial hardening gate; keep the staged gateway-key/UI work, model bootstrap fixes, cache directories, and other untracked work separate until separately authorized.

## DriftCheckDraft

- Scope status: The commit stayed inside the approved thin private route/model/relay/deployment/evidence boundary; no payment, public launch, second gateway owner, or unrelated bootstrap fix was included.
- Compatibility status: Native New API ownership remains canonical; the staged gateway-key/UI foundation is preserved as a separate index track.
- Retirement status: Unsupported private legacy routes remain centrally unavailable rather than deleted; inherited task-polling races and broader commercial hardening remain deferred.
- New risk signals:
- Full inherited Linux `-race` evidence remains unresolved outside the committed thin slice.
- Advisory decision: needs-verification

## Checkpoint Update

- Current todo: Obtain host-admin recovery for the D-backed WSL runtime before retrying the exact Compose and race gates.
- Active slice: External WSL service recovery boundary for the private MVP runtime proof.
- Completed todos:
- wsl.exe --shutdown completed without changing the D-backed distro, but Ubuntu still failed to start with CreateInstance/E_ACCESSDENIED.
- Starting LxssManager was denied by Windows permissions; no service restart, distro re-registration, import, reset, or deletion was performed.
- Evidence refs:
- docs/aegis/work/2026-08-10-commercial-mvp-phase1/evidence-bundle-draft-thin-new-api-private-mvp-runtime-recovery.json
- docs/aegis/work/2026-08-10-commercial-mvp-phase1/90-evidence.md
- Blocked on: Host-admin WSL recovery is required: the D-backed Ubuntu distro cannot be enumerated or started from this session, and LxssManager start is denied. Local code and structural Compose gates remain green.
- Next step: Restore WSL service/distro access externally, then verify wsl.exe --distribution Ubuntu --exec /bin/true, run verify-compose.sh up, and run affected Go tests with -race. Preserve all repository changes.

## DriftCheckDraft

- Scope status: The slice remains limited to external host recovery for the approved thin New API private MVP runtime proof; no application, route, schema, or deployment-contract owner changed.
- Compatibility status: Native New API ownership, non-commercial compatibility, staged deferred gateway-key work, and all user changes remain preserved.
- Retirement status: No code path or distro was retired; only non-destructive WSL shutdown and read-only service inspection were attempted.
- New risk signals:
- WSL shutdown did not restore access and LxssManager start was denied; host-admin recovery is required before Compose up or WSL race evidence.
- Advisory decision: needs-verification

## Checkpoint Update

- Current todo: Recover WSL outside the repository task before retrying the exact Compose and race gates.
- Active slice: Host-admin WSL recovery is outside the repository sandbox boundary.
- Completed todos:
- Elevated Start-Service LxssManager was rejected because Windows could not open the service.
- Elevated Restart-Service WslService was rejected because Windows could not stop/open the service.
- Evidence refs:
- docs/aegis/work/2026-08-10-commercial-mvp-phase1/evidence-bundle-draft-thin-new-api-private-mvp-admin-recovery.json
- docs/aegis/work/2026-08-10-commercial-mvp-phase1/90-evidence.md
- Blocked on: Windows service control remains unavailable even with elevation; Ubuntu cannot be started from this session. No repository or distro mutation is authorized beyond the attempted reversible service actions.
- Next step: Restart Windows or repair WSL service access externally, then verify Ubuntu starts before rerunning Compose up and WSL race tests.

## DriftCheckDraft

- Scope status: The slice remains limited to host-admin recovery for runtime proof; no application or deployment-contract code changed.
- Compatibility status: All New API ownership, staged deferred work, and user changes remain preserved.
- Retirement status: No code path or D-backed distro was retired or rewritten; only reversible service control was attempted.
- New risk signals:
- Elevated Windows service control is denied for both LxssManager and WslService; host reboot or WSL repair is required externally.
- Advisory decision: needs-verification

## Checkpoint Update

- Current todo: Close the thin New API private MVP evidence gate; retain the inherited full-race gap for owner review.
- Active slice: Runtime Compose proof and Linux race evidence boundary for the approved thin private MVP.
- Completed todos:
- Private-mode route allowlisting, root aliases, Bearer-only enforcement, legacy-route rejection, commercial model selection, response sanitization, bounded streaming, and sequence ordering are implemented and tested.
- Affected Go, contract/helper, and deployment tests; affected vet; gofmt; diff hygiene; and independent security/SSE review passed with no Critical or Important findings.
- Authorized reboot restored D-backed Ubuntu WSL2; /bin/true succeeded and the exact Compose up proof passed with all five services healthy and the recorded mock-isolation checks.
- The MVP-focused Linux -race selection passed model, service, middleware, controller, router, and relay/channel/openai in a read-only golang:1.26.1-bookworm container.
- Evidence refs:
- docs/aegis/work/2026-08-10-commercial-mvp-phase1/evidence-bundle-draft-thin-new-api-private-mvp-final.json
- docs/aegis/work/2026-08-10-commercial-mvp-phase1/evidence-bundle-draft-thin-new-api-private-mvp-runtime-compose-pass.json
- docs/aegis/work/2026-08-10-commercial-mvp-phase1/evidence-bundle-draft-thin-new-api-private-mvp-race.json
- docs/aegis/work/2026-08-10-commercial-mvp-phase1/90-evidence.md
- Blocked on: The unfiltered Linux -race suite is not green because unrelated inherited service task-polling tests report races in logger.logHelper and Task state; the MVP-focused race selection passes, and no thin-MVP local code gate is blocked.
- Next step: Run the Aegis bundle and check, validate the generated artifacts, record the final worktree fingerprint, and hand off without staging or committing.

## DriftCheckDraft

- Scope status: The slice remains limited to the approved thin New API private route, model, relay, deployment-contract, and runtime-proof boundary; no payments, public launch, or second gateway owner was added.
- Compatibility status: Native New API token, group, model, quota, and usage ownership remains canonical; non-commercial behavior and staged gateway-key work are preserved. The exact Compose proof now passes after D-backed WSL recovery.
- Retirement status: Unsupported private legacy routes remain centrally unavailable rather than deleted; inherited task-polling race findings and broader commercial hardening remain outside this thin MVP slice.
- New risk signals:
- The unfiltered Linux -race run exposes inherited service task-polling races in logger.logHelper and Task state; the MVP-focused race selection passes all six affected packages.
- Ubuntu has no native Go or gcc; the race evidence used the cached golang:1.26.1-bookworm container with a read-only source bind.
- A bounded sequence-max failure edge and the non-blocking Docker Bake/buildx warning remain Minor/deferred.
- Advisory decision: needs-verification

## Checkpoint Update

- Current todo: Hand off the thin New API private MVP evidence slice with the inherited full-race gap explicit.
- Active slice: Thin private MVP evidence handoff and inherited race-gap boundary.
- Completed todos:
- Private-mode route allowlisting, root aliases, Bearer-only enforcement, legacy-route rejection, commercial model selection, response sanitization, bounded streaming, and sequence ordering are implemented and tested.
- Affected Go, contract/helper, and deployment tests; affected vet; gofmt; diff hygiene; and independent security/SSE review passed with no Critical or Important findings.
- Authorized reboot restored D-backed Ubuntu WSL2; /bin/true succeeded and the exact Compose up proof passed with all five services healthy and the recorded mock-isolation checks.
- The MVP-focused Linux -race selection passed all six affected packages in a read-only golang:1.26.1-bookworm container; the unfiltered service race remains an inherited task-polling finding.
- Aegis bundle, workspace check, selected artifact validation, and final worktree fingerprint/diff checks passed without staging or committing.
- Evidence refs:
- docs/aegis/work/2026-08-10-commercial-mvp-phase1/evidence-bundle-draft-thin-new-api-private-mvp-final.json
- docs/aegis/work/2026-08-10-commercial-mvp-phase1/evidence-bundle-draft-thin-new-api-private-mvp-runtime-compose-pass.json
- docs/aegis/work/2026-08-10-commercial-mvp-phase1/evidence-bundle-draft-thin-new-api-private-mvp-race.json
- docs/aegis/work/2026-08-10-commercial-mvp-phase1/90-evidence.md
- Blocked on: The unfiltered Linux -race suite is not green because unrelated inherited service task-polling tests report races in logger.logHelper and Task state; the MVP-focused race selection passes, and no thin-MVP local code gate is blocked.
- Next step: Owner review of the inherited race gap; if it is accepted or separately assigned, continue the next approved gate. Do not stage, commit, push, deploy, or launch without explicit authority.

## Checkpoint Update

- Current todo: Hand off the thin New API private MVP evidence slice with the inherited full-race gap explicit.
- Active slice: Resume reconciliation and affected-gate refresh; no application-code or index mutation.
- Completed todos:
- Reconciled the live worktree against the checkpoint: the staged gateway-key/UI foundation, unstaged thin private-MVP changes, untracked evidence/cache artifacts, and the separate Proxy Server worktree remain preserved.
- Confirmed D-backed Ubuntu WSL2 starts successfully; `/bin/true` and the Compose structural proof passed after resume.
- Fresh read-only container verification passed all affected tests, `go vet`, container `gofmt -l`, `git diff --check`, and `git diff --cached --check`.
- Evidence refs:
- docs/aegis/work/2026-08-10-commercial-mvp-phase1/evidence-bundle-draft-thin-new-api-private-mvp-handoff-refresh.json
- docs/aegis/work/2026-08-10-commercial-mvp-phase1/90-evidence.md
- Blocked on: The unfiltered Linux `-race` suite remains non-green only in inherited service task-polling tests (`logger.logHelper` and `Task` state); the MVP-focused race selection remains passed. No thin-MVP local gate is blocked.
- Next step: Keep the thin private-MVP diff as a local handoff until explicit authority is given to isolate and commit it; do not stage, commit, push, deploy, or launch the preserved gateway-key or unrelated work.

## DriftCheckDraft

- Scope status: The refresh stayed within the approved thin private route/model/relay/deployment proof and handoff boundary; no payments, public launch, or second gateway owner was added.
- Compatibility status: Native New API token, group, model, quota, and usage ownership remains canonical; staged gateway-key work and all unrelated changes remain untouched.
- Retirement status: Unsupported private legacy routes remain centrally unavailable rather than deleted; the inherited task-polling race and broader commercial hardening remain deferred.
- New risk signals:
- The complete inherited Linux `-race` suite remains unresolved outside this slice; Ubuntu has no native Go toolchain, so the focused evidence uses a read-only cached Go container.
- A bounded sequence-max failure edge and the non-blocking Docker Bake/buildx warning remain Minor/deferred.
- Advisory decision: needs-verification

## Checkpoint Update

- Current todo: Preserve the isolated thin private-MVP commit and the staged gateway-key/UI foundation as separate tracks.
- Active slice: Post-commit handoff verification.
- Completed todos:
- Created commit `1759e8b32ecfed510f820a53239dcc906166312d` with only the approved thin private-MVP source, tests, deployment contract, and handoff evidence.
- Reconstructed the real index so the pre-existing 41 gateway-key/UI entries remain staged; the three overlapping deployment files retain only their gateway-key hunks in the index.
- Post-commit affected tests, Compose config, Git diff checks, and Aegis check/bundle passed.
- Evidence refs:
- docs/aegis/work/2026-08-10-commercial-mvp-phase1/evidence-bundle-draft-thin-new-api-private-mvp-commit.json
- docs/aegis/work/2026-08-10-commercial-mvp-phase1/90-evidence.md
- Blocked on: The inherited unfiltered Linux `-race` suite remains non-green only in unrelated service task-polling tests; the focused private-MVP race selection and post-commit affected gate pass.
- Next step: Review the isolated commit and decide the next commercial hardening gate; keep the staged gateway-key/UI work, model bootstrap fixes, cache directories, and other untracked work separate until separately authorized.

## DriftCheckDraft

- Scope status: The commit stayed inside the approved thin private route/model/relay/deployment/evidence boundary; no payment, public launch, second gateway owner, or unrelated bootstrap fix was included.
- Compatibility status: Native New API ownership remains canonical; the staged gateway-key/UI foundation is preserved as a separate index track.
- Retirement status: Unsupported private legacy routes remain centrally unavailable rather than deleted; inherited task-polling races and broader commercial hardening remain deferred.
- New risk signals:
- Full inherited Linux `-race` evidence remains unresolved outside the committed thin slice.
- Advisory decision: needs-verification
