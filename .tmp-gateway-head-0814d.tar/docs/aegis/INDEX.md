# Aegis Workspace Index

This index tracks files created under this project's `docs/aegis/` workspace.
Entries are workspace records, not authoritative runtime decisions.

| Date | Kind | Path | Title |
| --- | --- | --- | --- |
| 2026-07-31 | work | docs/aegis/work/2026-07-31-step1-plan-review/10-intent.md | Step 1 plan correction and review intent |
| 2026-07-31 | work | docs/aegis/work/2026-07-31-step1-plan-review/20-checkpoint.md | Step 1 plan correction and review checkpoint |
| 2026-07-31 | work | docs/aegis/work/2026-07-31-step1-plan-review/90-evidence.md | Step 1 plan correction and review evidence |
| 2026-07-31 | work | docs/aegis/work/2026-07-31-step1-plan-review/99-reflection.md | Step 1 plan correction and review reflection |
| 2026-07-31 | artifact | docs/aegis/work/2026-07-31-step1-plan-review/task-intent-draft.json | Step 1 plan correction and review task intent draft |
| 2026-07-31 | artifact | docs/aegis/work/2026-07-31-step1-plan-review/baseline-read-set-hint.json | Step 1 plan correction and review baseline read-set hint |
| 2026-07-31 | artifact | docs/aegis/work/2026-07-31-step1-plan-review/baseline-usage-draft.json | Step 1 plan correction and review baseline usage draft |
| 2026-07-31 | artifact | docs/aegis/work/2026-07-31-step1-plan-review/impact-statement-draft.json | Step 1 plan correction and review impact statement draft |
| 2026-07-31 | artifact | docs/aegis/work/2026-07-31-step1-plan-review/todo-checkpoint-draft.json | Step 1 plan correction and review todo checkpoint draft |
| 2026-07-31 | artifact | docs/aegis/work/2026-07-31-step1-plan-review/drift-check-draft.json | Step 1 plan correction and review drift check draft |
| 2026-07-31 | work | docs/aegis/work/2026-07-31-commercial-mvp-rescope/10-intent.md | Commercial MVP rescope and plan review intent |
| 2026-07-31 | work | docs/aegis/work/2026-07-31-commercial-mvp-rescope/20-checkpoint.md | Commercial MVP rescope and plan review checkpoint |
| 2026-07-31 | work | docs/aegis/work/2026-07-31-commercial-mvp-rescope/90-evidence.md | Commercial MVP rescope and plan review evidence |
| 2026-07-31 | work | docs/aegis/work/2026-07-31-commercial-mvp-rescope/99-reflection.md | Commercial MVP rescope and plan review reflection |
| 2026-07-31 | artifact | docs/aegis/work/2026-07-31-commercial-mvp-rescope/task-intent-draft.json | Commercial MVP rescope and plan review task intent draft |
| 2026-07-31 | artifact | docs/aegis/work/2026-07-31-commercial-mvp-rescope/baseline-read-set-hint.json | Commercial MVP rescope and plan review baseline read-set hint |
| 2026-07-31 | artifact | docs/aegis/work/2026-07-31-commercial-mvp-rescope/baseline-usage-draft.json | Commercial MVP rescope and plan review baseline usage draft |
| 2026-07-31 | artifact | docs/aegis/work/2026-07-31-commercial-mvp-rescope/impact-statement-draft.json | Commercial MVP rescope and plan review impact statement draft |
| 2026-07-31 | artifact | docs/aegis/work/2026-07-31-commercial-mvp-rescope/todo-checkpoint-draft.json | Commercial MVP rescope and plan review todo checkpoint draft |
| 2026-07-31 | artifact | docs/aegis/work/2026-07-31-commercial-mvp-rescope/drift-check-draft.json | Commercial MVP rescope and plan review drift check draft |
| 2026-07-31 | artifact | docs/aegis/work/2026-07-31-commercial-mvp-rescope/evidence-bundle-draft-commercial-mvp-plan-structure.json | 2026-07-31-commercial-mvp-rescope evidence commercial-mvp-plan-structure |
| 2026-07-31 | artifact | docs/aegis/work/2026-07-31-commercial-mvp-rescope/resume-state-hint.json | 2026-07-31-commercial-mvp-rescope resume state hint |
| 2026-07-31 | artifact | docs/aegis/work/2026-07-31-commercial-mvp-rescope/evidence-bundle-draft-independent-plan-review-round1.json | 2026-07-31-commercial-mvp-rescope evidence independent-plan-review-round1 |
| 2026-07-31 | artifact | docs/aegis/work/2026-07-31-commercial-mvp-rescope/evidence-bundle-draft-independent-security-review-round2.json | 2026-07-31-commercial-mvp-rescope evidence independent-security-review-round2 |
| 2026-07-31 | artifact | docs/aegis/work/2026-07-31-commercial-mvp-rescope/gate-input-pack.json | 2026-07-31-commercial-mvp-rescope gate input pack |
| 2026-07-31 | work | docs/aegis/work/2026-07-31-commercial-mvp-rescope/proof-bundle.md | 2026-07-31-commercial-mvp-rescope proof bundle |
| 2026-07-31 | artifact | docs/aegis/work/2026-07-31-commercial-mvp-rescope/evidence-bundle-draft-final-fixed-hash-verification.json | 2026-07-31-commercial-mvp-rescope evidence final-fixed-hash-verification |
| 2026-07-31 | artifact | docs/aegis/work/2026-07-31-commercial-mvp-rescope/evidence-bundle-draft-review-blocker-closure.json | 2026-07-31-commercial-mvp-rescope evidence review-blocker-closure |
| 2026-07-31 | work | docs/aegis/work/2026-07-31-commercial-mvp-phase0/10-intent.md | Commercial MVP Phase 0 execution intent |
| 2026-07-31 | work | docs/aegis/work/2026-07-31-commercial-mvp-phase0/20-checkpoint.md | Commercial MVP Phase 0 execution checkpoint |
| 2026-07-31 | work | docs/aegis/work/2026-07-31-commercial-mvp-phase0/90-evidence.md | Commercial MVP Phase 0 execution evidence |
| 2026-07-31 | work | docs/aegis/work/2026-07-31-commercial-mvp-phase0/99-reflection.md | Commercial MVP Phase 0 execution reflection |
| 2026-07-31 | artifact | docs/aegis/work/2026-07-31-commercial-mvp-phase0/task-intent-draft.json | Commercial MVP Phase 0 execution task intent draft |
| 2026-07-31 | artifact | docs/aegis/work/2026-07-31-commercial-mvp-phase0/baseline-read-set-hint.json | Commercial MVP Phase 0 execution baseline read-set hint |
| 2026-07-31 | artifact | docs/aegis/work/2026-07-31-commercial-mvp-phase0/baseline-usage-draft.json | Commercial MVP Phase 0 execution baseline usage draft |
| 2026-07-31 | artifact | docs/aegis/work/2026-07-31-commercial-mvp-phase0/impact-statement-draft.json | Commercial MVP Phase 0 execution impact statement draft |
| 2026-07-31 | artifact | docs/aegis/work/2026-07-31-commercial-mvp-phase0/todo-checkpoint-draft.json | Commercial MVP Phase 0 execution todo checkpoint draft |
| 2026-07-31 | artifact | docs/aegis/work/2026-07-31-commercial-mvp-phase0/drift-check-draft.json | Commercial MVP Phase 0 execution drift check draft |
| 2026-08-01 | artifact | docs/aegis/work/2026-07-31-commercial-mvp-phase0/evidence-bundle-draft-step-0-2.json | Commercial MVP Phase 0 Step 0.2 verification and review evidence |
| 2026-08-02 | artifact | docs/aegis/work/2026-07-31-commercial-mvp-phase0/resume-state-hint.json | 2026-07-31-commercial-mvp-phase0 resume state hint |
| 2026-08-02 | artifact | docs/aegis/work/2026-07-31-commercial-mvp-phase0/evidence-bundle-draft-step-0-3.json | Commercial MVP Phase 0 Step 0.3 verification and combined review evidence |
| 2026-08-02 | artifact | docs/aegis/work/2026-07-31-commercial-mvp-phase0/gate-input-pack.json | 2026-07-31-commercial-mvp-phase0 gate input pack |
| 2026-08-02 | work | docs/aegis/work/2026-07-31-commercial-mvp-phase0/proof-bundle.md | 2026-07-31-commercial-mvp-phase0 proof bundle |
| 2026-08-10 | artifact | docs/aegis/work/2026-07-31-commercial-mvp-phase0/evidence-bundle-draft-step-0-6.json | 2026-07-31-commercial-mvp-phase0 evidence step-0-6 |
| 2026-08-10 | work | docs/aegis/work/2026-08-10-commercial-mvp-phase1/10-intent.md | Commercial MVP Phase 1 execution intent |
| 2026-08-10 | work | docs/aegis/work/2026-08-10-commercial-mvp-phase1/20-checkpoint.md | Commercial MVP Phase 1 execution checkpoint |
| 2026-08-10 | work | docs/aegis/work/2026-08-10-commercial-mvp-phase1/90-evidence.md | Commercial MVP Phase 1 execution evidence |
| 2026-08-10 | work | docs/aegis/work/2026-08-10-commercial-mvp-phase1/99-reflection.md | Commercial MVP Phase 1 execution reflection |
| 2026-08-10 | artifact | docs/aegis/work/2026-08-10-commercial-mvp-phase1/task-intent-draft.json | Commercial MVP Phase 1 execution task intent draft |
| 2026-08-10 | artifact | docs/aegis/work/2026-08-10-commercial-mvp-phase1/baseline-read-set-hint.json | Commercial MVP Phase 1 execution baseline read-set hint |
| 2026-08-10 | artifact | docs/aegis/work/2026-08-10-commercial-mvp-phase1/baseline-usage-draft.json | Commercial MVP Phase 1 execution baseline usage draft |
| 2026-08-10 | artifact | docs/aegis/work/2026-08-10-commercial-mvp-phase1/impact-statement-draft.json | Commercial MVP Phase 1 execution impact statement draft |
| 2026-08-10 | artifact | docs/aegis/work/2026-08-10-commercial-mvp-phase1/todo-checkpoint-draft.json | Commercial MVP Phase 1 execution todo checkpoint draft |
| 2026-08-10 | artifact | docs/aegis/work/2026-08-10-commercial-mvp-phase1/drift-check-draft.json | Commercial MVP Phase 1 execution drift check draft |
| 2026-08-10 | artifact | docs/aegis/work/2026-08-10-commercial-mvp-phase1/evidence-bundle-draft-step-1-1-migration-review.json | 2026-08-10-commercial-mvp-phase1 evidence step-1-1-migration-review |
| 2026-08-10 | artifact | docs/aegis/work/2026-08-10-commercial-mvp-phase1/resume-state-hint.json | 2026-08-10-commercial-mvp-phase1 resume state hint |
| 2026-08-11 | artifact | docs/aegis/work/2026-08-10-commercial-mvp-phase1/evidence-bundle-draft-step-1-1.json | 2026-08-10-commercial-mvp-phase1 evidence step-1-1 |
| 2026-08-11 | artifact | docs/aegis/work/2026-08-10-commercial-mvp-phase1/gate-input-pack.json | 2026-08-10-commercial-mvp-phase1 gate input pack |
| 2026-08-11 | work | docs/aegis/work/2026-08-10-commercial-mvp-phase1/proof-bundle.md | 2026-08-10-commercial-mvp-phase1 proof bundle |
| 2026-08-12 | artifact | docs/aegis/work/2026-08-10-commercial-mvp-phase1/evidence-bundle-draft-step-1-3.json | 2026-08-10-commercial-mvp-phase1 evidence step-1-3 |
| 2026-08-12 | plan | docs/aegis/plans/2026-08-12-thin-new-api-private-mvp.md | Thin New API private MVP implementation plan |
| 2026-08-12 | spec | docs/aegis/specs/2026-08-12-thin-new-api-private-mvp-design.md | Thin New API private MVP design |
| 2026-08-13 | artifact | docs/aegis/work/2026-08-10-commercial-mvp-phase1/evidence-bundle-draft-thin-new-api-private-mvp-final.json | 2026-08-10-commercial-mvp-phase1 evidence thin-new-api-private-mvp-final |
| 2026-08-13 | artifact | docs/aegis/work/2026-08-10-commercial-mvp-phase1/evidence-bundle-draft-thin-new-api-private-mvp-runtime-retry.json | 2026-08-10-commercial-mvp-phase1 evidence thin-new-api-private-mvp-runtime-retry |
| 2026-08-13 | artifact | docs/aegis/work/2026-08-10-commercial-mvp-phase1/evidence-bundle-draft-thin-new-api-private-mvp-runtime-recovery.json | 2026-08-10-commercial-mvp-phase1 evidence thin-new-api-private-mvp-runtime-recovery |
| 2026-08-13 | artifact | docs/aegis/work/2026-08-10-commercial-mvp-phase1/evidence-bundle-draft-thin-new-api-private-mvp-admin-recovery.json | 2026-08-10-commercial-mvp-phase1 evidence thin-new-api-private-mvp-admin-recovery |
| 2026-08-13 | artifact | docs/aegis/work/2026-08-10-commercial-mvp-phase1/evidence-bundle-draft-thin-new-api-private-mvp-runtime-compose-pass.json | 2026-08-10-commercial-mvp-phase1 evidence thin-new-api-private-mvp-runtime-compose-pass |
| 2026-08-13 | artifact | docs/aegis/work/2026-08-10-commercial-mvp-phase1/evidence-bundle-draft-thin-new-api-private-mvp-race.json | 2026-08-10-commercial-mvp-phase1 evidence thin-new-api-private-mvp-race |
