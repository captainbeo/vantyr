# New API upstream provenance

- Upstream repository: <https://github.com/QuantumNous/new-api>
- Reviewed upstream commit: `66ee6b8f9889050ffef1f863a4314ce4a0516fb9`
- Reviewed upstream tree: `52c4e1cb5bd1fd94d414273cd810019f79d2ee0d`
- Import date: 2026-07-31
- Fork branch: `codex/commercial-mvp`
- Import method: the pinned commit was fetched into
  `refs/remotes/new-api-upstream/mvp-pin` and merged with unrelated histories
  allowed. The merge preserves both the local approved-design history and the
  upstream commit as parents.

The fork must not track a moving tag or `latest` image. Future upstream updates
require an explicit full commit SHA, review of the intervening history, and the
same verification gates as any other product change.

## Verification

The upstream side of the import is valid only when all of the following hold:

```text
git rev-parse refs/remotes/new-api-upstream/mvp-pin
git rev-parse HEAD^2
git show -s --format=%T refs/remotes/new-api-upstream/mvp-pin
git merge-base --is-ancestor 66ee6b8f9889050ffef1f863a4314ce4a0516fb9 HEAD
```

The first two commands must return
`66ee6b8f9889050ffef1f863a4314ce4a0516fb9`; the tree command must return
`52c4e1cb5bd1fd94d414273cd810019f79d2ee0d`; and the ancestry check must exit
successfully.

The commercial MVP plan's shorthand that `git rev-parse HEAD` equals the pin
cannot literally hold after preserving the approved local history and adding a
fork commit. The merge's upstream parent and pinned remote reference are the
authoritative provenance checks.

## Imported baseline

The unmodified pinned tree was verified on 2026-07-31 with the official,
checksum-verified Go `1.25.1` Linux toolchain under WSL2 Ubuntu:

```text
GOWORK=off go test ./...
cd relaykit && GOWORK=off go test ./...
```

Both modules passed. `relaykit` was tested independently as required by the
upstream project conventions.

The Windows `go test` launcher in the Codex host left generated test processes
in the initialized state. Direct execution exposed an additional upstream
Windows-only fixture defect: three cache tests derive supposedly unique keys
from back-to-back `time.Now().UnixNano()` calls and collide at Windows clock
resolution. Each test passes in isolation, and the exact Linux suite passes.
No upstream source or test was changed to conceal either host-specific issue;
Linux CI remains authoritative for this fork.
