package logger

import (
	"net/url"
	"testing"

	"github.com/stretchr/testify/require"
)

func TestRegisteredSensitiveValueIsRedacted(t *testing.T) {
	secret := "commercial-redactor-test-value/with+symbols"
	RegisterSensitiveValue(secret)

	message := "raw=" + secret + " query=" + url.QueryEscape(secret) + " path=" + url.PathEscape(secret)
	redacted := redactSensitiveValues(message)

	require.NotContains(t, redacted, secret)
	require.NotContains(t, redacted, url.QueryEscape(secret))
	require.NotContains(t, redacted, url.PathEscape(secret))
	require.Contains(t, redacted, "[REDACTED]")
}
