## O que entendi

This is a greenfield, production API/backend: a thin Go fork of
`QuantumNous/new-api` that issues customer API keys, enforces subscription
limits, routes OpenAI-compatible requests across configurable upstream
reseller/transfer-station channels, meters usage and cost, and exposes the
Responses API contract required by Codex CLI. PostgreSQL is the durable system
of record, Redis is the mandatory fail-closed concurrency/rate admission and
channel-health store, Docker is the deployment baseline, and GitHub Actions is
the CI baseline. Codex CLI is the active AI coding platform. This initialization
activates 19 project-relevant agents.

If this summary becomes inaccurate, update this file and regenerate the A Team
roster before dispatching work.

---

# INIT.md — AI API Reseller Gateway

> Initialized on 2026-07-30. Project routing is recorded in
> `.agent-sync/TEAM.md` and `.agent-sync/ROUTING.md`.

## Project Overview

- **Name:** AI API Reseller Gateway
- **Type:** API/backend service with a thin inherited-console integration page
- **Status:** Commercial MVP planning; implementation blocked on plan approval
**Description:** A production gateway built as a thin, upstream-tracking Go
fork of `QuantumNous/new-api`. Customers authenticate with platform-issued
keys. The gateway performs authentication, subscription enforcement, quota and
concurrency control, upstream channel routing and failover, usage metering,
cost accounting, and audit logging before forwarding requests to configurable
reseller or transfer-station channels. Its public Codex integration follows the
OpenAI Responses API contract; Kadirr is a compatibility reference, not a
runtime dependency.

## Primary Programming Languages

- [x] TypeScript / JavaScript
- [ ] Python
- [x] Go
- [ ] Rust
- [ ] Kotlin / Java (Android)
- [ ] Swift (iOS / macOS)
- [ ] Dart (Flutter)
- [ ] Other

## Tech Stack

- **Frontend:** Reused New API customer console plus one thin branded
  integration/setup page; Stripe Customer Portal owns billing self-service
- **Backend:** Thin Go fork of `QuantumNous/new-api`
- **Database:** PostgreSQL for durable subscription, quota, billing, and audit
  state; Redis is mandatory for atomic concurrency and rate-limit enforcement
- **Runtime:** Go backend and the inherited TypeScript/React frontend
- **Build system:** Go modules and Docker
- **CI/CD:** GitHub Actions
- **Client compatibility:** Codex CLI and OpenAI-compatible API clients
- **External services:** Configurable upstream LLM channels and Stripe-hosted
  billing

## Communication & Collaboration Tools

- [ ] Gmail / email
- [ ] Slack
- [ ] GitHub Issues / PRs
- [ ] Linear
- [ ] Notion
- [x] None — no human communication workflow is currently in scope

## Scope Boundaries

- **Will this project have E2E tests?** Yes
- **Will this project use a PostgreSQL database?** Yes
- **Will this project handle authentication or user data?** Yes
- **Is there a multi-channel communication workflow?** No — upstream provider
  channels are product routing, not a human messaging workflow
- **Are there autonomous agent loops running unattended?** No
- **Will there be regular documentation / codemaps?** Yes
- **Does this project make LLM API calls?** Yes
- **Does this project use Terraform / Docker / Kubernetes?** Yes — Docker is in
  scope; Terraform and Kubernetes are not yet selected
- **Does this project have a production environment?** Yes
- **Are there performance targets or SLAs?** Yes — exact plan concurrency caps,
  failover latency thresholds, rolling channel-health metrics, quota integrity,
  and concurrent load/stress acceptance tests are required. Numeric service SLOs
  beyond the supplied plan limits will be set only from Step 5 load evidence and
  are not initial release claims.

## Compliance Scope

- [x] GDPR / RGPD (EU customer and usage data)
- [ ] COPPA
- [x] PCI-DSS (payment integration boundary)
- [ ] SOC 2
- [ ] HIPAA
- [ ] None

**PCI scope constraint:** Card entry and raw card data stay on Stripe-hosted
surfaces. The gateway stores only provider identifiers and the minimum billing
state required for idempotent, auditable subscription processing. Outsourcing
card handling reduces PCI scope; it does not eliminate payment-security
obligations.

## Active AI Platforms

- [ ] Claude Code
- [x] Codex CLI
- [ ] Cursor
- [ ] OpenCode
- [ ] Multiple CLIs simultaneously

## Team & Workflow

- **Number of developers:** One human owner assumed initially, supported by
  specialist agents; update if the human team changes
- **Branching model:** Feature branches
- **Review process:** Human approval gates plus mandatory automated specialist
  reviews
- **Orchestrator mode:** Daily checkpoints during the one-week build and
  on-demand dispatch
- **Existing `TASKS.md`:** No — create separately when execution planning begins

## Quality Standards

- **Minimum test coverage:** No arbitrary repository-wide percentage has been
  specified. Critical authentication, authorization, billing, quota, limiter,
  routing, failover, secret resolution, and audit paths require complete
  risk-based unit, integration, E2E, failure-injection, and concurrency coverage.
- **Linting enforced:** Yes
- **Type checking enforced:** Yes — Go compiler, `go vet`, and selected static
  analysis
- **Performance testing:** Required before launch, including exact-cap,
  quota-leakage, rapid sequential image, limiter-outage, and concurrent failover
  tests
- **Security testing:** Required, including dependency, static, secret, input,
  authorization, SSRF, injection, log-leakage, and failure-mode checks

## Non-Negotiable Rules

- Extend `QuantumNous/new-api`; do not replace it with a custom gateway or
  routing sidecar.
- Keep New API as the single customer authentication, request-enforcement,
  routing, metering, and request-audit boundary. Stripe owns billing events;
  PostgreSQL stores the authoritative access projection consumed by the gateway.
  Direct API calls must not bypass controls.
- Store upstream channels, model mappings, priorities, weights, auth schemes,
  timeouts, health policy, and cost metadata in configuration or the database.
  Core logic must remain vendor-neutral.
- Keep raw upstream credentials out of source, version control, client-visible
  configuration, responses, and logs. Resolve environment or secrets-manager
  references at runtime and fail closed when resolution fails.
- Rate, quota, image, and concurrency enforcement must fail closed whenever
  their authoritative state service is unavailable.
- Validate and sanitize customer-controlled input before any upstream request.
  Treat upstream URLs as privileged configuration and defend against SSRF.
- Make subscription, renewal, upgrade, top-up, webhook, and credit-grant state
  transitions idempotent and auditable.
- Keep upstream cost accounting separate from customer pricing and record money
  in integer minor units or micro-units, never binary floating point.
- Do not persist or log raw payment-card data. Use Stripe-hosted payment
  handling and verify webhook signatures.
- Preserve transparent failover only before the downstream response is
  committed. Never replay a request after meaningful response bytes have
  reached the customer.
- Use prepared/parameterized database operations, least privilege, centralized
  sanitized errors, structured logs, and append-only audit records for
  security-sensitive events.
- Do not advance a build checkpoint until its acceptance tests pass.
- All schema changes require an explicit migration and rollback plan. All API
  endpoints require a reviewed contract before implementation.
- Work in isolated feature branches/worktrees, write tests before production
  code, and run mandatory review and verification gates before completion.

## Active Work / Next Steps

1. Preserve the approved channel/Codex design as architecture authority and the
   oversized Step 1 plan as a future hardening roadmap.
2. Independently review and obtain owner approval for the concise commercial
   MVP plan before importing or modifying product source.
3. After approval, create an isolated worktree and implement the MVP phase by
   phase, stopping whenever a phase test/review gate fails.
4. Launch only Limited Weekly and Limited Monthly to a small private cohort.
   Keep the other five plans stored but disabled and keep all image routes
   disabled until the independent hourly limiter passes its gate.

## Agents to Prune

- `chief-of-staff` — no email, Slack, or customer-message triage workflow
- `flutter-reviewer` — no Dart or Flutter source
- `kotlin-reviewer` — no Kotlin, Java, or Android source
- `loop-operator` — no unattended autonomous coding-agent loops
- `python-reviewer` — no Python application source in the declared scope
- `rust-reviewer` — no Rust source
- `swift-reviewer` — no Swift or Apple-platform source

## Declared Assumptions

- The commercial MVP includes only the smallest frontend delta needed for
  branded Codex setup and Stripe Portal access; New API continues to own API
  key, quota, and usage views.
- PostgreSQL reservations and events are authoritative for durable request
  quota and billing/access state. Redis Lua scripts own atomic concurrency and
  hourly-rate admission; Redis or limiter unavailability rejects protected
  requests.
- Customer gateway keys use one-time display and indexed HMAC verification;
  the native full-key recovery routes are disabled.
- The first private deployment may use one application replica and one region.
  It still requires two configured channels, but no provider-redundancy claim is
  made when both channels share a supplier or failure domain.
- Only Limited Weekly and Limited Monthly are enabled initially. Image access
  and all five unlimited plans remain disabled until their later release gates.
- The cloud host, infrastructure-as-code tool, exact numeric SLOs, and human
  team size beyond the initial owner are not yet specified.
- Stripe hosts card collection; this project never receives or stores PAN/CVC.
- Background gateway health checks are product workers, not autonomous
  coding-agent loops.
