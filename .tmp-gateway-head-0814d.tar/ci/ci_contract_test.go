package ci_test

import (
	"os"
	"strings"
	"testing"

	"gopkg.in/yaml.v3"
)

func TestCommercialMVPCIWorkflowWiresRequiredGates(t *testing.T) {
	workflow, err := os.ReadFile("../.github/workflows/ci.yml")
	if err != nil {
		t.Fatal(err)
	}
	text := string(workflow)
	var document map[string]any
	if err := yaml.Unmarshal(workflow, &document); err != nil {
		t.Fatalf("CI workflow is not valid YAML: %v", err)
	}

	required := []string{
		"go test -race",
		"staticcheck",
		"bun run build",
		"migration:",
		"go test ./docs/migrations",
		"govulncheck",
		"bun audit",
		"gitleaks",
		"compose:",
		"deploy/mvp/verify-compose.sh up",
		"scripts/ci/negative-control.sh",
		"workflow_dispatch:",
		"--config=/repo/.gitleaks.toml",
		"(cd relaykit && GOWORK=off go run golang.org/x/vuln/cmd/govulncheck@v1.1.4 ./...)",
	}
	for _, marker := range required {
		if !strings.Contains(text, marker) {
			t.Errorf("CI workflow is missing required marker %q", marker)
		}
	}
}

func TestCommercialMVPCIDependencyAuditCreatesFrontendEmbedPlaceholder(t *testing.T) {
	workflow, err := os.ReadFile("../.github/workflows/ci.yml")
	if err != nil {
		t.Fatal(err)
	}

	text := string(workflow)
	start := strings.Index(text, "  dependency-audit:\n")
	if start == -1 {
		t.Fatal("CI workflow is missing dependency-audit job")
	}
	end := strings.Index(text[start+len("  dependency-audit:\n"):], "\n  secret-scan:")
	if end == -1 {
		t.Fatal("CI workflow dependency-audit job has no bounded end")
	}
	dependencyAudit := text[start : start+len("  dependency-audit:\n")+end]

	placeholder := "- name: Create frontend embed placeholder"
	if !strings.Contains(dependencyAudit, placeholder) {
		t.Fatalf("dependency-audit job must create the frontend embed placeholder before Go audit")
	}
	if !strings.Contains(dependencyAudit, "mkdir -p web/dist\n          touch web/dist/index.html") {
		t.Fatalf("dependency-audit job placeholder step must create web/dist/index.html")
	}

	placeholderIndex := strings.Index(dependencyAudit, placeholder)
	auditIndex := strings.Index(dependencyAudit, "- name: Go vulnerability audit")
	if auditIndex == -1 {
		t.Fatal("dependency-audit job is missing Go vulnerability audit step")
	}
	if placeholderIndex > auditIndex {
		t.Fatal("dependency-audit frontend embed placeholder must run before Go vulnerability audit")
	}
}

func TestCommercialMVPCINegativeControlsAreSelectable(t *testing.T) {
	workflow, err := os.ReadFile("../.github/workflows/ci.yml")
	if err != nil {
		t.Fatal(err)
	}
	text := string(workflow)
	for _, control := range []string{"clean", "failing-test", "secret-sentinel"} {
		if !strings.Contains(text, control) {
			t.Errorf("CI workflow does not expose %q negative-control mode", control)
		}
	}
}

func TestCommercialMVPGitleaksPolicyExtendsDefaultRules(t *testing.T) {
	config, err := os.ReadFile("../.gitleaks.toml")
	if err != nil {
		t.Fatal(err)
	}

	if !tomlSectionContains(string(config), "extend", "useDefault = true") {
		t.Error("Gitleaks policy must extend the default detector rules")
	}
}

func TestCommercialMVPGitleaksAllowlistsMatchContainerPathSuffixes(t *testing.T) {
	config, err := os.ReadFile("../.gitleaks.toml")
	if err != nil {
		t.Fatal(err)
	}
	text := string(config)

	paths := []string{
		`controller/token_test\.go`,
		`middleware/auth\.go`,
		`relay/channel/task/jimeng/adaptor\.go`,
		`relay/channel/vertex/service_account\.go`,
		`relaykit/relayconvert/kitutil/mask\.go`,
		`common/utils\.go`,
		`deploy/mvp/mock/main_test\.go`,
	}
	for _, path := range paths {
		marker := "paths = ['''(?:^|/)" + path + "$''']"
		if !strings.Contains(text, marker) {
			t.Errorf("Gitleaks allowlist must match the exact repo-relative suffix for %q, including /repo container paths", path)
		}
	}

	for _, line := range strings.Split(text, "\n") {
		line = strings.TrimSpace(line)
		if strings.HasPrefix(line, "paths = ['''") && !strings.HasPrefix(line, "paths = ['''(?:^|/)") {
			t.Errorf("Gitleaks allowlist path is not container-path-compatible: %s", line)
		}
	}
}

func TestCommercialMVPGitleaksVerifiedNonSecretsUseRuleScopedExactPairs(t *testing.T) {
	config, err := os.ReadFile("../.gitleaks.toml")
	if err != nil {
		t.Fatal(err)
	}
	text := string(config)
	if strings.Contains(text, "[[allowlists]]") {
		t.Error("Gitleaks v8.24.2 ignores top-level [[allowlists]] tables")
	}
	if strings.Contains(text, "\n[allowlist]\n") {
		t.Error("Gitleaks policy must not use a broad global allowlist")
	}
	if strings.Contains(text, "disabledRules") {
		t.Error("Gitleaks policy must not disable default detector rules")
	}

	keyAlphabet := "0123456789" + "abcdefghijklmnopqrstuvwxyz" + "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
	mockControlToken := "abcdefghijklmnopqrstuvwxyz" + "ABCDEF" + "0123456789"
	authVersion := "864b7076" + "dbcd0a3c" + "01b55203" + "16720ebf"
	maskExample := "AIzaSyAAA" + "aUooTUni" + "8AdaOkSRM" + "da30n_Q4" + "vrV70"
	exceptions := []struct {
		ruleID      string
		description string
		path        string
		lines       []string
	}{
		{
			ruleID:      "generic-api-key",
			description: "Verified token-controller test fixtures",
			path:        `paths = ['''(?:^|/)controller/token_test\.go$''']`,
			lines: []string{
				`^\s*token := seedToken\(t, db, 1, "list-token", "` + "abcd1234" + "efgh5678" + `"\)\s*$`,
				`^\s*token := seedToken\(t, db, 1, "searchable-token", "` + "ijkl1234" + "mnop5678" + `"\)\s*$`,
				`^\s*token := seedToken\(t, db, 1, "detail-token", "` + "qrst1234" + "uvwx5678" + `"\)\s*$`,
				`^\s*token := seedToken\(t, db, 1, "editable-token", "` + "yzab1234" + "cdef5678" + `"\)\s*$`,
			},
		},
		{
			ruleID:      "generic-api-key",
			description: "Verified authentication header test literal",
			path:        `paths = ['''(?:^|/)middleware/auth\.go$''']`,
			lines:       []string{`^\s*c\.Header\("Auth-Version", "` + authVersion + `"\)\s*$`},
		},
		{
			ruleID:      "generic-api-key",
			description: "Verified API-key masking example",
			path:        `paths = ['''(?:^|/)relaykit/relayconvert/kitutil/mask\.go$''']`,
			lines: []string{`^\s*// Mask API keys \(e\.g\., "api_key:` + maskExample +
				`" -> "api_key:\*\*\*"\)\s*$`},
		},
		{
			ruleID:      "generic-api-key",
			description: "Verified Jimeng protocol literals",
			path:        `paths = ['''(?:^|/)relay/channel/task/jimeng/adaptor\.go$''']`,
			lines: []string{
				`^\s*"req_key": "` + "jimeng_" + "vgfm_t2v_l20" + `",`,
				`^\s*if r\.ReqKey == "` + "jimeng_" + "v30_pro" + `" \{\s*$`,
				`^\s*r\.ReqKey = "` + "jimeng_" + "ti2v_v30_pro" + `"\s*$`,
			},
		},
		{
			ruleID:      "generic-api-key",
			description: "Verified random-key alphabet",
			path:        `paths = ['''(?:^|/)common/utils\.go$''']`,
			lines:       []string{`^\s*const keyChars = "` + keyAlphabet + `"\s*$`},
		},
		{
			ruleID:      "generic-api-key",
			description: "Verified mock control-token test fixture",
			path:        `paths = ['''(?:^|/)deploy/mvp/mock/main_test\.go$''']`,
			lines:       []string{`^\s*const testControlToken = "` + mockControlToken + `"\s*$`},
		},
		{
			ruleID:      "private-key",
			description: "Verified private-key PEM delimiter handling",
			path:        `paths = ['''(?:^|/)relay/channel/vertex/service_account\.go$''']`,
			lines:       []string{`-----BEGIN PRIVATE ` + "KEY-----" + `", ""\)\n\s*privateKeyPEM = strings\.ReplaceAll\(privateKeyPEM, "-----END PRIVATE ` + "KEY-----"},
		},
		{
			ruleID:      "gcp-api-key",
			description: "Verified API-key masking example",
			path:        `paths = ['''(?:^|/)relaykit/relayconvert/kitutil/mask\.go$''']`,
			lines: []string{`^\s*// Mask API keys \(e\.g\., "api_key:` + maskExample +
				`" -> "api_key:\*\*\*"\)\s*$`},
		},
	}

	wantAllowlistsPerRule := map[string]int{
		"generic-api-key": 6,
		"private-key":     1,
		"gcp-api-key":     1,
	}
	if got := strings.Count(text, "[[rules]]"); got != len(wantAllowlistsPerRule) {
		t.Errorf("Gitleaks policy has %d default-rule override blocks, want %d", got, len(wantAllowlistsPerRule))
	}
	for ruleID, want := range wantAllowlistsPerRule {
		block := gitleaksRuleBlock(text, ruleID)
		if block == "" {
			t.Errorf("Gitleaks policy is missing default-rule override %q", ruleID)
			continue
		}
		if got := strings.Count(block, "[[rules.allowlists]]"); got != want {
			t.Errorf("Gitleaks rule %q has %d exact allowlists, want %d", ruleID, got, want)
		}
	}

	for _, exception := range exceptions {
		ruleBlock := gitleaksRuleBlock(text, exception.ruleID)
		block := gitleaksRuleAllowlistBlock(ruleBlock, exception.description)
		if block == "" {
			t.Errorf("Gitleaks rule %q is missing allowlist %q", exception.ruleID, exception.description)
			continue
		}
		markers := []string{`condition = "AND"`, exception.path}
		if exception.ruleID == "private-key" {
			markers = append(markers, `regexTarget = "match"`)
		} else {
			markers = append(markers, `regexTarget = "line"`)
		}
		markers = append(markers, exception.lines...)
		for _, marker := range markers {
			if !strings.Contains(block, marker) {
				t.Errorf("Gitleaks rule %q allowlist %q is missing exact marker %q", exception.ruleID, exception.description, marker)
			}
		}
	}
}

func TestCommercialMVPSecretSentinelUsesProductionGitleaksPolicy(t *testing.T) {
	script, err := os.ReadFile("../scripts/ci/negative-control.sh")
	if err != nil {
		t.Fatal(err)
	}
	text := string(script)

	required := []string{
		"${BASH_SOURCE[0]}",
		"gitleaks_config=",
		`"$temp_dir:/scan:ro"`,
		`"$gitleaks_config:/config/.gitleaks.toml:ro"`,
		"--source=/scan",
		"--config=/config/.gitleaks.toml",
	}
	for _, marker := range required {
		if !strings.Contains(text, marker) {
			t.Errorf("secret-sentinel control is missing production-policy marker %q", marker)
		}
	}
}

func tomlSectionContains(config, section, setting string) bool {
	inSection := false
	for _, line := range strings.Split(config, "\n") {
		line = strings.TrimSpace(line)
		if strings.HasPrefix(line, "[") {
			inSection = line == "["+section+"]"
			continue
		}
		if inSection && line == setting {
			return true
		}
	}
	return false
}

func gitleaksRuleBlock(config, ruleID string) string {
	for _, block := range strings.Split(config, "[[rules]]") {
		header := strings.SplitN(block, "[[rules.allowlists]]", 2)[0]
		if strings.Contains(header, `id = "`+ruleID+`"`) {
			return block
		}
	}
	return ""
}

func gitleaksRuleAllowlistBlock(ruleBlock, description string) string {
	for _, block := range strings.Split(ruleBlock, "[[rules.allowlists]]") {
		if strings.Contains(block, `description = "`+description+`"`) {
			return block
		}
	}
	return ""
}
