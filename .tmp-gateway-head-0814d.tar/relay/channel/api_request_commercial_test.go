package channel_test

import (
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"net/url"
	"strings"
	"testing"

	"github.com/QuantumNous/new-api/common"
	channel "github.com/QuantumNous/new-api/relay/channel"
	"github.com/QuantumNous/new-api/relay/channel/openai"
	relaycommon "github.com/QuantumNous/new-api/relay/common"
	relayconstant "github.com/QuantumNous/new-api/relay/constant"
	"github.com/QuantumNous/new-api/service"
	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/require"
)

func commercialRelayInfo(baseURL, authType, authHeader string) *relaycommon.RelayInfo {
	host, _, _ := net.SplitHostPort(mustParseURL(baseURL).Host)
	return &relaycommon.RelayInfo{
		RelayMode: relayconstant.RelayModeResponses,
		ChannelMeta: &relaycommon.ChannelMeta{
			ChannelBaseUrl:          baseURL,
			ApiKey:                  "resolved-commercial-secret",
			Commercial:              true,
			AuthType:                authType,
			AuthHeaderName:          authHeader,
			ConnectTimeoutMS:        1000,
			ResponseHeaderTimeoutMS: 1000,
			NonstreamTotalTimeoutMS: 3000,
			StreamMaxDurationMS:     3000,
			MaxResponseBytes:        4,
			MaxStreamBytes:          16,
			AllowedPrivateHosts:     []string{host},
		},
	}
}

func mustParseURL(rawURL string) *url.URL {
	parsed, err := url.Parse(rawURL)
	if err != nil {
		panic(err)
	}
	return parsed
}

func TestCommercialDoApiRequestReplacesAuthAndSanitizesUpstreamResponse(t *testing.T) {
	tests := []struct {
		name       string
		authType   string
		authHeader string
		assertAuth func(*testing.T, http.Header)
	}{
		{
			name:     "bearer",
			authType: service.CommercialAuthBearer,
			assertAuth: func(t *testing.T, headers http.Header) {
				require.Equal(t, "Bearer resolved-commercial-secret", headers.Get("Authorization"))
			},
		},
		{
			name:       "fixed header",
			authType:   service.CommercialAuthFixedHeader,
			authHeader: "X-Transfer-Key",
			assertAuth: func(t *testing.T, headers http.Header) {
				require.Empty(t, headers.Get("Authorization"))
				require.Equal(t, "resolved-commercial-secret", headers.Get("X-Transfer-Key"))
			},
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			received := make(chan http.Header, 1)
			server := httptest.NewServer(http.HandlerFunc(func(writer http.ResponseWriter, request *http.Request) {
				received <- request.Header.Clone()
				writer.Header().Set("Content-Type", "application/json")
				writer.Header().Set("X-Reasoning-Included", "true")
				writer.Header().Set("Set-Cookie", "upstream-secret=value")
				writer.Header().Set("X-Upstream-Internal", "internal")
				_, _ = writer.Write([]byte("12345"))
			}))
			defer server.Close()

			recorder := httptest.NewRecorder()
			ctx, _ := gin.CreateTestContext(recorder)
			ctx.Request = httptest.NewRequest(http.MethodPost, "/v1/responses", strings.NewReader(`{"model":"gpt-5.4"}`))
			ctx.Request.Header.Set("Content-Type", "application/json")
			ctx.Request.Header.Set("Authorization", "Bearer customer-secret")
			ctx.Request.Header.Set("Cookie", "customer=session")
			ctx.Request.Header.Set("Forwarded", "for=127.0.0.1")
			ctx.Request.Header.Set("X-Forwarded-For", "127.0.0.1")
			info := commercialRelayInfo(server.URL, test.authType, test.authHeader)

			response, err := channel.DoApiRequest(&openai.Adaptor{}, ctx, info, strings.NewReader(`{"model":"upstream"}`))

			require.NoError(t, err)
			upstreamHeaders := <-received
			test.assertAuth(t, upstreamHeaders)
			require.Empty(t, upstreamHeaders.Get("Cookie"))
			require.Empty(t, upstreamHeaders.Get("Forwarded"))
			require.Empty(t, upstreamHeaders.Get("X-Forwarded-For"))
			require.Equal(t, "application/json", response.Header.Get("Content-Type"))
			require.Equal(t, "true", response.Header.Get("X-Reasoning-Included"))
			require.Empty(t, response.Header.Get("Set-Cookie"))
			require.Empty(t, response.Header.Get("X-Upstream-Internal"))
			body, readErr := io.ReadAll(response.Body)
			require.ErrorIs(t, readErr, service.ErrCommercialResponseTooLarge)
			require.Equal(t, "1234", string(body))
		})
	}
}

func TestCommercialHeaderOverrideRejectsPassthroughAndCredentialInterpolation(t *testing.T) {
	for _, override := range []map[string]any{
		{"*": ""},
		{"Authorization": "Bearer {api_key}"},
		{"X-Transfer-Key": "literal-secret"},
		{"X-Upstream": "{client_header:X-Customer-Controlled}"},
		{"Content-Type": "text/plain"},
		{"Content-Encoding": "gzip"},
		{"Accept": "application/xml"},
	} {
		recorder := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(recorder)
		ctx.Request = httptest.NewRequest(http.MethodPost, "/v1/responses", nil)
		info := commercialRelayInfo("https://transfer.example", service.CommercialAuthFixedHeader, "X-Transfer-Key")
		info.HeadersOverride = override

		_, err := channel.ResolveHeaderOverride(info, ctx)

		require.Error(t, err, override)
	}
}

func TestCommercialDoRequestRejectsUnsupportedRelayModeWithoutDialing(t *testing.T) {
	recorder := httptest.NewRecorder()
	ctx, _ := gin.CreateTestContext(recorder)
	ctx.Request = httptest.NewRequest(http.MethodPost, "/v1/chat/completions", nil)
	info := commercialRelayInfo("https://transfer.example", service.CommercialAuthBearer, "")
	info.RelayMode = relayconstant.RelayModeChatCompletions
	request := httptest.NewRequest(http.MethodPost, "https://transfer.example/v1/chat/completions", nil)

	_, err := channel.DoRequest(ctx, request, info)

	require.Error(t, err)
	require.NotContains(t, err.Error(), "transfer.example")
}

func TestCommercialDoApiRequestAppliesCodexHeaderContractAcrossResponsesRoutes(t *testing.T) {
	previousSecret := common.CryptoSecret
	common.CryptoSecret = "commercial-relay-header-secret"
	t.Cleanup(func() { common.CryptoSecret = previousSecret })

	received := make(chan http.Header, 2)
	server := httptest.NewServer(http.HandlerFunc(func(writer http.ResponseWriter, request *http.Request) {
		received <- request.Header.Clone()
		writer.Header().Set("Content-Type", "application/json")
		_, _ = writer.Write([]byte("{}"))
	}))
	defer server.Close()

	var firstPseudonyms map[string]string
	for _, test := range []struct {
		path string
		mode int
	}{
		{"/v1/responses", relayconstant.RelayModeResponses},
		{"/v1/responses/compact", relayconstant.RelayModeResponsesCompact},
	} {
		recorder := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(recorder)
		ctx.Request = httptest.NewRequest(http.MethodPost, test.path, strings.NewReader(`{"model":"gpt-5.4"}`))
		for name, value := range map[string]string{
			"Content-Type": "application/json", "Authorization": "Bearer customer-secret",
			"Cookie": "customer=session", "Forwarded": "for=127.0.0.1", "X-Forwarded-For": "127.0.0.1",
			"Session-Id": "session-123", "Thread-Id": "thread-456", "X-Client-Request-Id": "request-789",
			"X-Openai-Subagent": "codex_cli", "X-Codex-Turn-State": "opaque turn state", "Originator": "Codex CLI",
		} {
			ctx.Request.Header.Set(name, value)
		}
		info := commercialRelayInfo(server.URL, service.CommercialAuthBearer, "")
		info.RelayMode = test.mode
		info.UseRuntimeHeadersOverride = true
		info.RuntimeHeadersOverride = map[string]any{
			"session-id": "session-123",
			"originator": "Codex CLI",
		}

		response, err := channel.DoApiRequest(&openai.Adaptor{}, ctx, info, strings.NewReader(`{"model":"upstream"}`))
		require.NoError(t, err)
		require.NoError(t, response.Body.Close())
		upstream := <-received
		require.Equal(t, "Bearer resolved-commercial-secret", upstream.Get("Authorization"))
		require.Equal(t, "codex_cli", upstream.Get("X-Openai-Subagent"))
		require.Equal(t, "opaque turn state", upstream.Get("X-Codex-Turn-State"))
		for _, name := range []string{"Cookie", "Forwarded", "X-Forwarded-For", "Originator"} {
			require.Empty(t, upstream.Get(name), name)
		}
		current := map[string]string{}
		for _, name := range []string{"Session-Id", "Thread-Id", "X-Client-Request-Id"} {
			current[name] = upstream.Get(name)
			require.Len(t, current[name], 64)
		}
		if firstPseudonyms == nil {
			firstPseudonyms = current
		} else {
			require.Equal(t, firstPseudonyms, current)
		}
	}
}

func TestCommercialDoApiRequestMalformedFirstFrameKeepsJSONErrorHeaders(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(writer http.ResponseWriter, request *http.Request) {
		writer.Header().Set("Content-Type", "text/event-stream")
		writer.Header().Set("X-Reasoning-Included", "true")
		writer.Header().Set("X-Codex-Turn-State", "upstream-state")
		_, _ = writer.Write([]byte("data: {\"type\":\"vendor.private\",\"secret\":\"vendor sentinel\"}\n\n"))
	}))
	defer server.Close()

	recorder := httptest.NewRecorder()
	ctx, _ := gin.CreateTestContext(recorder)
	ctx.Request = httptest.NewRequest(http.MethodPost, "/v1/responses", strings.NewReader(`{"model":"gpt-5.4","stream":true}`))
	ctx.Request.Header.Set("Content-Type", "application/json")
	info := commercialRelayInfo(server.URL, service.CommercialAuthBearer, "")
	info.IsStream = true
	info.FirstEventTimeoutMS = 100
	info.StreamIdleTimeoutMS = 200
	info.MaxEventBytes = 1024
	info.MaxStreamBytes = 4096

	response, err := channel.DoApiRequest(&openai.Adaptor{}, ctx, info, strings.NewReader(`{"model":"upstream","stream":true}`))
	require.NoError(t, err)

	usage, apiErr := openai.OaiResponsesStreamHandler(ctx, info, response)
	require.Nil(t, usage)
	require.NotNil(t, apiErr)
	require.NotContains(t, apiErr.Error(), "vendor sentinel")

	ctx.JSON(apiErr.StatusCode, gin.H{"error": apiErr.ToOpenAIError()})
	require.Equal(t, "application/json; charset=utf-8", recorder.Header().Get("Content-Type"))
	for _, name := range []string{
		"Cache-Control", "Connection", "Transfer-Encoding", "X-Accel-Buffering",
		"X-Reasoning-Included", "X-Codex-Turn-State",
	} {
		require.Empty(t, recorder.Header().Get(name), name)
	}
	require.NotContains(t, recorder.Body.String(), "vendor sentinel")
}
