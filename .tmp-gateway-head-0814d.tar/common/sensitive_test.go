package common

import (
	"bytes"
	"net/url"
	"testing"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/require"
)

func TestSystemLogSinksRedactRegisteredSensitiveValues(t *testing.T) {
	secret := "commercial-system-log-secret/with+symbols"
	RegisterSensitiveValue(secret)
	message := "ordinary text raw=" + secret + " query=" + url.QueryEscape(secret) + " path=" + url.PathEscape(secret)
	var output bytes.Buffer
	var errors bytes.Buffer

	LogWriterMu.Lock()
	previousOutput := gin.DefaultWriter
	previousError := gin.DefaultErrorWriter
	gin.DefaultWriter = &output
	gin.DefaultErrorWriter = &errors
	LogWriterMu.Unlock()
	t.Cleanup(func() {
		LogWriterMu.Lock()
		gin.DefaultWriter = previousOutput
		gin.DefaultErrorWriter = previousError
		LogWriterMu.Unlock()
	})

	SysLog(message)
	SysError(message)
	for _, rendered := range []string{output.String(), errors.String()} {
		require.Contains(t, rendered, "ordinary text")
		require.Contains(t, rendered, "[REDACTED]")
		require.NotContains(t, rendered, secret)
		require.NotContains(t, rendered, url.QueryEscape(secret))
		require.NotContains(t, rendered, url.PathEscape(secret))
	}
}
