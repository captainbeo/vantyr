package common

import (
	"net/url"
	"strings"
	"sync"
)

var sensitiveLogValues sync.Map

func RegisterSensitiveValue(value string) {
	if value == "" {
		return
	}
	sensitiveLogValues.Store(value, struct{}{})
}

func RedactSensitiveValues(message string) string {
	sensitiveLogValues.Range(func(key, _ any) bool {
		value, ok := key.(string)
		if !ok || value == "" {
			return true
		}
		for _, candidate := range []string{value, url.QueryEscape(value), url.PathEscape(value)} {
			if candidate != "" {
				message = strings.ReplaceAll(message, candidate, "[REDACTED]")
			}
		}
		return true
	})
	return message
}
