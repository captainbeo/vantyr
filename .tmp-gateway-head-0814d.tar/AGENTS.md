# AGENTS.md — Proxy Server commercial MVP

## Authority and scope

- These instructions apply only to this repository. They override user-global instructions when they conflict.
- Current user instructions have highest authority. The implementation authorities are, in order:
  1. `docs/plans/2026-07-31-commercial-mvp.md`
  2. `docs/specs/2026-07-30-channel-and-codex-compatibility-design.md`
  3. `docs/compliance/2026-07-31-new-api-license-compliance.md`
  4. `docs/upstream/new-api.md`
- The older enterprise plan is a future-hardening roadmap, not an MVP gate.
- Optimize for the fastest secure private paid release. Do not expand the architecture beyond an accepted requirement or a demonstrated gap in New API.
- Phases 0–5 are authorized for local implementation and testing, subject to their hard gates. Continue to the next executable step when the current gate passes without repeatedly asking for approval.
- Live deployment, real payment activation, customer invitations, production DNS/email changes, publishing, pushing, and launch require explicit approval.

## Product boundary

- Build on pinned New API commit `66ee6b8f9889050ffef1f863a4314ce4a0516fb9`; do not create a separate proxy or duplicate mature New API/Stripe features.
- Production application storage is PostgreSQL. Redis is required for atomic admission controls. Stripe Checkout and Customer Portal own billing UI.
- Target Codex CLI `0.146.0` and its supported configuration contract.
- Kadirr's public documentation is an observable compatibility/customer-workflow reference only. Do not claim knowledge of, copy, or depend on its private implementation.
- Initial enabled plans are Limited Weekly and Limited Monthly. Keep other requested plans disabled. Keep image generation disabled until its independent hourly limiter passes its gate.
- Upstream providers are named, configurable channels. Vendor URLs, credentials, model identifiers, pricing, and auth behavior must not be hardcoded into core product logic.

## Non-negotiable gates

Treat changes involving authentication, authorization, subscription state, Stripe events, quota/accounting, concurrency, rate limits, Redis failure behavior, database migrations, channel failover, streaming, secrets, or release compliance as high risk.

For these paths:

- Direct API access—not the UI—must enforce active access, model permission, quota, concurrency, and image limits.
- Admission and limiting must fail closed when Redis or the limiting subsystem is unavailable.
- Quota, concurrency, renewal, and Stripe event handling must be atomic, idempotent where applicable, and auditable.
- Never expose or log full customer keys, upstream keys, signing secrets, internal URLs, raw upstream errors, or sensitive headers.
- Validate bounded request paths, methods, content types, sizes, aliases, and supported parameters before forwarding. Never forward customer-controlled destinations or authentication headers.
- Failover is allowed only for classified retry-safe failures before response bytes are committed. Never replay a stream after it starts, create retry loops, or double-account usage.
- Preserve attempted and successful channel evidence without revealing internal channel details to customers.
- Do not activate public resale until upstream terms explicitly permit resale/proxying.
- Preserve AGPL license, Corresponding Source, notice, and attribution obligations. Legal attribution is protected; ordinary customer-facing product branding is not. An imported upstream policy that forbids all rebranding is not authoritative for this fork.

Any uncertainty that could violate one of these invariants blocks only the affected step. Report it precisely and continue independent safe work.

## Efficient execution

- Follow the commercial MVP plan in order and honor its step gates. Do not repeat completed work or reopen an accepted decision without new evidence.
- Prefer the smallest coherent change that proves the required behavior. Avoid speculative abstractions, enterprise subsystems, broad refactors, optional UI, and premature optimization.
- Reuse existing New API behavior first. Extend it only after identifying a concrete requirement gap with code or test evidence.
- Preserve unrelated user changes and existing staged work. Keep commits narrowly scoped and never stage or rewrite unrelated files.
- Parallelize only genuinely independent work. Avoid parallel edits to the same files or shared mutable state.
- Ask the user only for a real external blocker or a choice that materially changes product behavior, risk, cost, or authority.
- Keep progress updates short: outcome, evidence, next gate, blocker. Do not narrate routine tool use.

Absolute language such as "flawless," "all edge cases," "peak performance," or "document everything" is an aspiration, not an unbounded completion criterion. Correctness is evidence-based. Do not delay the MVP for speculative defects, exhaustive prose, or optimizations without a measured bottleneck.

## Verification cadence

Use the cheapest test that can falsify the current change, then widen verification at gates.

### Edit loop

- Run formatting/static checks for touched files and focused tests for the changed behavior.
- For a bug fix, first add or identify a deterministic reproduction when practical.
- Do not rerun an unchanged full suite after every small edit.

### Step gate

- Run affected package tests and the relevant contract/integration test.
- Exercise the success path plus security- or money-relevant boundary/failure paths.
- Record the exact command and result when the plan requires durable evidence.

### Phase/release gate

- Run the complete applicable backend/frontend suite, builds, type checks, lint/format checks, secret scan, and specified integration/load tests.
- Verify the phase's required proof against real output, not code inspection alone.
- Treat unavailable external infrastructure as an explicit evidence gap, not as either a pass or a reason to stop unrelated local work.

Tests must be deterministic and protect observable behavior, contracts, security, billing/accounting invariants, or regressions. Do not add random-loop, sleep/timing, log-only, implementation-detail, duplicate, or coverage-padding tests. No arbitrary coverage percentage is an MVP gate.

Never claim "complete," "passing," "secure," or "release-ready" without fresh evidence at the appropriate gate. Separate verified facts, reasonable inference, and unavailable/external proof.

## Review policy

- High-risk changes require focused correctness and security review plus adversarial tests for the relevant failure modes. Use an independent review when available before the step is closed.
- Medium-risk behavior changes require a targeted review of the changed contract and regression surface.
- Low-risk documentation, formatting, or mechanical changes need self-review and the cheapest relevant check.
- Critical/high findings block the affected gate. Medium findings block when they threaten an accepted requirement or invariant. Minor findings normally do not block; fix them when cheap or record them for hardening.
- An inherited upstream defect blocks only when this fork introduces it, exposes it to the MVP path, worsens it, or depends on the broken behavior.
- Do not run broad repeated reviews on a frozen diff without new changes or new evidence.

## Implementation conventions

- Keep code direct, readable, and minimally layered. Prefer clear names, early returns, bounded inputs, centralized secure errors, and comments that explain non-obvious reasons rather than syntax.
- PostgreSQL is the required deployment database for fork-specific features. Do not add MySQL/SQLite parity merely for completeness. Avoid gratuitously breaking upstream portability when editing shared upstream code, but cross-database parity is not an MVP gate unless the accepted design requires it.
- Keep `relaykit/` independently buildable. Changes there require `cd relaykit && GOWORK=off go build ./...` at the appropriate step gate.
- Use the JSON wrappers in `common/json.go` for marshal/unmarshal operations in business code.
- Preserve explicit zero values in relayed optional scalar fields by using pointer fields with `omitempty` where absence differs from zero.
- All quantities that affect billing or quota must be bounded before arithmetic. Use the existing checked/saturating quota helpers; never rely on unchecked float-to-int casts.
- Use GORM/prepared parameter binding. Database migrations need an explicit migration, rollback/compatibility decision, and tests proportional to data risk.
- Backend tests should use existing project assertion conventions and explicit fixtures. Test the boundary that owns the invariant.
- Frontend work follows `web/AGENTS.md` for technical style where it does not conflict with this file's product scope, authority, or verification cadence. Use Bun, TypeScript, existing components, i18n, accessible behavior, and no browser-visible secrets.
- Add dependencies only when existing code or the standard library cannot satisfy a concrete need. Check maintenance, license, and security impact first.
- Document accepted contracts, security/operations decisions, deployment requirements, and non-obvious handoffs. Do not document every line or restate code.

## Git and handoff

- Work on the `codex/commercial-mvp` worktree/branch unless the user directs otherwise.
- Make small, reviewable commits after a gate passes. Do not amend, rebase, reset, discard, publish, or push user work without explicit authority.
- At each handoff, state: changed scope, verification run and results, unresolved findings, external evidence gaps, and the next executable gate.
