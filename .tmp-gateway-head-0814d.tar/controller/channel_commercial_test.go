package controller

import (
	"net/http"
	"net/http/httptest"
	"strconv"
	"strings"
	"testing"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/constant"
	"github.com/QuantumNous/new-api/model"
	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/require"
)

func TestValidateChannelAllowsCommercialReferenceWriteWithoutRawKey(t *testing.T) {
	secretRef := "env://UPSTREAM_PRIMARY_API_KEY"
	authType := "bearer"
	channel := &model.Channel{
		Type:                constant.ChannelTypeOpenAI,
		Name:                "commercial",
		CommercialChannel:   true,
		BaseURL:             common.GetPointer("https://upstream.example.com"),
		SecretRef:           &secretRef,
		AuthType:            &authType,
		ReliabilityPolicyID: common.GetPointer(int64(11)),
		ActiveCostProfileID: common.GetPointer(int64(12)),
		ConfigVersion:       1,
	}

	require.NoError(t, validateChannel(channel, true))
}

func TestValidateChannelAllowsCommercialCodexReferenceWriteWithoutRawKey(t *testing.T) {
	secretRef := "env://UPSTREAM_CODEX_API_KEY"
	authType := "bearer"
	channel := &model.Channel{
		Type:                constant.ChannelTypeCodex,
		Name:                "commercial-codex",
		CommercialChannel:   true,
		BaseURL:             common.GetPointer("https://upstream.example.com"),
		SecretRef:           &secretRef,
		AuthType:            &authType,
		ReliabilityPolicyID: common.GetPointer(int64(11)),
		ActiveCostProfileID: common.GetPointer(int64(12)),
		ConfigVersion:       1,
	}

	require.NoError(t, validateChannel(channel, true))
}

func TestUpdateChannelPromotionForcesCommercialChannelDisabled(t *testing.T) {
	db := setupModelListControllerTestDB(t)
	for _, statement := range []string{
		"ALTER TABLE channels ADD COLUMN commercial_channel BOOLEAN NOT NULL DEFAULT FALSE",
		"ALTER TABLE channels ADD COLUMN secret_ref VARCHAR(255)",
		"ALTER TABLE channels ADD COLUMN auth_type VARCHAR(32)",
		"ALTER TABLE channels ADD COLUMN auth_header_name VARCHAR(128)",
		"ALTER TABLE channels ADD COLUMN failure_domain VARCHAR(128)",
		"ALTER TABLE channels ADD COLUMN reliability_policy_id INTEGER",
		"ALTER TABLE channels ADD COLUMN active_cost_profile_id INTEGER",
		"ALTER TABLE channels ADD COLUMN config_version INTEGER NOT NULL DEFAULT 0",
	} {
		require.NoError(t, db.Exec(statement).Error)
	}
	channel := &model.Channel{Name: "legacy-promotion", Type: constant.ChannelTypeOpenAI, Status: common.ChannelStatusEnabled, Key: "legacy-key"}
	require.NoError(t, db.Create(channel).Error)

	recorder := httptest.NewRecorder()
	ctx, _ := gin.CreateTestContext(recorder)
	ctx.Set("id", 1)
	ctx.Set("role", common.RoleRootUser)
	ctx.Request = httptest.NewRequest(http.MethodPut, "/api/channel/"+strconv.Itoa(channel.Id), strings.NewReader(`{"id":`+strconv.Itoa(channel.Id)+`,"commercial_channel":true,"base_url":"https://upstream.example.com","secret_ref":"env://UPSTREAM_API_KEY","auth_type":"bearer","reliability_policy_id":11,"active_cost_profile_id":12,"config_version":1}`))

	UpdateChannel(ctx)

	require.Equal(t, http.StatusOK, recorder.Code)
	require.Contains(t, recorder.Body.String(), `"success":true`)
	var persisted struct {
		CommercialChannel bool
		Status            int
	}
	require.NoError(t, db.Raw("SELECT commercial_channel, status FROM channels WHERE id = ?", channel.Id).Scan(&persisted).Error)
	require.True(t, persisted.CommercialChannel)
	require.NotEqual(t, common.ChannelStatusEnabled, persisted.Status)
}

func TestGetChannelKeyRejectsCommercialRecovery(t *testing.T) {
	db := setupModelListControllerTestDB(t)
	db = db.Debug()
	for _, statement := range []string{
		"ALTER TABLE channels ADD COLUMN commercial_channel BOOLEAN NOT NULL DEFAULT FALSE",
		"ALTER TABLE channels ADD COLUMN secret_ref VARCHAR(255)",
		"ALTER TABLE channels ADD COLUMN auth_type VARCHAR(32)",
		"ALTER TABLE channels ADD COLUMN auth_header_name VARCHAR(128)",
		"ALTER TABLE channels ADD COLUMN failure_domain VARCHAR(128)",
		"ALTER TABLE channels ADD COLUMN reliability_policy_id INTEGER",
		"ALTER TABLE channels ADD COLUMN active_cost_profile_id INTEGER",
		"ALTER TABLE channels ADD COLUMN config_version INTEGER NOT NULL DEFAULT 0",
	} {
		require.NoError(t, db.Exec(statement).Error)
	}
	channel := &model.Channel{Name: "commercial", Key: "should-not-return"}
	require.NoError(t, db.Create(channel).Error)
	secretRef := "env://UPSTREAM_PRIMARY_API_KEY"
	authType := "bearer"
	require.NoError(t, db.Exec("UPDATE channels SET key = ?, commercial_channel = ?, secret_ref = ?, auth_type = ?, reliability_policy_id = ?, active_cost_profile_id = ?, config_version = ? WHERE id = ?", nil, true, secretRef, authType, 11, 12, 1, channel.Id).Error)
	var commercial bool
	require.NoError(t, db.Raw("SELECT commercial_channel FROM channels WHERE id = ?", channel.Id).Scan(&commercial).Error)
	require.True(t, commercial)

	recorder := httptest.NewRecorder()
	ctx, _ := gin.CreateTestContext(recorder)
	ctx.Params = gin.Params{{Key: "id", Value: "1"}}
	ctx.Request = httptest.NewRequest(http.MethodPost, "/api/channel/1/key", nil)

	GetChannelKey(ctx)

	require.Equal(t, http.StatusForbidden, recorder.Code)
	require.NotContains(t, recorder.Body.String(), "should-not-return")
	require.Contains(t, recorder.Body.String(), "commercial channel key recovery is disabled")
}

func TestGetChannelOmitsCommercialRawKeyButReturnsMetadata(t *testing.T) {
	db := setupModelListControllerTestDB(t)
	for _, statement := range []string{
		"ALTER TABLE channels ADD COLUMN commercial_channel BOOLEAN NOT NULL DEFAULT FALSE",
		"ALTER TABLE channels ADD COLUMN secret_ref VARCHAR(255)",
		"ALTER TABLE channels ADD COLUMN auth_type VARCHAR(32)",
		"ALTER TABLE channels ADD COLUMN auth_header_name VARCHAR(128)",
		"ALTER TABLE channels ADD COLUMN failure_domain VARCHAR(128)",
		"ALTER TABLE channels ADD COLUMN reliability_policy_id INTEGER",
		"ALTER TABLE channels ADD COLUMN active_cost_profile_id INTEGER",
		"ALTER TABLE channels ADD COLUMN config_version INTEGER NOT NULL DEFAULT 0",
	} {
		require.NoError(t, db.Exec(statement).Error)
	}
	secretRef := "env://UPSTREAM_PRIMARY_API_KEY"
	authType := "fixed-header"
	require.NoError(t, db.Exec("INSERT INTO channels (name, key, commercial_channel, secret_ref, auth_type, auth_header_name, reliability_policy_id, active_cost_profile_id, config_version) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)", "commercial", "should-not-return", true, secretRef, authType, "X-Upstream-Key", 11, 12, 1).Error)

	recorder := httptest.NewRecorder()
	ctx, _ := gin.CreateTestContext(recorder)
	ctx.Params = gin.Params{{Key: "id", Value: "1"}}
	ctx.Request = httptest.NewRequest(http.MethodGet, "/api/channel/1", nil)

	GetChannel(ctx)

	require.Equal(t, http.StatusOK, recorder.Code)
	require.NotContains(t, recorder.Body.String(), "should-not-return")
	require.Contains(t, recorder.Body.String(), "env://UPSTREAM_PRIMARY_API_KEY")
	require.Contains(t, recorder.Body.String(), "fixed-header")
	require.Contains(t, recorder.Body.String(), "X-Upstream-Key")
}

func TestUpdateChannelPartialCommercialMetadataPreservesOmittedFields(t *testing.T) {
	db := setupModelListControllerTestDB(t)
	for _, statement := range []string{
		"ALTER TABLE channels ADD COLUMN commercial_channel BOOLEAN NOT NULL DEFAULT FALSE",
		"ALTER TABLE channels ADD COLUMN secret_ref VARCHAR(255)",
		"ALTER TABLE channels ADD COLUMN auth_type VARCHAR(32)",
		"ALTER TABLE channels ADD COLUMN auth_header_name VARCHAR(128)",
		"ALTER TABLE channels ADD COLUMN failure_domain VARCHAR(128)",
		"ALTER TABLE channels ADD COLUMN reliability_policy_id INTEGER",
		"ALTER TABLE channels ADD COLUMN active_cost_profile_id INTEGER",
		"ALTER TABLE channels ADD COLUMN config_version INTEGER NOT NULL DEFAULT 0",
	} {
		require.NoError(t, db.Exec(statement).Error)
	}
	channel := &model.Channel{Name: "commercial"}
	require.NoError(t, db.Create(channel).Error)
	require.NoError(t, db.Exec(`UPDATE channels
SET commercial_channel = ?, base_url = ?, secret_ref = ?, auth_type = ?, auth_header_name = ?,
    failure_domain = ?, reliability_policy_id = ?, active_cost_profile_id = ?, config_version = ?
WHERE id = ?`, true, "https://upstream.example.com", "env://UPSTREAM_PRIMARY_API_KEY", "fixed-header", "X-Upstream-Key", "primary", 11, 12, 7, channel.Id).Error)

	recorder := httptest.NewRecorder()
	ctx, _ := gin.CreateTestContext(recorder)
	ctx.Set("id", 1)
	ctx.Set("role", common.RoleRootUser)
	ctx.Request = httptest.NewRequest(
		http.MethodPut,
		"/api/channel/",
		strings.NewReader(`{"id":`+strconv.Itoa(channel.Id)+`,"secret_ref":"env://UPSTREAM_ROTATED_API_KEY"}`),
	)

	UpdateChannel(ctx)

	require.Equal(t, http.StatusOK, recorder.Code)
	require.Contains(t, recorder.Body.String(), `"success":true`)
	var persisted struct {
		BaseURL             string
		SecretRef           string
		AuthType            string
		AuthHeaderName      string
		FailureDomain       string
		ReliabilityPolicyID int64
		ActiveCostProfileID int64
		ConfigVersion       int64
	}
	require.NoError(t, db.Raw(`SELECT base_url, secret_ref, auth_type, auth_header_name, failure_domain,
reliability_policy_id, active_cost_profile_id, config_version FROM channels WHERE id = ?`, channel.Id).Scan(&persisted).Error)
	require.Equal(t, "https://upstream.example.com", persisted.BaseURL)
	require.Equal(t, "env://UPSTREAM_ROTATED_API_KEY", persisted.SecretRef)
	require.Equal(t, "fixed-header", persisted.AuthType)
	require.Equal(t, "X-Upstream-Key", persisted.AuthHeaderName)
	require.Equal(t, "primary", persisted.FailureDomain)
	require.EqualValues(t, 11, persisted.ReliabilityPolicyID)
	require.EqualValues(t, 12, persisted.ActiveCostProfileID)
	require.EqualValues(t, 7, persisted.ConfigVersion)
}

func TestUpdateChannelRejectsExplicitCommercialDemotion(t *testing.T) {
	db := setupModelListControllerTestDB(t)
	for _, statement := range []string{
		"ALTER TABLE channels ADD COLUMN commercial_channel BOOLEAN NOT NULL DEFAULT FALSE",
		"ALTER TABLE channels ADD COLUMN secret_ref VARCHAR(255)",
		"ALTER TABLE channels ADD COLUMN auth_type VARCHAR(32)",
		"ALTER TABLE channels ADD COLUMN auth_header_name VARCHAR(128)",
		"ALTER TABLE channels ADD COLUMN failure_domain VARCHAR(128)",
		"ALTER TABLE channels ADD COLUMN reliability_policy_id INTEGER",
		"ALTER TABLE channels ADD COLUMN active_cost_profile_id INTEGER",
		"ALTER TABLE channels ADD COLUMN config_version INTEGER NOT NULL DEFAULT 0",
	} {
		require.NoError(t, db.Exec(statement).Error)
	}
	channel := &model.Channel{Name: "commercial", Status: common.ChannelStatusManuallyDisabled}
	require.NoError(t, db.Create(channel).Error)
	secretRef := "env://UPSTREAM_PRIMARY_API_KEY"
	authType := "bearer"
	require.NoError(t, db.Exec(`UPDATE channels SET commercial_channel = ?, secret_ref = ?, auth_type = ?, reliability_policy_id = ?, active_cost_profile_id = ?, config_version = ? WHERE id = ?`, true, secretRef, authType, 11, 12, 7, channel.Id).Error)

	recorder := httptest.NewRecorder()
	ctx, _ := gin.CreateTestContext(recorder)
	ctx.Params = gin.Params{{Key: "id", Value: strconv.Itoa(channel.Id)}}
	ctx.Set("id", 1)
	ctx.Set("role", common.RoleRootUser)
	ctx.Request = httptest.NewRequest(http.MethodPut, "/api/channel/"+strconv.Itoa(channel.Id), strings.NewReader(`{"id":`+strconv.Itoa(channel.Id)+`,"commercial_channel":false}`))

	UpdateChannel(ctx)

	require.Equal(t, http.StatusOK, recorder.Code)
	require.Contains(t, recorder.Body.String(), "commercial channel demotion is disabled")
	var stillCommercial bool
	require.NoError(t, db.Raw("SELECT commercial_channel FROM channels WHERE id = ?", channel.Id).Scan(&stillCommercial).Error)
	require.True(t, stillCommercial)
}
