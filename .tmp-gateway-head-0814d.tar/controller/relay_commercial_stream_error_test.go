package controller

import (
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/constant"
	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/require"
)

func TestCommercialCommittedStreamDoesNotAppendJSONError(t *testing.T) {
	recorder := httptest.NewRecorder()
	ctx, _ := gin.CreateTestContext(recorder)
	ctx.Request = httptest.NewRequest(http.MethodPost, "/v1/responses", nil)
	common.SetContextKey(ctx, constant.ContextKeyChannelCommercial, true)
	_, err := ctx.Writer.WriteString("data: committed\n\n")
	require.NoError(t, err)

	require.False(t, shouldWriteRelayErrorResponse(ctx))

	legacyRecorder := httptest.NewRecorder()
	legacy, _ := gin.CreateTestContext(legacyRecorder)
	legacy.Request = httptest.NewRequest(http.MethodPost, "/v1/responses", nil)
	_, err = legacy.Writer.WriteString("legacy")
	require.NoError(t, err)
	require.True(t, shouldWriteRelayErrorResponse(legacy))
}
