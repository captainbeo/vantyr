package controller

import (
	"net/http"
	"net/http/httptest"
	"strconv"
	"testing"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/constant"
	"github.com/QuantumNous/new-api/model"
	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/require"
)

func TestVideoProxyRejectsPromotedCommercialChannelWithPersistedPrivateKey(t *testing.T) {
	db := setupModelListControllerTestDB(t)
	originalMemoryCache := common.MemoryCacheEnabled
	common.MemoryCacheEnabled = false
	t.Cleanup(func() { common.MemoryCacheEnabled = originalMemoryCache })
	require.NoError(t, db.AutoMigrate(&model.Task{}))
	for _, statement := range []string{
		"ALTER TABLE channels ADD COLUMN commercial_channel BOOLEAN NOT NULL DEFAULT FALSE",
		"ALTER TABLE channels ADD COLUMN secret_ref VARCHAR(255)",
		"ALTER TABLE channels ADD COLUMN auth_type VARCHAR(32)",
		"ALTER TABLE channels ADD COLUMN auth_header_name VARCHAR(128)",
		"ALTER TABLE channels ADD COLUMN failure_domain VARCHAR(128)",
		"ALTER TABLE channels ADD COLUMN reliability_policy_id INTEGER",
		"ALTER TABLE channels ADD COLUMN active_cost_profile_id INTEGER",
		"ALTER TABLE channels ADD COLUMN config_version INTEGER NOT NULL DEFAULT 0",
	} {
		require.NoError(t, db.Exec(statement).Error)
	}

	resultURL := `{"uri":"data:video/mp4;base64,YQ=="}`
	require.NoError(t, db.Exec(`INSERT INTO channels (id, name, type, status, key, commercial_channel, secret_ref, auth_type, reliability_policy_id, active_cost_profile_id, config_version) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
		181, "promoted-commercial", constant.ChannelTypeGemini, common.ChannelStatusManuallyDisabled, "legacy-channel-key", true, "env://PROMOTED_COMMERCIAL_KEY", "bearer", 11, 12, 1).Error)
	task := &model.Task{
		TaskID:    "task_promoted_commercial_proxy",
		UserId:    71,
		ChannelId: 181,
		Status:    model.TaskStatusSuccess,
		Data:      []byte(resultURL),
		PrivateData: model.TaskPrivateData{
			Key: "retained-private-key",
		},
	}
	require.NoError(t, db.Create(task).Error)
	var persisted model.Task
	require.NoError(t, db.First(&persisted, task.ID).Error)
	require.Equal(t, "retained-private-key", persisted.PrivateData.Key)

	recorder := httptest.NewRecorder()
	ctx, _ := gin.CreateTestContext(recorder)
	ctx.Params = gin.Params{{Key: "task_id", Value: task.TaskID}}
	ctx.Set("id", task.UserId)
	ctx.Request = httptest.NewRequest(http.MethodGet, "/v1/videos/"+task.TaskID+"/content", nil)

	VideoProxy(ctx)

	require.Equal(t, http.StatusForbidden, recorder.Code)
	require.Contains(t, recorder.Body.String(), `"type":"server_error"`)
	require.NotContains(t, recorder.Body.String(), "commercial channel")
	require.NotContains(t, recorder.Body.String(), "retained-private-key")
	require.NotContains(t, recorder.Body.String(), strconv.Itoa(task.ChannelId))
}

func TestUpdateChannelBalanceRejectsCommercialCredentialUse(t *testing.T) {
	balance, err := updateChannelBalance(&model.Channel{
		Type:              constant.ChannelTypeOpenAI,
		CommercialChannel: true,
		Key:               "stale-commercial-key",
	})

	require.ErrorIs(t, err, model.ErrCommercialChannelInactive)
	require.Zero(t, balance)
}
