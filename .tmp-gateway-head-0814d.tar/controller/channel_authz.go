package controller

import "github.com/QuantumNous/new-api/model"

func equalInt64Ptr(a, b *int64) bool {
	if a == nil || b == nil {
		return a == b
	}
	return *a == *b
}

func channelHasSensitiveChanges(channel *PatchChannel, origin *model.Channel, requestData map[string]any) bool {
	if _, ok := requestData["type"]; ok && channel.Type != origin.Type {
		return true
	}
	if _, ok := requestData["key"]; ok && channel.Key != "" && channel.Key != origin.Key {
		return true
	}
	if _, ok := requestData["base_url"]; ok && !equalStringPtr(channel.BaseURL, origin.BaseURL) {
		return true
	}
	if _, ok := requestData["openai_organization"]; ok && !equalStringPtr(channel.OpenAIOrganization, origin.OpenAIOrganization) {
		return true
	}
	if _, ok := requestData["header_override"]; ok && !equalStringPtr(channel.HeaderOverride, origin.HeaderOverride) {
		return true
	}
	if _, ok := requestData["param_override"]; ok && !equalStringPtr(channel.ParamOverride, origin.ParamOverride) {
		return true
	}
	if _, ok := requestData["setting"]; ok && !equalStringPtr(channel.Setting, origin.Setting) {
		return true
	}
	if _, ok := requestData["other"]; ok && channel.Other != origin.Other {
		return true
	}
	if _, ok := requestData["settings"]; ok && channel.OtherSettings != origin.OtherSettings {
		return true
	}
	if _, ok := requestData["commercial_channel"]; ok && channel.CommercialChannel != origin.CommercialChannel {
		return true
	}
	if _, ok := requestData["secret_ref"]; ok && !equalStringPtr(channel.SecretRef, origin.SecretRef) {
		return true
	}
	if _, ok := requestData["auth_type"]; ok && !equalStringPtr(channel.AuthType, origin.AuthType) {
		return true
	}
	if _, ok := requestData["auth_header_name"]; ok && !equalStringPtr(channel.AuthHeaderName, origin.AuthHeaderName) {
		return true
	}
	if _, ok := requestData["failure_domain"]; ok && !equalStringPtr(channel.FailureDomain, origin.FailureDomain) {
		return true
	}
	if _, ok := requestData["reliability_policy_id"]; ok && !equalInt64Ptr(channel.ReliabilityPolicyID, origin.ReliabilityPolicyID) {
		return true
	}
	if _, ok := requestData["active_cost_profile_id"]; ok && !equalInt64Ptr(channel.ActiveCostProfileID, origin.ActiveCostProfileID) {
		return true
	}
	if _, ok := requestData["config_version"]; ok && channel.ConfigVersion != origin.ConfigVersion {
		return true
	}
	if _, ok := requestData["key_mode"]; ok && channel.KeyMode != nil {
		return true
	}
	// Fail closed: any field present in the request that is neither a known
	// sensitive field (gated above) nor an explicitly classified non-sensitive
	// field must be treated as sensitive. This keeps a newly added channel field
	// from silently becoming editable by ChannelWrite-only admins until it is
	// consciously classified in channelNonSensitiveFields.
	for field := range requestData {
		if _, ok := channelSensitiveFields[field]; ok {
			continue
		}
		if _, ok := channelNonSensitiveFields[field]; ok {
			continue
		}
		if _, ok := channelOperationalFields[field]; ok {
			continue
		}
		if _, ok := channelReadOnlyFields[field]; ok {
			continue
		}
		return true
	}
	return false
}

// channelSensitiveFields lists the channel fields whose modification requires
// ChannelSensitiveWrite. They are each checked individually in
// channelHasSensitiveChanges with a precise old-vs-new comparison; this set is
// used to exclude them from the fail-closed scan for unknown fields.
var channelSensitiveFields = map[string]struct{}{
	"type":                   {},
	"key":                    {},
	"base_url":               {},
	"openai_organization":    {},
	"header_override":        {},
	"param_override":         {},
	"setting":                {},
	"other":                  {},
	"settings":               {},
	"key_mode":               {},
	"commercial_channel":     {},
	"secret_ref":             {},
	"auth_type":              {},
	"auth_header_name":       {},
	"failure_domain":         {},
	"reliability_policy_id":  {},
	"active_cost_profile_id": {},
	"config_version":         {},
}

// channelOperationalFields lists fields managed by operation endpoints instead
// of the general channel edit endpoint.
var channelOperationalFields = map[string]struct{}{
	"status": {},
}

// channelReadOnlyFields lists server-managed/accounting fields that the general
// channel edit endpoint must ignore even if a client sends them.
var channelReadOnlyFields = map[string]struct{}{
	"created_time":         {},
	"test_time":            {},
	"response_time":        {},
	"balance":              {},
	"balance_updated_time": {},
	"used_quota":           {},
}

func clearChannelReadOnlyFields(channel *PatchChannel, requestData map[string]any) {
	if _, ok := requestData["created_time"]; ok {
		channel.CreatedTime = 0
	}
	if _, ok := requestData["test_time"]; ok {
		channel.TestTime = 0
	}
	if _, ok := requestData["response_time"]; ok {
		channel.ResponseTime = 0
	}
	if _, ok := requestData["balance"]; ok {
		channel.Balance = 0
	}
	if _, ok := requestData["balance_updated_time"]; ok {
		channel.BalanceUpdatedTime = 0
	}
	if _, ok := requestData["used_quota"]; ok {
		channel.UsedQuota = 0
	}
}

func mergeCommercialChannelPatch(channel *PatchChannel, origin *model.Channel, requestData map[string]any) {
	if origin == nil || !origin.CommercialChannel {
		return
	}
	if _, ok := requestData["commercial_channel"]; !ok {
		channel.CommercialChannel = origin.CommercialChannel
	}
	if _, ok := requestData["base_url"]; !ok {
		channel.BaseURL = origin.BaseURL
	}
	if _, ok := requestData["secret_ref"]; !ok {
		channel.SecretRef = origin.SecretRef
	}
	if _, ok := requestData["auth_type"]; !ok {
		channel.AuthType = origin.AuthType
	}
	if _, ok := requestData["auth_header_name"]; !ok {
		channel.AuthHeaderName = origin.AuthHeaderName
	}
	if _, ok := requestData["failure_domain"]; !ok {
		channel.FailureDomain = origin.FailureDomain
	}
	if _, ok := requestData["reliability_policy_id"]; !ok {
		channel.ReliabilityPolicyID = origin.ReliabilityPolicyID
	}
	if _, ok := requestData["active_cost_profile_id"]; !ok {
		channel.ActiveCostProfileID = origin.ActiveCostProfileID
	}
	if _, ok := requestData["config_version"]; !ok {
		channel.ConfigVersion = origin.ConfigVersion
	}
}

// channelNonSensitiveFields lists routing / server-managed channel
// fields a ChannelWrite admin may edit without ChannelSensitiveWrite. When a new
// field is added to model.Channel it must be added to either this set or
// channelSensitiveFields or channelOperationalFields; otherwise it falls through
// to the fail-closed branch and is treated as sensitive. The
// TestChannelFieldsAreClassified guard test enforces this.
var channelNonSensitiveFields = map[string]struct{}{
	"id":                  {},
	"test_model":          {},
	"name":                {},
	"weight":              {},
	"models":              {},
	"group":               {},
	"model_mapping":       {},
	"status_code_mapping": {},
	"priority":            {},
	"auto_ban":            {},
	"other_info":          {},
	"tag":                 {},
	"remark":              {},
	"channel_info":        {},
	"multi_key_mode":      {},
}
