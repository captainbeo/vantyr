FROM redis:7.4.5-alpine@sha256:bb186d083732f669da90be8b0f975a37812b15e913465bb14d845db72a4e3e08

COPY deploy/mvp/redis-entrypoint.sh /opt/mvp/redis-entrypoint.sh
ENTRYPOINT ["/bin/sh", "/opt/mvp/redis-entrypoint.sh"]
