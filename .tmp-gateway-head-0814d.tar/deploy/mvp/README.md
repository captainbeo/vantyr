# Commercial MVP Compose

This Compose project is a local Phase 0 foundation. It does not authorize a
deployment or claim that the Corresponding Source URL is public.

From WSL, prepare an immutable gateway build context and a temporary non-secret
Compose env file:

```sh
deploy/mvp/prepare-gateway-context.sh /tmp/commercial-mvp-build.env
```

Set fresh URL-safe values of 32 to 128 characters in
`MVP_POSTGRES_PASSWORD`, `MVP_REDIS_PASSWORD`, `MVP_SESSION_SECRET`,
`MVP_MOCK_PRIMARY_CONTROL_TOKEN`, and `MVP_MOCK_SECONDARY_CONTROL_TOKEN`.
Also set distinct `MVP_MOCK_PRIMARY_RELAY_CREDENTIAL` and
`MVP_MOCK_SECONDARY_RELAY_CREDENTIAL` values.
Compose reads them into in-memory deployment secrets; they do not belong in the
env file, repository, command line, or rendered configuration.

Then run:

```sh
docker compose --env-file /tmp/commercial-mvp-build.env -f deploy/mvp/compose.yaml config
docker compose --env-file /tmp/commercial-mvp-build.env -f deploy/mvp/compose.yaml up --build --wait
docker compose --env-file /tmp/commercial-mvp-build.env -f deploy/mvp/compose.yaml down
```

The disposable proof helper generates its own ephemeral test secrets, verifies
that rendered configuration contains none of their values, uses a unique
Compose project, and removes only that project's test containers and volumes:

```sh
bash deploy/mvp/verify-compose.sh config
bash deploy/mvp/verify-compose.sh up
```

The gateway and mock control ports bind only to host loopback. The database,
Redis, mock relay ports, and backend network are not externally published.

Each mock control listener accepts authenticated
`PUT /control/mode` with an exact `application/json` body whose `mode` is
`normal` or `unavailable`. Port `18081` uses
`MVP_MOCK_PRIMARY_CONTROL_TOKEN`; port `18082` uses
`MVP_MOCK_SECONDARY_CONTROL_TOKEN`. Clients should load the bearer header from
a protected input or credential file rather than exposing the token in a
command argument. Every relay/control result returns the non-secret
`X-Mock-Station-ID` header; `/healthz` deliberately returns no identifying
detail.

The gateway seeds the two mock channel rows from `mock-channels.json`. A first
start that installs the commercial migration leaves them disabled; restart the
gateway after migration completion to cross the existing activation fence and
enable them. The fixture explicitly sets `PRIVATE_MVP_MODE=1`; private mode is
never inferred from the channel seed-file marker. Both rows declare the shared `compose-mock-provider` failure
domain because they run inside the same local fixture environment.
