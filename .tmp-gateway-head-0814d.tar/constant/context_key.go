package constant

type ContextKey string

const (
	ContextKeyTokenCountMeta  ContextKey = "token_count_meta"
	ContextKeyPromptTokens    ContextKey = "prompt_tokens"
	ContextKeyEstimatedTokens ContextKey = "estimated_tokens"

	ContextKeyOriginalModel    ContextKey = "original_model"
	ContextKeyRequestStartTime ContextKey = "request_start_time"

	/* token related keys */
	ContextKeyTokenUnlimited         ContextKey = "token_unlimited_quota"
	ContextKeyTokenKey               ContextKey = "token_key"
	ContextKeyTokenId                ContextKey = "token_id"
	ContextKeyTokenGroup             ContextKey = "token_group"
	ContextKeyTokenSpecificChannelId ContextKey = "specific_channel_id"
	ContextKeyTokenModelLimitEnabled ContextKey = "token_model_limit_enabled"
	ContextKeyTokenModelLimit        ContextKey = "token_model_limit"
	ContextKeyTokenCrossGroupRetry   ContextKey = "token_cross_group_retry"

	/* channel related keys */
	ContextKeyChannelId                      ContextKey = "channel_id"
	ContextKeyChannelName                    ContextKey = "channel_name"
	ContextKeyChannelCreateTime              ContextKey = "channel_create_time"
	ContextKeyChannelBaseUrl                 ContextKey = "base_url"
	ContextKeyChannelType                    ContextKey = "channel_type"
	ContextKeyChannelSetting                 ContextKey = "channel_setting"
	ContextKeyChannelOtherSetting            ContextKey = "channel_other_setting"
	ContextKeyChannelParamOverride           ContextKey = "param_override"
	ContextKeyChannelHeaderOverride          ContextKey = "header_override"
	ContextKeyChannelOrganization            ContextKey = "channel_organization"
	ContextKeyChannelAutoBan                 ContextKey = "auto_ban"
	ContextKeyChannelModelMapping            ContextKey = "model_mapping"
	ContextKeyChannelStatusCodeMapping       ContextKey = "status_code_mapping"
	ContextKeyChannelIsMultiKey              ContextKey = "channel_is_multi_key"
	ContextKeyChannelMultiKeyIndex           ContextKey = "channel_multi_key_index"
	ContextKeyChannelKey                     ContextKey = "channel_key"
	ContextKeyChannelCommercial              ContextKey = "channel_commercial"
	ContextKeyChannelAuthType                ContextKey = "channel_auth_type"
	ContextKeyChannelAuthHeaderName          ContextKey = "channel_auth_header_name"
	ContextKeyChannelConnectTimeoutMS        ContextKey = "channel_connect_timeout_ms"
	ContextKeyChannelResponseHeaderTimeoutMS ContextKey = "channel_response_header_timeout_ms"
	ContextKeyChannelFirstEventTimeoutMS     ContextKey = "channel_first_event_timeout_ms"
	ContextKeyChannelStreamIdleTimeoutMS     ContextKey = "channel_stream_idle_timeout_ms"
	ContextKeyChannelStreamMaxDurationMS     ContextKey = "channel_stream_max_duration_ms"
	ContextKeyChannelNonstreamTotalTimeoutMS ContextKey = "channel_nonstream_total_timeout_ms"
	ContextKeyChannelMaxEventBytes           ContextKey = "channel_max_event_bytes"
	ContextKeyChannelMaxStreamBytes          ContextKey = "channel_max_stream_bytes"
	ContextKeyChannelMaxResponseBytes        ContextKey = "channel_max_response_bytes"
	ContextKeyChannelAllowedPrivateHosts     ContextKey = "channel_allowed_private_hosts"

	ContextKeyAutoGroup           ContextKey = "auto_group"
	ContextKeyAutoGroupIndex      ContextKey = "auto_group_index"
	ContextKeyAutoGroupRetryIndex ContextKey = "auto_group_retry_index"

	/* user related keys */
	ContextKeyUserId      ContextKey = "id"
	ContextKeyUserSetting ContextKey = "user_setting"
	ContextKeyUserQuota   ContextKey = "user_quota"
	ContextKeyUserStatus  ContextKey = "user_status"
	ContextKeyUserEmail   ContextKey = "user_email"
	ContextKeyUserGroup   ContextKey = "user_group"
	ContextKeyUsingGroup  ContextKey = "group"
	ContextKeyUserName    ContextKey = "username"

	ContextKeyLocalCountTokens ContextKey = "local_count_tokens"

	ContextKeySystemPromptOverride ContextKey = "system_prompt_override"

	// ContextKeyFileSourcesToCleanup stores file sources that need cleanup when request ends
	ContextKeyFileSourcesToCleanup ContextKey = "file_sources_to_cleanup"

	// ContextKeyAdminRejectReason stores an admin-only reject/block reason extracted from upstream responses.
	// It is not returned to end users, but can be persisted into consume/error logs for debugging.
	ContextKeyAdminRejectReason ContextKey = "admin_reject_reason"

	// ContextKeyLanguage stores the user's language preference for i18n
	ContextKeyLanguage ContextKey = "language"
	ContextKeyIsStream ContextKey = "is_stream"

	// ContextKeyAuditLogged marks that the current request has already recorded
	// a manage/operation audit log inside the handler. When set, the admin-audit
	// fallback in authHelper (finishAdminAudit) skips its record to avoid
	// duplicate entries.
	ContextKeyAuditLogged ContextKey = "audit_logged"

	// ContextKeyPrivateMVPUserLogs marks the private customer usage-log route so
	// its response can use the stricter commercial projection without changing
	// inherited operator and non-commercial views.
	ContextKeyPrivateMVPUserLogs ContextKey = "private_mvp_user_logs"

	// ContextKeyPrivateMVPModelOutput marks the token-scoped model list as a
	// public platform catalog, hiding adaptor/channel ownership metadata.
	ContextKeyPrivateMVPModelOutput ContextKey = "private_mvp_model_output"

	// ContextKeyPrivateMVPMode marks requests entering the private deployment
	// boundary. Channel setup uses it to reject legacy channels even when the
	// inherited selector returns one before commercial filtering is applied.
	ContextKeyPrivateMVPMode ContextKey = "private_mvp_mode"
)
