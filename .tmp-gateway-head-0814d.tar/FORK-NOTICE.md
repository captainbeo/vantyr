# Fork Origin and Modification Notice

This commercial-MVP fork is based on **new-api** by QuantumNous and its
contributors:

- Original project: <https://github.com/QuantumNous/new-api>
- Upstream revision: `66ee6b8f9889050ffef1f863a4314ce4a0516fb9`
- Fork modifications began: **2026-07-31**

The fork preserves the original project identity, copyright notices,
`LICENSE`, `NOTICE`, `THIRD-PARTY-LICENSES.md`, and the user-interface
attribution required by the upstream project's AGPLv3 Section 7 additional
terms. The fork is not represented as an official QuantumNous release.

## Corresponding Source offer

Every production release of this fork must offer its complete Corresponding
Source to every remote user at no charge through the global user-interface
footer. The release build receives the public source URL through
`VITE_CORRESPONDING_SOURCE_URL`; production builds reject a missing, mutable,
non-HTTPS, or lexically non-canonical value. The root route shell is the sole
owner of this compliance footer, outside TanStack Router's route error and
not-found boundaries.

The URL must have this immutable form:

```text
https://github.com/<public-fork-owner>/<public-fork-repository>/tree/<40-character-deployed-commit>
```

The commit in the URL must be the same source revision recorded in the release
container's `org.opencontainers.image.revision` label and deployment record.
Release images must be built through `scripts/build-release-image.sh`. It
anchors itself to its repository, rejects a dirty checkout, archives the exact
tracked `HEAD` revision into a temporary context, verifies the public source URL
resolves, and inspects the built label. The Dockerfile rejects contexts without
the matching release-context revision marker, so an ordinary build from a
mutable working tree fails closed. The two inherited upstream image-publication
workflows are retired.

The production Docker build creates the frontend and immediately verifies only
that the configured attribution, upstream link, and exact source URL strings
are present in that fresh artifact. That check does not prove browser
rendering, public source availability, image publication, deployment, or the
deployed image digest. Those remain separate release evidence gates.

The public repository at that revision must include the preferred form of all
covered source plus the files and scripts needed to build, install, run, and
modify it, including the Go and web source, dependency manifests and lock
files, migrations, Dockerfiles, Compose files, `LICENSE`, `NOTICE`, and
`THIRD-PARTY-LICENSES.md`.

The source publication must not contain secret-bearing production environment
files or values, upstream or Stripe credentials, signing keys, database
contents, customer data, production logs, backups, or other deployment secrets.
Sanitized configuration templates such as `.env.example` and every script
needed to build or run the covered work remain part of the Corresponding Source.

Publishing the source commit and confirming that the footer link resolves for
both signed-out and signed-in users are release gates. A build passing locally
with a test URL is not sufficient evidence for a production release.
