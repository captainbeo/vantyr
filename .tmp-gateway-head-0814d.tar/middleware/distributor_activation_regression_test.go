package middleware

import (
	"net/http"
	"net/http/httptest"
	"strconv"
	"strings"
	"testing"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/constant"
	"github.com/QuantumNous/new-api/model"
	"github.com/QuantumNous/new-api/relaykit/types"
	"github.com/gin-gonic/gin"
	"github.com/glebarez/sqlite"
	"github.com/stretchr/testify/require"
	"gorm.io/gorm"
)

func TestDistributeStopsBeforeNextWhenSelectedChannelSetupFails(t *testing.T) {
	dsn := "file:distributor_activation_regression_" + strings.ReplaceAll(t.Name(), "/", "_") + "?mode=memory&cache=shared"
	db, err := gorm.Open(sqlite.Open(dsn), &gorm.Config{})
	require.NoError(t, err)
	originalDB := model.DB
	originalMemoryCache := common.MemoryCacheEnabled
	model.DB = db
	common.MemoryCacheEnabled = false
	t.Cleanup(func() {
		model.DB = originalDB
		common.MemoryCacheEnabled = originalMemoryCache
	})
	require.NoError(t, db.AutoMigrate(&model.Channel{}))
	for _, statement := range []string{
		"ALTER TABLE channels ADD COLUMN commercial_channel BOOLEAN NOT NULL DEFAULT FALSE",
		"ALTER TABLE channels ADD COLUMN secret_ref VARCHAR(255)",
		"ALTER TABLE channels ADD COLUMN auth_type VARCHAR(32)",
		"ALTER TABLE channels ADD COLUMN auth_header_name VARCHAR(128)",
		"ALTER TABLE channels ADD COLUMN failure_domain VARCHAR(128)",
		"ALTER TABLE channels ADD COLUMN reliability_policy_id INTEGER",
		"ALTER TABLE channels ADD COLUMN active_cost_profile_id INTEGER",
		"ALTER TABLE channels ADD COLUMN config_version INTEGER NOT NULL DEFAULT 0",
	} {
		require.NoError(t, db.Exec(statement).Error)
	}
	secretRef := "env://UPSTREAM_PRIMARY_API_KEY"
	authType := "bearer"
	channel := &model.Channel{
		Name:                "commercial-selected",
		Type:                constant.ChannelTypeOpenAI,
		CommercialChannel:   true,
		BaseURL:             common.GetPointer("https://mock-primary"),
		SecretRef:           &secretRef,
		AuthType:            &authType,
		ReliabilityPolicyID: common.GetPointer(int64(11)),
		ActiveCostProfileID: common.GetPointer(int64(12)),
		ConfigVersion:       1,
	}
	require.NoError(t, db.Create(channel).Error)
	// Simulate a legacy/status bypass reaching the token-specific selection path.
	require.NoError(t, db.Exec("UPDATE channels SET status = ? WHERE id = ?", common.ChannelStatusEnabled, channel.Id).Error)

	gin.SetMode(gin.TestMode)
	router := gin.New()
	router.Use(func(c *gin.Context) {
		c.Set(string(constant.ContextKeyTokenSpecificChannelId), strconv.Itoa(channel.Id))
		c.Next()
	})
	nextCalled := false
	router.POST("/v1/chat/completions", Distribute(), func(c *gin.Context) {
		nextCalled = true
		c.Status(http.StatusOK)
	})
	recorder := httptest.NewRecorder()
	request := httptest.NewRequest(http.MethodPost, "/v1/chat/completions", strings.NewReader(`{"model":"gpt-5.4"}`))
	request.Header.Set("Content-Type", "application/json")
	router.ServeHTTP(recorder, request)

	require.False(t, nextCalled)
	require.GreaterOrEqual(t, recorder.Code, http.StatusBadRequest)
	require.Contains(t, recorder.Body.String(), "commercial channel")
}

func TestPrivateMVPSetupRejectsLegacySelectedChannel(t *testing.T) {
	gin.SetMode(gin.TestMode)
	recorder := httptest.NewRecorder()
	ctx, _ := gin.CreateTestContext(recorder)
	ctx.Request = httptest.NewRequest(http.MethodPost, "/v1/responses", nil)
	common.SetContextKey(ctx, constant.ContextKeyPrivateMVPMode, true)

	apiErr := SetupContextForSelectedChannel(ctx, &model.Channel{
		Id:   7004,
		Name: "legacy-selected",
		Type: constant.ChannelTypeOpenAI,
	}, "gpt-5.4")

	require.NotNil(t, apiErr)
	require.ErrorIs(t, apiErr, model.ErrCommercialChannelInactive)
	require.True(t, types.IsSkipRetryError(apiErr))
	require.Empty(t, common.GetContextKeyString(ctx, constant.ContextKeyChannelKey))
}
