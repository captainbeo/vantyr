package middleware

import (
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/constant"
	"github.com/QuantumNous/new-api/model"
	"github.com/gin-gonic/gin"
	"github.com/glebarez/sqlite"
	"github.com/stretchr/testify/require"
	"gorm.io/gorm"
)

func useCommercialDistributorPolicyDB(t *testing.T) {
	t.Helper()
	db, err := gorm.Open(sqlite.Open("file:commercial_distributor_policy?mode=memory&cache=shared"), &gorm.Config{})
	require.NoError(t, err)
	require.NoError(t, db.Exec(`CREATE TABLE channel_reliability_policies (
		id INTEGER PRIMARY KEY,
		channel_id INTEGER NOT NULL,
		connect_timeout_ms INTEGER NOT NULL,
		response_header_timeout_ms INTEGER NOT NULL,
		first_semantic_event_timeout_ms INTEGER NOT NULL,
		stream_idle_timeout_ms INTEGER NOT NULL,
		stream_max_duration_ms INTEGER NOT NULL,
		nonstream_total_timeout_ms INTEGER NOT NULL,
		max_precommit_buffer_bytes INTEGER NOT NULL,
		max_stream_bytes INTEGER NOT NULL,
		max_response_bytes INTEGER NOT NULL
	)`).Error)
	require.NoError(t, db.Exec(`INSERT INTO channel_reliability_policies VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
		11, 7001, 100, 200, 300, 400, 5000, 1000, 4096, 8192, 6144,
	).Error)
	originalDB := model.DB
	model.DB = db
	t.Cleanup(func() { model.DB = originalDB })
}

func useCommercialDistributorActivation(t *testing.T, enabled bool) {
	t.Helper()
	previous := commercialChannelSelectionEnabled
	commercialChannelSelectionEnabled = func() bool { return enabled }
	t.Cleanup(func() { commercialChannelSelectionEnabled = previous })
}

func TestSetupContextForSelectedCommercialChannelResolvesReference(t *testing.T) {
	useCommercialDistributorPolicyDB(t)
	useCommercialDistributorActivation(t, true)
	t.Setenv("COMMERCIAL_DISTRIBUTOR_TEST_KEY", "commercial-distributor-test-value")
	t.Setenv("COMMERCIAL_MOCK_HOST_ALLOWLIST", "mock-primary")
	secretRef := "env://COMMERCIAL_DISTRIBUTOR_TEST_KEY"
	authType := "fixed-header"
	headerName := "X-Transfer-Key"
	policyID := int64(11)
	costProfileID := int64(12)
	channel := &model.Channel{
		Id:                  7001,
		Name:                "commercial-primary",
		Type:                constant.ChannelTypeOpenAI,
		CommercialChannel:   true,
		BaseURL:             common.GetPointer("https://mock-primary"),
		SecretRef:           &secretRef,
		AuthType:            &authType,
		AuthHeaderName:      &headerName,
		ReliabilityPolicyID: &policyID,
		ActiveCostProfileID: &costProfileID,
		ConfigVersion:       1,
	}
	recorder := httptest.NewRecorder()
	ctx, _ := gin.CreateTestContext(recorder)
	ctx.Request = httptest.NewRequest(http.MethodPost, "/v1/responses", nil)

	apiErr := SetupContextForSelectedChannel(ctx, channel, "gpt-5.4")

	require.Nil(t, apiErr)
	require.Equal(t, "commercial-distributor-test-value", common.GetContextKeyString(ctx, constant.ContextKeyChannelKey))
	require.True(t, common.GetContextKeyBool(ctx, constant.ContextKeyChannelCommercial))
	require.Equal(t, "fixed-header", common.GetContextKeyString(ctx, constant.ContextKeyChannelAuthType))
	require.Equal(t, "X-Transfer-Key", common.GetContextKeyString(ctx, constant.ContextKeyChannelAuthHeaderName))
	require.Equal(t, 100, common.GetContextKeyInt(ctx, constant.ContextKeyChannelConnectTimeoutMS))
	require.Equal(t, 200, common.GetContextKeyInt(ctx, constant.ContextKeyChannelResponseHeaderTimeoutMS))
	require.Equal(t, 300, common.GetContextKeyInt(ctx, constant.ContextKeyChannelFirstEventTimeoutMS))
	require.Equal(t, 400, common.GetContextKeyInt(ctx, constant.ContextKeyChannelStreamIdleTimeoutMS))
	require.Equal(t, 5000, common.GetContextKeyInt(ctx, constant.ContextKeyChannelStreamMaxDurationMS))
	require.Equal(t, 1000, common.GetContextKeyInt(ctx, constant.ContextKeyChannelNonstreamTotalTimeoutMS))
	require.Equal(t, 4096, common.GetContextKeyInt(ctx, constant.ContextKeyChannelMaxEventBytes))
	require.Equal(t, 8192, common.GetContextKeyInt(ctx, constant.ContextKeyChannelMaxStreamBytes))
	require.Equal(t, 6144, common.GetContextKeyInt(ctx, constant.ContextKeyChannelMaxResponseBytes))
	require.Equal(t, []string{"mock-primary"}, common.GetContextKeyStringSlice(ctx, constant.ContextKeyChannelAllowedPrivateHosts))
	require.Empty(t, channel.Key)
}

func TestSetupContextForSelectedCommercialChannelFailsClosedWhenSecretMissing(t *testing.T) {
	useCommercialDistributorActivation(t, true)
	secretRef := "env://COMMERCIAL_DISTRIBUTOR_MISSING_KEY"
	authType := "bearer"
	policyID := int64(11)
	costProfileID := int64(12)
	channel := &model.Channel{
		Id:                  7002,
		Name:                "commercial-missing-secret",
		Type:                constant.ChannelTypeOpenAI,
		CommercialChannel:   true,
		BaseURL:             common.GetPointer("https://mock-primary"),
		SecretRef:           &secretRef,
		AuthType:            &authType,
		ReliabilityPolicyID: &policyID,
		ActiveCostProfileID: &costProfileID,
		ConfigVersion:       1,
	}
	recorder := httptest.NewRecorder()
	ctx, _ := gin.CreateTestContext(recorder)
	ctx.Request = httptest.NewRequest(http.MethodPost, "/v1/responses", nil)

	apiErr := SetupContextForSelectedChannel(ctx, channel, "gpt-5.4")

	require.NotNil(t, apiErr)
	require.Empty(t, common.GetContextKeyString(ctx, constant.ContextKeyChannelKey))
}

func TestSetupContextForSelectedCommercialChannelRequiresRestartActivation(t *testing.T) {
	useCommercialDistributorActivation(t, false)
	secretRef := "env://COMMERCIAL_DISTRIBUTOR_TEST_KEY"
	authType := "bearer"
	policyID := int64(11)
	costProfileID := int64(12)
	channel := &model.Channel{
		Id:                  7003,
		Name:                "commercial-before-restart",
		Type:                constant.ChannelTypeOpenAI,
		CommercialChannel:   true,
		BaseURL:             common.GetPointer("https://mock-primary"),
		SecretRef:           &secretRef,
		AuthType:            &authType,
		ReliabilityPolicyID: &policyID,
		ActiveCostProfileID: &costProfileID,
		ConfigVersion:       1,
	}
	recorder := httptest.NewRecorder()
	ctx, _ := gin.CreateTestContext(recorder)
	ctx.Request = httptest.NewRequest(http.MethodPost, "/v1/responses", nil)

	apiErr := SetupContextForSelectedChannel(ctx, channel, "gpt-5.4")

	require.NotNil(t, apiErr)
	require.Contains(t, apiErr.Error(), model.ErrCommercialChannelInactive.Error())
	require.Empty(t, common.GetContextKeyString(ctx, constant.ContextKeyChannelKey))
}

func TestChannelAffinityRejectsCommercialChannelForUnsupportedPath(t *testing.T) {
	channel := &model.Channel{CommercialChannel: true, Type: constant.ChannelTypeOpenAI}

	require.False(t, channelSupportsRequestPath(channel, "/v1/chat/completions", "gpt-5.4"))
	require.True(t, channelSupportsRequestPath(channel, "/v1/responses", "gpt-5.4"))
}
