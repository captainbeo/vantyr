package model

import (
	"errors"
	"fmt"
	"net/http"
	"net/url"
	"os"
	"regexp"
	"strings"
	"sync"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/constant"
	"gorm.io/gorm"
)

var (
	ErrCommercialChannelRawKey            = errors.New("commercial channels do not accept raw keys")
	ErrCommercialChannelBaseURL           = errors.New("commercial channels require an explicit validated base URL")
	ErrCommercialChannelSecretRef         = errors.New("commercial channels require an env secret reference")
	ErrCommercialChannelAuthType          = errors.New("commercial channels require bearer or fixed-header auth")
	ErrCommercialChannelAuthHeaderName    = errors.New("commercial fixed-header auth requires a valid header name")
	ErrCommercialChannelReliabilityPolicy = errors.New("commercial channels require a reliability policy")
	ErrCommercialChannelCostProfile       = errors.New("commercial channels require a cost profile")
	ErrCommercialChannelConfigVersion     = errors.New("commercial channels require a positive config version")
	ErrCommercialChannelKeyRecovery       = errors.New("commercial channel key recovery is disabled")
	ErrCommercialChannelInactive          = errors.New("commercial channels are inactive until resolver activation")
	ErrCommercialChannelDemotion          = errors.New("commercial channel demotion is disabled")
)

var commercialSecretRefPattern = regexp.MustCompile(`^env://[A-Z_][A-Z0-9_]*$`)
var commercialHeaderNamePattern = regexp.MustCompile(`^[A-Za-z0-9!#$%&'*+\-.^_` + "`" + `|~]+$`)
var commercialReservedAuthHeaders = map[string]struct{}{
	"Accept":              {},
	"Accept-Encoding":     {},
	"Connection":          {},
	"Content-Encoding":    {},
	"Content-Length":      {},
	"Content-Type":        {},
	"Cookie":              {},
	"Expect":              {},
	"Host":                {},
	"Keep-Alive":          {},
	"Proxy-Authenticate":  {},
	"Proxy-Authorization": {},
	"Proxy-Connection":    {},
	"Session-Id":          {},
	"Te":                  {},
	"Thread-Id":           {},
	"Trailer":             {},
	"Transfer-Encoding":   {},
	"Upgrade":             {},
	"X-Client-Request-Id": {},
	"X-Codex-Turn-State":  {},
	"X-Openai-Subagent":   {},
}

var commercialChannelColumns = []string{"commercial_channel", "secret_ref", "auth_type", "auth_header_name", "failure_domain", "reliability_policy_id", "active_cost_profile_id", "config_version"}
var commercialChannelSelectionTypes = []int{constant.ChannelTypeOpenAI, constant.ChannelTypeCodex}

var commercialChannelColumnTypes = func(db *gorm.DB) ([]gorm.ColumnType, error) {
	return db.Migrator().ColumnTypes(&Channel{})
}

var commercialChannelSchemaCapability = struct {
	sync.Mutex
	db      *gorm.DB
	loaded  bool
	columns map[string]struct{}
	err     error
}{}

func resetCommercialChannelSchemaCapability() {
	commercialChannelSchemaCapability.Lock()
	commercialChannelSchemaCapability.db = nil
	commercialChannelSchemaCapability.loaded = false
	commercialChannelSchemaCapability.columns = nil
	commercialChannelSchemaCapability.err = nil
	commercialChannelSchemaCapability.Unlock()
}

func refreshCommercialChannelSchemaCapability() error {
	resetCommercialChannelSchemaCapability()
	_, err := loadCommercialChannelSchemaCapability()
	return err
}

func loadCommercialChannelSchemaCapability() (map[string]struct{}, error) {
	db := DB
	if db == nil {
		return nil, errors.New("commercial channel schema capability requires a database")
	}

	commercialChannelSchemaCapability.Lock()
	defer commercialChannelSchemaCapability.Unlock()
	if commercialChannelSchemaCapability.loaded && commercialChannelSchemaCapability.db == db {
		_, hasCommercialChannel := commercialChannelSchemaCapability.columns["commercial_channel"]
		if hasCommercialChannel || commercialChannelSchemaCapability.err != nil {
			return commercialChannelSchemaCapability.columns, commercialChannelSchemaCapability.err
		}
	}

	columnTypes, err := commercialChannelColumnTypes(db)
	columns := make(map[string]struct{}, len(columnTypes))
	if err == nil {
		for _, columnType := range columnTypes {
			columns[columnType.Name()] = struct{}{}
		}
	} else {
		err = fmt.Errorf("commercial channel schema probe: %w", err)
	}
	commercialChannelSchemaCapability.db = db
	commercialChannelSchemaCapability.loaded = true
	commercialChannelSchemaCapability.columns = columns
	commercialChannelSchemaCapability.err = err
	return columns, err
}

func commercialChannelColumnPresent(column string) (bool, error) {
	columns, err := loadCommercialChannelSchemaCapability()
	if err != nil {
		return false, err
	}
	_, present := columns[column]
	return present, nil
}

func attachCommercialChannelSchemaError(query *gorm.DB, err error) *gorm.DB {
	query = query.Session(&gorm.Session{})
	_ = query.AddError(err)
	return query
}

// EnsureChannelRawCredentialUseAllowed keeps commercial channels inactive
// until a resolver owns production of their request-scoped credential.
func EnsureChannelRawCredentialUseAllowed(channel *Channel) error {
	if channel != nil && channel.CommercialChannel {
		return ErrCommercialChannelInactive
	}
	return nil
}

func CommercialChannelRequestPathAllowed(requestPath string) bool {
	if requestPath == "" {
		return true
	}
	switch requestPath {
	case "/v1/responses", "/responses", "/v1/responses/compact", "/responses/compact":
		return true
	default:
		return false
	}
}

func CommercialChannelSelectionAllowed(channelType int, requestPath string) bool {
	if !CommercialChannelRequestPathAllowed(requestPath) {
		return false
	}
	for _, supportedType := range commercialChannelSelectionTypes {
		if channelType == supportedType {
			return true
		}
	}
	return false
}

func ensureCommercialChannelSelectionReady() error {
	if !CommercialChannelSelectionEnabled() {
		return ErrCommercialChannelInactive
	}
	present, err := commercialChannelColumnPresent("commercial_channel")
	if err != nil {
		return err
	}
	if !present {
		return ErrCommercialChannelInactive
	}
	return nil
}

func CommercialAuthHeaderNameAllowed(headerName string) bool {
	headerName = http.CanonicalHeaderKey(strings.TrimSpace(headerName))
	if headerName == "" || !commercialHeaderNamePattern.MatchString(headerName) {
		return false
	}
	_, reserved := commercialReservedAuthHeaders[headerName]
	return !reserved
}

func registerCommercialSecretReference(secretRef string) {
	envName := strings.TrimPrefix(strings.TrimSpace(secretRef), "env://")
	if envName == "" {
		return
	}
	if secret, ok := os.LookupEnv(envName); ok && secret != "" {
		common.RegisterSensitiveValue(secret)
	}
}

func validCommercialChannelBaseURL(rawURL string) bool {
	trimmedURL := strings.TrimSpace(rawURL)
	if trimmedURL == "" || trimmedURL != rawURL {
		return false
	}
	parsed, err := url.Parse(trimmedURL)
	if err != nil || parsed == nil || !parsed.IsAbs() || parsed.Opaque != "" || parsed.Hostname() == "" {
		return false
	}
	if !strings.EqualFold(parsed.Scheme, "http") && !strings.EqualFold(parsed.Scheme, "https") {
		return false
	}
	return parsed.User == nil && parsed.RawQuery == "" && !parsed.ForceQuery &&
		parsed.Fragment == "" && parsed.RawFragment == "" &&
		(parsed.Path == "" || parsed.Path == "/")
}

func (channel *Channel) ValidateCommercialWrite() error {
	if channel == nil || !channel.CommercialChannel {
		return nil
	}
	if channel.Key != "" {
		return ErrCommercialChannelRawKey
	}
	if channel.BaseURL == nil || !validCommercialChannelBaseURL(*channel.BaseURL) {
		return ErrCommercialChannelBaseURL
	}
	if channel.SecretRef == nil || !commercialSecretRefPattern.MatchString(strings.TrimSpace(*channel.SecretRef)) {
		return ErrCommercialChannelSecretRef
	}
	registerCommercialSecretReference(*channel.SecretRef)
	if channel.AuthType == nil || (*channel.AuthType != "bearer" && *channel.AuthType != "fixed-header") {
		return ErrCommercialChannelAuthType
	}
	if *channel.AuthType == "fixed-header" {
		if channel.AuthHeaderName == nil || strings.TrimSpace(*channel.AuthHeaderName) == "" ||
			!CommercialAuthHeaderNameAllowed(*channel.AuthHeaderName) {
			return ErrCommercialChannelAuthHeaderName
		}
	}
	if channel.ReliabilityPolicyID == nil || *channel.ReliabilityPolicyID <= 0 {
		return ErrCommercialChannelReliabilityPolicy
	}
	if channel.ActiveCostProfileID == nil || *channel.ActiveCostProfileID <= 0 {
		return ErrCommercialChannelCostProfile
	}
	if channel.ConfigVersion <= 0 {
		return ErrCommercialChannelConfigVersion
	}
	return nil
}

func (channel *Channel) persistCommercialColumns(tx *gorm.DB) error {
	return tx.Exec(`UPDATE channels
SET key = ?, commercial_channel = ?, secret_ref = ?, auth_type = ?, auth_header_name = ?,
    failure_domain = ?, reliability_policy_id = ?, active_cost_profile_id = ?, config_version = ?
WHERE id = ?`,
		nil,
		channel.CommercialChannel,
		channel.SecretRef,
		channel.AuthType,
		channel.AuthHeaderName,
		channel.FailureDomain,
		channel.ReliabilityPolicyID,
		channel.ActiveCostProfileID,
		channel.ConfigVersion,
		channel.Id,
	).Error
}

func (channel *Channel) BeforeCreate(tx *gorm.DB) error {
	if channel != nil && channel.CommercialChannel {
		channel.Status = common.ChannelStatusManuallyDisabled
		tx.Statement.Omits = append(tx.Statement.Omits, "key")
	}
	return channel.ValidateCommercialWrite()
}

func (channel *Channel) AfterCreate(tx *gorm.DB) error {
	if !channel.CommercialChannel {
		return nil
	}
	return channel.persistCommercialColumns(tx.Session(&gorm.Session{NewDB: true, SkipHooks: true}))
}

func (channel *Channel) BeforeUpdate(tx *gorm.DB) error {
	if channel != nil && !channel.CommercialChannel && channel.Id > 0 {
		var current struct {
			CommercialChannel bool
		}
		err := tx.Session(&gorm.Session{NewDB: true, SkipHooks: true}).Table("channels").Select("commercial_channel").Where("id = ?", channel.Id).Scan(&current).Error
		if err != nil && !isMissingCommercialColumnError(err) {
			return err
		}
		if err == nil && current.CommercialChannel {
			return ErrCommercialChannelDemotion
		}
	}
	if channel != nil && channel.CommercialChannel && channel.Id > 0 {
		var current struct {
			CommercialChannel bool
		}
		if err := tx.Session(&gorm.Session{NewDB: true, SkipHooks: true}).Table("channels").Select("commercial_channel").Where("id = ?", channel.Id).Scan(&current).Error; err != nil {
			return err
		}
		if !current.CommercialChannel {
			// Promotion is an ownership boundary: a legacy enabled row must enter
			// commercial mode disabled until the resolver activates it.
			channel.Status = common.ChannelStatusManuallyDisabled
			tx.Statement.SetColumn("status", common.ChannelStatusManuallyDisabled)
		}
	}
	if channel != nil && channel.CommercialChannel && channel.Status == common.ChannelStatusEnabled && !CommercialChannelSelectionEnabled() {
		return ErrCommercialChannelInactive
	}
	if channel != nil && channel.CommercialChannel {
		tx.Statement.Omits = append(tx.Statement.Omits, "key")
	}
	return channel.ValidateCommercialWrite()
}

func isMissingCommercialColumnError(err error) bool {
	if err == nil {
		return false
	}
	message := strings.ToLower(err.Error())
	if !strings.Contains(message, "commercial_channel") {
		return false
	}
	return strings.Contains(message, "no such column") ||
		strings.Contains(message, "unknown column") ||
		strings.Contains(message, "does not exist")
}

func (channel *Channel) AfterUpdate(tx *gorm.DB) error {
	if !channel.CommercialChannel {
		return nil
	}
	return channel.persistCommercialColumns(tx.Session(&gorm.Session{NewDB: true, SkipHooks: true}))
}

func (channel *Channel) BeforeDelete(tx *gorm.DB) error {
	if channel != nil && channel.CommercialChannel && channel.Key != "" {
		return fmt.Errorf("%w: delete attempted with raw key", ErrCommercialChannelRawKey)
	}
	return nil
}
