package model

import (
	"errors"
	"strings"
	"testing"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/constant"
	"github.com/QuantumNous/new-api/relaykit/dto"
	"github.com/glebarez/sqlite"
	"github.com/stretchr/testify/require"
	"gorm.io/gorm"
)

func commercialSchemaProbeStatements(statements []string) []string {
	var probes []string
	for _, statement := range statements {
		normalized := strings.ToLower(statement)
		if strings.Contains(normalized, "sqlite_master") ||
			strings.Contains(normalized, "pragma_table_info") ||
			strings.Contains(normalized, "pragma table_info") {
			probes = append(probes, statement)
		}
	}
	return probes
}

func setupPreMigrationCompatibilityDB(t *testing.T) *gorm.DB {
	t.Helper()
	dsn := "file:pre_migration_compatibility_" + strings.ReplaceAll(t.Name(), "/", "_") + "?mode=memory&cache=shared"
	db, err := gorm.Open(sqlite.Open(dsn), &gorm.Config{})
	require.NoError(t, err)
	originalDB := DB
	originalMemoryCache := common.MemoryCacheEnabled
	DB = db
	resetCommercialChannelSchemaCapability()
	common.MemoryCacheEnabled = false
	t.Cleanup(func() {
		DB = originalDB
		resetCommercialChannelSchemaCapability()
		common.MemoryCacheEnabled = originalMemoryCache
	})
	require.NoError(t, db.AutoMigrate(&Channel{}, &Ability{}))
	return db
}

func TestPreMigrationSchemaSupportsFixAbilityAndAdvancedCustomPathFiltering(t *testing.T) {
	db := setupPreMigrationCompatibilityDB(t)
	otherSettings := `{"advanced_custom":{"advanced_routes":[{"incoming_path":"/v1/chat/completions","models":["gpt-5.4"]}]}}`
	channel := &Channel{
		Name:          "legacy-advanced-custom",
		Type:          constant.ChannelTypeAdvancedCustom,
		Status:        common.ChannelStatusEnabled,
		Key:           "legacy-key",
		Group:         "default",
		Models:        "gpt-5.4",
		OtherSettings: otherSettings,
	}
	require.NoError(t, db.Create(channel).Error)
	require.NoError(t, db.Create(&Ability{Group: "default", Model: "gpt-5.4", ChannelId: channel.Id, Enabled: true}).Error)

	success, failures, err := FixAbility()
	require.NoError(t, err)
	require.Equal(t, 1, success)
	require.Zero(t, failures)

	abilities := []Ability{{Group: "default", Model: "gpt-5.4", ChannelId: channel.Id, Enabled: true}}
	filtered := filterAbilitiesByRequestPathAndModel(abilities, "/v1/chat/completions", "gpt-5.4")
	require.Len(t, filtered, 1)
	filtered = filterAbilitiesByRequestPathAndModel(abilities, "/v1/responses", "gpt-5.4")
	require.Empty(t, filtered)
	selected, err := GetChannel("default", "gpt-5.4", 0, "")
	require.NoError(t, err)
	require.NotNil(t, selected)
	require.Equal(t, channel.Id, selected.Id)

	// Keep the DTO import tied to the pre-migration fixture's route contract.
	var settings dto.ChannelOtherSettings
	require.NoError(t, common.UnmarshalJsonStr(otherSettings, &settings))
	require.NotNil(t, settings.AdvancedCustom)
}

func TestAdvancedCustomPathFilteringFailsClosedOnChannelReadError(t *testing.T) {
	setupPreMigrationCompatibilityDB(t)
	abilities := []Ability{{Group: "default", Model: "gpt-5.4", ChannelId: 101, Enabled: true}}
	// A missing channel is a read error/consistency failure, not permission to
	// return an unfiltered candidate.
	require.NoError(t, DB.Migrator().DropTable(&Channel{}))
	require.Empty(t, filterAbilitiesByRequestPathAndModel(abilities, "/v1/chat/completions", "gpt-5.4"))
}

func TestPartialCommercialSchemaUsesLegacyChannelProjection(t *testing.T) {
	db := setupPreMigrationCompatibilityDB(t)
	require.NoError(t, db.Exec("ALTER TABLE channels ADD COLUMN commercial_channel BOOLEAN NOT NULL DEFAULT FALSE").Error)
	channel := &Channel{Name: "partial-schema-channel", Status: common.ChannelStatusEnabled, Key: "legacy-key"}
	require.NoError(t, db.Create(channel).Error)
	require.NoError(t, db.Exec("UPDATE channels SET commercial_channel = ? WHERE id = ?", true, channel.Id).Error)

	channels, err := GetAllChannels(0, 10, false, false)
	require.NoError(t, err)
	require.Len(t, channels, 1)
	require.True(t, channels[0].CommercialChannel)
}

func TestAbilityReadsPreserveLegacyOrphansAndExcludeCommercialChannels(t *testing.T) {
	db := setupPreMigrationCompatibilityDB(t)
	require.NoError(t, db.Exec("ALTER TABLE channels ADD COLUMN commercial_channel BOOLEAN NOT NULL DEFAULT FALSE").Error)

	legacy := &Channel{Name: "legacy-disabled-channel", Status: common.ChannelStatusManuallyDisabled, Key: "legacy-key"}
	require.NoError(t, db.Create(legacy).Error)
	commercial := &Channel{Name: "commercial-channel", Status: common.ChannelStatusEnabled, Key: "legacy-key"}
	require.NoError(t, db.Create(commercial).Error)
	require.NoError(t, db.Exec("UPDATE channels SET commercial_channel = ? WHERE id = ?", true, commercial.Id).Error)
	require.NoError(t, db.Create(&[]Ability{
		{Group: "default", Model: "legacy-orphan-model", ChannelId: 9999, Enabled: true},
		{Group: "default", Model: "legacy-disabled-channel-model", ChannelId: legacy.Id, Enabled: true},
		{Group: "default", Model: "commercial-model", ChannelId: commercial.Id, Enabled: true},
	}).Error)

	require.ElementsMatch(t,
		[]string{"legacy-orphan-model"},
		GetGroupEnabledModels("default"),
	)
	require.ElementsMatch(t,
		[]string{"legacy-orphan-model"},
		GetEnabledModels(),
	)

	abilities := GetAllEnableAbilities()
	require.Len(t, abilities, 1)
	models := make([]string, 0, len(abilities))
	for _, ability := range abilities {
		models = append(models, ability.Model)
	}
	require.ElementsMatch(t, []string{"legacy-orphan-model"}, models)

	abilitiesWithChannels, err := GetAllEnableAbilityWithChannels()
	require.NoError(t, err)
	require.Len(t, abilitiesWithChannels, 1)
	models = models[:0]
	for _, ability := range abilitiesWithChannels {
		models = append(models, ability.Model)
	}
	require.ElementsMatch(t, []string{"legacy-orphan-model"}, models)
}

func TestCommercialDemotionOwnershipReadFailsClosed(t *testing.T) {
	db := setupPreMigrationCompatibilityDB(t)
	legacy := &Channel{Name: "legacy", Status: common.ChannelStatusEnabled, Key: "legacy-key"}
	require.NoError(t, db.Create(legacy).Error)
	require.NoError(t, legacy.BeforeUpdate(db))

	sqlDB, err := db.DB()
	require.NoError(t, err)
	require.NoError(t, sqlDB.Close())
	err = legacy.BeforeUpdate(db)
	require.Error(t, err)
	require.NotContains(t, strings.ToLower(err.Error()), "commercial_channel")
}

func TestCommercialChannelSchemaCapabilityDoesNotProbePerRead(t *testing.T) {
	recorder := &migrationSQLRecorder{}
	dsn := "file:commercial_schema_capability_" + strings.ReplaceAll(t.Name(), "/", "_") + "?mode=memory&cache=shared"
	db, err := gorm.Open(sqlite.Open(dsn), &gorm.Config{Logger: recorder})
	require.NoError(t, err)
	originalDB := DB
	DB = db
	resetCommercialChannelSchemaCapability()
	t.Cleanup(func() {
		DB = originalDB
		resetCommercialChannelSchemaCapability()
	})
	require.NoError(t, db.AutoMigrate(&Channel{}, &Ability{}))
	require.NoError(t, db.Exec("ALTER TABLE channels ADD COLUMN commercial_channel BOOLEAN NOT NULL DEFAULT FALSE").Error)

	legacy := &Channel{Name: "legacy", Status: common.ChannelStatusEnabled, Key: "legacy-key"}
	require.NoError(t, db.Create(legacy).Error)
	require.NoError(t, db.Create(&Ability{Group: "default", Model: "legacy-model", ChannelId: legacy.Id, Enabled: true}).Error)

	// Warm the capability once. Both projection and eligibility must share it.
	var warmup []Channel
	require.NoError(t, ApplyChannelReadProjection(db.Model(&Channel{})).Find(&warmup).Error)
	_ = applyCommercialChannelEligibility(db.Model(&Ability{}))
	recorder.reset()

	for range 3 {
		channels, err := GetAllChannels(0, 10, false, false)
		require.NoError(t, err)
		require.Len(t, channels, 1)
		require.Len(t, GetAllEnableAbilities(), 1)
	}

	require.Empty(t, commercialSchemaProbeStatements(recorder.statements))
}

func TestCommercialChannelSchemaProbeErrorIsCachedAndFailsSelectionClosed(t *testing.T) {
	db := setupPreMigrationCompatibilityDB(t)
	probeErr := errors.New("deterministic commercial schema probe failure")
	originalProbe := commercialChannelColumnTypes
	probeCalls := 0
	commercialChannelColumnTypes = func(*gorm.DB) ([]gorm.ColumnType, error) {
		probeCalls++
		return nil, probeErr
	}
	resetCommercialChannelSchemaCapability()
	t.Cleanup(func() {
		commercialChannelColumnTypes = originalProbe
		resetCommercialChannelSchemaCapability()
	})

	legacy := &Channel{Name: "legacy", Status: common.ChannelStatusEnabled, Key: "legacy-key"}
	require.NoError(t, db.Create(legacy).Error)
	require.NoError(t, db.Create(&Ability{Group: "default", Model: "legacy-model", ChannelId: legacy.Id, Enabled: true}).Error)

	for range 3 {
		abilities, err := GetAllEnableAbilityWithChannels()
		require.ErrorIs(t, err, probeErr)
		require.Empty(t, abilities)
	}
	require.Equal(t, 1, probeCalls)
}

func TestLegacyCommercialSchemaCapabilityRechecksAfterMigrationWindow(t *testing.T) {
	db := setupPreMigrationCompatibilityDB(t)
	legacy := &Channel{Name: "legacy", Status: common.ChannelStatusEnabled, Key: "legacy-key"}
	require.NoError(t, db.Create(legacy).Error)
	require.NoError(t, db.Create(&Ability{Group: "default", Model: "legacy-model", ChannelId: legacy.Id, Enabled: true}).Error)
	require.NoError(t, db.Exec("ALTER TABLE channels ADD COLUMN secret_ref VARCHAR(255)").Error)
	_ = applyCommercialChannelEligibility(db.Model(&Ability{}))

	require.NoError(t, db.Exec("ALTER TABLE channels ADD COLUMN commercial_channel BOOLEAN NOT NULL DEFAULT FALSE").Error)
	require.NoError(t, db.Exec("UPDATE channels SET commercial_channel = ? WHERE id = ?", true, legacy.Id).Error)

	abilities, err := GetAllEnableAbilityWithChannels()
	require.NoError(t, err)
	require.Empty(t, abilities)
}
