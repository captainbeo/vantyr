package model

import (
	"testing"

	"github.com/QuantumNous/new-api/common"
	"github.com/glebarez/sqlite"
	"github.com/stretchr/testify/require"
	"gorm.io/gorm"
)

func TestCommercialChannelFoundationMigrationSkipsNonPostgreSQL(t *testing.T) {
	db, err := gorm.Open(sqlite.Open("file:commercial_channel_migration_skip?mode=memory&cache=shared"), &gorm.Config{})
	require.NoError(t, err)
	originalDB := DB
	originalType := common.MainDatabaseType()
	DB = db
	common.SetMainDatabaseType(common.DatabaseTypeSQLite)
	t.Cleanup(func() {
		DB = originalDB
		common.SetMainDatabaseType(originalType)
	})

	require.NoError(t, migrateCommercialChannelFoundation())
	require.False(t, db.Migrator().HasTable("channel_cost_profiles"))
}
