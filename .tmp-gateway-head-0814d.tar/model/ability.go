package model

import (
	"errors"
	"fmt"
	"strings"
	"sync"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/constant"
	"github.com/QuantumNous/new-api/relaykit/dto"

	"github.com/samber/lo"
	"gorm.io/gorm"
	"gorm.io/gorm/clause"
)

type Ability struct {
	Group     string  `json:"group" gorm:"type:varchar(64);primaryKey;autoIncrement:false"`
	Model     string  `json:"model" gorm:"type:varchar(255);primaryKey;autoIncrement:false"`
	ChannelId int     `json:"channel_id" gorm:"primaryKey;autoIncrement:false;index"`
	Enabled   bool    `json:"enabled"`
	Priority  *int64  `json:"priority" gorm:"bigint;default:0;index"`
	Weight    uint    `json:"weight" gorm:"default:0;index"`
	Tag       *string `json:"tag" gorm:"index"`
}

type AbilityWithChannel struct {
	Ability
	ChannelType int `json:"channel_type"`
}

func GetAllEnableAbilityWithChannels() ([]AbilityWithChannel, error) {
	var abilities []AbilityWithChannel
	query := DB.Table("abilities").
		Select("abilities.*, channels.type as channel_type").
		Joins("LEFT JOIN channels ON abilities.channel_id = channels.id").
		Where("abilities.enabled = ?", true)
	err := applyCommercialChannelEligibility(query).
		Scan(&abilities).Error
	return abilities, err
}

func GetGroupEnabledModels(group string) []string {
	var models []string
	// Find distinct models
	query := DB.Table("abilities").
		Where("abilities."+commonGroupCol+" = ? AND abilities.enabled = ?", group, true)
	applyCommercialChannelEligibilityByChannelID(query).
		Distinct("abilities.model").Pluck("abilities.model", &models)
	return models
}

// GetGroupEnabledModelsCommercialOnly returns only enabled models owned by
// resolver-backed commercial channels. Private MVP routes use this projection
// so inherited legacy channels cannot widen the customer-visible catalog.
func GetGroupEnabledModelsCommercialOnly(group string) []string {
	var models []string
	query := DB.Table("abilities").
		Where("abilities."+commonGroupCol+" = ? AND abilities.enabled = ?", group, true)
	applyAbilityCommercialOnlyEligibility(query).
		Distinct("abilities.model").Pluck("abilities.model", &models)
	return models
}

func GetEnabledModels() []string {
	var models []string
	// Find distinct models
	query := DB.Table("abilities").
		Where("abilities.enabled = ?", true)
	applyCommercialChannelEligibilityByChannelID(query).
		Distinct("abilities.model").Pluck("abilities.model", &models)
	return models
}

// GetEnabledModelsCommercialOnly returns enabled models owned by commercial
// channels after the process-restart activation fence has passed.
func GetEnabledModelsCommercialOnly() []string {
	var models []string
	query := DB.Table("abilities").Where("abilities.enabled = ?", true)
	applyAbilityCommercialOnlyEligibility(query).
		Distinct("abilities.model").Pluck("abilities.model", &models)
	return models
}

func GetAllEnableAbilities() []Ability {
	var abilities []Ability
	query := DB.Model(&Ability{}).
		Select("abilities.*").
		Where("abilities.enabled = ?", true)
	applyCommercialChannelEligibilityByChannelID(query).
		Find(&abilities)
	return abilities
}

func applyCommercialChannelEligibility(query *gorm.DB) *gorm.DB {
	present, err := commercialChannelColumnPresent("commercial_channel")
	if err != nil {
		return attachCommercialChannelSchemaError(query, err)
	}
	if !present {
		return query
	}
	query = query.Where("channels.id IS NULL OR channels.status = ?", common.ChannelStatusEnabled)
	if CommercialChannelSelectionEnabled() {
		return query
	}
	return query.Where("channels.commercial_channel IS NOT TRUE")
}

// applyCommercialChannelEligibilityByChannelID keeps ability-table reads
// compatible with legacy orphaned abilities while excluding promoted
// commercial channels when the discriminator is available.
func applyCommercialChannelEligibilityByChannelID(query *gorm.DB) *gorm.DB {
	present, err := commercialChannelColumnPresent("commercial_channel")
	if err != nil {
		return attachCommercialChannelSchemaError(query, err)
	}
	if !present {
		return query
	}
	ineligibleChannelIDs := query.Session(&gorm.Session{NewDB: true}).
		Table("channels").
		Select("id")
	if CommercialChannelSelectionEnabled() {
		ineligibleChannelIDs = ineligibleChannelIDs.Where("status <> ?", common.ChannelStatusEnabled)
	} else {
		ineligibleChannelIDs = ineligibleChannelIDs.Where("commercial_channel IS TRUE OR status <> ?", common.ChannelStatusEnabled)
	}
	return query.Where("abilities.channel_id NOT IN (?)", ineligibleChannelIDs)
}

func applyAbilityChannelEligibility(query *gorm.DB) *gorm.DB {
	query = query.Where("abilities.enabled = ?", true)
	return applyCommercialChannelEligibilityByChannelID(query)
}

func applyAbilityCommercialOnlyEligibility(query *gorm.DB) *gorm.DB {
	if err := ensureCommercialChannelSelectionReady(); err != nil {
		return attachCommercialChannelSchemaError(query, err)
	}
	return query.Where("abilities.channel_id IN (?)", DB.Table("channels").
		Select("id").
		Where("commercial_channel IS TRUE AND status = ? AND type IN ?", common.ChannelStatusEnabled, commercialChannelSelectionTypes))
}

func applyAbilityRequestPathEligibility(query *gorm.DB, requestPath string) *gorm.DB {
	present, err := commercialChannelColumnPresent("commercial_channel")
	if err != nil {
		return attachCommercialChannelSchemaError(query, err)
	}
	if !present {
		return query
	}
	commercialChannelIDs := query.Session(&gorm.Session{NewDB: true}).
		Table("channels").
		Select("id").
		Where("commercial_channel IS TRUE")
	if CommercialChannelRequestPathAllowed(requestPath) {
		commercialChannelIDs = commercialChannelIDs.Where("type NOT IN ?", commercialChannelSelectionTypes)
	}
	return query.Where("abilities.channel_id NOT IN (?)", commercialChannelIDs)
}

func applyAbilitySelectionEligibility(query *gorm.DB, requestPath string) *gorm.DB {
	return applyAbilityRequestPathEligibility(applyAbilityChannelEligibility(query), requestPath)
}

func getPriority(group string, model string, retry int, requestPath string) (int, error) {
	return getPriorityWithCommercialOnly(group, model, retry, requestPath, false)
}

func getPriorityWithCommercialOnly(group string, model string, retry int, requestPath string, commercialOnly bool) (int, error) {

	var priorities []int
	query := applyAbilitySelectionEligibility(DB.Model(&Ability{}), requestPath)
	if commercialOnly {
		query = applyAbilityCommercialOnlyEligibility(query)
	}
	err := query.
		Select("DISTINCT(abilities.priority)").
		Where("abilities."+commonGroupCol+" = ? and abilities.model = ?", group, model).
		Order("abilities.priority DESC").              // 按优先级降序排序
		Pluck("abilities.priority", &priorities).Error // Pluck用于将查询的结果直接扫描到一个切片中

	if err != nil {
		// 处理错误
		return 0, err
	}

	if len(priorities) == 0 {
		// 如果没有查询到优先级，则返回错误
		return 0, errors.New("数据库一致性被破坏")
	}

	// 确定要使用的优先级
	var priorityToUse int
	if retry >= len(priorities) {
		// 如果重试次数大于优先级数，则使用最小的优先级
		priorityToUse = priorities[len(priorities)-1]
	} else {
		priorityToUse = priorities[retry]
	}
	return priorityToUse, nil
}

func getChannelQuery(group string, model string, retry int, requestPath string) (*gorm.DB, error) {
	return getChannelQueryWithCommercialOnly(group, model, retry, requestPath, false)
}

func getChannelQueryWithCommercialOnly(group string, model string, retry int, requestPath string, commercialOnly bool) (*gorm.DB, error) {
	selectAbilities := func(query *gorm.DB) *gorm.DB {
		query = applyAbilitySelectionEligibility(query, requestPath)
		if commercialOnly {
			query = applyAbilityCommercialOnlyEligibility(query)
		}
		return query
	}
	maxPrioritySubQuery := selectAbilities(DB.Model(&Ability{})).Select("MAX(abilities.priority)").Where("abilities."+commonGroupCol+" = ? and abilities.model = ?", group, model)
	channelQuery := selectAbilities(DB.Model(&Ability{})).Where("abilities."+commonGroupCol+" = ? and abilities.model = ? and abilities.priority = (?)", group, model, maxPrioritySubQuery)
	if retry != 0 {
		priority, err := getPriorityWithCommercialOnly(group, model, retry, requestPath, commercialOnly)
		if err != nil {
			return nil, err
		} else {
			channelQuery = selectAbilities(DB.Model(&Ability{})).Where("abilities."+commonGroupCol+" = ? and abilities.model = ? and abilities.priority = ?", group, model, priority)
		}
	}

	return channelQuery, nil
}

func GetChannel(group string, model string, retry int, requestPath string) (*Channel, error) {
	return getChannelWithCommercialOnly(group, model, retry, requestPath, false)
}

func GetChannelCommercialOnly(group string, model string, retry int, requestPath string) (*Channel, error) {
	if err := ensureCommercialChannelSelectionReady(); err != nil {
		return nil, err
	}
	return getChannelWithCommercialOnly(group, model, retry, requestPath, true)
}

func getChannelWithCommercialOnly(group string, model string, retry int, requestPath string, commercialOnly bool) (*Channel, error) {
	var abilities []Ability

	var err error = nil
	channelQuery, err := getChannelQueryWithCommercialOnly(group, model, retry, requestPath, commercialOnly)
	if err != nil {
		return nil, err
	}
	if common.UsingMainDatabase(common.DatabaseTypeSQLite) || common.UsingMainDatabase(common.DatabaseTypePostgreSQL) {
		err = channelQuery.Order("abilities.weight DESC").Find(&abilities).Error
	} else {
		err = channelQuery.Order("abilities.weight DESC").Find(&abilities).Error
	}
	if err != nil {
		return nil, err
	}
	abilities = filterAbilitiesByRequestPathAndModelWithCommercialOnly(abilities, requestPath, model, commercialOnly)
	channel := Channel{}
	if len(abilities) > 0 {
		// Randomly choose one
		weightSum := uint(0)
		for _, ability_ := range abilities {
			weightSum += ability_.Weight + 10
		}
		// Randomly choose one
		weight := common.GetRandomInt(int(weightSum))
		for _, ability_ := range abilities {
			weight -= int(ability_.Weight) + 10
			//log.Printf("weight: %d, ability weight: %d", weight, *ability_.Weight)
			if weight <= 0 {
				channel.Id = ability_.ChannelId
				break
			}
		}
	} else {
		return nil, nil
	}
	err = omitCommercialColumnsWhenAbsent(DB).First(&channel, "id = ?", channel.Id).Error
	return &channel, err
}

// filterAbilitiesByRequestPathAndModel restricts candidates by request path and
// model for the DB (non-memory-cache) selection path. Only Advanced Custom
// (type 58) channels are path-checked: kept only when one of their routes matches
// requestPath and model; all other channel types always pass. When requestPath is
// empty, filtering is skipped.
func filterAbilitiesByRequestPathAndModel(abilities []Ability, requestPath string, model string) []Ability {
	return filterAbilitiesByRequestPathAndModelWithCommercialOnly(abilities, requestPath, model, false)
}

func filterAbilitiesByRequestPathAndModelWithCommercialOnly(abilities []Ability, requestPath string, model string, commercialOnly bool) []Ability {
	if requestPath == "" || len(abilities) == 0 {
		if !commercialOnly {
			return abilities
		}
	}

	channelIds := make([]int, 0, len(abilities))
	seen := make(map[int]struct{}, len(abilities))
	for _, ability := range abilities {
		if _, ok := seen[ability.ChannelId]; ok {
			continue
		}
		seen[ability.ChannelId] = struct{}{}
		channelIds = append(channelIds, ability.ChannelId)
	}

	var channels []*Channel
	if err := omitCommercialColumnsWhenAbsent(DB.Where("id IN ?", channelIds)).Find(&channels).Error; err != nil {
		// A channel read failure is a consistency failure; never widen selection.
		return nil
	}
	channelsByID := make(map[int]*Channel, len(channels))

	advancedConfigs := make(map[int]*dto.AdvancedCustomConfig)
	for _, channel := range channels {
		channelsByID[channel.Id] = channel
		if channel.Type == constant.ChannelTypeAdvancedCustom {
			advancedConfigs[channel.Id] = channel.GetOtherSettings().AdvancedCustom
		}
	}

	filtered := make([]Ability, 0, len(abilities))
	for _, ability := range abilities {
		if commercialOnly {
			channel, ok := channelsByID[ability.ChannelId]
			if !ok || !channel.CommercialChannel || channel.Status != common.ChannelStatusEnabled {
				continue
			}
		}
		config, isAdvancedCustom := advancedConfigs[ability.ChannelId]
		if !isAdvancedCustom {
			filtered = append(filtered, ability)
			continue
		}
		if config != nil && config.SupportsPathForModel(requestPath, model) {
			filtered = append(filtered, ability)
		}
	}
	return filtered
}

func (channel *Channel) AddAbilities(tx *gorm.DB) error {
	models_ := strings.Split(channel.Models, ",")
	groups_ := strings.Split(channel.Group, ",")
	abilitySet := make(map[string]struct{})
	abilities := make([]Ability, 0, len(models_))
	for _, model := range models_ {
		for _, group := range groups_ {
			key := group + "|" + model
			if _, exists := abilitySet[key]; exists {
				continue
			}
			abilitySet[key] = struct{}{}
			ability := Ability{
				Group:     group,
				Model:     model,
				ChannelId: channel.Id,
				Enabled:   channel.Status == common.ChannelStatusEnabled,
				Priority:  channel.Priority,
				Weight:    uint(channel.GetWeight()),
				Tag:       channel.Tag,
			}
			abilities = append(abilities, ability)
		}
	}
	if len(abilities) == 0 {
		return nil
	}
	// choose DB or provided tx
	useDB := DB
	if tx != nil {
		useDB = tx
	}
	for _, chunk := range lo.Chunk(abilities, 50) {
		err := useDB.Clauses(clause.OnConflict{DoNothing: true}).Create(&chunk).Error
		if err != nil {
			return err
		}
	}
	return nil
}

func (channel *Channel) DeleteAbilities() error {
	return DB.Where("channel_id = ?", channel.Id).Delete(&Ability{}).Error
}

// UpdateAbilities updates abilities of this channel.
// Make sure the channel is completed before calling this function.
func (channel *Channel) UpdateAbilities(tx *gorm.DB) error {
	isNewTx := false
	// 如果没有传入事务，创建新的事务
	if tx == nil {
		tx = DB.Begin()
		if tx.Error != nil {
			return tx.Error
		}
		isNewTx = true
		defer func() {
			if r := recover(); r != nil {
				tx.Rollback()
			}
		}()
	}

	// First delete all abilities of this channel
	err := tx.Where("channel_id = ?", channel.Id).Delete(&Ability{}).Error
	if err != nil {
		if isNewTx {
			tx.Rollback()
		}
		return err
	}

	// Then add new abilities
	models_ := strings.Split(channel.Models, ",")
	groups_ := strings.Split(channel.Group, ",")
	abilitySet := make(map[string]struct{})
	abilities := make([]Ability, 0, len(models_))
	for _, model := range models_ {
		for _, group := range groups_ {
			key := group + "|" + model
			if _, exists := abilitySet[key]; exists {
				continue
			}
			abilitySet[key] = struct{}{}
			ability := Ability{
				Group:     group,
				Model:     model,
				ChannelId: channel.Id,
				Enabled:   channel.Status == common.ChannelStatusEnabled,
				Priority:  channel.Priority,
				Weight:    uint(channel.GetWeight()),
				Tag:       channel.Tag,
			}
			abilities = append(abilities, ability)
		}
	}

	if len(abilities) > 0 {
		for _, chunk := range lo.Chunk(abilities, 50) {
			err = tx.Clauses(clause.OnConflict{DoNothing: true}).Create(&chunk).Error
			if err != nil {
				if isNewTx {
					tx.Rollback()
				}
				return err
			}
		}
	}

	// 如果是新创建的事务，需要提交
	if isNewTx {
		return tx.Commit().Error
	}

	return nil
}

func UpdateAbilityStatus(channelId int, status bool) error {
	return DB.Model(&Ability{}).Where("channel_id = ?", channelId).Select("enabled").Update("enabled", status).Error
}

func UpdateAbilityStatusByTag(tag string, status bool) error {
	query := DB.Model(&Ability{}).Where("tag = ?", tag)
	if status {
		present, err := commercialChannelColumnPresent("commercial_channel")
		if err != nil {
			return err
		}
		if present && !CommercialChannelSelectionEnabled() {
			query = query.Where("channel_id IN (?)", DB.Table("channels").Select("id").Where("commercial_channel IS NOT TRUE"))
		}
	}
	return query.Select("enabled").Update("enabled", status).Error
}

func UpdateAbilityByTag(tag string, newTag *string, priority *int64, weight *uint) error {
	ability := Ability{}
	if newTag != nil {
		ability.Tag = newTag
	}
	if priority != nil {
		ability.Priority = priority
	}
	if weight != nil {
		ability.Weight = *weight
	}
	return DB.Model(&Ability{}).Where("tag = ?", tag).Updates(ability).Error
}

var fixLock = sync.Mutex{}

func FixAbility() (int, int, error) {
	lock := fixLock.TryLock()
	if !lock {
		return 0, 0, errors.New("已经有一个修复任务在运行中，请稍后再试")
	}
	defer fixLock.Unlock()

	// truncate abilities table
	if common.UsingMainDatabase(common.DatabaseTypeSQLite) {
		err := DB.Exec("DELETE FROM abilities").Error
		if err != nil {
			common.SysLog(fmt.Sprintf("Delete abilities failed: %s", err.Error()))
			return 0, 0, err
		}
	} else {
		err := DB.Exec("TRUNCATE TABLE abilities").Error
		if err != nil {
			common.SysLog(fmt.Sprintf("Truncate abilities failed: %s", err.Error()))
			return 0, 0, err
		}
	}
	var channels []*Channel
	// Find all channels
	err := omitCommercialColumnsWhenAbsent(DB.Model(&Channel{})).Find(&channels).Error
	if err != nil {
		return 0, 0, err
	}
	if len(channels) == 0 {
		return 0, 0, nil
	}
	successCount := 0
	failCount := 0
	for _, chunk := range lo.Chunk(channels, 50) {
		ids := lo.Map(chunk, func(c *Channel, _ int) int { return c.Id })
		// Delete all abilities of this channel
		err = DB.Where("channel_id IN ?", ids).Delete(&Ability{}).Error
		if err != nil {
			common.SysLog(fmt.Sprintf("Delete abilities failed: %s", err.Error()))
			failCount += len(chunk)
			continue
		}
		// Then add new abilities
		for _, channel := range chunk {
			err = channel.AddAbilities(nil)
			if err != nil {
				common.SysLog(fmt.Sprintf("Add abilities for channel %d failed: %s", channel.Id, err.Error()))
				failCount++
			} else {
				successCount++
			}
		}
	}
	InitChannelCache()
	return successCount, failCount, nil
}
