package model

import (
	"context"
	"database/sql"
	"strings"
	"sync/atomic"
	"time"

	"github.com/QuantumNous/new-api/common"
)

var commercialChannelSelectionReady atomic.Bool
var commercialChannelRestartRequired atomic.Bool

// CommercialChannelSelectionEnabled reports whether this process started with
// the complete commercial channel foundation already present.
func CommercialChannelSelectionEnabled() bool {
	return commercialChannelSelectionReady.Load()
}

func initializeCommercialChannelActivation(migrationCompleteAtProcessStart bool) {
	if migrationCompleteAtProcessStart && registerCommercialSecretsAtProcessStart() != nil {
		migrationCompleteAtProcessStart = false
	}
	if !migrationCompleteAtProcessStart {
		commercialChannelRestartRequired.Store(true)
	}
	commercialChannelSelectionReady.Store(migrationCompleteAtProcessStart && !commercialChannelRestartRequired.Load())
}

func registerCommercialSecretsAtProcessStart() error {
	if DB == nil {
		return ErrCommercialChannelInactive
	}
	var secretRefs []string
	if err := DB.Table("channels").
		Where("commercial_channel IS TRUE").
		Distinct("secret_ref").
		Pluck("secret_ref", &secretRefs).Error; err != nil {
		return err
	}
	for _, secretRef := range secretRefs {
		if !commercialSecretRefPattern.MatchString(strings.TrimSpace(secretRef)) {
			return ErrCommercialChannelSecretRef
		}
		registerCommercialSecretReference(secretRef)
	}
	return nil
}

func closeCommercialChannelSelection() {
	commercialChannelSelectionReady.Store(false)
}

func commercialChannelFoundationCompleteAtProcessStart() bool {
	if DB == nil || !common.UsingMainDatabase(common.DatabaseTypePostgreSQL) {
		return false
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	sqlDB, err := DB.DB()
	if err != nil {
		return false
	}
	conn, err := sqlDB.Conn(ctx)
	if err != nil {
		return false
	}
	defer conn.Close()

	var ledger sql.NullString
	if err := conn.QueryRowContext(ctx, "SELECT to_regclass('public."+commercialChannelLedger+"')").Scan(&ledger); err != nil || !ledger.Valid {
		return false
	}
	return commercialChannelVerifyDownOwnership(ctx, conn) == nil
}
