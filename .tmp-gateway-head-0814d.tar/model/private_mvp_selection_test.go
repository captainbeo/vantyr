package model

import (
	"testing"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/constant"
	"github.com/stretchr/testify/require"
)

func TestCommercialOnlyChannelSelectionExcludesEnabledLegacyChannels(t *testing.T) {
	db := setupCommercialActivationRegressionDB(t)
	useCommercialChannelActivationState(t, true)

	highPriority := int64(100)
	lowPriority := int64(10)
	legacy := &Channel{
		Name: "private-mvp-legacy", Type: constant.ChannelTypeOpenAI,
		Status: common.ChannelStatusEnabled, Key: "legacy-key",
		Group: "default", Models: "gpt-5.4", Priority: &highPriority,
	}
	require.NoError(t, db.Create(legacy).Error)
	commercial := insertCommercialActivationRegressionChannel(t, db, "private-mvp-commercial", "private-mvp", common.ChannelStatusEnabled)
	require.NoError(t, db.Model(commercial).Updates(map[string]any{
		"status": common.ChannelStatusEnabled, "group": "default", "models": "gpt-5.4", "priority": lowPriority,
	}).Error)
	require.NoError(t, db.Create(&Ability{
		Group: "default", Model: "gpt-5.4", ChannelId: legacy.Id,
		Enabled: true, Priority: &highPriority,
	}).Error)
	require.NoError(t, db.Create(&Ability{
		Group: "default", Model: "gpt-5.4", ChannelId: commercial.Id,
		Enabled: true, Priority: &lowPriority,
	}).Error)

	for _, memoryCache := range []bool{false, true} {
		common.MemoryCacheEnabled = memoryCache
		if memoryCache {
			InitChannelCache()
		}
		selected, err := GetRandomSatisfiedChannelCommercialOnly("default", "gpt-5.4", 0, "/v1/responses")
		require.NoError(t, err)
		require.NotNil(t, selected)
		require.Equal(t, commercial.Id, selected.Id)
	}
}

func TestCommercialOnlyModelProjectionsExcludeLegacyChannels(t *testing.T) {
	db := setupCommercialActivationRegressionDB(t)
	useCommercialChannelActivationState(t, true)

	legacy := &Channel{
		Name: "private-mvp-legacy-model", Type: constant.ChannelTypeOpenAI,
		Status: common.ChannelStatusEnabled, Key: "legacy-key",
		Group: "default", Models: "legacy-model",
	}
	require.NoError(t, db.Create(legacy).Error)
	commercial := insertCommercialActivationRegressionChannel(t, db, "private-mvp-commercial-model", "private-mvp-model", common.ChannelStatusEnabled)
	require.NoError(t, db.Model(commercial).Updates(map[string]any{
		"status": common.ChannelStatusEnabled, "group": "default", "models": "commercial-model",
	}).Error)
	require.NoError(t, db.Create(&Ability{Group: "default", Model: "legacy-model", ChannelId: legacy.Id, Enabled: true}).Error)
	require.NoError(t, db.Create(&Ability{Group: "default", Model: "commercial-model", ChannelId: commercial.Id, Enabled: true}).Error)

	require.Equal(t, []string{"commercial-model"}, GetGroupEnabledModelsCommercialOnly("default"))
	require.Equal(t, []string{"commercial-model"}, GetEnabledModelsCommercialOnly())
}
