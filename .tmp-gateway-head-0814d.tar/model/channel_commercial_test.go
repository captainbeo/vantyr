package model

import (
	"os"
	"reflect"
	"testing"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/constant"
	"github.com/glebarez/sqlite"
	"github.com/stretchr/testify/require"
	"gorm.io/gorm"
)

func TestValidateCommercialChannelWriteRejectsRawKey(t *testing.T) {
	channel := &Channel{
		CommercialChannel: true,
		Key:               "raw-upstream-key",
		SecretRef:         common.GetPointer("env://UPSTREAM_PRIMARY_API_KEY"),
		AuthType:          common.GetPointer("bearer"),
	}

	err := channel.ValidateCommercialWrite()

	require.ErrorIs(t, err, ErrCommercialChannelRawKey)
}

func TestValidateCommercialChannelWriteRequiresExplicitBaseURL(t *testing.T) {
	secretRef := "env://UPSTREAM_PRIMARY_API_KEY"
	authType := "bearer"
	policyID := int64(11)
	costProfileID := int64(12)
	channel := &Channel{
		CommercialChannel:   true,
		SecretRef:           &secretRef,
		AuthType:            &authType,
		ReliabilityPolicyID: &policyID,
		ActiveCostProfileID: &costProfileID,
		ConfigVersion:       1,
	}

	require.ErrorIs(t, channel.ValidateCommercialWrite(), ErrCommercialChannelBaseURL)
}

func TestCommercialChannelGetBaseURLDoesNotFallBackToProviderDefault(t *testing.T) {
	empty := ""
	channel := &Channel{Type: constant.ChannelTypeOpenAI, CommercialChannel: true, BaseURL: &empty}

	require.Empty(t, channel.GetBaseURL())
}

func TestValidateCommercialChannelWriteRequiresReferenceOnlyMetadata(t *testing.T) {
	ptr := func(value string) *string { return common.GetPointer(value) }

	valid := func() *Channel {
		return &Channel{
			CommercialChannel:   true,
			BaseURL:             ptr("https://upstream.example.com"),
			SecretRef:           ptr("env://UPSTREAM_PRIMARY_API_KEY"),
			AuthType:            ptr("bearer"),
			ReliabilityPolicyID: common.GetPointer(int64(11)),
			ActiveCostProfileID: common.GetPointer(int64(12)),
			ConfigVersion:       1,
		}
	}

	tests := []struct {
		name string
		edit func(*Channel)
		err  error
	}{
		{name: "missing secret reference", edit: func(channel *Channel) { channel.SecretRef = nil }, err: ErrCommercialChannelSecretRef},
		{name: "missing base URL", edit: func(channel *Channel) { channel.BaseURL = nil }, err: ErrCommercialChannelBaseURL},
		{name: "base URL must be an origin", edit: func(channel *Channel) { channel.BaseURL = ptr("https://upstream.example.com/v1") }, err: ErrCommercialChannelBaseURL},
		{name: "base URL cannot carry surrounding whitespace", edit: func(channel *Channel) { channel.BaseURL = ptr(" https://upstream.example.com ") }, err: ErrCommercialChannelBaseURL},
		{name: "base URL cannot carry credentials", edit: func(channel *Channel) { channel.BaseURL = ptr("https://user:pass@upstream.example.com") }, err: ErrCommercialChannelBaseURL},
		{name: "literal secret", edit: func(channel *Channel) { channel.SecretRef = ptr("actual-secret") }, err: ErrCommercialChannelSecretRef},
		{name: "unsupported auth type", edit: func(channel *Channel) { channel.AuthType = ptr("query") }, err: ErrCommercialChannelAuthType},
		{name: "fixed header requires a safe name", edit: func(channel *Channel) {
			channel.AuthType = ptr("fixed-header")
			channel.AuthHeaderName = ptr("X-Auth\r\nInjected")
		}, err: ErrCommercialChannelAuthHeaderName},
		{name: "missing policy", edit: func(channel *Channel) { channel.ReliabilityPolicyID = nil }, err: ErrCommercialChannelReliabilityPolicy},
		{name: "missing cost profile", edit: func(channel *Channel) { channel.ActiveCostProfileID = nil }, err: ErrCommercialChannelCostProfile},
		{name: "missing config revision", edit: func(channel *Channel) { channel.ConfigVersion = 0 }, err: ErrCommercialChannelConfigVersion},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			channel := valid()
			test.edit(channel)
			require.ErrorIs(t, channel.ValidateCommercialWrite(), test.err)
		})
	}

	require.NoError(t, valid().ValidateCommercialWrite())
}

func TestCommercialChannelCreateStoresLegacyKeyAsNull(t *testing.T) {
	db, err := gorm.Open(sqlite.Open("file:commercial_channel_key_null?mode=memory&cache=shared"), &gorm.Config{})
	require.NoError(t, err)
	originalDB := DB
	DB = db
	t.Cleanup(func() { DB = originalDB })
	require.NoError(t, db.AutoMigrate(&Channel{}))
	for _, statement := range []string{
		"ALTER TABLE channels ADD COLUMN commercial_channel BOOLEAN NOT NULL DEFAULT FALSE",
		"ALTER TABLE channels ADD COLUMN secret_ref VARCHAR(255)",
		"ALTER TABLE channels ADD COLUMN auth_type VARCHAR(32)",
		"ALTER TABLE channels ADD COLUMN auth_header_name VARCHAR(128)",
		"ALTER TABLE channels ADD COLUMN failure_domain VARCHAR(128)",
		"ALTER TABLE channels ADD COLUMN reliability_policy_id INTEGER",
		"ALTER TABLE channels ADD COLUMN active_cost_profile_id INTEGER",
		"ALTER TABLE channels ADD COLUMN config_version INTEGER NOT NULL DEFAULT 0",
	} {
		require.NoError(t, db.Exec(statement).Error)
	}
	require.NoError(t, db.Exec("CREATE TRIGGER commercial_channel_key_guard BEFORE UPDATE ON channels WHEN NEW.commercial_channel = 1 AND NEW.key IS NOT NULL BEGIN SELECT RAISE(ABORT, 'commercial channel key must be null'); END").Error)

	secretRef := "env://UPSTREAM_PRIMARY_API_KEY"
	authType := "bearer"
	channel := &Channel{
		Name:                "commercial",
		CommercialChannel:   true,
		BaseURL:             common.GetPointer("https://upstream.example.com"),
		SecretRef:           &secretRef,
		AuthType:            &authType,
		ReliabilityPolicyID: common.GetPointer(int64(11)),
		ActiveCostProfileID: common.GetPointer(int64(12)),
		ConfigVersion:       1,
	}
	require.NoError(t, db.Create(channel).Error)

	var storedKey *string
	require.NoError(t, db.Raw("SELECT key FROM channels WHERE id = ?", channel.Id).Scan(&storedKey).Error)
	require.Nil(t, storedKey)
	var persisted struct {
		CommercialChannel bool
		SecretRef         string
		AuthType          string
	}
	require.NoError(t, db.Raw("SELECT commercial_channel, secret_ref, auth_type FROM channels WHERE id = ?", channel.Id).Scan(&persisted).Error)
	require.True(t, persisted.CommercialChannel)
	require.Equal(t, "env://UPSTREAM_PRIMARY_API_KEY", persisted.SecretRef)
	require.Equal(t, "bearer", persisted.AuthType)
}

func TestCommercialChannelMigrationOwnersAndContract(t *testing.T) {
	require.Equal(t, "channel_cost_profiles", (ChannelCostProfile{}).TableName())
	require.Equal(t, "channel_cost_rates", (ChannelCostRate{}).TableName())
	require.Equal(t, "channel_reliability_policies", (ChannelReliabilityPolicy{}).TableName())

	contract := CommercialChannelFoundationSQL()
	for _, fragment := range []string{
		"pg_advisory_lock(19860810, 1011)",
		"CREATE UNIQUE INDEX CONCURRENTLY",
		"ck_channels_commercial_activation",
		"fk_channels_active_cost_profile",
		"trg_channel_cost_profiles_immutable",
		"FOR EACH ROW",
		"VALIDATE CONSTRAINT",
	} {
		require.Contains(t, contract, fragment)
	}
}

func TestCommercialChannelActivationFenceBlocksLegacyRelayAndEnablement(t *testing.T) {
	db, err := gorm.Open(sqlite.Open("file:commercial_channel_activation_fence?mode=memory&cache=shared"), &gorm.Config{})
	require.NoError(t, err)
	originalDB := DB
	originalMemoryCache := common.MemoryCacheEnabled
	DB = db
	common.MemoryCacheEnabled = false
	t.Cleanup(func() {
		DB = originalDB
		common.MemoryCacheEnabled = originalMemoryCache
	})
	require.NoError(t, db.AutoMigrate(&Channel{}))
	for _, statement := range []string{
		"ALTER TABLE channels ADD COLUMN commercial_channel BOOLEAN NOT NULL DEFAULT FALSE",
		"ALTER TABLE channels ADD COLUMN secret_ref VARCHAR(255)",
		"ALTER TABLE channels ADD COLUMN auth_type VARCHAR(32)",
		"ALTER TABLE channels ADD COLUMN auth_header_name VARCHAR(128)",
		"ALTER TABLE channels ADD COLUMN failure_domain VARCHAR(128)",
		"ALTER TABLE channels ADD COLUMN reliability_policy_id INTEGER",
		"ALTER TABLE channels ADD COLUMN active_cost_profile_id INTEGER",
		"ALTER TABLE channels ADD COLUMN config_version INTEGER NOT NULL DEFAULT 0",
	} {
		require.NoError(t, db.Exec(statement).Error)
	}
	secretRef := "env://UPSTREAM_PRIMARY_API_KEY"
	authType := "bearer"
	channel := &Channel{
		Name:                "commercial-fenced",
		CommercialChannel:   true,
		BaseURL:             common.GetPointer("https://upstream.example.com"),
		SecretRef:           &secretRef,
		AuthType:            &authType,
		ReliabilityPolicyID: common.GetPointer(int64(11)),
		ActiveCostProfileID: common.GetPointer(int64(12)),
		ConfigVersion:       1,
	}
	require.NoError(t, db.Create(channel).Error)
	var storedStatus int
	require.NoError(t, db.Raw("SELECT status FROM channels WHERE id = ?", channel.Id).Scan(&storedStatus).Error)
	require.NotEqual(t, common.ChannelStatusEnabled, storedStatus)

	channel.Key = ""
	_, _, apiErr := channel.GetNextEnabledKey()
	require.Error(t, apiErr)
	require.Contains(t, apiErr.Error(), "commercial channel")
	require.False(t, UpdateChannelStatus(channel.Id, "", common.ChannelStatusEnabled, "test activation"))
	require.NoError(t, db.Raw("SELECT status FROM channels WHERE id = ?", channel.Id).Scan(&storedStatus).Error)
	require.NotEqual(t, common.ChannelStatusEnabled, storedStatus)
}

func TestOrdinaryMigrationModelsSelectChannelByDatabaseTypeAndExistence(t *testing.T) {
	originalType := common.MainDatabaseType()
	t.Cleanup(func() { common.SetMainDatabaseType(originalType) })

	tests := []struct {
		name                string
		databaseType        common.DatabaseType
		channelTablePresent bool
		wantChannel         bool
	}{
		{name: "existing PostgreSQL", databaseType: common.DatabaseTypePostgreSQL, channelTablePresent: true, wantChannel: false},
		{name: "fresh PostgreSQL", databaseType: common.DatabaseTypePostgreSQL, channelTablePresent: false, wantChannel: true},
		{name: "existing SQLite", databaseType: common.DatabaseTypeSQLite, channelTablePresent: true, wantChannel: true},
		{name: "existing MySQL", databaseType: common.DatabaseTypeMySQL, channelTablePresent: true, wantChannel: true},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			common.SetMainDatabaseType(test.databaseType)
			hasChannel := false
			for _, migratedModel := range ordinaryMigrationModels(test.channelTablePresent) {
				if reflect.TypeOf(migratedModel) == reflect.TypeOf(&Channel{}) {
					hasChannel = true
					break
				}
			}
			require.Equal(t, test.wantChannel, hasChannel)
		})
	}
}

func TestPostgresFreshMigrationModelsUseLegacyTokenBootstrap(t *testing.T) {
	models := postgresFreshMigrationModels(false)
	var tokenModel interface{}
	for _, model := range models {
		if reflect.TypeOf(model) == reflect.TypeOf(&legacyTokenMigration{}) {
			tokenModel = model
			break
		}
	}
	require.NotNil(t, tokenModel)
	for _, model := range models {
		require.NotEqual(t, reflect.TypeOf(&Token{}), reflect.TypeOf(model))
	}
}

func TestCommercialChannelPreflightTriggerLookupUsesRelationNamespace(t *testing.T) {
	source, err := os.ReadFile("channel_commercial_migration.go")
	require.NoError(t, err)
	require.NotContains(t, string(source), "t.tgnamespace")
	require.Contains(t, string(source), "JOIN pg_class")
	require.Contains(t, string(source), "t.tgrelid")
	require.Contains(t, string(source), "rel.relnamespace")
}

func TestCommercialChannelGORMDemotionIsRejected(t *testing.T) {
	db, err := gorm.Open(sqlite.Open("file:commercial_channel_gorm_demotion?mode=memory&cache=shared"), &gorm.Config{})
	require.NoError(t, err)
	originalDB := DB
	DB = db
	t.Cleanup(func() { DB = originalDB })
	require.NoError(t, db.AutoMigrate(&Channel{}))
	for _, statement := range []string{
		"ALTER TABLE channels ADD COLUMN commercial_channel BOOLEAN NOT NULL DEFAULT FALSE",
		"ALTER TABLE channels ADD COLUMN secret_ref VARCHAR(255)",
		"ALTER TABLE channels ADD COLUMN auth_type VARCHAR(32)",
		"ALTER TABLE channels ADD COLUMN auth_header_name VARCHAR(128)",
		"ALTER TABLE channels ADD COLUMN failure_domain VARCHAR(128)",
		"ALTER TABLE channels ADD COLUMN reliability_policy_id INTEGER",
		"ALTER TABLE channels ADD COLUMN active_cost_profile_id INTEGER",
		"ALTER TABLE channels ADD COLUMN config_version INTEGER NOT NULL DEFAULT 0",
	} {
		require.NoError(t, db.Exec(statement).Error)
	}
	secretRef := "env://UPSTREAM_PRIMARY_API_KEY"
	authType := "bearer"
	channel := &Channel{
		Name:                "commercial-gorm-demotion",
		CommercialChannel:   true,
		BaseURL:             common.GetPointer("https://upstream.example.com"),
		SecretRef:           &secretRef,
		AuthType:            &authType,
		ReliabilityPolicyID: common.GetPointer(int64(11)),
		ActiveCostProfileID: common.GetPointer(int64(12)),
		ConfigVersion:       1,
	}
	require.NoError(t, db.Create(channel).Error)
	var loaded Channel
	require.NoError(t, db.First(&loaded, channel.Id).Error)
	loaded.CommercialChannel = false
	require.ErrorIs(t, db.Save(&loaded).Error, ErrCommercialChannelDemotion)
	var stillCommercial bool
	require.NoError(t, db.Raw("SELECT commercial_channel FROM channels WHERE id = ?", channel.Id).Scan(&stillCommercial).Error)
	require.True(t, stillCommercial)
}
