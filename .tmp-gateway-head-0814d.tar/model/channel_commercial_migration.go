package model

import (
	"context"
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"errors"
	"fmt"
	"reflect"
	"strings"
	"time"

	"github.com/QuantumNous/new-api/common"
	"github.com/jackc/pgx/v5/pgtype"
)

const (
	commercialChannelMigrationID = "2026-08-10-commercial-channel-foundation"
	commercialChannelLockClass   = int64(19860810)
	commercialChannelLockObject  = int64(1011)
	commercialChannelLedger      = "commercial_channel_migration_objects"
)

type ChannelCostProfile struct {
	ID           int64      `gorm:"column:id;primaryKey"`
	ChannelID    int        `gorm:"column:channel_id;not null"`
	Version      int64      `gorm:"column:version;not null"`
	Currency     string     `gorm:"column:currency;type:char(3);not null;default:USD"`
	RoundingRule string     `gorm:"column:rounding_rule;type:varchar(32);not null;default:half-up-at-attempt-total"`
	EffectiveAt  time.Time  `gorm:"column:effective_at;not null"`
	RetiredAt    *time.Time `gorm:"column:retired_at"`
	CreatedAt    time.Time  `gorm:"column:created_at;not null;default:now()"`
}

func (ChannelCostProfile) TableName() string { return "channel_cost_profiles" }

type ChannelCostRate struct {
	ID               int64     `gorm:"column:id;primaryKey"`
	CostProfileID    int64     `gorm:"column:cost_profile_id;not null"`
	EndpointClass    string    `gorm:"column:endpoint_class;not null"`
	PublicModelAlias string    `gorm:"column:public_model_alias;not null"`
	UpstreamModel    string    `gorm:"column:upstream_model;not null"`
	MeterDimension   string    `gorm:"column:meter_dimension;not null"`
	PriceNumerator   int64     `gorm:"column:price_numerator;not null"`
	UnitDenominator  int64     `gorm:"column:unit_denominator;not null"`
	CreatedAt        time.Time `gorm:"column:created_at;not null;default:now()"`
}

func (ChannelCostRate) TableName() string { return "channel_cost_rates" }

type ChannelReliabilityPolicy struct {
	ID                          int64                   `gorm:"column:id;primaryKey"`
	ChannelID                   int                     `gorm:"column:channel_id;not null"`
	Version                     int64                   `gorm:"column:version;not null"`
	ConnectTimeoutMS            int                     `gorm:"column:connect_timeout_ms;not null"`
	ResponseHeaderTimeoutMS     int                     `gorm:"column:response_header_timeout_ms;not null"`
	FirstSemanticEventTimeoutMS int                     `gorm:"column:first_semantic_event_timeout_ms;not null"`
	StreamIdleTimeoutMS         int                     `gorm:"column:stream_idle_timeout_ms;not null"`
	StreamMaxDurationMS         int                     `gorm:"column:stream_max_duration_ms;not null"`
	NonstreamTotalTimeoutMS     int                     `gorm:"column:nonstream_total_timeout_ms;not null"`
	LogicalPrecommitDeadlineMS  int                     `gorm:"column:logical_precommit_deadline_ms;not null"`
	MaxPrecommitBufferBytes     int                     `gorm:"column:max_precommit_buffer_bytes;not null"`
	MaxStreamBytes              int                     `gorm:"column:max_stream_bytes;not null"`
	MaxResponseBytes            int                     `gorm:"column:max_response_bytes;not null"`
	RetryableStatuses           pgtype.FlatArray[int32] `gorm:"column:retryable_statuses;type:integer[];not null;default:'{}'"`
	WindowSeconds               int                     `gorm:"column:window_seconds;not null"`
	BucketSeconds               int                     `gorm:"column:bucket_seconds;not null"`
	DegradedErrorRateBPS        int                     `gorm:"column:degraded_error_rate_bps;not null"`
	OpenErrorRateBPS            int                     `gorm:"column:open_error_rate_bps;not null"`
	DegradedP95MS               int                     `gorm:"column:degraded_p95_ms;not null"`
	RecoveryP95MS               int                     `gorm:"column:recovery_p95_ms;not null"`
	MinimumSamples              int                     `gorm:"column:minimum_samples;not null"`
	ConsecutiveFailureLimit     int                     `gorm:"column:consecutive_failure_limit;not null"`
	CooldownSeconds             int                     `gorm:"column:cooldown_seconds;not null"`
	RecoverySuccesses           int                     `gorm:"column:recovery_successes;not null"`
	LatencyBucketBoundsMS       pgtype.FlatArray[int32] `gorm:"column:latency_bucket_bounds_ms;type:integer[];not null;default:'{}'"`
	CreatedAt                   time.Time               `gorm:"column:created_at;not null;default:now()"`
}

func (ChannelReliabilityPolicy) TableName() string { return "channel_reliability_policies" }

type commercialMigrationExecutor interface {
	ExecContext(context.Context, string, ...any) (sql.Result, error)
	QueryContext(context.Context, string, ...any) (*sql.Rows, error)
	QueryRowContext(context.Context, string, ...any) *sql.Row
}

type commercialCatalogColumn struct {
	Name     string `json:"name"`
	Type     string `json:"type"`
	NotNull  bool   `json:"notnull"`
	Identity string `json:"identity"`
	Default  string `json:"default"`
}

type commercialCatalogIndex struct {
	Table    string   `json:"table"`
	Unique   bool     `json:"unique"`
	Valid    bool     `json:"valid"`
	Ready    bool     `json:"ready"`
	KeyCount int      `json:"key_count"`
	Columns  []string `json:"columns"`
}

type commercialCatalogConstraint struct {
	Type       string   `json:"type"`
	Validated  bool     `json:"validated"`
	Deferrable bool     `json:"deferrable"`
	Deferred   bool     `json:"deferred"`
	Columns    []string `json:"columns"`
	Reference  string   `json:"reference"`
	RefColumns []string `json:"ref_columns"`
	OnDelete   string   `json:"on_delete"`
	Expression string   `json:"expression"`
}

func commercialExpectedTableColumns(name string) ([]commercialCatalogColumn, bool) {
	identity := func(name, typ string) commercialCatalogColumn {
		return commercialCatalogColumn{Name: name, Type: typ, NotNull: true, Identity: "d"}
	}
	column := func(name, typ, defaultValue string, notNull bool) commercialCatalogColumn {
		return commercialCatalogColumn{Name: name, Type: typ, Default: defaultValue, NotNull: notNull}
	}
	switch name {
	case "channel_cost_profiles":
		return []commercialCatalogColumn{
			identity("id", "bigint"), column("channel_id", "integer", "", true), column("version", "bigint", "", true),
			column("currency", "character(3)", "'USD'::bpchar", true), column("rounding_rule", "character varying(32)", "'half-up-at-attempt-total'::character varying", true),
			column("effective_at", "timestamp with time zone", "", true), column("retired_at", "timestamp with time zone", "", false), column("created_at", "timestamp with time zone", "now()", true),
		}, true
	case "channel_cost_rates":
		return []commercialCatalogColumn{
			identity("id", "bigint"), column("cost_profile_id", "bigint", "", true), column("endpoint_class", "character varying(64)", "", true),
			column("public_model_alias", "character varying(128)", "", true), column("upstream_model", "character varying(255)", "", true), column("meter_dimension", "character varying(64)", "", true),
			column("price_numerator", "bigint", "", true), column("unit_denominator", "bigint", "", true), column("created_at", "timestamp with time zone", "now()", true),
		}, true
	case "channel_reliability_policies":
		columns := []commercialCatalogColumn{identity("id", "bigint"), column("channel_id", "integer", "", true), column("version", "bigint", "", true)}
		for _, name := range []string{"connect_timeout_ms", "response_header_timeout_ms", "first_semantic_event_timeout_ms", "stream_idle_timeout_ms", "stream_max_duration_ms", "nonstream_total_timeout_ms", "logical_precommit_deadline_ms", "max_precommit_buffer_bytes", "max_stream_bytes", "max_response_bytes"} {
			columns = append(columns, column(name, "integer", "", true))
		}
		columns = append(columns,
			column("retryable_statuses", "integer[]", "'{}'::integer[]", true),
			column("window_seconds", "integer", "", true), column("bucket_seconds", "integer", "", true), column("degraded_error_rate_bps", "integer", "", true), column("open_error_rate_bps", "integer", "", true),
			column("degraded_p95_ms", "integer", "", true), column("recovery_p95_ms", "integer", "", true), column("minimum_samples", "integer", "", true), column("consecutive_failure_limit", "integer", "", true), column("cooldown_seconds", "integer", "", true), column("recovery_successes", "integer", "", true),
			column("latency_bucket_bounds_ms", "integer[]", "'{}'::integer[]", true), column("created_at", "timestamp with time zone", "now()", true),
		)
		return columns, true
	case commercialChannelLedger:
		return []commercialCatalogColumn{
			column("migration_id", "character varying(128)", "", true), column("object_type", "character varying(32)", "", true), column("schema_name", "character varying(128)", "", true), column("object_name", "character varying(255)", "", true),
			column("phase", "integer", "", true), column("definition_hash", "character(64)", "", true), column("state", "character varying(16)", "", true), column("validated", "boolean", "false", true),
			column("created_at", "timestamp with time zone", "now()", true), column("updated_at", "timestamp with time zone", "now()", true),
		}, true
	default:
		return nil, false
	}
}

func commercialExpectedChannelColumn(name string) (commercialCatalogColumn, bool) {
	columns := map[string]commercialCatalogColumn{
		"commercial_channel":     {Name: name, Type: "boolean", NotNull: true, Default: "false"},
		"secret_ref":             {Name: name, Type: "character varying(255)"},
		"auth_type":              {Name: name, Type: "character varying(32)"},
		"auth_header_name":       {Name: name, Type: "character varying(128)"},
		"failure_domain":         {Name: name, Type: "character varying(128)"},
		"reliability_policy_id":  {Name: name, Type: "bigint"},
		"active_cost_profile_id": {Name: name, Type: "bigint"},
		"config_version":         {Name: name, Type: "bigint", NotNull: true, Default: "0"},
	}
	column, ok := columns[name]
	return column, ok
}

func CommercialChannelFoundationSQL() string {
	return strings.Join([]string{
		"SELECT pg_advisory_lock(19860810, 1011)",
		commercialChannelProfilesDDL,
		commercialChannelRatesDDL,
		commercialChannelReliabilityDDL,
		"ALTER TABLE public.channels ALTER COLUMN key DROP NOT NULL",
		commercialChannelColumnsDDL,
		commercialChannelIndexes,
		commercialChannelLatencyBoundsFunctionDDL,
		commercialChannelChecksDDL,
		commercialChannelConstraintsDDL,
		commercialChannelForeignKeysDDL,
		commercialChannelTriggersDDL,
		"VALIDATE CONSTRAINT",
	}, "\n")
}

const commercialChannelLedgerDDL = `
CREATE TABLE public.commercial_channel_migration_objects (
  migration_id varchar(128) NOT NULL,
  object_type varchar(32) NOT NULL,
  schema_name varchar(128) NOT NULL,
  object_name varchar(255) NOT NULL,
  phase integer NOT NULL,
  definition_hash char(64) NOT NULL,
  state varchar(16) NOT NULL,
  validated boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (migration_id, object_type, schema_name, object_name)
)`

const commercialChannelProfilesDDL = `CREATE TABLE public.channel_cost_profiles (
  id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
  channel_id integer NOT NULL,
  version bigint NOT NULL,
  currency char(3) NOT NULL DEFAULT 'USD',
  rounding_rule varchar(32) NOT NULL DEFAULT 'half-up-at-attempt-total',
  effective_at timestamptz NOT NULL,
  retired_at timestamptz NULL,
  created_at timestamptz NOT NULL DEFAULT now()
)`

const commercialChannelRatesDDL = `CREATE TABLE public.channel_cost_rates (
  id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
  cost_profile_id bigint NOT NULL,
  endpoint_class varchar(64) NOT NULL,
  public_model_alias varchar(128) NOT NULL,
  upstream_model varchar(255) NOT NULL,
  meter_dimension varchar(64) NOT NULL,
  price_numerator bigint NOT NULL,
  unit_denominator bigint NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
)`

const commercialChannelReliabilityDDL = `CREATE TABLE public.channel_reliability_policies (
  id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
  channel_id integer NOT NULL,
  version bigint NOT NULL,
  connect_timeout_ms integer NOT NULL,
  response_header_timeout_ms integer NOT NULL,
  first_semantic_event_timeout_ms integer NOT NULL,
  stream_idle_timeout_ms integer NOT NULL,
  stream_max_duration_ms integer NOT NULL,
  nonstream_total_timeout_ms integer NOT NULL,
  logical_precommit_deadline_ms integer NOT NULL,
  max_precommit_buffer_bytes integer NOT NULL,
  max_stream_bytes integer NOT NULL,
  max_response_bytes integer NOT NULL,
  retryable_statuses integer[] NOT NULL DEFAULT '{}',
  window_seconds integer NOT NULL,
  bucket_seconds integer NOT NULL,
  degraded_error_rate_bps integer NOT NULL,
  open_error_rate_bps integer NOT NULL,
  degraded_p95_ms integer NOT NULL,
  recovery_p95_ms integer NOT NULL,
  minimum_samples integer NOT NULL,
  consecutive_failure_limit integer NOT NULL,
  cooldown_seconds integer NOT NULL,
  recovery_successes integer NOT NULL,
  latency_bucket_bounds_ms integer[] NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
)`

const (
	commercialChannelLatencyBoundsFunctionName      = "fn_channel_latency_bucket_bounds_valid"
	commercialChannelLatencyBoundsFunctionSignature = commercialChannelLatencyBoundsFunctionName + "(integer[])"
	commercialChannelLatencyBoundsFunctionDDL       = `CREATE FUNCTION public.fn_channel_latency_bucket_bounds_valid(bounds integer[])
RETURNS boolean
LANGUAGE plpgsql
IMMUTABLE
STRICT
PARALLEL SAFE
AS $$
DECLARE
  previous_bound integer;
  current_bound integer;
BEGIN
  IF COALESCE(array_ndims(bounds), 0) > 1 OR cardinality(bounds) > 32 THEN
    RETURN false;
  END IF;
  FOREACH current_bound IN ARRAY bounds LOOP
    IF current_bound IS NULL OR current_bound < 1 OR current_bound > 10000 OR
       (previous_bound IS NOT NULL AND current_bound <= previous_bound) THEN
      RETURN false;
    END IF;
    previous_bound := current_bound;
  END LOOP;
  RETURN true;
END $$`
)

const commercialChannelColumnsDDL = `
ALTER TABLE public.channels
  ADD COLUMN commercial_channel boolean NOT NULL DEFAULT false;
ALTER TABLE public.channels
  ADD COLUMN secret_ref varchar(255) NULL;
ALTER TABLE public.channels
  ADD COLUMN auth_type varchar(32) NULL;
ALTER TABLE public.channels
  ADD COLUMN auth_header_name varchar(128) NULL;
ALTER TABLE public.channels
  ADD COLUMN failure_domain varchar(128) NULL;
ALTER TABLE public.channels
  ADD COLUMN reliability_policy_id bigint NULL;
ALTER TABLE public.channels
  ADD COLUMN active_cost_profile_id bigint NULL;
ALTER TABLE public.channels
  ADD COLUMN config_version bigint NOT NULL DEFAULT 0;`

const commercialChannelChecksDDL = `
ALTER TABLE public.channels ADD CONSTRAINT ck_channels_commercial_activation CHECK (
  commercial_channel IS NOT TRUE OR (key IS NULL AND secret_ref IS NOT NULL AND auth_type IS NOT NULL AND auth_type IN ('bearer', 'fixed-header') AND reliability_policy_id IS NOT NULL AND active_cost_profile_id IS NOT NULL AND config_version > 0)
) NOT VALID;
ALTER TABLE public.channels ADD CONSTRAINT ck_channels_commercial_secret_ref CHECK (
  commercial_channel IS NOT TRUE OR secret_ref ~ '^env://[A-Z_][A-Z0-9_]*$'
) NOT VALID;
ALTER TABLE public.channels ADD CONSTRAINT ck_channels_commercial_auth CHECK (
  commercial_channel IS NOT TRUE OR (auth_type IS NOT NULL AND auth_type IN ('bearer', 'fixed-header') AND (auth_type <> 'fixed-header' OR (auth_header_name IS NOT NULL AND btrim(auth_header_name) <> '' AND auth_header_name !~ '[[:cntrl:][:space:]]')))
) NOT VALID;
ALTER TABLE public.channel_cost_rates ADD CONSTRAINT ck_channel_cost_rates_bounds CHECK (
  price_numerator BETWEEN 0 AND 1000000000 AND unit_denominator BETWEEN 1 AND 1000000000
) NOT VALID;
ALTER TABLE public.channel_reliability_policies ADD CONSTRAINT ck_channel_reliability_policies_bounds CHECK (
  connect_timeout_ms BETWEEN 1 AND 10000 AND response_header_timeout_ms BETWEEN 1 AND 10000 AND first_semantic_event_timeout_ms BETWEEN 1 AND 10000 AND stream_idle_timeout_ms BETWEEN 1 AND 10000 AND stream_max_duration_ms BETWEEN 1 AND 10000 AND nonstream_total_timeout_ms BETWEEN 1 AND 10000 AND logical_precommit_deadline_ms BETWEEN 1 AND 10000 AND max_precommit_buffer_bytes BETWEEN 1 AND 1048576 AND max_stream_bytes BETWEEN 1 AND 8388608 AND max_response_bytes BETWEEN 1 AND 8388608 AND window_seconds BETWEEN 1 AND 10000 AND bucket_seconds BETWEEN 1 AND window_seconds AND degraded_error_rate_bps BETWEEN 0 AND 10000 AND open_error_rate_bps BETWEEN degraded_error_rate_bps AND 10000 AND recovery_p95_ms BETWEEN 1 AND degraded_p95_ms AND degraded_p95_ms BETWEEN 1 AND 10000 AND minimum_samples BETWEEN 1 AND 10000 AND consecutive_failure_limit BETWEEN 1 AND 10000 AND cooldown_seconds BETWEEN 1 AND 10000 AND recovery_successes BETWEEN 1 AND 10000 AND retryable_statuses <@ ARRAY[408,429,500,502,503,504,524]::integer[] AND cardinality(retryable_statuses) <= 16 AND public.fn_channel_latency_bucket_bounds_valid(latency_bucket_bounds_ms)
) NOT VALID;`

const commercialChannelForeignKeysDDL = `
ALTER TABLE public.channel_cost_profiles ADD CONSTRAINT fk_channel_cost_profiles_channel_id FOREIGN KEY (channel_id) REFERENCES public.channels(id) ON DELETE RESTRICT NOT VALID;
ALTER TABLE public.channel_cost_rates ADD CONSTRAINT fk_channel_cost_rates_profile_id FOREIGN KEY (cost_profile_id) REFERENCES public.channel_cost_profiles(id) ON DELETE RESTRICT NOT VALID;
ALTER TABLE public.channel_reliability_policies ADD CONSTRAINT fk_channel_reliability_policies_channel_id FOREIGN KEY (channel_id) REFERENCES public.channels(id) ON DELETE RESTRICT NOT VALID;
ALTER TABLE public.channels ADD CONSTRAINT fk_channels_active_cost_profile FOREIGN KEY (id, active_cost_profile_id) REFERENCES public.channel_cost_profiles(channel_id, id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED NOT VALID;
ALTER TABLE public.channels ADD CONSTRAINT fk_channels_reliability_policy FOREIGN KEY (id, reliability_policy_id) REFERENCES public.channel_reliability_policies(channel_id, id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED NOT VALID;`

const commercialChannelTriggersDDL = `
CREATE OR REPLACE FUNCTION public.fn_channel_cost_profiles_immutable() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN RAISE EXCEPTION 'commercial channel cost profiles are immutable' USING ERRCODE = 'check_violation'; END IF;
  IF OLD.retired_at IS NULL AND NEW.retired_at IS NOT NULL AND NEW.id IS NOT DISTINCT FROM OLD.id AND NEW.channel_id IS NOT DISTINCT FROM OLD.channel_id AND NEW.version IS NOT DISTINCT FROM OLD.version AND NEW.currency IS NOT DISTINCT FROM OLD.currency AND NEW.rounding_rule IS NOT DISTINCT FROM OLD.rounding_rule AND NEW.effective_at IS NOT DISTINCT FROM OLD.effective_at AND NEW.created_at IS NOT DISTINCT FROM OLD.created_at THEN RETURN NEW; END IF;
  RAISE EXCEPTION 'commercial channel cost profiles are immutable' USING ERRCODE = 'check_violation';
END $$;
CREATE OR REPLACE FUNCTION public.fn_channel_cost_rates_immutable() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION 'commercial channel cost rates are immutable' USING ERRCODE = 'check_violation'; END $$;
CREATE OR REPLACE FUNCTION public.fn_channel_reliability_policies_immutable() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION 'commercial channel reliability policies are immutable' USING ERRCODE = 'check_violation'; END $$;
CREATE TRIGGER trg_channel_cost_profiles_immutable BEFORE UPDATE OR DELETE ON public.channel_cost_profiles FOR EACH ROW EXECUTE FUNCTION public.fn_channel_cost_profiles_immutable();
CREATE TRIGGER trg_channel_cost_rates_immutable BEFORE UPDATE OR DELETE ON public.channel_cost_rates FOR EACH ROW EXECUTE FUNCTION public.fn_channel_cost_rates_immutable();
CREATE TRIGGER trg_channel_reliability_policies_immutable BEFORE UPDATE OR DELETE ON public.channel_reliability_policies FOR EACH ROW EXECUTE FUNCTION public.fn_channel_reliability_policies_immutable();`

const commercialChannelIndexes = `
CREATE UNIQUE INDEX CONCURRENTLY ux_channel_cost_profiles_channel_id ON public.channel_cost_profiles (channel_id, id);
CREATE UNIQUE INDEX CONCURRENTLY ux_channel_cost_profiles_channel_version ON public.channel_cost_profiles (channel_id, version);
CREATE UNIQUE INDEX CONCURRENTLY ux_channel_cost_rates_dimension ON public.channel_cost_rates (cost_profile_id, endpoint_class, public_model_alias, upstream_model, meter_dimension);
CREATE UNIQUE INDEX CONCURRENTLY ux_channel_reliability_policies_channel_id ON public.channel_reliability_policies (channel_id, id);
CREATE UNIQUE INDEX CONCURRENTLY ux_channel_reliability_policies_channel_version ON public.channel_reliability_policies (channel_id, version);`

const commercialChannelConstraintsDDL = `
ALTER TABLE public.channel_cost_profiles ADD CONSTRAINT uq_channel_cost_profiles_channel_id UNIQUE USING INDEX ux_channel_cost_profiles_channel_id;
ALTER TABLE public.channel_cost_profiles ADD CONSTRAINT uq_channel_cost_profiles_channel_version UNIQUE USING INDEX ux_channel_cost_profiles_channel_version;
ALTER TABLE public.channel_cost_rates ADD CONSTRAINT uq_channel_cost_rates_dimension UNIQUE USING INDEX ux_channel_cost_rates_dimension;
ALTER TABLE public.channel_reliability_policies ADD CONSTRAINT uq_channel_reliability_policies_channel_id UNIQUE USING INDEX ux_channel_reliability_policies_channel_id;
ALTER TABLE public.channel_reliability_policies ADD CONSTRAINT uq_channel_reliability_policies_channel_version UNIQUE USING INDEX ux_channel_reliability_policies_channel_version;`

type commercialLedgerObject struct {
	ObjectType string
	SchemaName string
	ObjectName string
	Phase      int
	Hash       string
	Validated  bool
	State      string
}

var commercialChannelTables = []commercialLedgerObject{
	{ObjectType: "table", SchemaName: "public", ObjectName: "channel_cost_profiles", Phase: 2, Hash: commercialDefinitionHash(commercialChannelProfilesDDL)},
	{ObjectType: "table", SchemaName: "public", ObjectName: "channel_cost_rates", Phase: 2, Hash: commercialDefinitionHash(commercialChannelRatesDDL)},
	{ObjectType: "table", SchemaName: "public", ObjectName: "channel_reliability_policies", Phase: 2, Hash: commercialDefinitionHash(commercialChannelReliabilityDDL)},
}

func commercialDefinitionHash(definition string) string {
	digest := sha256.Sum256([]byte(strings.Join(strings.Fields(definition), " ")))
	return hex.EncodeToString(digest[:])
}

type commercialExpectedFunctionDefinition struct {
	Source     string
	Arguments  string
	Result     string
	Volatility string
	Strict     bool
	Parallel   string
}

func commercialExpectedFunction(name string) (commercialExpectedFunctionDefinition, bool) {
	name = strings.TrimSuffix(name, "()")
	if open := strings.IndexByte(name, '('); open >= 0 {
		name = name[:open]
	}
	switch name {
	case commercialChannelLatencyBoundsFunctionName:
		return commercialExpectedFunctionDefinition{
			Source: `DECLARE
  previous_bound integer;
  current_bound integer;
BEGIN
  IF COALESCE(array_ndims(bounds), 0) > 1 OR cardinality(bounds) > 32 THEN
    RETURN false;
  END IF;
  FOREACH current_bound IN ARRAY bounds LOOP
    IF current_bound IS NULL OR current_bound < 1 OR current_bound > 10000 OR
       (previous_bound IS NOT NULL AND current_bound <= previous_bound) THEN
      RETURN false;
    END IF;
    previous_bound := current_bound;
  END LOOP;
  RETURN true;
END`, Arguments: "bounds integer[]", Result: "boolean", Volatility: "i", Strict: true, Parallel: "s",
		}, true
	case "fn_channel_cost_profiles_immutable":
		return commercialExpectedFunctionDefinition{
			Source: `BEGIN
  IF TG_OP = 'DELETE' THEN RAISE EXCEPTION 'commercial channel cost profiles are immutable' USING ERRCODE = 'check_violation'; END IF;
  IF OLD.retired_at IS NULL AND NEW.retired_at IS NOT NULL AND NEW.id IS NOT DISTINCT FROM OLD.id AND NEW.channel_id IS NOT DISTINCT FROM OLD.channel_id AND NEW.version IS NOT DISTINCT FROM OLD.version AND NEW.currency IS NOT DISTINCT FROM OLD.currency AND NEW.rounding_rule IS NOT DISTINCT FROM OLD.rounding_rule AND NEW.effective_at IS NOT DISTINCT FROM OLD.effective_at AND NEW.created_at IS NOT DISTINCT FROM OLD.created_at THEN RETURN NEW; END IF;
  RAISE EXCEPTION 'commercial channel cost profiles are immutable' USING ERRCODE = 'check_violation';
END`, Arguments: "", Result: "trigger", Volatility: "v", Parallel: "u",
		}, true
	case "fn_channel_cost_rates_immutable":
		return commercialExpectedFunctionDefinition{Source: "BEGIN RAISE EXCEPTION 'commercial channel cost rates are immutable' USING ERRCODE = 'check_violation'; END", Arguments: "", Result: "trigger", Volatility: "v", Parallel: "u"}, true
	case "fn_channel_reliability_policies_immutable":
		return commercialExpectedFunctionDefinition{Source: "BEGIN RAISE EXCEPTION 'commercial channel reliability policies are immutable' USING ERRCODE = 'check_violation'; END", Arguments: "", Result: "trigger", Volatility: "v", Parallel: "u"}, true
	default:
		return commercialExpectedFunctionDefinition{}, false
	}
}

func commercialChannelExpectedDefinitionHash(objectType, schemaName, objectName string) string {
	switch objectType {
	case "migration":
		if schemaName == "public" && objectName == commercialChannelMigrationID {
			return commercialDefinitionHash(commercialChannelLedgerDDL)
		}
	case "table":
		for _, object := range commercialChannelTables {
			if object.SchemaName == schemaName && object.ObjectName == objectName {
				return object.Hash
			}
		}
	case "column":
		if schemaName == "public.channels" {
			definitions := map[string]string{
				"commercial_channel":     "boolean NOT NULL DEFAULT false",
				"secret_ref":             "varchar(255) NULL",
				"auth_type":              "varchar(32) NULL",
				"auth_header_name":       "varchar(128) NULL",
				"failure_domain":         "varchar(128) NULL",
				"reliability_policy_id":  "bigint NULL",
				"active_cost_profile_id": "bigint NULL",
				"config_version":         "bigint NOT NULL DEFAULT 0",
			}
			if definition, ok := definitions[objectName]; ok {
				return commercialDefinitionHash(definition)
			}
		}
	case "index":
		if schemaName == "public" {
			ddls := map[string]string{
				"ux_channel_cost_profiles_channel_id":             "CREATE UNIQUE INDEX CONCURRENTLY ux_channel_cost_profiles_channel_id ON public.channel_cost_profiles (channel_id, id)",
				"ux_channel_cost_profiles_channel_version":        "CREATE UNIQUE INDEX CONCURRENTLY ux_channel_cost_profiles_channel_version ON public.channel_cost_profiles (channel_id, version)",
				"ux_channel_cost_rates_dimension":                 "CREATE UNIQUE INDEX CONCURRENTLY ux_channel_cost_rates_dimension ON public.channel_cost_rates (cost_profile_id, endpoint_class, public_model_alias, upstream_model, meter_dimension)",
				"ux_channel_reliability_policies_channel_id":      "CREATE UNIQUE INDEX CONCURRENTLY ux_channel_reliability_policies_channel_id ON public.channel_reliability_policies (channel_id, id)",
				"ux_channel_reliability_policies_channel_version": "CREATE UNIQUE INDEX CONCURRENTLY ux_channel_reliability_policies_channel_version ON public.channel_reliability_policies (channel_id, version)",
			}
			if ddl, ok := ddls[objectName]; ok {
				return commercialDefinitionHash(ddl)
			}
		}
	case "constraint":
		return commercialChannelConstraintHash(schemaName, objectName)
	case "function":
		if objectName == commercialChannelLatencyBoundsFunctionSignature {
			return commercialDefinitionHash(commercialChannelLatencyBoundsFunctionDDL)
		}
		if expected, ok := commercialExpectedFunction(objectName); ok {
			return commercialDefinitionHash("CREATE OR REPLACE FUNCTION public." + strings.TrimSuffix(objectName, "()") + "() RETURNS " + expected.Result + " LANGUAGE plpgsql AS $$\n" + expected.Source + "\n$$")
		}
	case "trigger":
		parts := strings.SplitN(schemaName, ".", 2)
		if len(parts) == 2 {
			function := strings.TrimPrefix(objectName, "trg_")
			function = strings.TrimSuffix(function, "_immutable") + "_immutable"
			if function == "channel_cost_profiles_immutable" {
				function = "fn_" + function
			} else if function == "channel_cost_rates_immutable" {
				function = "fn_" + function
			} else if function == "channel_reliability_policies_immutable" {
				function = "fn_" + function
			}
			return commercialDefinitionHash("CREATE TRIGGER " + objectName + " BEFORE UPDATE OR DELETE ON public." + parts[1] + " FOR EACH ROW EXECUTE FUNCTION public." + function + "()")
		}
	}
	return ""
}

func commercialChannelConstraintHash(schemaName, objectName string) string {
	ddls := map[string]string{
		"public.channels\x00ck_channels_commercial_activation":                                   "commercial_channel IS NOT TRUE OR (key IS NULL AND secret_ref IS NOT NULL AND auth_type IS NOT NULL AND auth_type IN ('bearer', 'fixed-header') AND reliability_policy_id IS NOT NULL AND active_cost_profile_id IS NOT NULL AND config_version > 0)",
		"public.channels\x00ck_channels_commercial_secret_ref":                                   "commercial_channel IS NOT TRUE OR secret_ref ~ '^env://[A-Z_][A-Z0-9_]*$'",
		"public.channels\x00ck_channels_commercial_auth":                                         "commercial_channel IS NOT TRUE OR (auth_type IS NOT NULL AND auth_type IN ('bearer', 'fixed-header') AND (auth_type <> 'fixed-header' OR (auth_header_name IS NOT NULL AND btrim(auth_header_name) <> '' AND auth_header_name !~ '[[:cntrl:][:space:]]')))",
		"public.channel_cost_rates\x00ck_channel_cost_rates_bounds":                              "price_numerator BETWEEN 0 AND 1000000000 AND unit_denominator BETWEEN 1 AND 1000000000",
		"public.channel_reliability_policies\x00ck_channel_reliability_policies_bounds":          "connect_timeout_ms BETWEEN 1 AND 10000 AND response_header_timeout_ms BETWEEN 1 AND 10000 AND first_semantic_event_timeout_ms BETWEEN 1 AND 10000 AND stream_idle_timeout_ms BETWEEN 1 AND 10000 AND stream_max_duration_ms BETWEEN 1 AND 10000 AND nonstream_total_timeout_ms BETWEEN 1 AND 10000 AND logical_precommit_deadline_ms BETWEEN 1 AND 10000 AND max_precommit_buffer_bytes BETWEEN 1 AND 1048576 AND max_stream_bytes BETWEEN 1 AND 8388608 AND max_response_bytes BETWEEN 1 AND 8388608 AND window_seconds BETWEEN 1 AND 10000 AND bucket_seconds BETWEEN 1 AND window_seconds AND degraded_error_rate_bps BETWEEN 0 AND 10000 AND open_error_rate_bps BETWEEN degraded_error_rate_bps AND 10000 AND degraded_p95_ms BETWEEN 1 AND 10000 AND recovery_p95_ms BETWEEN 1 AND degraded_p95_ms AND minimum_samples BETWEEN 1 AND 10000 AND consecutive_failure_limit BETWEEN 1 AND 10000 AND cooldown_seconds BETWEEN 1 AND 10000 AND recovery_successes BETWEEN 1 AND 10000 AND retryable_statuses <@ ARRAY[408,429,500,502,503,504,524]::integer[] AND cardinality(retryable_statuses) <= 16 AND public.fn_channel_latency_bucket_bounds_valid(latency_bucket_bounds_ms)",
		"public.channel_cost_profiles\x00uq_channel_cost_profiles_channel_id":                    "ux_channel_cost_profiles_channel_id",
		"public.channel_cost_profiles\x00uq_channel_cost_profiles_channel_version":               "ux_channel_cost_profiles_channel_version",
		"public.channel_cost_rates\x00uq_channel_cost_rates_dimension":                           "ux_channel_cost_rates_dimension",
		"public.channel_reliability_policies\x00uq_channel_reliability_policies_channel_id":      "ux_channel_reliability_policies_channel_id",
		"public.channel_reliability_policies\x00uq_channel_reliability_policies_channel_version": "ux_channel_reliability_policies_channel_version",
		"public.channel_cost_profiles\x00fk_channel_cost_profiles_channel_id":                    "ALTER TABLE public.channel_cost_profiles ADD CONSTRAINT fk_channel_cost_profiles_channel_id FOREIGN KEY (channel_id) REFERENCES public.channels(id) ON DELETE RESTRICT NOT VALID",
		"public.channel_cost_rates\x00fk_channel_cost_rates_profile_id":                          "ALTER TABLE public.channel_cost_rates ADD CONSTRAINT fk_channel_cost_rates_profile_id FOREIGN KEY (cost_profile_id) REFERENCES public.channel_cost_profiles(id) ON DELETE RESTRICT NOT VALID",
		"public.channel_reliability_policies\x00fk_channel_reliability_policies_channel_id":      "ALTER TABLE public.channel_reliability_policies ADD CONSTRAINT fk_channel_reliability_policies_channel_id FOREIGN KEY (channel_id) REFERENCES public.channels(id) ON DELETE RESTRICT NOT VALID",
		"public.channels\x00fk_channels_active_cost_profile":                                     "ALTER TABLE public.channels ADD CONSTRAINT fk_channels_active_cost_profile FOREIGN KEY (id, active_cost_profile_id) REFERENCES public.channel_cost_profiles(channel_id, id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED NOT VALID",
		"public.channels\x00fk_channels_reliability_policy":                                      "ALTER TABLE public.channels ADD CONSTRAINT fk_channels_reliability_policy FOREIGN KEY (id, reliability_policy_id) REFERENCES public.channel_reliability_policies(channel_id, id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED NOT VALID",
	}
	if definition, ok := ddls[schemaName+"\x00"+objectName]; ok {
		return commercialDefinitionHash(definition)
	}
	return ""
}

func commercialVerifyLiveFunction(ctx context.Context, conn commercialMigrationExecutor, object commercialLedgerObject) error {
	expected, ok := commercialExpectedFunction(object.ObjectName)
	if !ok {
		return fmt.Errorf("commercial channel migration has no expected function definition for %s", object.ObjectName)
	}
	var actual struct {
		Source, Arguments, Result, Volatility, Parallel string
		Strict                                          bool
	}
	name := strings.TrimSuffix(object.ObjectName, "()")
	if open := strings.IndexByte(name, '('); open >= 0 {
		name = name[:open]
	}
	regprocedure := object.ObjectName
	if !strings.Contains(regprocedure, "(") {
		regprocedure += "()"
	}
	if err := conn.QueryRowContext(ctx, `SELECT p.prosrc, pg_get_function_arguments(p.oid), pg_get_function_result(p.oid), p.provolatile, p.proisstrict, p.proparallel
FROM pg_proc AS p
JOIN pg_namespace AS n ON n.oid = p.pronamespace
WHERE n.nspname = 'public' AND p.proname = $1 AND p.oid = to_regprocedure($2)`, name, "public."+regprocedure).Scan(&actual.Source, &actual.Arguments, &actual.Result, &actual.Volatility, &actual.Strict, &actual.Parallel); err != nil {
		return fmt.Errorf("commercial channel migration read live function %s: %w", object.ObjectName, err)
	}
	if strings.Join(strings.Fields(actual.Source), " ") != strings.Join(strings.Fields(expected.Source), " ") || actual.Arguments != expected.Arguments || actual.Result != expected.Result || actual.Volatility != expected.Volatility || actual.Strict != expected.Strict || actual.Parallel != expected.Parallel {
		return fmt.Errorf("commercial channel migration live definition mismatch for %s.%s", object.SchemaName, object.ObjectName)
	}
	return nil
}

func commercialVerifyLiveTable(ctx context.Context, conn commercialMigrationExecutor, object commercialLedgerObject) error {
	expected, ok := commercialExpectedTableColumns(object.ObjectName)
	if !ok {
		return fmt.Errorf("commercial channel migration has no expected table definition for %s.%s", object.SchemaName, object.ObjectName)
	}
	var encoded string
	if err := conn.QueryRowContext(ctx, `SELECT (COALESCE(jsonb_agg(jsonb_build_object('name', a.attname, 'type', format_type(a.atttypid, a.atttypmod), 'notnull', a.attnotnull, 'identity', a.attidentity, 'default', COALESCE(pg_get_expr(d.adbin, d.adrelid), '')) ORDER BY a.attnum), '[]'::jsonb))::text
FROM pg_class AS c
JOIN pg_namespace AS n ON n.oid = c.relnamespace
JOIN pg_attribute AS a ON a.attrelid = c.oid AND a.attnum > 0 AND NOT a.attisdropped
LEFT JOIN pg_attrdef AS d ON d.adrelid = a.attrelid AND d.adnum = a.attnum
WHERE n.nspname = 'public' AND c.relname = $1`, object.ObjectName).Scan(&encoded); err != nil {
		return err
	}
	var actual []commercialCatalogColumn
	if err := common.UnmarshalJsonStr(encoded, &actual); err != nil {
		return fmt.Errorf("commercial channel migration decode live table %s: %w", object.ObjectName, err)
	}
	if !reflect.DeepEqual(actual, expected) {
		return fmt.Errorf("commercial channel migration live definition mismatch for %s.%s", object.SchemaName, object.ObjectName)
	}
	return nil
}

func commercialVerifyLiveColumn(ctx context.Context, conn commercialMigrationExecutor, object commercialLedgerObject) error {
	parts := strings.SplitN(object.SchemaName, ".", 2)
	if len(parts) != 2 || parts[0] != "public" || parts[1] != "channels" {
		return fmt.Errorf("commercial channel migration has invalid live column owner %s", object.SchemaName)
	}
	expected, ok := commercialExpectedChannelColumn(object.ObjectName)
	if !ok {
		return fmt.Errorf("commercial channel migration has no expected column definition for %s", object.ObjectName)
	}
	var encoded string
	if err := conn.QueryRowContext(ctx, `SELECT jsonb_build_object('name', a.attname, 'type', format_type(a.atttypid, a.atttypmod), 'notnull', a.attnotnull, 'identity', a.attidentity, 'default', COALESCE(pg_get_expr(d.adbin, d.adrelid), ''))::text
FROM pg_class AS c
JOIN pg_namespace AS n ON n.oid = c.relnamespace
JOIN pg_attribute AS a ON a.attrelid = c.oid AND a.attnum > 0 AND a.attname = $1 AND NOT a.attisdropped
LEFT JOIN pg_attrdef AS d ON d.adrelid = a.attrelid AND d.adnum = a.attnum
WHERE n.nspname = $2 AND c.relname = $3`, object.ObjectName, parts[0], parts[1]).Scan(&encoded); err != nil {
		return err
	}
	var actual commercialCatalogColumn
	if err := common.UnmarshalJsonStr(encoded, &actual); err != nil {
		return fmt.Errorf("commercial channel migration decode live column %s: %w", object.ObjectName, err)
	}
	if !reflect.DeepEqual(actual, expected) {
		return fmt.Errorf("commercial channel migration live definition mismatch for %s.%s", object.SchemaName, object.ObjectName)
	}
	return nil
}

func commercialExpectedIndexDefinition(name string) (commercialCatalogIndex, bool) {
	definitions := map[string]commercialCatalogIndex{
		"ux_channel_cost_profiles_channel_id":             {Table: "channel_cost_profiles", Unique: true, Valid: true, Ready: true, KeyCount: 2, Columns: []string{"channel_id", "id"}},
		"ux_channel_cost_profiles_channel_version":        {Table: "channel_cost_profiles", Unique: true, Valid: true, Ready: true, KeyCount: 2, Columns: []string{"channel_id", "version"}},
		"ux_channel_cost_rates_dimension":                 {Table: "channel_cost_rates", Unique: true, Valid: true, Ready: true, KeyCount: 5, Columns: []string{"cost_profile_id", "endpoint_class", "public_model_alias", "upstream_model", "meter_dimension"}},
		"ux_channel_reliability_policies_channel_id":      {Table: "channel_reliability_policies", Unique: true, Valid: true, Ready: true, KeyCount: 2, Columns: []string{"channel_id", "id"}},
		"ux_channel_reliability_policies_channel_version": {Table: "channel_reliability_policies", Unique: true, Valid: true, Ready: true, KeyCount: 2, Columns: []string{"channel_id", "version"}},
	}
	definition, ok := definitions[name]
	return definition, ok
}

func commercialLiveAttachedIndexName(ctx context.Context, conn commercialMigrationExecutor, object commercialLedgerObject) (string, error) {
	table, constraint, ok := commercialChannelAttachedIndexConstraint(object.ObjectName)
	if !ok {
		return "", fmt.Errorf("commercial channel migration has unknown attached index %s", object.ObjectName)
	}
	var name string
	if err := conn.QueryRowContext(ctx, `SELECT index_rel.relname
FROM pg_constraint AS con
JOIN pg_class AS table_rel ON table_rel.oid = con.conrelid
JOIN pg_namespace AS table_ns ON table_ns.oid = table_rel.relnamespace
JOIN pg_class AS index_rel ON index_rel.oid = con.conindid
JOIN pg_namespace AS index_ns ON index_ns.oid = index_rel.relnamespace
WHERE con.contype = 'u' AND table_ns.nspname = 'public' AND table_rel.relname = $1 AND con.conname = $2 AND index_ns.nspname = 'public'`, table, constraint).Scan(&name); err != nil {
		return "", err
	}
	return name, nil
}

func commercialVerifyLiveIndex(ctx context.Context, conn commercialMigrationExecutor, object commercialLedgerObject) error {
	expected, ok := commercialExpectedIndexDefinition(object.ObjectName)
	if !ok {
		return fmt.Errorf("commercial channel migration has no expected index definition for %s", object.ObjectName)
	}
	physicalName := object.ObjectName
	logicalExists, _, _, err := commercialIndexState(ctx, conn, object.ObjectName)
	if err != nil {
		return err
	}
	if object.State == "attached" {
		if logicalExists {
			return fmt.Errorf("commercial migration found leftover logical index %s after constraint attachment", object.ObjectName)
		}
		physicalName, err = commercialLiveAttachedIndexName(ctx, conn, object)
	} else if !logicalExists {
		physicalName, err = commercialLiveAttachedIndexName(ctx, conn, object)
	}
	if err != nil {
		return err
	}
	var encoded string
	if err := conn.QueryRowContext(ctx, `SELECT jsonb_build_object(
  'table', table_rel.relname,
  'unique', index_info.indisunique,
  'valid', index_info.indisvalid,
  'ready', index_info.indisready,
  'key_count', index_info.indnkeyatts,
  'columns', COALESCE((SELECT jsonb_agg(att.attname ORDER BY key_position.ordinality)
                       FROM unnest(index_info.indkey) WITH ORDINALITY AS key_position(attnum, ordinality)
                       JOIN pg_attribute AS att ON att.attrelid = index_info.indrelid AND att.attnum = key_position.attnum), '[]'::jsonb)
)::text
FROM pg_index AS index_info
JOIN pg_class AS index_rel ON index_rel.oid = index_info.indexrelid
JOIN pg_class AS table_rel ON table_rel.oid = index_info.indrelid
JOIN pg_namespace AS table_ns ON table_ns.oid = table_rel.relnamespace
WHERE table_ns.nspname = 'public' AND index_rel.relname = $1`, physicalName).Scan(&encoded); err != nil {
		return err
	}
	var actual commercialCatalogIndex
	if err := common.UnmarshalJsonStr(encoded, &actual); err != nil {
		return fmt.Errorf("commercial channel migration decode live index %s: %w", object.ObjectName, err)
	}
	if actual.Table != expected.Table || !actual.Unique || actual.KeyCount != expected.KeyCount || !reflect.DeepEqual(actual.Columns, expected.Columns) || (!logicalExists && (!actual.Valid || !actual.Ready)) {
		return fmt.Errorf("commercial channel migration live definition mismatch for %s.%s", object.SchemaName, object.ObjectName)
	}
	return nil
}

func commercialExpectedConstraint(objectName string) (commercialCatalogConstraint, bool) {
	definitions := map[string]commercialCatalogConstraint{
		"ck_channels_commercial_activation": {
			Type: "c", Validated: true, Columns: []string{"commercial_channel", "key", "secret_ref", "auth_type", "reliability_policy_id", "active_cost_profile_id", "config_version"}, RefColumns: []string{}, OnDelete: " ",
			Expression: `((commercial_channel IS NOT TRUE) OR ((key IS NULL) AND (secret_ref IS NOT NULL) AND (auth_type IS NOT NULL) AND ((auth_type)::text = ANY ((ARRAY['bearer'::character varying, 'fixed-header'::character varying])::text[])) AND (reliability_policy_id IS NOT NULL) AND (active_cost_profile_id IS NOT NULL) AND (config_version > 0)))`,
		},
		"ck_channels_commercial_secret_ref": {
			Type: "c", Validated: true, Columns: []string{"commercial_channel", "secret_ref"}, RefColumns: []string{}, OnDelete: " ",
			Expression: `((commercial_channel IS NOT TRUE) OR ((secret_ref)::text ~ '^env://[A-Z_][A-Z0-9_]*$'::text))`,
		},
		"ck_channels_commercial_auth": {
			Type: "c", Validated: true, Columns: []string{"commercial_channel", "auth_type", "auth_header_name"}, RefColumns: []string{}, OnDelete: " ",
			Expression: `((commercial_channel IS NOT TRUE) OR ((auth_type IS NOT NULL) AND ((auth_type)::text = ANY ((ARRAY['bearer'::character varying, 'fixed-header'::character varying])::text[])) AND (((auth_type)::text <> 'fixed-header'::text) OR ((auth_header_name IS NOT NULL) AND (btrim((auth_header_name)::text) <> ''::text) AND ((auth_header_name)::text !~ '[[:cntrl:][:space:]]'::text)))))`,
		},
		"ck_channel_cost_rates_bounds": {
			Type: "c", Validated: true, Columns: []string{"price_numerator", "unit_denominator"}, RefColumns: []string{}, OnDelete: " ",
			Expression: `(((price_numerator >= 0) AND (price_numerator <= 1000000000)) AND ((unit_denominator >= 1) AND (unit_denominator <= 1000000000)))`,
		},
		"ck_channel_reliability_policies_bounds": {
			Type: "c", Validated: true, Columns: []string{"connect_timeout_ms", "response_header_timeout_ms", "first_semantic_event_timeout_ms", "stream_idle_timeout_ms", "stream_max_duration_ms", "nonstream_total_timeout_ms", "logical_precommit_deadline_ms", "max_precommit_buffer_bytes", "max_stream_bytes", "max_response_bytes", "window_seconds", "bucket_seconds", "degraded_error_rate_bps", "open_error_rate_bps", "degraded_p95_ms", "recovery_p95_ms", "minimum_samples", "consecutive_failure_limit", "cooldown_seconds", "recovery_successes", "retryable_statuses", "latency_bucket_bounds_ms"}, RefColumns: []string{}, OnDelete: " ",
			Expression: `(((connect_timeout_ms >= 1) AND (connect_timeout_ms <= 10000)) AND ((response_header_timeout_ms >= 1) AND (response_header_timeout_ms <= 10000)) AND ((first_semantic_event_timeout_ms >= 1) AND (first_semantic_event_timeout_ms <= 10000)) AND ((stream_idle_timeout_ms >= 1) AND (stream_idle_timeout_ms <= 10000)) AND ((stream_max_duration_ms >= 1) AND (stream_max_duration_ms <= 10000)) AND ((nonstream_total_timeout_ms >= 1) AND (nonstream_total_timeout_ms <= 10000)) AND ((logical_precommit_deadline_ms >= 1) AND (logical_precommit_deadline_ms <= 10000)) AND ((max_precommit_buffer_bytes >= 1) AND (max_precommit_buffer_bytes <= 1048576)) AND ((max_stream_bytes >= 1) AND (max_stream_bytes <= 8388608)) AND ((max_response_bytes >= 1) AND (max_response_bytes <= 8388608)) AND ((window_seconds >= 1) AND (window_seconds <= 10000)) AND ((bucket_seconds >= 1) AND (bucket_seconds <= window_seconds)) AND ((degraded_error_rate_bps >= 0) AND (degraded_error_rate_bps <= 10000)) AND ((open_error_rate_bps >= degraded_error_rate_bps) AND (open_error_rate_bps <= 10000)) AND ((degraded_p95_ms >= 1) AND (degraded_p95_ms <= 10000)) AND ((recovery_p95_ms >= 1) AND (recovery_p95_ms <= degraded_p95_ms)) AND ((minimum_samples >= 1) AND (minimum_samples <= 10000)) AND ((consecutive_failure_limit >= 1) AND (consecutive_failure_limit <= 10000)) AND ((cooldown_seconds >= 1) AND (cooldown_seconds <= 10000)) AND ((recovery_successes >= 1) AND (recovery_successes <= 10000)) AND (retryable_statuses <@ ARRAY[408, 429, 500, 502, 503, 504, 524]) AND (cardinality(retryable_statuses) <= 16) AND fn_channel_latency_bucket_bounds_valid(latency_bucket_bounds_ms))`,
		},
		"uq_channel_cost_profiles_channel_id":             {Type: "u", Validated: true, Columns: []string{"channel_id", "id"}, RefColumns: []string{}, OnDelete: " "},
		"uq_channel_cost_profiles_channel_version":        {Type: "u", Validated: true, Columns: []string{"channel_id", "version"}, RefColumns: []string{}, OnDelete: " "},
		"uq_channel_cost_rates_dimension":                 {Type: "u", Validated: true, Columns: []string{"cost_profile_id", "endpoint_class", "public_model_alias", "upstream_model", "meter_dimension"}, RefColumns: []string{}, OnDelete: " "},
		"uq_channel_reliability_policies_channel_id":      {Type: "u", Validated: true, Columns: []string{"channel_id", "id"}, RefColumns: []string{}, OnDelete: " "},
		"uq_channel_reliability_policies_channel_version": {Type: "u", Validated: true, Columns: []string{"channel_id", "version"}, RefColumns: []string{}, OnDelete: " "},
		"fk_channel_cost_profiles_channel_id":             {Type: "f", Validated: false, Columns: []string{"channel_id"}, Reference: "channels", RefColumns: []string{"id"}, OnDelete: "r"},
		"fk_channel_cost_rates_profile_id":                {Type: "f", Validated: false, Columns: []string{"cost_profile_id"}, Reference: "channel_cost_profiles", RefColumns: []string{"id"}, OnDelete: "r"},
		"fk_channel_reliability_policies_channel_id":      {Type: "f", Validated: false, Columns: []string{"channel_id"}, Reference: "channels", RefColumns: []string{"id"}, OnDelete: "r"},
		"fk_channels_active_cost_profile":                 {Type: "f", Validated: false, Columns: []string{"id", "active_cost_profile_id"}, Reference: "channel_cost_profiles", RefColumns: []string{"channel_id", "id"}, OnDelete: "r", Deferrable: true, Deferred: true},
		"fk_channels_reliability_policy":                  {Type: "f", Validated: false, Columns: []string{"id", "reliability_policy_id"}, Reference: "channel_reliability_policies", RefColumns: []string{"channel_id", "id"}, OnDelete: "r", Deferrable: true, Deferred: true},
	}
	definition, ok := definitions[objectName]
	return definition, ok
}

func commercialVerifyLiveConstraint(ctx context.Context, conn commercialMigrationExecutor, object commercialLedgerObject) error {
	expected, ok := commercialExpectedConstraint(object.ObjectName)
	if !ok {
		return nil
	}
	parts := strings.SplitN(object.SchemaName, ".", 2)
	if len(parts) != 2 {
		return fmt.Errorf("commercial channel migration has invalid constraint owner %s", object.SchemaName)
	}
	var encoded string
	if err := conn.QueryRowContext(ctx, `SELECT jsonb_build_object(
  'type', con.contype,
  'validated', con.convalidated,
  'deferrable', con.condeferrable,
  'deferred', con.condeferred,
  'columns', COALESCE((SELECT jsonb_agg(att.attname ORDER BY key_position.ordinality)
                       FROM unnest(con.conkey) WITH ORDINALITY AS key_position(attnum, ordinality)
                       JOIN pg_attribute AS att ON att.attrelid = con.conrelid AND att.attnum = key_position.attnum), '[]'::jsonb),
  'reference', COALESCE((SELECT ref_rel.relname FROM pg_class AS ref_rel WHERE ref_rel.oid = con.confrelid), ''),
  'ref_columns', COALESCE((SELECT jsonb_agg(ref_att.attname ORDER BY ref_position.ordinality)
                           FROM unnest(con.confkey) WITH ORDINALITY AS ref_position(attnum, ordinality)
                           JOIN pg_attribute AS ref_att ON ref_att.attrelid = con.confrelid AND ref_att.attnum = ref_position.attnum), '[]'::jsonb),
  'on_delete', COALESCE(con.confdeltype::text, ''),
  'expression', COALESCE(pg_get_expr(con.conbin, con.conrelid, false), '')
)::text
FROM pg_constraint AS con
JOIN pg_class AS rel ON rel.oid = con.conrelid
JOIN pg_namespace AS ns ON ns.oid = rel.relnamespace
WHERE ns.nspname = $1 AND rel.relname = $2 AND con.conname = $3`, parts[0], parts[1], object.ObjectName).Scan(&encoded); err != nil {
		return err
	}
	var actual commercialCatalogConstraint
	if err := common.UnmarshalJsonStr(encoded, &actual); err != nil {
		return fmt.Errorf("commercial channel migration decode live constraint %s: %w", object.ObjectName, err)
	}
	expectedValidated := expected.Type == "u" || object.Validated
	if actual.Type != expected.Type || actual.Validated != expectedValidated || actual.Deferrable != expected.Deferrable || actual.Deferred != expected.Deferred || !reflect.DeepEqual(actual.Columns, expected.Columns) || actual.Reference != expected.Reference || !reflect.DeepEqual(actual.RefColumns, expected.RefColumns) || actual.OnDelete != expected.OnDelete || actual.Expression != expected.Expression {
		return fmt.Errorf("commercial channel migration live definition mismatch for %s.%s", object.SchemaName, object.ObjectName)
	}
	return nil
}

func commercialVerifyLiveTrigger(ctx context.Context, conn commercialMigrationExecutor, object commercialLedgerObject) error {
	parts := strings.SplitN(object.SchemaName, ".", 2)
	if len(parts) != 2 {
		return fmt.Errorf("commercial channel migration has invalid trigger owner %s", object.SchemaName)
	}
	expectedFunction := strings.TrimPrefix(object.ObjectName, "trg_")
	expectedFunction = "fn_" + expectedFunction
	var tableName, functionName, enabled string
	var triggerType int
	if err := conn.QueryRowContext(ctx, `SELECT rel.relname, p.proname, t.tgenabled, t.tgtype
FROM pg_trigger AS t
JOIN pg_class AS rel ON rel.oid = t.tgrelid
JOIN pg_namespace AS ns ON ns.oid = rel.relnamespace
JOIN pg_proc AS p ON p.oid = t.tgfoid
WHERE ns.nspname = $1 AND rel.relname = $2 AND t.tgname = $3 AND NOT t.tgisinternal`, parts[0], parts[1], object.ObjectName).Scan(&tableName, &functionName, &enabled, &triggerType); err != nil {
		return err
	}
	if tableName != parts[1] || functionName != expectedFunction || enabled != "O" || triggerType != 27 {
		return fmt.Errorf("commercial channel migration live definition mismatch for %s.%s", object.SchemaName, object.ObjectName)
	}
	return nil
}

func migrateCommercialChannelFoundation() error {
	if DB == nil || !common.UsingMainDatabase(common.DatabaseTypePostgreSQL) {
		return nil
	}
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()
	sqlDB, err := DB.DB()
	if err != nil {
		return err
	}
	conn, err := sqlDB.Conn(ctx)
	if err != nil {
		return err
	}
	defer conn.Close()
	if _, err := conn.ExecContext(ctx, "SELECT pg_advisory_lock($1, $2)", commercialChannelLockClass, commercialChannelLockObject); err != nil {
		return fmt.Errorf("commercial channel migration advisory lock: %w", err)
	}
	defer conn.ExecContext(context.Background(), "SELECT pg_advisory_unlock($1, $2)", commercialChannelLockClass, commercialChannelLockObject)
	if _, err := conn.ExecContext(ctx, "SET lock_timeout = '5s'"); err != nil {
		return err
	}
	if _, err := conn.ExecContext(ctx, "SET statement_timeout = '30s'"); err != nil {
		return err
	}
	if err := commercialChannelPreflight(ctx, conn); err != nil {
		return err
	}
	if err := commercialChannelEnsureLedger(ctx, conn); err != nil {
		return err
	}
	if err := commercialChannelTransactionalPhase(ctx, conn); err != nil {
		return err
	}
	if err := commercialChannelConcurrentIndexes(ctx, conn); err != nil {
		return err
	}
	if err := commercialChannelConstraintsAndTriggers(ctx, conn); err != nil {
		return err
	}
	if err := commercialChannelValidate(ctx, conn); err != nil {
		return err
	}
	return nil
}

type commercialDownLedgerExpectation struct {
	ObjectType         string
	SchemaName         string
	ObjectName         string
	Phase              int
	RequiredState      string
	RequiresValidation bool
}

func commercialChannelDownLedgerExpectations() map[string]commercialDownLedgerExpectation {
	expectations := make(map[string]commercialDownLedgerExpectation)
	add := func(objectType, schemaName, objectName string, phase int, state string, validated bool) {
		key := objectType + "\x00" + schemaName + "\x00" + objectName
		expectations[key] = commercialDownLedgerExpectation{
			ObjectType: objectType, SchemaName: schemaName, ObjectName: objectName,
			Phase: phase, RequiredState: state, RequiresValidation: validated,
		}
	}
	add("migration", "public", commercialChannelMigrationID, 1, "created", false)
	for _, object := range commercialChannelTables {
		add(object.ObjectType, object.SchemaName, object.ObjectName, object.Phase, "created", false)
	}
	for _, column := range []string{"commercial_channel", "secret_ref", "auth_type", "auth_header_name", "failure_domain", "reliability_policy_id", "active_cost_profile_id", "config_version"} {
		add("column", "public.channels", column, 3, "created", false)
	}
	for _, index := range []string{"ux_channel_cost_profiles_channel_id", "ux_channel_cost_profiles_channel_version", "ux_channel_cost_rates_dimension", "ux_channel_reliability_policies_channel_id", "ux_channel_reliability_policies_channel_version"} {
		add("index", "public", index, 4, "attached", false)
	}
	for _, check := range []struct{ table, name string }{
		{"channels", "ck_channels_commercial_activation"},
		{"channels", "ck_channels_commercial_secret_ref"},
		{"channels", "ck_channels_commercial_auth"},
		{"channel_cost_rates", "ck_channel_cost_rates_bounds"},
		{"channel_reliability_policies", "ck_channel_reliability_policies_bounds"},
	} {
		add("constraint", "public."+check.table, check.name, 5, "created", true)
	}
	for _, constraint := range []struct{ table, name string }{
		{"channel_cost_profiles", "uq_channel_cost_profiles_channel_id"},
		{"channel_cost_profiles", "uq_channel_cost_profiles_channel_version"},
		{"channel_cost_rates", "uq_channel_cost_rates_dimension"},
		{"channel_reliability_policies", "uq_channel_reliability_policies_channel_id"},
		{"channel_reliability_policies", "uq_channel_reliability_policies_channel_version"},
	} {
		add("constraint", "public."+constraint.table, constraint.name, 5, "created", false)
	}
	for _, fk := range []struct{ table, name string }{
		{"channel_cost_profiles", "fk_channel_cost_profiles_channel_id"},
		{"channel_cost_rates", "fk_channel_cost_rates_profile_id"},
		{"channel_reliability_policies", "fk_channel_reliability_policies_channel_id"},
		{"channels", "fk_channels_active_cost_profile"},
		{"channels", "fk_channels_reliability_policy"},
	} {
		add("constraint", "public."+fk.table, fk.name, 5, "created", true)
	}
	add("function", "public", commercialChannelLatencyBoundsFunctionSignature, 5, "created", false)
	for _, function := range []string{"fn_channel_cost_profiles_immutable", "fn_channel_cost_rates_immutable", "fn_channel_reliability_policies_immutable"} {
		add("function", "public", function, 5, "created", false)
	}
	for _, trigger := range []struct{ table, name string }{
		{"channel_cost_profiles", "trg_channel_cost_profiles_immutable"},
		{"channel_cost_rates", "trg_channel_cost_rates_immutable"},
		{"channel_reliability_policies", "trg_channel_reliability_policies_immutable"},
	} {
		add("trigger", "public."+trigger.table, trigger.name, 5, "created", false)
	}
	return expectations
}

func commercialChannelAttachedIndexConstraint(index string) (table, constraint string, ok bool) {
	for _, item := range []struct{ table, constraint, index string }{
		{"channel_cost_profiles", "uq_channel_cost_profiles_channel_id", "ux_channel_cost_profiles_channel_id"},
		{"channel_cost_profiles", "uq_channel_cost_profiles_channel_version", "ux_channel_cost_profiles_channel_version"},
		{"channel_cost_rates", "uq_channel_cost_rates_dimension", "ux_channel_cost_rates_dimension"},
		{"channel_reliability_policies", "uq_channel_reliability_policies_channel_id", "ux_channel_reliability_policies_channel_id"},
		{"channel_reliability_policies", "uq_channel_reliability_policies_channel_version", "ux_channel_reliability_policies_channel_version"},
	} {
		if item.index == index {
			return item.table, item.constraint, true
		}
	}
	return "", "", false
}

func commercialChannelVerifyDownOwnership(ctx context.Context, conn *sql.Conn) error {
	var ledgerOwner *string
	if err := conn.QueryRowContext(ctx, "SELECT obj_description('public."+commercialChannelLedger+"'::regclass, 'pg_class')").Scan(&ledgerOwner); err != nil {
		return err
	}
	if ledgerOwner == nil || *ledgerOwner != commercialChannelMigrationID {
		return errors.New("commercial channel migration ownership ledger has an incompatible owner")
	}
	expectations := commercialChannelDownLedgerExpectations()
	rows, err := conn.QueryContext(ctx, "SELECT object_type, schema_name, object_name, phase, definition_hash, state, validated FROM public."+commercialChannelLedger+" WHERE migration_id = $1", commercialChannelMigrationID)
	if err != nil {
		return err
	}
	type ledgerRow struct {
		objectType, schemaName, objectName, definitionHash, state string
		phase                                                     int
		validated                                                 bool
	}
	var ledgerRows []ledgerRow
	for rows.Next() {
		var row ledgerRow
		if err := rows.Scan(&row.objectType, &row.schemaName, &row.objectName, &row.phase, &row.definitionHash, &row.state, &row.validated); err != nil {
			_ = rows.Close()
			return err
		}
		ledgerRows = append(ledgerRows, row)
	}
	if err := rows.Close(); err != nil {
		return err
	}
	if err := rows.Err(); err != nil {
		return err
	}
	seen := make(map[string]bool, len(expectations))
	for _, row := range ledgerRows {
		key := row.objectType + "\x00" + row.schemaName + "\x00" + row.objectName
		expectation, ok := expectations[key]
		if !ok || seen[key] || expectation.Phase != row.phase || expectation.RequiredState != row.state || (expectation.RequiresValidation && !row.validated) {
			return fmt.Errorf("commercial channel migration ownership ledger mismatch for %s.%s", row.schemaName, row.objectName)
		}
		expectedHash := commercialChannelExpectedDefinitionHash(row.objectType, row.schemaName, row.objectName)
		if expectedHash == "" || row.definitionHash != expectedHash {
			return fmt.Errorf("commercial channel migration definition hash mismatch for %s.%s", row.schemaName, row.objectName)
		}
		seen[key] = true
		if row.objectType == "index" {
			table, constraint, ok := commercialChannelAttachedIndexConstraint(row.objectName)
			if !ok {
				return fmt.Errorf("commercial channel migration has unknown attached index %s", row.objectName)
			}
			attached, err := commercialIndexBacksConstraint(ctx, conn, table, constraint, constraint)
			if err != nil {
				return err
			}
			if !attached {
				return fmt.Errorf("commercial channel migration attached index %s is missing its owned constraint", row.objectName)
			}
			object := commercialLedgerObject{ObjectType: row.objectType, SchemaName: row.schemaName, ObjectName: row.objectName, Hash: row.definitionHash, State: row.state, Validated: row.validated}
			if err := commercialVerifyLiveObject(ctx, conn, object); err != nil {
				return err
			}
			continue
		}
		if row.objectType == "migration" {
			continue
		}
		object := commercialLedgerObject{ObjectType: row.objectType, SchemaName: row.schemaName, ObjectName: row.objectName, Validated: row.validated}
		exists, err := commercialMigrationObjectExists(ctx, conn, object)
		if err != nil {
			return err
		}
		if !exists {
			return fmt.Errorf("commercial channel migration owned object is missing: %s.%s", row.schemaName, row.objectName)
		}
		if err := commercialVerifyLiveObject(ctx, conn, object); err != nil {
			return err
		}
	}
	if len(seen) != len(expectations) {
		return fmt.Errorf("commercial channel migration ownership ledger is incomplete: got %d objects, want %d", len(seen), len(expectations))
	}
	return nil
}

func commercialChannelFoundationDown() error {
	if DB == nil || !common.UsingMainDatabase(common.DatabaseTypePostgreSQL) {
		return nil
	}
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()
	sqlDB, err := DB.DB()
	if err != nil {
		return err
	}
	conn, err := sqlDB.Conn(ctx)
	if err != nil {
		return err
	}
	defer conn.Close()
	if _, err := conn.ExecContext(ctx, "SELECT pg_advisory_lock($1, $2)", commercialChannelLockClass, commercialChannelLockObject); err != nil {
		return fmt.Errorf("commercial channel migration DOWN advisory lock: %w", err)
	}
	defer conn.ExecContext(context.Background(), "SELECT pg_advisory_unlock($1, $2)", commercialChannelLockClass, commercialChannelLockObject)
	if _, err := conn.ExecContext(ctx, "SET lock_timeout = '5s'"); err != nil {
		return err
	}
	if _, err := conn.ExecContext(ctx, "SET statement_timeout = '30s'"); err != nil {
		return err
	}
	var migrationState string
	if err := conn.QueryRowContext(ctx, "SELECT state FROM public."+commercialChannelLedger+" WHERE migration_id = $1 AND object_type = 'migration' AND schema_name = 'public' AND object_name = $1", commercialChannelMigrationID).Scan(&migrationState); err != nil {
		return err
	}
	if migrationState != "created" {
		return fmt.Errorf("commercial channel migration DOWN requires completed UP ownership, got %q", migrationState)
	}
	if err := commercialChannelVerifyDownOwnership(ctx, conn); err != nil {
		return err
	}
	tx, err := conn.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	rollback := func(err error) error { _ = tx.Rollback(); return err }
	if _, err := tx.ExecContext(ctx, "LOCK TABLE public.channels, public.channel_cost_rates, public.channel_cost_profiles, public.channel_reliability_policies IN ACCESS EXCLUSIVE MODE"); err != nil {
		return rollback(err)
	}
	var commercialRows, profileRows, rateRows, policyRows, pointerRows, nullLegacyKeys int
	queries := []struct {
		destination *int
		query       string
	}{
		{&commercialRows, "SELECT count(*) FROM public.channels WHERE commercial_channel IS TRUE"},
		{&profileRows, "SELECT count(*) FROM public.channel_cost_profiles"},
		{&rateRows, "SELECT count(*) FROM public.channel_cost_rates"},
		{&policyRows, "SELECT count(*) FROM public.channel_reliability_policies"},
		{&pointerRows, "SELECT count(*) FROM public.channels WHERE reliability_policy_id IS NOT NULL OR active_cost_profile_id IS NOT NULL"},
		{&nullLegacyKeys, "SELECT count(*) FROM public.channels WHERE key IS NULL"},
	}
	for _, check := range queries {
		if err := tx.QueryRowContext(ctx, check.query).Scan(check.destination); err != nil {
			return rollback(err)
		}
	}
	if commercialRows != 0 || profileRows != 0 || rateRows != 0 || policyRows != 0 || pointerRows != 0 || nullLegacyKeys != 0 {
		return rollback(fmt.Errorf("commercial channel migration DOWN empty-state guard failed: channels=%d profiles=%d rates=%d policies=%d pointers=%d null_legacy_keys=%d", commercialRows, profileRows, rateRows, policyRows, pointerRows, nullLegacyKeys))
	}
	for _, fk := range []struct{ table, name string }{
		{"channels", "fk_channels_active_cost_profile"},
		{"channels", "fk_channels_reliability_policy"},
		{"channel_cost_profiles", "fk_channel_cost_profiles_channel_id"},
		{"channel_cost_rates", "fk_channel_cost_rates_profile_id"},
		{"channel_reliability_policies", "fk_channel_reliability_policies_channel_id"},
	} {
		if _, err := tx.ExecContext(ctx, "ALTER TABLE public."+fk.table+" DROP CONSTRAINT "+fk.name); err != nil {
			return rollback(err)
		}
	}
	for _, trigger := range []struct{ table, name string }{
		{"channel_cost_profiles", "trg_channel_cost_profiles_immutable"},
		{"channel_cost_rates", "trg_channel_cost_rates_immutable"},
		{"channel_reliability_policies", "trg_channel_reliability_policies_immutable"},
	} {
		if _, err := tx.ExecContext(ctx, "DROP TRIGGER "+trigger.name+" ON public."+trigger.table); err != nil {
			return rollback(err)
		}
	}
	for _, constraint := range []struct{ table, name string }{
		{"channels", "ck_channels_commercial_activation"},
		{"channels", "ck_channels_commercial_secret_ref"},
		{"channels", "ck_channels_commercial_auth"},
		{"channel_cost_rates", "ck_channel_cost_rates_bounds"},
		{"channel_reliability_policies", "ck_channel_reliability_policies_bounds"},
		{"channel_cost_profiles", "uq_channel_cost_profiles_channel_id"},
		{"channel_cost_profiles", "uq_channel_cost_profiles_channel_version"},
		{"channel_cost_rates", "uq_channel_cost_rates_dimension"},
		{"channel_reliability_policies", "uq_channel_reliability_policies_channel_id"},
		{"channel_reliability_policies", "uq_channel_reliability_policies_channel_version"},
	} {
		if _, err := tx.ExecContext(ctx, "ALTER TABLE public."+constraint.table+" DROP CONSTRAINT "+constraint.name); err != nil {
			return rollback(err)
		}
	}
	for _, function := range []string{"fn_channel_cost_profiles_immutable()", "fn_channel_cost_rates_immutable()", "fn_channel_reliability_policies_immutable()", commercialChannelLatencyBoundsFunctionSignature} {
		if _, err := tx.ExecContext(ctx, "DROP FUNCTION public."+function); err != nil {
			return rollback(err)
		}
	}
	for _, table := range []string{"channel_cost_rates", "channel_cost_profiles", "channel_reliability_policies"} {
		if _, err := tx.ExecContext(ctx, "DROP TABLE public."+table); err != nil {
			return rollback(err)
		}
	}
	for _, column := range []string{"commercial_channel", "secret_ref", "auth_type", "auth_header_name", "failure_domain", "reliability_policy_id", "active_cost_profile_id", "config_version"} {
		if _, err := tx.ExecContext(ctx, "ALTER TABLE public.channels DROP COLUMN "+column); err != nil {
			return rollback(err)
		}
	}
	if _, err := tx.ExecContext(ctx, "ALTER TABLE public.channels ALTER COLUMN key SET NOT NULL"); err != nil {
		return rollback(err)
	}
	if _, err := tx.ExecContext(ctx, "UPDATE public."+commercialChannelLedger+" SET state = 'rolled_back', validated = false, updated_at = now() WHERE migration_id = $1", commercialChannelMigrationID); err != nil {
		return rollback(err)
	}
	return tx.Commit()
}

func commercialChannelOwnedObjects() []commercialLedgerObject {
	objects := make([]commercialLedgerObject, 0, 38)
	add := func(objectType, schemaName, objectName string, phase int, definition string) {
		hash := commercialDefinitionHash(definition)
		if expectedHash := commercialChannelExpectedDefinitionHash(objectType, schemaName, objectName); expectedHash != "" {
			hash = expectedHash
		}
		objects = append(objects, commercialLedgerObject{
			ObjectType: objectType,
			SchemaName: schemaName,
			ObjectName: objectName,
			Phase:      phase,
			Hash:       hash,
		})
	}
	objects = append(objects, commercialChannelTables...)
	for _, column := range []struct{ name, definition string }{
		{"commercial_channel", "boolean NOT NULL DEFAULT false"},
		{"secret_ref", "varchar(255) NULL"},
		{"auth_type", "varchar(32) NULL"},
		{"auth_header_name", "varchar(128) NULL"},
		{"failure_domain", "varchar(128) NULL"},
		{"reliability_policy_id", "bigint NULL"},
		{"active_cost_profile_id", "bigint NULL"},
		{"config_version", "bigint NOT NULL DEFAULT 0"},
	} {
		add("column", "public.channels", column.name, 3, column.definition)
	}
	for _, index := range []struct{ name, definition string }{
		{"ux_channel_cost_profiles_channel_id", "CREATE UNIQUE INDEX CONCURRENTLY ux_channel_cost_profiles_channel_id ON public.channel_cost_profiles (channel_id, id)"},
		{"ux_channel_cost_profiles_channel_version", "CREATE UNIQUE INDEX CONCURRENTLY ux_channel_cost_profiles_channel_version ON public.channel_cost_profiles (channel_id, version)"},
		{"ux_channel_cost_rates_dimension", "CREATE UNIQUE INDEX CONCURRENTLY ux_channel_cost_rates_dimension ON public.channel_cost_rates (cost_profile_id, endpoint_class, public_model_alias, upstream_model, meter_dimension)"},
		{"ux_channel_reliability_policies_channel_id", "CREATE UNIQUE INDEX CONCURRENTLY ux_channel_reliability_policies_channel_id ON public.channel_reliability_policies (channel_id, id)"},
		{"ux_channel_reliability_policies_channel_version", "CREATE UNIQUE INDEX CONCURRENTLY ux_channel_reliability_policies_channel_version ON public.channel_reliability_policies (channel_id, version)"},
	} {
		add("index", "public", index.name, 4, index.definition)
	}
	for _, check := range []struct{ table, name, expression string }{
		{"channels", "ck_channels_commercial_activation", "commercial_channel IS NOT TRUE OR (key IS NULL AND secret_ref IS NOT NULL AND auth_type IS NOT NULL AND auth_type IN ('bearer', 'fixed-header') AND reliability_policy_id IS NOT NULL AND active_cost_profile_id IS NOT NULL AND config_version > 0)"},
		{"channels", "ck_channels_commercial_secret_ref", "commercial_channel IS NOT TRUE OR secret_ref ~ '^env://[A-Z_][A-Z0-9_]*$'"},
		{"channels", "ck_channels_commercial_auth", "commercial_channel IS NOT TRUE OR (auth_type IS NOT NULL AND auth_type IN ('bearer', 'fixed-header') AND (auth_type <> 'fixed-header' OR (auth_header_name IS NOT NULL AND btrim(auth_header_name) <> '' AND auth_header_name !~ '[[:cntrl:][:space:]]')))"},
		{"channel_cost_rates", "ck_channel_cost_rates_bounds", "price_numerator BETWEEN 0 AND 1000000000 AND unit_denominator BETWEEN 1 AND 1000000000"},
		{"channel_reliability_policies", "ck_channel_reliability_policies_bounds", "connect_timeout_ms BETWEEN 1 AND 10000 AND response_header_timeout_ms BETWEEN 1 AND 10000 AND first_semantic_event_timeout_ms BETWEEN 1 AND 10000 AND stream_idle_timeout_ms BETWEEN 1 AND 10000 AND stream_max_duration_ms BETWEEN 1 AND 10000 AND nonstream_total_timeout_ms BETWEEN 1 AND 10000 AND logical_precommit_deadline_ms BETWEEN 1 AND 10000 AND max_precommit_buffer_bytes BETWEEN 1 AND 1048576 AND max_stream_bytes BETWEEN 1 AND 8388608 AND max_response_bytes BETWEEN 1 AND 8388608 AND window_seconds BETWEEN 1 AND 10000 AND bucket_seconds BETWEEN 1 AND window_seconds AND degraded_error_rate_bps BETWEEN 0 AND 10000 AND open_error_rate_bps BETWEEN degraded_error_rate_bps AND 10000 AND degraded_p95_ms BETWEEN 1 AND 10000 AND recovery_p95_ms BETWEEN 1 AND degraded_p95_ms AND minimum_samples BETWEEN 1 AND 10000 AND consecutive_failure_limit BETWEEN 1 AND 10000 AND cooldown_seconds BETWEEN 1 AND 10000 AND recovery_successes BETWEEN 1 AND 10000 AND retryable_statuses <@ ARRAY[408,429,500,502,503,504,524]::integer[] AND cardinality(retryable_statuses) <= 16 AND public.fn_channel_latency_bucket_bounds_valid(latency_bucket_bounds_ms)"},
	} {
		add("constraint", "public."+check.table, check.name, 5, check.expression)
	}
	for _, constraint := range []struct{ table, name, index string }{
		{"channel_cost_profiles", "uq_channel_cost_profiles_channel_id", "ux_channel_cost_profiles_channel_id"},
		{"channel_cost_profiles", "uq_channel_cost_profiles_channel_version", "ux_channel_cost_profiles_channel_version"},
		{"channel_cost_rates", "uq_channel_cost_rates_dimension", "ux_channel_cost_rates_dimension"},
		{"channel_reliability_policies", "uq_channel_reliability_policies_channel_id", "ux_channel_reliability_policies_channel_id"},
		{"channel_reliability_policies", "uq_channel_reliability_policies_channel_version", "ux_channel_reliability_policies_channel_version"},
	} {
		add("constraint", "public."+constraint.table, constraint.name, 5, constraint.index)
	}
	for _, foreignKey := range []struct{ table, name, definition string }{
		{"channel_cost_profiles", "fk_channel_cost_profiles_channel_id", "ALTER TABLE public.channel_cost_profiles ADD CONSTRAINT fk_channel_cost_profiles_channel_id FOREIGN KEY (channel_id) REFERENCES public.channels(id) ON DELETE RESTRICT NOT VALID"},
		{"channel_cost_rates", "fk_channel_cost_rates_profile_id", "ALTER TABLE public.channel_cost_rates ADD CONSTRAINT fk_channel_cost_rates_profile_id FOREIGN KEY (cost_profile_id) REFERENCES public.channel_cost_profiles(id) ON DELETE RESTRICT NOT VALID"},
		{"channel_reliability_policies", "fk_channel_reliability_policies_channel_id", "ALTER TABLE public.channel_reliability_policies ADD CONSTRAINT fk_channel_reliability_policies_channel_id FOREIGN KEY (channel_id) REFERENCES public.channels(id) ON DELETE RESTRICT NOT VALID"},
		{"channels", "fk_channels_active_cost_profile", "ALTER TABLE public.channels ADD CONSTRAINT fk_channels_active_cost_profile FOREIGN KEY (id, active_cost_profile_id) REFERENCES public.channel_cost_profiles(channel_id, id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED NOT VALID"},
		{"channels", "fk_channels_reliability_policy", "ALTER TABLE public.channels ADD CONSTRAINT fk_channels_reliability_policy FOREIGN KEY (id, reliability_policy_id) REFERENCES public.channel_reliability_policies(channel_id, id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED NOT VALID"},
	} {
		add("constraint", "public."+foreignKey.table, foreignKey.name, 5, foreignKey.definition)
	}
	add("function", "public", commercialChannelLatencyBoundsFunctionSignature, 5, commercialChannelLatencyBoundsFunctionDDL)
	for _, function := range []struct{ name, definition string }{
		{"fn_channel_cost_profiles_immutable", commercialChannelTriggersDDL},
		{"fn_channel_cost_rates_immutable", commercialChannelTriggersDDL},
		{"fn_channel_reliability_policies_immutable", commercialChannelTriggersDDL},
	} {
		add("function", "public", function.name, 5, function.definition)
	}
	for _, trigger := range []struct{ table, name string }{
		{"channel_cost_profiles", "trg_channel_cost_profiles_immutable"},
		{"channel_cost_rates", "trg_channel_cost_rates_immutable"},
		{"channel_reliability_policies", "trg_channel_reliability_policies_immutable"},
	} {
		add("trigger", "public."+trigger.table, trigger.name, 5, "CREATE TRIGGER "+trigger.name+" BEFORE UPDATE OR DELETE ON public."+trigger.table+" FOR EACH ROW EXECUTE FUNCTION public.fn_"+strings.TrimPrefix(trigger.name, "trg_")+"()")
	}
	return objects
}

func commercialChannelPreflightObjectExists(ctx context.Context, conn commercialMigrationExecutor, object commercialLedgerObject, ledgerState string) (bool, error) {
	if object.ObjectType == "index" && ledgerState == "attached" {
		table, constraint, ok := commercialChannelAttachedIndexConstraint(object.ObjectName)
		if !ok {
			return false, fmt.Errorf("commercial channel migration has unknown attached index %s", object.ObjectName)
		}
		logicalExists, _, _, err := commercialIndexState(ctx, conn, object.ObjectName)
		if err != nil {
			return false, err
		}
		if logicalExists {
			return false, fmt.Errorf("commercial migration found leftover logical index %s after constraint attachment", object.ObjectName)
		}
		return commercialIndexBacksConstraint(ctx, conn, table, constraint, constraint)
	}
	if object.ObjectType == "trigger" {
		var globalExists bool
		if err := conn.QueryRowContext(ctx, `SELECT EXISTS (
  SELECT 1
  FROM pg_trigger AS t
  JOIN pg_class AS rel ON rel.oid = t.tgrelid
  JOIN pg_namespace AS n ON n.oid = rel.relnamespace
  WHERE n.nspname = 'public' AND t.tgname = $1 AND NOT t.tgisinternal
)`, object.ObjectName).Scan(&globalExists); err != nil {
			return false, err
		}
		if !globalExists {
			return false, nil
		}
		parts := strings.SplitN(object.SchemaName, ".", 2)
		if len(parts) != 2 {
			return false, fmt.Errorf("commercial channel migration has invalid trigger owner %s", object.SchemaName)
		}
		ownedExists, err := commercialNamedObjectExists(ctx, conn, "trigger", object.ObjectName, parts[1])
		if err != nil {
			return false, err
		}
		if !ownedExists {
			return false, fmt.Errorf("commercial channel migration found unowned trigger public.%s", object.ObjectName)
		}
		return true, nil
	}
	return commercialMigrationObjectExists(ctx, conn, object)
}

func commercialChannelPreflight(ctx context.Context, conn commercialMigrationExecutor) error {
	var supported bool
	if err := conn.QueryRowContext(ctx, "SELECT current_setting('server_version_num')::int >= 140000").Scan(&supported); err != nil {
		return err
	}
	if !supported {
		return errors.New("commercial channel migration requires PostgreSQL 14 or newer")
	}
	var channelsPresent bool
	if err := conn.QueryRowContext(ctx, "SELECT to_regclass('public.channels') IS NOT NULL").Scan(&channelsPresent); err != nil {
		return err
	}
	if !channelsPresent {
		return errors.New("commercial channel migration requires public.channels")
	}
	var ledgerPresent bool
	if err := conn.QueryRowContext(ctx, "SELECT to_regclass('public."+commercialChannelLedger+"') IS NOT NULL").Scan(&ledgerPresent); err != nil {
		return err
	}
	if ledgerPresent {
		var comment *string
		if err := conn.QueryRowContext(ctx, "SELECT obj_description('public."+commercialChannelLedger+"'::regclass, 'pg_class')").Scan(&comment); err != nil {
			return err
		}
		if comment == nil || *comment != commercialChannelMigrationID {
			return errors.New("commercial channel migration ownership ledger has an incompatible owner")
		}
		rows, err := conn.QueryContext(ctx, "SELECT object_type, schema_name, object_name, phase, definition_hash, state, validated FROM public."+commercialChannelLedger+" WHERE migration_id = $1", commercialChannelMigrationID)
		if err != nil {
			return err
		}
		ledger := make(map[string]commercialLedgerObject)
		for rows.Next() {
			var object commercialLedgerObject
			if err := rows.Scan(&object.ObjectType, &object.SchemaName, &object.ObjectName, &object.Phase, &object.Hash, &object.State, &object.Validated); err != nil {
				_ = rows.Close()
				return err
			}
			key := object.ObjectType + "\x00" + object.SchemaName + "\x00" + object.ObjectName
			if _, duplicate := ledger[key]; duplicate {
				_ = rows.Close()
				return fmt.Errorf("commercial channel migration ownership ledger has duplicate %s.%s", object.SchemaName, object.ObjectName)
			}
			ledger[key] = object
		}
		if err := rows.Close(); err != nil {
			return err
		}
		if err := rows.Err(); err != nil {
			return err
		}
		expected := commercialChannelOwnedObjects()
		expectedKeys := make(map[string]struct{}, len(expected))
		for _, object := range expected {
			key := object.ObjectType + "\x00" + object.SchemaName + "\x00" + object.ObjectName
			expectedKeys[key] = struct{}{}
			owned, hasLedger := ledger[key]
			if hasLedger && owned.Hash != object.Hash {
				return fmt.Errorf("commercial channel migration definition hash mismatch for %s.%s", object.SchemaName, object.ObjectName)
			}
			exists, err := commercialChannelPreflightObjectExists(ctx, conn, object, owned.State)
			if err != nil {
				return err
			}
			if exists && !hasLedger {
				return fmt.Errorf("commercial channel migration found unowned %s %s.%s", object.ObjectType, object.SchemaName, object.ObjectName)
			}
			if hasLedger && object.ObjectType == "index" && owned.State == "attached" && !exists {
				return fmt.Errorf("commercial channel migration attached index %s is missing its owned constraint", object.ObjectName)
			}
			if hasLedger && !exists && owned.State != "planned" && owned.State != "rolled_back" {
				return fmt.Errorf("commercial channel migration owned object is missing: %s.%s", object.SchemaName, object.ObjectName)
			}
			if hasLedger && exists {
				ownedObject := object
				ownedObject.State = owned.State
				ownedObject.Validated = owned.Validated
				if err := commercialVerifyLiveObject(ctx, conn, ownedObject); err != nil {
					return err
				}
			}
		}
		for key, object := range ledger {
			if object.ObjectType == "migration" && object.SchemaName == "public" && object.ObjectName == commercialChannelMigrationID {
				if object.Hash != commercialDefinitionHash(commercialChannelLedgerDDL) {
					return fmt.Errorf("commercial channel migration definition hash mismatch for migration ledger")
				}
				continue
			}
			if _, ok := expectedKeys[key]; !ok {
				return fmt.Errorf("commercial channel migration ownership ledger has unexpected object %s.%s", object.SchemaName, object.ObjectName)
			}
		}
		return nil
	}
	for _, object := range commercialChannelOwnedObjects() {
		exists, err := commercialChannelPreflightObjectExists(ctx, conn, object, "")
		if err != nil {
			return err
		}
		if exists {
			return fmt.Errorf("commercial channel migration found pre-existing %s %s.%s", object.ObjectType, object.SchemaName, object.ObjectName)
		}
	}
	return nil
}

func commercialChannelEnsureLedger(ctx context.Context, conn commercialMigrationExecutor) error {
	var ledgerPresent bool
	if err := conn.QueryRowContext(ctx, "SELECT to_regclass('public."+commercialChannelLedger+"') IS NOT NULL").Scan(&ledgerPresent); err != nil {
		return err
	}
	if !ledgerPresent {
		if _, err := conn.ExecContext(ctx, commercialChannelLedgerDDL); err != nil {
			return err
		}
		if _, err := conn.ExecContext(ctx, "COMMENT ON TABLE public."+commercialChannelLedger+" IS '"+commercialChannelMigrationID+"'"); err != nil {
			return err
		}
	} else {
		var existingHash string
		err := conn.QueryRowContext(ctx, "SELECT definition_hash FROM public."+commercialChannelLedger+" WHERE migration_id = $1 AND object_type = 'migration' AND schema_name = 'public' AND object_name = $1", commercialChannelMigrationID).Scan(&existingHash)
		if err != nil && !errors.Is(err, sql.ErrNoRows) {
			return err
		}
		if err == nil && existingHash != commercialDefinitionHash(commercialChannelLedgerDDL) {
			return errors.New("commercial channel migration definition hash mismatch for migration ledger")
		}
	}
	_, err := conn.ExecContext(ctx, "INSERT INTO public."+commercialChannelLedger+" (migration_id, object_type, schema_name, object_name, phase, definition_hash, state) VALUES ($1, 'migration', 'public', $1, 1, $2, 'created') ON CONFLICT (migration_id, object_type, schema_name, object_name) DO UPDATE SET state = 'created', updated_at = now()", commercialChannelMigrationID, commercialDefinitionHash(commercialChannelLedgerDDL))
	return err
}

func commercialLedgerPrepare(ctx context.Context, conn commercialMigrationExecutor, object commercialLedgerObject) error {
	var existingHash, state string
	var validated bool
	err := conn.QueryRowContext(ctx, "SELECT definition_hash, state, validated FROM public."+commercialChannelLedger+" WHERE migration_id = $1 AND object_type = $2 AND schema_name = $3 AND object_name = $4", commercialChannelMigrationID, object.ObjectType, object.SchemaName, object.ObjectName).Scan(&existingHash, &state, &validated)
	if errors.Is(err, sql.ErrNoRows) {
		exists, existsErr := commercialMigrationObjectExists(ctx, conn, object)
		if existsErr != nil {
			return existsErr
		}
		if exists {
			return fmt.Errorf("commercial channel migration found unowned %s %s.%s", object.ObjectType, object.SchemaName, object.ObjectName)
		}
		_, err = conn.ExecContext(ctx, "INSERT INTO public."+commercialChannelLedger+" (migration_id, object_type, schema_name, object_name, phase, definition_hash, state) VALUES ($1, $2, $3, $4, $5, $6, 'planned')", commercialChannelMigrationID, object.ObjectType, object.SchemaName, object.ObjectName, object.Phase, object.Hash)
		return err
	}
	if err != nil {
		return err
	}
	if existingHash != object.Hash {
		return fmt.Errorf("commercial channel migration ownership hash mismatch for %s.%s", object.SchemaName, object.ObjectName)
	}
	exists, err := commercialMigrationObjectExists(ctx, conn, object)
	if err != nil {
		return err
	}
	if !exists && object.ObjectType == "index" {
		table, constraint, ok := commercialChannelAttachedIndexConstraint(object.ObjectName)
		if ok {
			exists, err = commercialIndexBacksConstraint(ctx, conn, table, constraint, constraint)
			if err != nil {
				return err
			}
		}
	}
	if !exists {
		if state != "planned" && state != "rolled_back" {
			return fmt.Errorf("commercial channel migration owned object is missing: %s.%s", object.SchemaName, object.ObjectName)
		}
		return nil
	}
	object.State = state
	object.Validated = validated
	if err := commercialVerifyLiveObject(ctx, conn, object); err != nil {
		return err
	}
	return nil
}

func commercialVerifyLiveObject(ctx context.Context, conn commercialMigrationExecutor, object commercialLedgerObject) error {
	switch object.ObjectType {
	case "table":
		return commercialVerifyLiveTable(ctx, conn, object)
	case "column":
		return commercialVerifyLiveColumn(ctx, conn, object)
	case "index":
		return commercialVerifyLiveIndex(ctx, conn, object)
	case "constraint":
		return commercialVerifyLiveConstraint(ctx, conn, object)
	case "function":
		return commercialVerifyLiveFunction(ctx, conn, object)
	case "trigger":
		return commercialVerifyLiveTrigger(ctx, conn, object)
	default:
		return fmt.Errorf("commercial channel migration has unsupported live object kind %q", object.ObjectType)
	}
}

func commercialMigrationObjectExists(ctx context.Context, conn commercialMigrationExecutor, object commercialLedgerObject) (bool, error) {
	switch object.ObjectType {
	case "table", "index":
		var exists bool
		err := conn.QueryRowContext(ctx, "SELECT to_regclass($1) IS NOT NULL", object.SchemaName+"."+object.ObjectName).Scan(&exists)
		return exists, err
	case "column":
		parts := strings.SplitN(object.SchemaName, ".", 2)
		if len(parts) != 2 {
			return false, fmt.Errorf("invalid column owner schema %q", object.SchemaName)
		}
		var exists bool
		err := conn.QueryRowContext(ctx, "SELECT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = $1 AND table_name = $2 AND column_name = $3)", parts[0], parts[1], object.ObjectName).Scan(&exists)
		return exists, err
	case "constraint":
		parts := strings.SplitN(object.SchemaName, ".", 2)
		if len(parts) != 2 {
			return false, fmt.Errorf("invalid constraint owner schema %q", object.SchemaName)
		}
		return commercialNamedObjectExists(ctx, conn, "constraint", object.ObjectName, parts[1])
	case "trigger":
		parts := strings.SplitN(object.SchemaName, ".", 2)
		if len(parts) != 2 {
			return false, fmt.Errorf("invalid trigger owner schema %q", object.SchemaName)
		}
		return commercialNamedObjectExists(ctx, conn, "trigger", object.ObjectName, parts[1])
	case "function":
		return commercialNamedObjectExists(ctx, conn, "function", object.ObjectName, "")
	default:
		return false, nil
	}
}

func commercialLedgerCreated(ctx context.Context, conn commercialMigrationExecutor, object commercialLedgerObject) error {
	_, err := conn.ExecContext(ctx, "UPDATE public."+commercialChannelLedger+" SET state = 'created', updated_at = now() WHERE migration_id = $1 AND object_type = $2 AND schema_name = $3 AND object_name = $4", commercialChannelMigrationID, object.ObjectType, object.SchemaName, object.ObjectName)
	return err
}

func commercialLedgerState(ctx context.Context, conn commercialMigrationExecutor, object commercialLedgerObject) (string, error) {
	var state string
	err := conn.QueryRowContext(ctx, "SELECT state FROM public."+commercialChannelLedger+" WHERE migration_id = $1 AND object_type = $2 AND schema_name = $3 AND object_name = $4", commercialChannelMigrationID, object.ObjectType, object.SchemaName, object.ObjectName).Scan(&state)
	return state, err
}

func commercialLedgerAttached(ctx context.Context, conn commercialMigrationExecutor, object commercialLedgerObject) error {
	result, err := conn.ExecContext(ctx, "UPDATE public."+commercialChannelLedger+" SET state = 'attached', updated_at = now() WHERE migration_id = $1 AND object_type = $2 AND schema_name = $3 AND object_name = $4", commercialChannelMigrationID, object.ObjectType, object.SchemaName, object.ObjectName)
	if err != nil {
		return err
	}
	if affected, err := result.RowsAffected(); err != nil {
		return err
	} else if affected != 1 {
		return fmt.Errorf("commercial channel migration cannot mark %s.%s attached", object.SchemaName, object.ObjectName)
	}
	return nil
}

func commercialTableExists(ctx context.Context, conn commercialMigrationExecutor, table string) (bool, error) {
	var exists bool
	err := conn.QueryRowContext(ctx, "SELECT to_regclass($1) IS NOT NULL", "public."+table).Scan(&exists)
	return exists, err
}

func commercialColumnExists(ctx context.Context, conn commercialMigrationExecutor, column string) (bool, error) {
	var exists bool
	err := conn.QueryRowContext(ctx, "SELECT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = 'public' AND table_name = 'channels' AND column_name = $1)", column).Scan(&exists)
	return exists, err
}

func commercialNamedObjectExists(ctx context.Context, conn commercialMigrationExecutor, kind, name, table string) (bool, error) {
	var exists bool
	var query string
	switch kind {
	case "index":
		query = "SELECT to_regclass($1) IS NOT NULL"
		return exists, conn.QueryRowContext(ctx, query, "public."+name).Scan(&exists)
	case "constraint":
		query = "SELECT EXISTS (SELECT 1 FROM pg_constraint c JOIN pg_class r ON r.oid = c.conrelid JOIN pg_namespace n ON n.oid = r.relnamespace WHERE n.nspname = 'public' AND r.relname = $1 AND c.conname = $2)"
	case "trigger":
		query = "SELECT EXISTS (SELECT 1 FROM pg_trigger t JOIN pg_class r ON r.oid = t.tgrelid JOIN pg_namespace n ON n.oid = r.relnamespace WHERE n.nspname = 'public' AND r.relname = $1 AND t.tgname = $2 AND NOT t.tgisinternal)"
	case "function":
		if !strings.Contains(name, "(") {
			name += "()"
		}
		query = "SELECT to_regprocedure($1) IS NOT NULL"
		return exists, conn.QueryRowContext(ctx, query, "public."+name).Scan(&exists)
	default:
		return false, fmt.Errorf("unsupported migration object kind %q", kind)
	}
	return exists, conn.QueryRowContext(ctx, query, table, name).Scan(&exists)
}

func commercialIndexState(ctx context.Context, conn commercialMigrationExecutor, name string) (exists, valid, ready bool, err error) {
	err = conn.QueryRowContext(ctx, `SELECT i.indisvalid, i.indisready
FROM pg_index AS i
JOIN pg_class AS c ON c.oid = i.indexrelid
JOIN pg_namespace AS n ON n.oid = c.relnamespace
WHERE n.nspname = 'public' AND c.relname = $1`, name).Scan(&valid, &ready)
	if errors.Is(err, sql.ErrNoRows) {
		return false, false, false, nil
	}
	if err != nil {
		return false, false, false, err
	}
	return true, valid, ready, nil
}

func commercialIndexBacksConstraint(ctx context.Context, conn commercialMigrationExecutor, table, constraint, index string) (bool, error) {
	var exists bool
	err := conn.QueryRowContext(ctx, `SELECT EXISTS (
  SELECT 1
  FROM pg_constraint AS con
  JOIN pg_class AS table_rel ON table_rel.oid = con.conrelid
  JOIN pg_namespace AS table_ns ON table_ns.oid = table_rel.relnamespace
  JOIN pg_class AS index_rel ON index_rel.oid = con.conindid
  JOIN pg_namespace AS index_ns ON index_ns.oid = index_rel.relnamespace
  WHERE con.contype = 'u'
    AND table_ns.nspname = 'public' AND table_rel.relname = $1
    AND con.conname = $2
    AND index_ns.nspname = 'public' AND index_rel.relname = $3
)`, table, constraint, index).Scan(&exists)
	return exists, err
}

func commercialChannelTransactionalPhase(ctx context.Context, conn *sql.Conn) error {
	tx, err := conn.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	rollback := func(err error) error { _ = tx.Rollback(); return err }
	for _, object := range commercialChannelTables {
		exists, err := commercialTableExists(ctx, tx, object.ObjectName)
		if err != nil {
			return rollback(err)
		}
		if !exists {
			if err := commercialLedgerPrepare(ctx, tx, object); err != nil {
				return rollback(err)
			}
			var ddl string
			switch object.ObjectName {
			case "channel_cost_profiles":
				ddl = commercialChannelProfilesDDL
			case "channel_cost_rates":
				ddl = commercialChannelRatesDDL
			case "channel_reliability_policies":
				ddl = commercialChannelReliabilityDDL
			}
			if _, err := tx.ExecContext(ctx, ddl); err != nil {
				return rollback(err)
			}
			if err := commercialLedgerCreated(ctx, tx, object); err != nil {
				return rollback(err)
			}
		} else if err := commercialLedgerPrepare(ctx, tx, object); err != nil {
			return rollback(err)
		}
	}
	if _, err := tx.ExecContext(ctx, "ALTER TABLE public.channels ALTER COLUMN key DROP NOT NULL"); err != nil {
		return rollback(err)
	}
	columns := []struct{ name, typ, definition string }{
		{"commercial_channel", "boolean", "boolean NOT NULL DEFAULT false"},
		{"secret_ref", "varchar(255)", "varchar(255) NULL"},
		{"auth_type", "varchar(32)", "varchar(32) NULL"},
		{"auth_header_name", "varchar(128)", "varchar(128) NULL"},
		{"failure_domain", "varchar(128)", "varchar(128) NULL"},
		{"reliability_policy_id", "bigint", "bigint NULL"},
		{"active_cost_profile_id", "bigint", "bigint NULL"},
		{"config_version", "bigint", "bigint NOT NULL DEFAULT 0"},
	}
	for _, column := range columns {
		exists, err := commercialColumnExists(ctx, tx, column.name)
		if err != nil {
			return rollback(err)
		}
		object := commercialLedgerObject{ObjectType: "column", SchemaName: "public.channels", ObjectName: column.name, Phase: 3, Hash: commercialDefinitionHash(column.definition)}
		if !exists {
			if err := commercialLedgerPrepare(ctx, tx, object); err != nil {
				return rollback(err)
			}
			if _, err := tx.ExecContext(ctx, "ALTER TABLE public.channels ADD COLUMN "+column.name+" "+column.definition); err != nil {
				return rollback(err)
			}
			if err := commercialLedgerCreated(ctx, tx, object); err != nil {
				return rollback(err)
			}
		} else if err := commercialLedgerPrepare(ctx, tx, object); err != nil {
			return rollback(err)
		}
	}
	return tx.Commit()
}

func commercialChannelConcurrentIndexes(ctx context.Context, conn commercialMigrationExecutor) error {
	indexes := []struct{ name, table, constraint, ddl string }{
		{"ux_channel_cost_profiles_channel_id", "channel_cost_profiles", "uq_channel_cost_profiles_channel_id", "CREATE UNIQUE INDEX CONCURRENTLY ux_channel_cost_profiles_channel_id ON public.channel_cost_profiles (channel_id, id)"},
		{"ux_channel_cost_profiles_channel_version", "channel_cost_profiles", "uq_channel_cost_profiles_channel_version", "CREATE UNIQUE INDEX CONCURRENTLY ux_channel_cost_profiles_channel_version ON public.channel_cost_profiles (channel_id, version)"},
		{"ux_channel_cost_rates_dimension", "channel_cost_rates", "uq_channel_cost_rates_dimension", "CREATE UNIQUE INDEX CONCURRENTLY ux_channel_cost_rates_dimension ON public.channel_cost_rates (cost_profile_id, endpoint_class, public_model_alias, upstream_model, meter_dimension)"},
		{"ux_channel_reliability_policies_channel_id", "channel_reliability_policies", "uq_channel_reliability_policies_channel_id", "CREATE UNIQUE INDEX CONCURRENTLY ux_channel_reliability_policies_channel_id ON public.channel_reliability_policies (channel_id, id)"},
		{"ux_channel_reliability_policies_channel_version", "channel_reliability_policies", "uq_channel_reliability_policies_channel_version", "CREATE UNIQUE INDEX CONCURRENTLY ux_channel_reliability_policies_channel_version ON public.channel_reliability_policies (channel_id, version)"},
	}
	for _, index := range indexes {
		object := commercialLedgerObject{ObjectType: "index", SchemaName: "public", ObjectName: index.name, Phase: 4, Hash: commercialDefinitionHash(index.ddl)}
		if err := commercialLedgerPrepare(ctx, conn, object); err != nil {
			return err
		}
		state, err := commercialLedgerState(ctx, conn, object)
		if err != nil {
			return err
		}
		if state == "attached" {
			attached, err := commercialIndexBacksConstraint(ctx, conn, index.table, index.constraint, index.constraint)
			if err != nil {
				return err
			}
			if !attached {
				return fmt.Errorf("commercial channel migration index %s is marked attached without its owned constraint", index.name)
			}
			continue
		}
		exists, valid, ready, err := commercialIndexState(ctx, conn, index.name)
		if err != nil {
			return err
		}
		if exists && (!valid || !ready) {
			if state != "planned" && state != "created" {
				return fmt.Errorf("commercial channel migration found invalid index %s with unexpected ledger state %q", index.name, state)
			}
			if _, err := conn.ExecContext(ctx, "DROP INDEX CONCURRENTLY public."+index.name); err != nil {
				return fmt.Errorf("commercial channel migration drop invalid index %s: %w", index.name, err)
			}
			exists = false
		}
		if !exists {
			if _, err := conn.ExecContext(ctx, index.ddl); err != nil {
				return err
			}
		}
		_, valid, ready, err = commercialIndexState(ctx, conn, index.name)
		if err != nil {
			return err
		}
		if !valid || !ready {
			return fmt.Errorf("commercial channel migration index %s is invalid after creation", index.name)
		}
		if err := commercialLedgerCreated(ctx, conn, object); err != nil {
			return err
		}
	}
	return nil
}

func commercialChannelConstraintsAndTriggers(ctx context.Context, conn *sql.Conn) error {
	tx, err := conn.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	rollback := func(err error) error { _ = tx.Rollback(); return err }
	latencyBoundsFunction := commercialLedgerObject{
		ObjectType: "function",
		SchemaName: "public",
		ObjectName: commercialChannelLatencyBoundsFunctionSignature,
		Phase:      5,
		Hash:       commercialDefinitionHash(commercialChannelLatencyBoundsFunctionDDL),
	}
	latencyBoundsFunctionExists, err := commercialMigrationObjectExists(ctx, tx, latencyBoundsFunction)
	if err != nil {
		return rollback(err)
	}
	if err := commercialLedgerPrepare(ctx, tx, latencyBoundsFunction); err != nil {
		return rollback(err)
	}
	if !latencyBoundsFunctionExists {
		if _, err := tx.ExecContext(ctx, commercialChannelLatencyBoundsFunctionDDL); err != nil {
			return rollback(err)
		}
	}
	if err := commercialLedgerCreated(ctx, tx, latencyBoundsFunction); err != nil {
		return rollback(err)
	}
	checks := []struct{ table, name, expression string }{
		{"channels", "ck_channels_commercial_activation", "commercial_channel IS NOT TRUE OR (key IS NULL AND secret_ref IS NOT NULL AND auth_type IS NOT NULL AND auth_type IN ('bearer', 'fixed-header') AND reliability_policy_id IS NOT NULL AND active_cost_profile_id IS NOT NULL AND config_version > 0)"},
		{"channels", "ck_channels_commercial_secret_ref", "commercial_channel IS NOT TRUE OR secret_ref ~ '^env://[A-Z_][A-Z0-9_]*$'"},
		{"channels", "ck_channels_commercial_auth", "commercial_channel IS NOT TRUE OR (auth_type IS NOT NULL AND auth_type IN ('bearer', 'fixed-header') AND (auth_type <> 'fixed-header' OR (auth_header_name IS NOT NULL AND btrim(auth_header_name) <> '' AND auth_header_name !~ '[[:cntrl:][:space:]]')))"},
		{"channel_cost_rates", "ck_channel_cost_rates_bounds", "price_numerator BETWEEN 0 AND 1000000000 AND unit_denominator BETWEEN 1 AND 1000000000"},
		{"channel_reliability_policies", "ck_channel_reliability_policies_bounds", "connect_timeout_ms BETWEEN 1 AND 10000 AND response_header_timeout_ms BETWEEN 1 AND 10000 AND first_semantic_event_timeout_ms BETWEEN 1 AND 10000 AND stream_idle_timeout_ms BETWEEN 1 AND 10000 AND stream_max_duration_ms BETWEEN 1 AND 10000 AND nonstream_total_timeout_ms BETWEEN 1 AND 10000 AND logical_precommit_deadline_ms BETWEEN 1 AND 10000 AND max_precommit_buffer_bytes BETWEEN 1 AND 1048576 AND max_stream_bytes BETWEEN 1 AND 8388608 AND max_response_bytes BETWEEN 1 AND 8388608 AND window_seconds BETWEEN 1 AND 10000 AND bucket_seconds BETWEEN 1 AND window_seconds AND degraded_error_rate_bps BETWEEN 0 AND 10000 AND open_error_rate_bps BETWEEN degraded_error_rate_bps AND 10000 AND degraded_p95_ms BETWEEN 1 AND 10000 AND recovery_p95_ms BETWEEN 1 AND degraded_p95_ms AND minimum_samples BETWEEN 1 AND 10000 AND consecutive_failure_limit BETWEEN 1 AND 10000 AND cooldown_seconds BETWEEN 1 AND 10000 AND recovery_successes BETWEEN 1 AND 10000 AND retryable_statuses <@ ARRAY[408,429,500,502,503,504,524]::integer[] AND cardinality(retryable_statuses) <= 16 AND public.fn_channel_latency_bucket_bounds_valid(latency_bucket_bounds_ms)"},
	}
	for _, check := range checks {
		exists, err := commercialNamedObjectExists(ctx, tx, "constraint", check.name, check.table)
		if err != nil {
			return rollback(err)
		}
		object := commercialLedgerObject{ObjectType: "constraint", SchemaName: "public." + check.table, ObjectName: check.name, Phase: 5, Hash: commercialDefinitionHash(check.expression)}
		if err := commercialLedgerPrepare(ctx, tx, object); err != nil {
			return rollback(err)
		}
		if !exists {
			if _, err := tx.ExecContext(ctx, "ALTER TABLE public."+check.table+" ADD CONSTRAINT "+check.name+" CHECK ("+check.expression+") NOT VALID"); err != nil {
				return rollback(err)
			}
		}
		if err := commercialLedgerCreated(ctx, tx, object); err != nil {
			return rollback(err)
		}
	}
	uniqueConstraints := []struct{ table, name, index string }{
		{"channel_cost_profiles", "uq_channel_cost_profiles_channel_id", "ux_channel_cost_profiles_channel_id"},
		{"channel_cost_profiles", "uq_channel_cost_profiles_channel_version", "ux_channel_cost_profiles_channel_version"},
		{"channel_cost_rates", "uq_channel_cost_rates_dimension", "ux_channel_cost_rates_dimension"},
		{"channel_reliability_policies", "uq_channel_reliability_policies_channel_id", "ux_channel_reliability_policies_channel_id"},
		{"channel_reliability_policies", "uq_channel_reliability_policies_channel_version", "ux_channel_reliability_policies_channel_version"},
	}
	for _, constraint := range uniqueConstraints {
		exists, err := commercialNamedObjectExists(ctx, tx, "constraint", constraint.name, constraint.table)
		if err != nil {
			return rollback(err)
		}
		object := commercialLedgerObject{ObjectType: "constraint", SchemaName: "public." + constraint.table, ObjectName: constraint.name, Phase: 5, Hash: commercialDefinitionHash(constraint.index)}
		if err := commercialLedgerPrepare(ctx, tx, object); err != nil {
			return rollback(err)
		}
		if !exists {
			if _, err := tx.ExecContext(ctx, "ALTER TABLE public."+constraint.table+" ADD CONSTRAINT "+constraint.name+" UNIQUE USING INDEX "+constraint.index); err != nil {
				return rollback(err)
			}
		}
		if err := commercialLedgerCreated(ctx, tx, object); err != nil {
			return rollback(err)
		}
		indexObject := commercialLedgerObject{ObjectType: "index", SchemaName: "public", ObjectName: constraint.index, Phase: 4}
		attached, err := commercialIndexBacksConstraint(ctx, tx, constraint.table, constraint.name, constraint.name)
		if err != nil {
			return rollback(err)
		}
		if !attached {
			return rollback(fmt.Errorf("commercial channel migration constraint %s is not backed by its renamed index", constraint.name))
		}
		if err := commercialLedgerAttached(ctx, tx, indexObject); err != nil {
			return rollback(err)
		}
	}
	foreignKeys := []struct{ table, name, ddl string }{
		{"channel_cost_profiles", "fk_channel_cost_profiles_channel_id", "ALTER TABLE public.channel_cost_profiles ADD CONSTRAINT fk_channel_cost_profiles_channel_id FOREIGN KEY (channel_id) REFERENCES public.channels(id) ON DELETE RESTRICT NOT VALID"},
		{"channel_cost_rates", "fk_channel_cost_rates_profile_id", "ALTER TABLE public.channel_cost_rates ADD CONSTRAINT fk_channel_cost_rates_profile_id FOREIGN KEY (cost_profile_id) REFERENCES public.channel_cost_profiles(id) ON DELETE RESTRICT NOT VALID"},
		{"channel_reliability_policies", "fk_channel_reliability_policies_channel_id", "ALTER TABLE public.channel_reliability_policies ADD CONSTRAINT fk_channel_reliability_policies_channel_id FOREIGN KEY (channel_id) REFERENCES public.channels(id) ON DELETE RESTRICT NOT VALID"},
		{"channels", "fk_channels_active_cost_profile", "ALTER TABLE public.channels ADD CONSTRAINT fk_channels_active_cost_profile FOREIGN KEY (id, active_cost_profile_id) REFERENCES public.channel_cost_profiles(channel_id, id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED NOT VALID"},
		{"channels", "fk_channels_reliability_policy", "ALTER TABLE public.channels ADD CONSTRAINT fk_channels_reliability_policy FOREIGN KEY (id, reliability_policy_id) REFERENCES public.channel_reliability_policies(channel_id, id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED NOT VALID"},
	}
	for _, fk := range foreignKeys {
		exists, err := commercialNamedObjectExists(ctx, tx, "constraint", fk.name, fk.table)
		if err != nil {
			return rollback(err)
		}
		object := commercialLedgerObject{ObjectType: "constraint", SchemaName: "public." + fk.table, ObjectName: fk.name, Phase: 5, Hash: commercialDefinitionHash(fk.ddl)}
		if err := commercialLedgerPrepare(ctx, tx, object); err != nil {
			return rollback(err)
		}
		if !exists {
			if _, err := tx.ExecContext(ctx, fk.ddl); err != nil {
				return rollback(err)
			}
		}
		if err := commercialLedgerCreated(ctx, tx, object); err != nil {
			return rollback(err)
		}
	}
	triggerFunctions := []struct{ name, ddl string }{
		{"fn_channel_cost_profiles_immutable", `CREATE OR REPLACE FUNCTION public.fn_channel_cost_profiles_immutable() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN RAISE EXCEPTION 'commercial channel cost profiles are immutable' USING ERRCODE = 'check_violation'; END IF;
  IF OLD.retired_at IS NULL AND NEW.retired_at IS NOT NULL AND NEW.id IS NOT DISTINCT FROM OLD.id AND NEW.channel_id IS NOT DISTINCT FROM OLD.channel_id AND NEW.version IS NOT DISTINCT FROM OLD.version AND NEW.currency IS NOT DISTINCT FROM OLD.currency AND NEW.rounding_rule IS NOT DISTINCT FROM OLD.rounding_rule AND NEW.effective_at IS NOT DISTINCT FROM OLD.effective_at AND NEW.created_at IS NOT DISTINCT FROM OLD.created_at THEN RETURN NEW; END IF;
  RAISE EXCEPTION 'commercial channel cost profiles are immutable' USING ERRCODE = 'check_violation';
END $$`},
		{"fn_channel_cost_rates_immutable", `CREATE OR REPLACE FUNCTION public.fn_channel_cost_rates_immutable() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION 'commercial channel cost rates are immutable' USING ERRCODE = 'check_violation'; END $$`},
		{"fn_channel_reliability_policies_immutable", `CREATE OR REPLACE FUNCTION public.fn_channel_reliability_policies_immutable() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION 'commercial channel reliability policies are immutable' USING ERRCODE = 'check_violation'; END $$`},
	}
	for _, function := range triggerFunctions {
		exists, err := commercialNamedObjectExists(ctx, tx, "function", function.name, "")
		if err != nil {
			return rollback(err)
		}
		object := commercialLedgerObject{ObjectType: "function", SchemaName: "public", ObjectName: function.name, Phase: 5, Hash: commercialDefinitionHash(function.ddl)}
		if err := commercialLedgerPrepare(ctx, tx, object); err != nil {
			return rollback(err)
		}
		if !exists {
			if _, err := tx.ExecContext(ctx, function.ddl); err != nil {
				return rollback(err)
			}
		}
		if err := commercialLedgerCreated(ctx, tx, object); err != nil {
			return rollback(err)
		}
	}
	triggers := []struct{ table, name, function string }{
		{"channel_cost_profiles", "trg_channel_cost_profiles_immutable", "fn_channel_cost_profiles_immutable"},
		{"channel_cost_rates", "trg_channel_cost_rates_immutable", "fn_channel_cost_rates_immutable"},
		{"channel_reliability_policies", "trg_channel_reliability_policies_immutable", "fn_channel_reliability_policies_immutable"},
	}
	for _, trigger := range triggers {
		exists, err := commercialNamedObjectExists(ctx, tx, "trigger", trigger.name, trigger.table)
		if err != nil {
			return rollback(err)
		}
		ddl := "CREATE TRIGGER " + trigger.name + " BEFORE UPDATE OR DELETE ON public." + trigger.table + " FOR EACH ROW EXECUTE FUNCTION public." + trigger.function + "()"
		object := commercialLedgerObject{ObjectType: "trigger", SchemaName: "public." + trigger.table, ObjectName: trigger.name, Phase: 5, Hash: commercialDefinitionHash(ddl)}
		if err := commercialLedgerPrepare(ctx, tx, object); err != nil {
			return rollback(err)
		}
		if !exists {
			if _, err := tx.ExecContext(ctx, ddl); err != nil {
				return rollback(err)
			}
		}
		if err := commercialLedgerCreated(ctx, tx, object); err != nil {
			return rollback(err)
		}
	}
	return tx.Commit()
}

func commercialChannelValidate(ctx context.Context, conn *sql.Conn) error {
	tx, err := conn.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	rollback := func(err error) error { _ = tx.Rollback(); return err }
	constraints := []struct{ table, name string }{
		{"channels", "ck_channels_commercial_activation"},
		{"channels", "ck_channels_commercial_secret_ref"},
		{"channels", "ck_channels_commercial_auth"},
		{"channel_cost_rates", "ck_channel_cost_rates_bounds"},
		{"channel_reliability_policies", "ck_channel_reliability_policies_bounds"},
		{"channel_cost_profiles", "fk_channel_cost_profiles_channel_id"},
		{"channel_cost_rates", "fk_channel_cost_rates_profile_id"},
		{"channel_reliability_policies", "fk_channel_reliability_policies_channel_id"},
		{"channels", "fk_channels_active_cost_profile"},
		{"channels", "fk_channels_reliability_policy"},
	}
	for _, constraint := range constraints {
		if _, err := tx.ExecContext(ctx, "ALTER TABLE public."+constraint.table+" VALIDATE CONSTRAINT "+constraint.name); err != nil {
			return rollback(err)
		}
		if _, err := tx.ExecContext(ctx, "UPDATE public."+commercialChannelLedger+" SET validated = true, updated_at = now() WHERE migration_id = $1 AND object_name = $2", commercialChannelMigrationID, constraint.name); err != nil {
			return rollback(err)
		}
	}
	var invalidCommercial int
	if err := tx.QueryRowContext(ctx, "SELECT count(*) FROM public.channels WHERE commercial_channel IS TRUE AND (key IS NOT NULL OR secret_ref IS NULL OR auth_type IS NULL OR reliability_policy_id IS NULL OR active_cost_profile_id IS NULL OR config_version <= 0)").Scan(&invalidCommercial); err != nil {
		return rollback(err)
	}
	if invalidCommercial != 0 {
		return rollback(fmt.Errorf("commercial channel activation guard found %d invalid rows", invalidCommercial))
	}
	return tx.Commit()
}
