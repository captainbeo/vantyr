package model

import (
	"testing"

	"github.com/QuantumNous/new-api/common"

	"github.com/stretchr/testify/require"
)

// TestFormatUserLogsStripsQuotaSaturation verifies the admin-only quota
// saturation marker (nested under other.admin_info) is removed for non-admin
// log views, since formatUserLogs strips the whole admin_info object.
func TestFormatUserLogsStripsQuotaSaturation(t *testing.T) {
	other := common.MapToJsonStr(map[string]interface{}{
		"model_price": 0.004,
		"admin_info": map[string]interface{}{
			"quota_saturation": map[string]interface{}{
				"op":      "QuotaFromDecimal",
				"kind":    "overflow",
				"clamped": common.MaxQuota,
			},
		},
	})
	logs := []*Log{{Other: other}}

	formatUserLogs(logs, 0)

	parsed, err := common.StrToMap(logs[0].Other)
	require.NoError(t, err)
	_, hasAdminInfo := parsed["admin_info"]
	require.False(t, hasAdminInfo, "admin_info (and nested quota_saturation) must be stripped for non-admin views")
	// Non-admin billing fields remain visible in the inherited projection.
	require.Contains(t, parsed, "model_price")
}

func TestFormatPrivateMVPUserLogsStripsHiddenFields(t *testing.T) {
	other := common.MapToJsonStr(map[string]interface{}{
		"channel_id":                 41,
		"channel_name":               "primary-transfer-station",
		"channel_type":               7,
		"model_price":                0.004,
		"model_ratio":                3.5,
		"group_ratio":                1.2,
		"completion_ratio":           1.1,
		"cache_ratio":                0.2,
		"audio_ratio":                0.7,
		"audio_completion_ratio":     0.8,
		"cache_creation_ratio":       0.3,
		"cache_creation_ratio_5m":    0.4,
		"cache_creation_ratio_1h":    0.5,
		"user_group_ratio":           0.9,
		"channel":                    "primary-transfer-station",
		"upstream_model_name":        "supplier-private-model",
		"is_model_mapped":            true,
		"reject_reason":              "supplier rejected request",
		"error_type":                 "upstream_error",
		"error_code":                 "supplier_failure",
		"status_code":                502,
		"tool_surcharges":            []interface{}{map[string]interface{}{"name": "web_search", "price": 0.01}},
		"audio_input_price":          0.02,
		"audio_input_seperate_price": true,
		"audio_input_token_count":    12,
		"image_ratio":                1.5,
		"usage_semantic":             "anthropic",
		"cache_creation_tokens":      13,
		"cache_write_tokens":         14,
		"input_tokens_total":         15,
		"provider_internal_field":    "must be dropped",
		"frt":                        42.5,
		"reasoning_effort":           "high",
		"request_path":               "/responses",
	})
	logs := []*Log{{
		UserId:            7,
		Username:          "customer@example.test",
		Content:           "upstream vendor body",
		Type:              LogTypeError,
		ModelName:         "gpt-5.4",
		TokenName:         "Codex",
		Quota:             123,
		PromptTokens:      11,
		CompletionTokens:  5,
		Group:             "default",
		ChannelId:         41,
		ChannelName:       "primary-transfer-station",
		TokenId:           99,
		UpstreamRequestId: "supplier-request-123",
		Ip:                "203.0.113.10",
		Other:             other,
	}}

	FormatPrivateMVPUserLogs(logs, 0)

	require.Zero(t, logs[0].ChannelId)
	require.Empty(t, logs[0].ChannelName)
	require.Equal(t, 7, logs[0].UserId)
	require.Equal(t, "customer@example.test", logs[0].Username)
	require.Equal(t, "request failed", logs[0].Content)
	require.Equal(t, "gpt-5.4", logs[0].ModelName)
	require.Equal(t, "Codex", logs[0].TokenName)
	require.Equal(t, 123, logs[0].Quota)
	require.Equal(t, 11, logs[0].PromptTokens)
	require.Equal(t, 5, logs[0].CompletionTokens)
	require.Equal(t, "default", logs[0].Group)
	require.Zero(t, logs[0].TokenId)
	require.Empty(t, logs[0].UpstreamRequestId)
	require.Empty(t, logs[0].Ip)
	parsed, err := common.StrToMap(logs[0].Other)
	require.NoError(t, err)
	for _, key := range []string{
		"channel_id", "channel_name", "channel_type", "model_price", "model_ratio",
		"group_ratio", "completion_ratio", "cache_ratio", "audio_ratio",
		"audio_completion_ratio", "cache_creation_ratio", "cache_creation_ratio_5m",
		"cache_creation_ratio_1h", "user_group_ratio", "channel", "upstream_model_name",
		"is_model_mapped", "reject_reason",
		"error_type", "error_code", "status_code", "tool_surcharges",
		"audio_input_price", "audio_input_seperate_price", "audio_input_token_count",
		"image_ratio", "usage_semantic", "provider_internal_field",
	} {
		_, present := parsed[key]
		require.False(t, present, "customer logs must not expose %s", key)
	}
	require.Equal(t, "/responses", parsed["request_path"])
	require.Equal(t, 42.5, parsed["frt"])
	require.Equal(t, "high", parsed["reasoning_effort"])
	// These bounded usage fields are safe customer metadata and are retained by
	// the explicit private-MVP projection.
	require.Equal(t, float64(13), parsed["cache_creation_tokens"])
	require.Equal(t, float64(14), parsed["cache_write_tokens"])
	require.Equal(t, float64(15), parsed["input_tokens_total"])

	consumeLog := *logs[0]
	consumeLog.Type = LogTypeConsume
	consumeLog.Content = "model price 0.004, group ratio 3.5"
	FormatPrivateMVPUserLogs([]*Log{&consumeLog}, 0)
	require.Equal(t, "request completed", consumeLog.Content)
}
