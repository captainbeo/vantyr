package model

import (
	"os"
	"strings"
	"testing"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/constant"
	"github.com/glebarez/sqlite"
	"github.com/stretchr/testify/require"
	"gorm.io/gorm"
)

func setupCommercialActivationRegressionDB(t *testing.T) *gorm.DB {
	t.Helper()
	dsn := "file:commercial_activation_regressions_" + strings.ReplaceAll(t.Name(), "/", "_") + "?mode=memory&cache=shared"
	db, err := gorm.Open(sqlite.Open(dsn), &gorm.Config{})
	require.NoError(t, err)
	originalDB := DB
	originalMemoryCache := common.MemoryCacheEnabled
	DB = db
	common.MemoryCacheEnabled = false
	t.Cleanup(func() {
		DB = originalDB
		common.MemoryCacheEnabled = originalMemoryCache
	})
	require.NoError(t, db.AutoMigrate(&Channel{}, &Ability{}))
	for _, statement := range []string{
		"ALTER TABLE channels ADD COLUMN commercial_channel BOOLEAN NOT NULL DEFAULT FALSE",
		"ALTER TABLE channels ADD COLUMN secret_ref VARCHAR(255)",
		"ALTER TABLE channels ADD COLUMN auth_type VARCHAR(32)",
		"ALTER TABLE channels ADD COLUMN auth_header_name VARCHAR(128)",
		"ALTER TABLE channels ADD COLUMN failure_domain VARCHAR(128)",
		"ALTER TABLE channels ADD COLUMN reliability_policy_id INTEGER",
		"ALTER TABLE channels ADD COLUMN active_cost_profile_id INTEGER",
		"ALTER TABLE channels ADD COLUMN config_version INTEGER NOT NULL DEFAULT 0",
	} {
		require.NoError(t, db.Exec(statement).Error)
	}
	return db
}

func insertCommercialActivationRegressionChannel(t *testing.T, db *gorm.DB, name, tag string, status int) *Channel {
	t.Helper()
	secretRef := "env://UPSTREAM_PRIMARY_API_KEY"
	authType := "bearer"
	channel := &Channel{
		Name:                name,
		Tag:                 &tag,
		Type:                constant.ChannelTypeOpenAI,
		Status:              status,
		CommercialChannel:   true,
		BaseURL:             common.GetPointer("https://upstream.example.com"),
		SecretRef:           &secretRef,
		AuthType:            &authType,
		ReliabilityPolicyID: common.GetPointer(int64(11)),
		ActiveCostProfileID: common.GetPointer(int64(12)),
		ConfigVersion:       1,
	}
	require.NoError(t, db.Create(channel).Error)
	return channel
}

func resetCommercialChannelActivationForTest() {
	commercialChannelSelectionReady.Store(false)
	commercialChannelRestartRequired.Store(false)
}

func useCommercialChannelActivationState(t *testing.T, enabled bool) {
	t.Helper()
	resetCommercialChannelActivationForTest()
	initializeCommercialChannelActivation(enabled)
	t.Cleanup(resetCommercialChannelActivationForTest)
}

func TestCommercialChannelSelectionRequiresCompletedMigrationAtProcessStart(t *testing.T) {
	db := setupCommercialActivationRegressionDB(t)
	useCommercialChannelActivationState(t, false)
	legacyTag := "restart-gate"
	legacy := &Channel{
		Name: "legacy-restart-gate", Tag: &legacyTag, Type: constant.ChannelTypeOpenAI,
		Status: common.ChannelStatusEnabled, Key: "legacy-key", Group: "default", Models: "legacy-model",
	}
	require.NoError(t, db.Create(legacy).Error)
	commercial := insertCommercialActivationRegressionChannel(t, db, "commercial-restart-gate", legacyTag, common.ChannelStatusManuallyDisabled)
	require.NoError(t, db.Model(commercial).Updates(map[string]any{"group": "default", "models": "commercial-model"}).Error)
	for _, ability := range []Ability{
		{Group: "default", Model: "legacy-model", ChannelId: legacy.Id, Enabled: true},
		{Group: "default", Model: "commercial-model", ChannelId: commercial.Id, Enabled: true},
		{Group: "default", Model: "orphan-model", ChannelId: 999999, Enabled: true},
	} {
		require.NoError(t, db.Create(&ability).Error)
	}

	require.ElementsMatch(t, []string{"legacy-model", "orphan-model"}, GetEnabledModels())
	selected, err := GetChannel("default", "commercial-model", 0, "")
	require.NoError(t, err)
	require.Nil(t, selected)
	common.MemoryCacheEnabled = true
	InitChannelCache()
	selected, err = GetRandomSatisfiedChannel("default", "commercial-model", 0, "")
	require.NoError(t, err)
	require.Nil(t, selected)
	require.False(t, UpdateChannelStatus(commercial.Id, "", common.ChannelStatusEnabled, "before restart"))

	initializeCommercialChannelActivation(true)
	require.False(t, CommercialChannelSelectionEnabled(), "migration completion in the same process must not imitate a restart")
	resetCommercialChannelActivationForTest()
	initializeCommercialChannelActivation(true)
	require.True(t, UpdateChannelStatus(commercial.Id, "", common.ChannelStatusEnabled, "after restart"))
	require.ElementsMatch(t, []string{"legacy-model", "commercial-model", "orphan-model"}, GetEnabledModels())
	selected, err = GetChannel("default", "commercial-model", 0, "")
	require.NoError(t, err)
	require.NotNil(t, selected)
	require.Equal(t, commercial.Id, selected.Id)
	InitChannelCache()
	selected, err = GetRandomSatisfiedChannel("default", "commercial-model", 0, "")
	require.NoError(t, err)
	require.NotNil(t, selected)
	require.Equal(t, commercial.Id, selected.Id)
}

func TestCommercialActivationRegistersEnvironmentSecretsBeforeSelection(t *testing.T) {
	db := setupCommercialActivationRegressionDB(t)
	resetCommercialChannelActivationForTest()
	t.Cleanup(resetCommercialChannelActivationForTest)
	const envName = "COMMERCIAL_STARTUP_REDACTOR_TEST_KEY"
	secret := "commercial-startup-redactor-" + strings.ReplaceAll(t.Name(), "/", "-")
	t.Setenv(envName, secret)
	channel := insertCommercialActivationRegressionChannel(t, db, "startup-redactor", "startup-redactor", common.ChannelStatusEnabled)
	require.NoError(t, db.Exec("UPDATE channels SET secret_ref = ? WHERE id = ?", "env://"+envName, channel.Id).Error)
	require.Equal(t, secret, common.RedactSensitiveValues(secret))

	initializeCommercialChannelActivation(true)

	require.True(t, CommercialChannelSelectionEnabled())
	require.Equal(t, "[REDACTED]", common.RedactSensitiveValues(secret))
}

func TestEnableChannelByTagLeavesCommercialAbilitiesDisabled(t *testing.T) {
	db := setupCommercialActivationRegressionDB(t)
	tag := "shared-tag"
	legacy := &Channel{Name: "legacy", Tag: &tag, Type: constant.ChannelTypeOpenAI, Status: common.ChannelStatusManuallyDisabled, Key: "legacy-key"}
	require.NoError(t, db.Create(legacy).Error)
	commercial := insertCommercialActivationRegressionChannel(t, db, "commercial", tag, common.ChannelStatusManuallyDisabled)
	modelName := "gpt-5.4"
	for _, channel := range []*Channel{legacy, commercial} {
		require.NoError(t, db.Create(&Ability{Group: "default", Model: modelName, ChannelId: channel.Id, Enabled: false, Tag: &tag}).Error)
	}

	require.NoError(t, EnableChannelByTag(tag))
	var statuses []struct {
		ID     int
		Status int
	}
	require.NoError(t, db.Model(&Channel{}).Where("id IN ?", []int{legacy.Id, commercial.Id}).Select("id, status").Order("id").Find(&statuses).Error)
	require.Len(t, statuses, 2)
	require.Equal(t, common.ChannelStatusEnabled, statuses[0].Status)
	require.NotEqual(t, common.ChannelStatusEnabled, statuses[1].Status)
	var abilities []Ability
	require.NoError(t, db.Order("channel_id").Find(&abilities).Error)
	require.Len(t, abilities, 2)
	require.True(t, abilities[0].Enabled)
	require.False(t, abilities[1].Enabled)
}

func TestDatabaseAbilityOwnersExcludeCommercialAndInactiveChannels(t *testing.T) {
	db := setupCommercialActivationRegressionDB(t)
	tag := "owner-tag"
	legacy := &Channel{Name: "legacy-owner", Tag: &tag, Type: constant.ChannelTypeOpenAI, Status: common.ChannelStatusEnabled, Key: "legacy-key", Group: "default", Models: "legacy-model"}
	require.NoError(t, db.Create(legacy).Error)
	commercial := insertCommercialActivationRegressionChannel(t, db, "commercial-owner", tag, common.ChannelStatusEnabled)
	commercial.Group = "default"
	commercial.Models = "commercial-model"
	require.NoError(t, db.Exec("UPDATE channels SET status = ? WHERE id = ?", common.ChannelStatusEnabled, commercial.Id).Error)
	disabled := &Channel{Name: "disabled-owner", Tag: &tag, Type: constant.ChannelTypeOpenAI, Status: common.ChannelStatusManuallyDisabled, Key: "disabled-key", Group: "default", Models: "disabled-model"}
	require.NoError(t, db.Create(disabled).Error)
	for _, candidate := range []struct {
		channel *Channel
		model   string
	}{
		{legacy, "legacy-model"},
		{commercial, "commercial-model"},
		{disabled, "disabled-model"},
	} {
		require.NoError(t, db.Create(&Ability{Group: "default", Model: candidate.model, ChannelId: candidate.channel.Id, Enabled: true, Tag: &tag}).Error)
	}

	require.Equal(t, []string{"legacy-model"}, GetEnabledModels())
	require.Equal(t, []string{"legacy-model"}, GetGroupEnabledModels("default"))
	enabledAbilities := GetAllEnableAbilities()
	require.Len(t, enabledAbilities, 1)
	require.Equal(t, legacy.Id, enabledAbilities[0].ChannelId)
	withChannels, err := GetAllEnableAbilityWithChannels()
	require.NoError(t, err)
	require.Len(t, withChannels, 1)
	require.Equal(t, legacy.Id, withChannels[0].ChannelId)
	bound, err := GetBoundChannelsByModelsMap([]string{"legacy-model", "commercial-model", "disabled-model"})
	require.NoError(t, err)
	require.Len(t, bound["legacy-model"], 1)
	require.Empty(t, bound["commercial-model"])
	require.Empty(t, bound["disabled-model"])
}

func TestDatabaseChannelSelectionExcludesCommercialAndInactiveChannels(t *testing.T) {
	db := setupCommercialActivationRegressionDB(t)
	tag := "selection-tag"
	commercial := insertCommercialActivationRegressionChannel(t, db, "commercial-selection", tag, common.ChannelStatusEnabled)
	legacy := &Channel{Name: "legacy-selection", Tag: &tag, Type: constant.ChannelTypeOpenAI, Status: common.ChannelStatusManuallyDisabled, Key: "legacy-key"}
	require.NoError(t, db.Create(legacy).Error)
	priority := int64(0)
	for _, channel := range []*Channel{commercial, legacy} {
		require.NoError(t, db.Create(&Ability{Group: "default", Model: "gpt-5.4", ChannelId: channel.Id, Enabled: true, Priority: &priority}).Error)
	}

	channel, err := GetChannel("default", "gpt-5.4", 0, "")
	require.NoError(t, err)
	require.Nil(t, channel)

	require.NoError(t, db.Model(legacy).Update("status", common.ChannelStatusEnabled).Error)
	channel, err = GetChannel("default", "gpt-5.4", 0, "")
	require.NoError(t, err)
	require.NotNil(t, channel)
	require.Equal(t, legacy.Id, channel.Id)
}

func TestDatabaseChannelSelectionRetryUsesAbilityPriority(t *testing.T) {
	db := setupCommercialActivationRegressionDB(t)
	highPriority := int64(2)
	lowPriority := int64(1)
	for _, candidate := range []struct {
		id       int
		priority *int64
	}{
		{1, &highPriority},
		{2, &lowPriority},
	} {
		channel := &Channel{Id: candidate.id, Name: "retry-selection", Type: constant.ChannelTypeOpenAI, Status: common.ChannelStatusEnabled, Key: "legacy-key"}
		require.NoError(t, db.Create(channel).Error)
		require.NoError(t, db.Create(&Ability{Group: "default", Model: "gpt-5.4", ChannelId: channel.Id, Enabled: true, Priority: candidate.priority}).Error)
	}

	channel, err := GetChannel("default", "gpt-5.4", 1, "")
	require.NoError(t, err)
	require.NotNil(t, channel)
	require.Equal(t, 2, channel.Id)
}

func TestMemoryChannelSelectionExcludesCommercialChannels(t *testing.T) {
	db := setupCommercialActivationRegressionDB(t)
	legacyTag := "legacy-cache"
	legacy := &Channel{Name: "legacy-cache", Tag: &legacyTag, Type: constant.ChannelTypeOpenAI, Status: common.ChannelStatusEnabled, Key: "legacy-key", Group: "default", Models: "legacy-model"}
	require.NoError(t, db.Create(legacy).Error)
	commercial := insertCommercialActivationRegressionChannel(t, db, "commercial-cache", legacyTag, common.ChannelStatusManuallyDisabled)
	commercial.Group = "default"
	commercial.Models = "commercial-model"
	require.NoError(t, db.Model(commercial).Updates(map[string]any{"group": commercial.Group, "models": commercial.Models}).Error)
	require.NoError(t, db.Exec("UPDATE channels SET status = ? WHERE id = ?", common.ChannelStatusEnabled, commercial.Id).Error)
	for _, candidate := range []struct {
		channel *Channel
		model   string
	}{
		{legacy, "legacy-model"},
		{commercial, "commercial-model"},
	} {
		require.NoError(t, db.Create(&Ability{Group: "default", Model: candidate.model, ChannelId: candidate.channel.Id, Enabled: true}).Error)
	}
	common.MemoryCacheEnabled = true
	InitChannelCache()

	channel, err := GetRandomSatisfiedChannel("default", "commercial-model", 0, "")
	require.NoError(t, err)
	require.Nil(t, channel)
}

func TestCommercialChannelSelectionUnsupportedPathFallsBackToLegacy(t *testing.T) {
	db := setupCommercialActivationRegressionDB(t)
	useCommercialChannelActivationState(t, true)
	highPriority := int64(100)
	lowPriority := int64(10)
	commercial := insertCommercialActivationRegressionChannel(t, db, "commercial-route", "route-selection", common.ChannelStatusEnabled)
	legacy := &Channel{
		Name: "legacy-route", Type: constant.ChannelTypeOpenAI, Status: common.ChannelStatusEnabled,
		Key: "legacy-key", Group: "default", Models: "gpt-5.4", Priority: &lowPriority,
	}
	require.NoError(t, db.Create(legacy).Error)
	require.NoError(t, db.Model(commercial).Updates(map[string]any{
		"status":   common.ChannelStatusEnabled,
		"group":    "default",
		"models":   "gpt-5.4",
		"priority": highPriority,
	}).Error)
	require.NoError(t, db.Create(&Ability{
		Group: "default", Model: "gpt-5.4", ChannelId: commercial.Id, Enabled: true, Priority: &highPriority,
	}).Error)
	require.NoError(t, db.Create(&Ability{
		Group: "default", Model: "gpt-5.4", ChannelId: legacy.Id, Enabled: true, Priority: &lowPriority,
	}).Error)

	for _, memoryCache := range []bool{false, true} {
		common.MemoryCacheEnabled = memoryCache
		if memoryCache {
			InitChannelCache()
		}
		selected, err := GetRandomSatisfiedChannel("default", "gpt-5.4", 0, "/v1/chat/completions")
		require.NoError(t, err)
		require.NotNil(t, selected)
		require.Equal(t, legacy.Id, selected.Id)

		selected, err = GetRandomSatisfiedChannel("default", "gpt-5.4", 0, "/v1/responses")
		require.NoError(t, err)
		require.NotNil(t, selected)
		require.Equal(t, commercial.Id, selected.Id)
	}
}

func TestCommercialChannelSelectionUnsupportedAdaptorFallsBackToCanonicalAdaptor(t *testing.T) {
	db := setupCommercialActivationRegressionDB(t)
	useCommercialChannelActivationState(t, true)
	highPriority := int64(100)
	lowPriority := int64(10)
	unsupported := insertCommercialActivationRegressionChannel(t, db, "commercial-gemini", "gemini-selection", common.ChannelStatusEnabled)
	supported := insertCommercialActivationRegressionChannel(t, db, "commercial-openai", "openai-selection", common.ChannelStatusEnabled)
	require.NoError(t, db.Model(unsupported).Updates(map[string]any{
		"type": constant.ChannelTypeGemini, "status": common.ChannelStatusEnabled,
		"group": "default", "models": "gpt-5.4", "priority": highPriority,
	}).Error)
	require.NoError(t, db.Model(supported).Updates(map[string]any{
		"status": common.ChannelStatusEnabled, "group": "default",
		"models": "gpt-5.4", "priority": lowPriority,
	}).Error)
	require.NoError(t, db.Create(&Ability{
		Group: "default", Model: "gpt-5.4", ChannelId: unsupported.Id, Enabled: true, Priority: &highPriority,
	}).Error)
	require.NoError(t, db.Create(&Ability{
		Group: "default", Model: "gpt-5.4", ChannelId: supported.Id, Enabled: true, Priority: &lowPriority,
	}).Error)

	for _, memoryCache := range []bool{false, true} {
		common.MemoryCacheEnabled = memoryCache
		if memoryCache {
			InitChannelCache()
		}
		selected, err := GetRandomSatisfiedChannel("default", "gpt-5.4", 0, "/v1/responses")
		require.NoError(t, err)
		require.NotNil(t, selected)
		require.Equal(t, supported.Id, selected.Id)
	}
}

func TestCommercialPromotionForcesDisabledStatus(t *testing.T) {
	db := setupCommercialActivationRegressionDB(t)
	legacy := &Channel{Name: "legacy-promotion", Type: constant.ChannelTypeOpenAI, Status: common.ChannelStatusEnabled, Key: "legacy-key"}
	require.NoError(t, db.Create(legacy).Error)
	secretRef := "env://UPSTREAM_PRIMARY_API_KEY"
	authType := "bearer"
	patch := &Channel{
		Id:                  legacy.Id,
		CommercialChannel:   true,
		BaseURL:             common.GetPointer("https://upstream.example.com"),
		SecretRef:           &secretRef,
		AuthType:            &authType,
		ReliabilityPolicyID: common.GetPointer(int64(11)),
		ActiveCostProfileID: common.GetPointer(int64(12)),
		ConfigVersion:       1,
	}
	require.NoError(t, db.Model(patch).Updates(patch).Error)
	var persisted struct {
		CommercialChannel bool
		Status            int
	}
	require.NoError(t, db.Raw("SELECT commercial_channel, status FROM channels WHERE id = ?", legacy.Id).Scan(&persisted).Error)
	require.True(t, persisted.CommercialChannel)
	require.NotEqual(t, common.ChannelStatusEnabled, persisted.Status)
}

func TestCommercialMigrationPreflightVerifiesDefinitionsAndRejectsAttachedLogicalResidue(t *testing.T) {
	source, err := os.ReadFile("channel_commercial_migration.go")
	require.NoError(t, err)
	text := string(source)
	require.Contains(t, text, "commercialVerifyLiveObject(ctx, conn, ownedObject)")
	require.Contains(t, text, "commercial migration found leftover logical index")
	require.Contains(t, text, "object.State == \"attached\"")
	require.Contains(t, text, `if hasLedger && !exists && owned.State != "planned" && owned.State != "rolled_back"`)
	require.NotContains(t, strings.ReplaceAll(text, " ", ""), "physicalName=object.ObjectName")
	require.Contains(t, text, "FOREIGN KEY (channel_id) REFERENCES public.channels(id) ON DELETE RESTRICT NOT VALID")
	require.Contains(t, text, "FOREIGN KEY (cost_profile_id) REFERENCES public.channel_cost_profiles(id) ON DELETE RESTRICT NOT VALID")
	require.Contains(t, text, "FOREIGN KEY (id, active_cost_profile_id) REFERENCES public.channel_cost_profiles(channel_id, id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED NOT VALID")
	require.Contains(t, text, "expectedValidated := expected.Type == \"u\" || object.Validated")
}

func TestCommercialChannelFoundationUsesContractByteBounds(t *testing.T) {
	contract := CommercialChannelFoundationSQL()
	require.Contains(t, contract, "max_precommit_buffer_bytes BETWEEN 1 AND 1048576")
	require.Contains(t, contract, "max_stream_bytes BETWEEN 1 AND 8388608")
	require.Contains(t, contract, "max_response_bytes BETWEEN 1 AND 8388608")
	require.NotContains(t, contract, "max_precommit_buffer_bytes BETWEEN 1 AND 10000")
	require.NotContains(t, contract, "max_stream_bytes BETWEEN 1 AND 10000")
	require.NotContains(t, contract, "max_response_bytes BETWEEN 1 AND 10000")
}

func TestCommercialAuthCheckRejectsNullAuthType(t *testing.T) {
	db, err := gorm.Open(sqlite.Open("file:commercial_auth_null_guard?mode=memory&cache=shared"), &gorm.Config{})
	require.NoError(t, err)
	require.NoError(t, db.Exec(`CREATE TABLE commercial_auth_guard (
  commercial_channel BOOLEAN NOT NULL,
  auth_type TEXT NULL,
  CHECK (commercial_channel IS NOT TRUE OR (auth_type IS NOT NULL AND auth_type IN ('bearer', 'fixed-header')))
)`).Error)
	require.Error(t, db.Exec("INSERT INTO commercial_auth_guard (commercial_channel, auth_type) VALUES (?, ?)", true, nil).Error)
	require.NoError(t, db.Exec("INSERT INTO commercial_auth_guard (commercial_channel, auth_type) VALUES (?, ?)", false, nil).Error)

	contract := CommercialChannelFoundationSQL()
	require.Contains(t, contract, "auth_type IS NOT NULL AND auth_type IN ('bearer', 'fixed-header')")
}
