package controller

import (
	"context"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"net/http"
	"net/url"
	"sort"
	"strconv"
	"strings"
	"time"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/logger"
	"github.com/QuantumNous/new-api/middleware"
	"github.com/QuantumNous/new-api/model"
	"github.com/QuantumNous/new-api/service"
	"github.com/QuantumNous/new-api/setting/system_setting"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

// The Telegram widget protocol (data-telegram-login) signs the user assertion with
// the bot token and works with a plain BotFather domain registration. The OIDC
// authorization-code flow additionally requires the exact redirect URI in
// BotFather's Allowed URLs, which the operator could not register. Vantyr
// therefore serves the widget protocol for login and bind.

const (
	// The widget has no nonce. Keep its signed assertion short-lived so captured
	// callbacks cannot be reused indefinitely.
	telegramAuthorizationMaxAge     = 5 * time.Minute
	telegramAuthorizationFutureSkew = 2 * time.Minute
	telegramBindFlowTTL             = 5 * time.Minute

	telegramBindErrorDisabled       = "TELEGRAM_BIND_DISABLED"
	telegramBindErrorInvalidRequest = "TELEGRAM_BIND_INVALID_REQUEST"
	telegramBindErrorFlowInvalid    = "TELEGRAM_BIND_FLOW_INVALID"
	telegramBindErrorSessionInvalid = "TELEGRAM_BIND_SESSION_INVALID"
	telegramBindErrorAlreadyBound   = "TELEGRAM_BIND_ALREADY_BOUND"
	telegramBindErrorUserDeleted    = "TELEGRAM_BIND_USER_DELETED"
	telegramBindErrorUserDisabled   = "TELEGRAM_BIND_USER_DISABLED"
	telegramBindErrorInternal       = "TELEGRAM_BIND_INTERNAL_ERROR"
)

var (
	errTelegramAccountAlreadyBound  = errors.New("telegram account is already bound")
	errTelegramBindAssertionInvalid = errors.New("telegram bind assertion is invalid")
	errTelegramBindUserDeleted      = errors.New("telegram bind user was deleted")
	errTelegramBindUserDisabled     = errors.New("telegram bind user was disabled")
)

func telegramWidgetBotToken() string {
	return strings.TrimSpace(system_setting.GetTelegramSettings().ClientSecret)
}

// telegramTrialGroupChatID returns the configured membership-gate group, or ""
// when the gate is disabled.
func telegramTrialGroupChatID() string {
	return strings.TrimSpace(system_setting.GetTelegramSettings().TrialGroupChatID)
}

// isTelegramGroupMember reports whether the Telegram account is a member of
// the trial-gate group, using the bot's API. The call fails closed for the
// credit: on any API error (bot kicked, network, Telegram outage) the trial
// is simply not granted now — the user can retry on their next Telegram
// login, so a transient failure never permanently denies the credit. It must
// never block login or registration, which proceed regardless of the answer.
func isTelegramGroupMember(telegramID string) bool {
	chatID := telegramTrialGroupChatID()
	if chatID == "" || telegramID == "" {
		return false
	}
	// The bot token is the full "<bot id>:<hash>" used by the widget HMAC;
	// getChatMember requires the bot to be a member of the group (privacy
	// mode does not matter for it).
	token := telegramWidgetBotToken()
	if token == "" {
		return false
	}
	userID, err := strconv.ParseInt(telegramID, 10, 64)
	if err != nil {
		return false
	}
	request, err := http.NewRequestWithContext(context.Background(), http.MethodGet,
		"https://api.telegram.org/bot"+token+"/getChatMember", nil)
	if err != nil {
		return false
	}
	query := request.URL.Query()
	query.Set("chat_id", chatID)
	query.Set("user_id", strconv.FormatInt(userID, 10))
	request.URL.RawQuery = query.Encode()
	response, err := telegramBotHTTPClient.Do(request)
	if err != nil {
		common.SysLog("telegram group membership check failed: " + err.Error())
		return false
	}
	defer response.Body.Close()
	var body struct {
		OK     bool `json:"ok"`
		Result struct {
			Status string `json:"status"`
		} `json:"result"`
	}
	if err := common.DecodeJson(response.Body, &body); err != nil {
		common.SysLog("telegram group membership check decode failed: " + err.Error())
		return false
	}
	if !body.OK {
		// A "left"/"kicked" user is a definitive answer, not an error.
		return false
	}
	switch body.Result.Status {
	case "creator", "administrator", "member", "restricted":
		return true
	default:
		// "left" and "kicked" are not members.
		return false
	}
}

var telegramBotHTTPClient = &http.Client{Timeout: 10 * time.Second}

func TelegramBindStart(c *gin.Context) {
	if !common.TelegramOAuthEnabled {
		c.JSON(http.StatusOK, gin.H{
			"message": "管理员未开启通过 Telegram 登录以及注册",
			"success": false,
		})
		return
	}
	identity, ok := middleware.GetSessionAuthIdentity(c)
	if !ok {
		c.JSON(http.StatusUnauthorized, gin.H{"success": false, "message": "未登录"})
		return
	}
	expiresAt := time.Now().Add(telegramBindFlowTTL)
	flowToken, _, err := model.CreateAuthFlow(model.AuthFlowCreate{
		Purpose:   model.AuthFlowPurposeTelegramBind,
		UserId:    identity.UserID,
		SessionId: identity.SessionID,
		ExpiresAt: expiresAt,
	})
	if err != nil {
		common.ApiError(c, err)
		return
	}
	callbackURL := "/api/oauth/telegram/bind/" + flowToken
	c.JSON(http.StatusOK, gin.H{
		"success": true,
		"message": "",
		"data": gin.H{
			"flow_token":   flowToken,
			"callback_url": callbackURL,
			"expires_at":   expiresAt.Unix(),
		},
	})
}

func TelegramBind(c *gin.Context) {
	if !common.TelegramOAuthEnabled {
		telegramBindFailure(c, telegramBindErrorDisabled)
		return
	}
	params := c.Request.URL.Query()
	telegramId, err := verifyTelegramAuthorization(params, telegramWidgetBotToken(), time.Now())
	if err != nil {
		common.SysLog("TelegramBind authorization failed: " + err.Error())
		telegramBindFailure(c, telegramBindErrorInvalidRequest)
		return
	}
	pendingFlow, err := model.GetAuthFlow(c.Param("flow_token"), model.AuthFlowMatch{
		Purpose: model.AuthFlowPurposeTelegramBind,
	})
	if err != nil {
		if !errors.Is(err, model.ErrAuthFlowInvalid) &&
			!errors.Is(err, model.ErrAuthFlowExpired) &&
			!errors.Is(err, model.ErrAuthFlowConsumed) {
			common.SysError("TelegramBind flow lookup failed: " + err.Error())
			telegramBindFailure(c, telegramBindErrorInternal)
			return
		}
		telegramBindFailure(c, telegramBindErrorFlowInvalid)
		return
	}
	identity, ok := middleware.GetSessionAuthIdentity(c)
	if !ok || identity.UserID != pendingFlow.UserId || identity.SessionID != pendingFlow.SessionId {
		if !ok {
			identity = service.AuthIdentity{}
		}
		if _, err := service.ValidateSessionReference(pendingFlow.UserId, pendingFlow.SessionId); err != nil {
			if !errors.Is(err, service.ErrLoginSessionInvalid) &&
				!errors.Is(err, service.ErrLoginSessionRevoked) &&
				!errors.Is(err, model.ErrUserSessionInactive) &&
				!errors.Is(err, gorm.ErrRecordNotFound) {
				common.SysError("TelegramBind session validation failed: " + err.Error())
				telegramBindFailure(c, telegramBindErrorInternal)
				return
			}

			var user model.User
			userErr := model.DB.First(&user, pendingFlow.UserId).Error
			switch {
			case errors.Is(userErr, gorm.ErrRecordNotFound):
				telegramBindFailure(c, telegramBindErrorUserDeleted)
			case userErr != nil:
				common.SysError("TelegramBind user status lookup failed: " + userErr.Error())
				telegramBindFailure(c, telegramBindErrorInternal)
			case user.Status != common.UserStatusEnabled:
				telegramBindFailure(c, telegramBindErrorUserDisabled)
			default:
				telegramBindFailure(c, telegramBindErrorSessionInvalid)
			}
			return
		}
	}
	assertion, assertionExpiresAt, err := telegramAuthorizationClaim(params, time.Now())
	if err != nil {
		common.SysLog("TelegramBind authorization claim failed: " + err.Error())
		telegramBindFailure(c, telegramBindErrorInvalidRequest)
		return
	}
	_, err = model.ConsumeAuthFlowWithAction(c.Param("flow_token"), model.AuthFlowMatch{
		Purpose:   model.AuthFlowPurposeTelegramBind,
		UserId:    pendingFlow.UserId,
		SessionId: pendingFlow.SessionId,
	}, func(tx *gorm.DB, flow *model.AuthFlow) error {
		if err := model.ClaimExternalAuthAssertionWithTx(tx, model.AuthFlowPurposeTelegramAssertion, assertion, assertionExpiresAt); err != nil {
			if errors.Is(err, model.ErrAuthFlowInvalid) || errors.Is(err, model.ErrAuthFlowConsumed) {
				return errors.Join(errTelegramBindAssertionInvalid, err)
			}
			return err
		}

		var user model.User
		if err := tx.First(&user, flow.UserId).Error; err != nil {
			if errors.Is(err, gorm.ErrRecordNotFound) {
				return errTelegramBindUserDeleted
			}
			return err
		}
		if user.Status != common.UserStatusEnabled {
			return errTelegramBindUserDisabled
		}

		var session model.UserSession
		if err := tx.Where("sid = ? AND user_id = ?", flow.SessionId, flow.UserId).First(&session).Error; err != nil {
			if errors.Is(err, gorm.ErrRecordNotFound) {
				return service.ErrLoginSessionRevoked
			}
			return err
		}
		if session.Status != model.UserSessionStatusActive || session.RevokedAt != 0 || session.ExpiresAt <= time.Now().Unix() {
			return service.ErrLoginSessionRevoked
		}
		if session.UserAuthVersion != user.AuthVersion {
			return service.ErrLoginSessionRevoked
		}
		if user.TelegramId != "" {
			return errTelegramAccountAlreadyBound
		}
		bindIdentity := model.AuthSessionIdentity{
			UserID:          flow.UserId,
			SessionID:       flow.SessionId,
			UserAuthVersion: user.AuthVersion,
			SessionVersion:  session.Version,
		}
		// Vantyr: bind only links the identity. The $5 trial is granted on
		// Telegram login once group membership is confirmed, so a user who
		// binds here and joins the group later still gets it on next login.
		if err := model.BindTelegramForSessionWithTx(tx, bindIdentity, telegramId); err != nil {
			if errors.Is(err, model.ErrExternalIdentityAlreadyClaimed) {
				return errTelegramAccountAlreadyBound
			}
			return err
		}
		return nil
	})
	if err != nil {
		switch {
		case errors.Is(err, errTelegramBindAssertionInvalid):
			telegramBindFailure(c, telegramBindErrorInvalidRequest)
		case errors.Is(err, errTelegramAccountAlreadyBound):
			telegramBindFailure(c, telegramBindErrorAlreadyBound)
		case errors.Is(err, errTelegramBindUserDeleted):
			telegramBindFailure(c, telegramBindErrorUserDeleted)
		case errors.Is(err, errTelegramBindUserDisabled):
			telegramBindFailure(c, telegramBindErrorUserDisabled)
		case errors.Is(err, service.ErrLoginSessionRevoked):
			telegramBindFailure(c, telegramBindErrorSessionInvalid)
		case errors.Is(err, model.ErrAuthFlowInvalid), errors.Is(err, model.ErrAuthFlowExpired), errors.Is(err, model.ErrAuthFlowConsumed):
			telegramBindFailure(c, telegramBindErrorFlowInvalid)
		default:
			common.SysError("TelegramBind failed: " + err.Error())
			telegramBindFailure(c, telegramBindErrorInternal)
		}
		return
	}

	callback := "/oauth/telegram?telegram_bind=success&flow_token=" + url.QueryEscape(c.Param("flow_token"))
	c.Redirect(http.StatusFound, callback)
}

func telegramBindFailure(c *gin.Context, errorCode string) {
	query := url.Values{
		"telegram_bind": {"error"},
		"flow_token":    {c.Param("flow_token")},
		"error_code":    {errorCode},
	}
	c.Redirect(http.StatusFound, "/oauth/telegram?"+query.Encode())
}

func TelegramLogin(c *gin.Context) {
	if !common.TelegramOAuthEnabled {
		c.JSON(200, gin.H{
			"message": "管理员未开启通过 Telegram 登录以及注册",
			"success": false,
		})
		return
	}
	params := c.Request.URL.Query()
	telegramId, err := verifyTelegramAuthorization(params, telegramWidgetBotToken(), time.Now())
	if err != nil {
		common.SysLog("TelegramLogin authorization failed: " + err.Error())
		c.JSON(200, gin.H{
			"message": "无效的请求",
			"success": false,
		})
		return
	}

	user := model.User{TelegramId: telegramId}
	stored, err := model.GetUserByTelegramID(telegramId)
	if err != nil {
		// Vantyr: an unknown Telegram account registers directly from the
		// verified widget assertion, mirroring OAuth registration. The
		// assertion claim runs inside the creation transaction, so a replayed
		// callback can never create two accounts.
		if !errors.Is(err, gorm.ErrRecordNotFound) {
			c.JSON(200, gin.H{
				"message": err.Error(),
				"success": false,
			})
			return
		}
		if !common.RegisterEnabled {
			c.JSON(200, gin.H{
				"message": "该 Telegram 账户未绑定",
				"success": false,
			})
			return
		}
		created, err := createTelegramLoginUser(params, telegramId, c)
		if err != nil {
			common.SysError("TelegramLogin registration failed: " + err.Error())
			c.JSON(200, gin.H{
				"message": "注册失败，请稍后重试",
				"success": false,
			})
			return
		}
		user = *created
	} else {
		user = *stored
		if err := claimTelegramAuthorization(params, time.Now()); err != nil {
			common.SysLog("TelegramLogin assertion replay rejected: " + err.Error())
			c.JSON(http.StatusForbidden, gin.H{
				"message": "该登录凭据已被使用",
				"success": false,
			})
			return
		}
	}
	// Vantyr: the $5 trial is granted on verified Telegram login when the
	// account is a member of the configured group (and not yet credited).
	// A transient membership-check failure or a not-yet-joined user simply
	// gets no credit now and can retry on the next login; login itself
	// proceeds regardless.
	if common.QuotaForNewUser > 0 {
		if credit := grantTelegramTrialOnLogin(telegramId, user.Id); credit > 0 {
			model.SyncCreditUserQuotaCache(user.Id, credit, "telegram verification")
			model.RecordLog(user.Id, model.LogTypeSystem,
				fmt.Sprintf("Telegram 验证赠送 %s", logger.LogQuota(credit)))
		}
	}
	setupLogin(&user, nil, c)
}

// grantTelegramTrialOnLogin checks group membership (bot API) and pays the
// one-per-user trial in its own short transaction.
func grantTelegramTrialOnLogin(telegramId string, userId int) int {
	if !telegramGroupMembershipCheck(telegramId) {
		return 0
	}
	var credit int
	if err := model.DB.Transaction(func(tx *gorm.DB) error {
		var err error
		credit, err = model.GrantTelegramTrialWithTx(tx, userId)
		return err
	}); err != nil {
		common.SysError("telegram trial grant failed: " + err.Error())
		return 0
	}
	return credit
}

// telegramGroupMembershipCheck is the seam tests use to pin the bot-API answer.
var telegramGroupMembershipCheck = isTelegramGroupMember

// createTelegramLoginUser resolves the inviter from the affiliate header and
// registers the Telegram account in one transaction with the assertion claim
// and the identity claim. The trial credit is granted by
// grantTelegramTrialOnLogin after the user row exists (membership first).
// It returns the created user for the login flow.
func createTelegramLoginUser(params url.Values, telegramId string, c *gin.Context) (*model.User, error) {
	// The widget signature covers the URL query, so the affiliate code travels
	// in a header instead — it is referral attribution chosen by the client,
	// not part of the Telegram assertion.
	affCode := strings.TrimSpace(c.GetHeader("X-Affiliate-Code"))
	if len(affCode) > 32 {
		affCode = ""
	}
	inviterId := 0
	if affCode != "" {
		inviterId, _ = model.GetUserIdByAffCode(affCode)
	}

	username := ""
	if widgetUsername := strings.TrimSpace(params.Get("username")); widgetUsername != "" &&
		len(widgetUsername) <= model.UserNameMaxLength {
		if exists, err := model.CheckUserExistOrDeleted(widgetUsername, ""); err == nil && !exists {
			username = widgetUsername
		}
	}
	if username == "" {
		username = "telegram_" + strconv.Itoa(model.GetMaxUserId()+1)
	}
	displayName := strings.TrimSpace(params.Get("first_name"))
	if lastName := strings.TrimSpace(params.Get("last_name")); lastName != "" {
		displayName = strings.TrimSpace(displayName + " " + lastName)
	}
	if displayName == "" {
		displayName = username
	}
	if len(displayName) > model.UserNameMaxLength {
		displayName = displayName[:model.UserNameMaxLength]
	}

	assertion, assertionExpiresAt, err := telegramAuthorizationClaim(params, time.Now())
	if err != nil {
		return nil, err
	}
	var user *model.User
	err = model.DB.Transaction(func(tx *gorm.DB) error {
		if err := model.ClaimExternalAuthAssertionWithTx(tx, model.AuthFlowPurposeTelegramAssertion, assertion, assertionExpiresAt); err != nil {
			return err
		}
		var err error
		user, _, err = model.CreateTelegramUserWithTx(tx, telegramId, username, displayName, inviterId, false)
		return err
	})
	if err != nil {
		return nil, err
	}
	// Inviter reward and sidebar config run post-commit, as for other OAuth
	// registrations. It is compliance- and option-gated inside.
	user.FinalizeOAuthUserCreation(inviterId)
	return user, nil
}

func claimTelegramAuthorization(params url.Values, now time.Time) error {
	assertion, expiresAt, err := telegramAuthorizationClaim(params, now)
	if err != nil {
		return err
	}
	return model.ClaimExternalAuthAssertion(model.AuthFlowPurposeTelegramAssertion, assertion, expiresAt)
}

func telegramAuthorizationClaim(params url.Values, now time.Time) (string, time.Time, error) {
	authDate, err := strconv.ParseInt(params.Get("auth_date"), 10, 64)
	if err != nil {
		return "", time.Time{}, errors.New("telegram authorization date is invalid")
	}
	hashBytes, err := hex.DecodeString(params.Get("hash"))
	if err != nil {
		return "", time.Time{}, errors.New("telegram authorization signature is invalid")
	}
	expiresAt := time.Unix(authDate, 0).Add(telegramAuthorizationMaxAge)
	if !expiresAt.After(now) {
		return "", time.Time{}, errors.New("telegram authorization has expired")
	}
	return hex.EncodeToString(hashBytes), expiresAt, nil
}

func verifyTelegramAuthorization(params url.Values, token string, now time.Time) (string, error) {
	if token == "" {
		return "", errors.New("telegram bot token is empty")
	}
	for _, values := range params {
		if len(values) != 1 {
			return "", errors.New("telegram authorization contains duplicate parameters")
		}
	}

	telegramID := params.Get("id")
	hash := params.Get("hash")
	authDateText := params.Get("auth_date")
	if telegramID == "" || hash == "" || authDateText == "" {
		return "", errors.New("telegram authorization is incomplete")
	}
	authDate, err := strconv.ParseInt(authDateText, 10, 64)
	if err != nil {
		return "", errors.New("telegram authorization date is invalid")
	}
	if authDate < now.Add(-telegramAuthorizationMaxAge).Unix() ||
		authDate > now.Add(telegramAuthorizationFutureSkew).Unix() {
		return "", errors.New("telegram authorization has expired")
	}

	strs := make([]string, 0, len(params)-1)
	for k, v := range params {
		if k == "hash" {
			continue
		}
		strs = append(strs, k+"="+v[0])
	}
	sort.Strings(strs)
	secret := sha256.Sum256([]byte(token))
	mac := hmac.New(sha256.New, secret[:])
	_, _ = mac.Write([]byte(strings.Join(strs, "\n")))
	providedHash, err := hex.DecodeString(hash)
	if err != nil || !hmac.Equal(providedHash, mac.Sum(nil)) {
		return "", errors.New("telegram authorization signature is invalid")
	}

	return telegramID, nil
}
